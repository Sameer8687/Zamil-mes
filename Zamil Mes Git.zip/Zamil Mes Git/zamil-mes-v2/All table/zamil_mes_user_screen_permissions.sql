-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: zamil_mes
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user_screen_permissions`
--

DROP TABLE IF EXISTS `user_screen_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_screen_permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` char(36) NOT NULL,
  `screen_id` bigint unsigned NOT NULL,
  `can_view` tinyint(1) NOT NULL DEFAULT '0',
  `can_create` tinyint(1) NOT NULL DEFAULT '0',
  `can_edit` tinyint(1) NOT NULL DEFAULT '0',
  `can_delete` tinyint(1) NOT NULL DEFAULT '0',
  `can_export` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=346 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_screen_permissions`
--

LOCK TABLES `user_screen_permissions` WRITE;
/*!40000 ALTER TABLE `user_screen_permissions` DISABLE KEYS */;
INSERT INTO `user_screen_permissions` VALUES (1,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',1,1,1,1,1,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(2,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',2,1,1,1,1,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(3,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',3,1,1,1,1,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(4,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',4,1,1,1,1,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(5,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',5,1,1,1,1,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(6,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',6,1,1,1,1,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(7,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',7,1,1,1,1,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(8,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',8,1,1,1,1,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(9,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',9,1,1,1,1,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(10,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',10,1,1,1,1,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(11,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',11,1,1,1,1,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(12,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',12,1,1,1,1,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(13,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',13,1,1,1,1,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(14,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',14,1,1,1,1,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(15,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',15,1,1,1,1,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(331,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',1,0,0,0,0,0,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(332,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',2,0,0,0,0,0,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(333,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',3,1,0,0,0,0,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(334,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',4,0,0,0,0,0,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(335,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',5,0,0,0,0,0,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(336,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',6,0,0,0,0,0,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(337,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',7,0,0,0,0,0,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(338,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',8,0,0,0,0,0,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(339,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',9,0,0,0,0,0,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(340,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',10,0,0,0,0,0,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(341,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',11,0,0,0,0,0,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(342,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',12,0,0,0,0,0,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(343,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',13,0,0,0,0,0,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(344,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',14,0,0,0,0,0,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(345,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',15,0,0,0,0,0,'2026-06-04 05:33:03','2026-06-04 05:33:03');
/*!40000 ALTER TABLE `user_screen_permissions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-04 12:36:17
