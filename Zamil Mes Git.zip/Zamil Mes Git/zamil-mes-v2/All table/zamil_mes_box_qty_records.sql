-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: zamil_mes
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `box_qty_records`
--

DROP TABLE IF EXISTS `box_qty_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `box_qty_records` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `org` varchar(50) NOT NULL,
  `productCode` varchar(50) NOT NULL,
  `productDesc` varchar(200) DEFAULT NULL,
  `qtyPerBox` int DEFAULT '0',
  `effectiveDate` date DEFAULT NULL,
  `createdBy` varchar(100) DEFAULT NULL,
  `updatedBy` varchar(100) DEFAULT NULL,
  `isActive` tinyint(1) DEFAULT '1',
  `isDeleted` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `box_qty_records`
--

LOCK TABLES `box_qty_records` WRITE;
/*!40000 ALTER TABLE `box_qty_records` DISABLE KEYS */;
INSERT INTO `box_qty_records` VALUES ('473e2265-23f2-46ec-b984-0249c6c01b8f','ZPC BU','ZPC-CC','Closure Cap',5000,'2026-01-01',NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30'),('5f794453-ed92-4231-ad29-21d616eced4b','FPP BU','FG7722','PP Granule 3kg',2700,'2026-01-01',NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30'),('67947926-f420-444d-99cc-ce2be84b147d','IPP BU','FG6601','LDPE Bag 1kg',1200,'2026-01-01',NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30'),('6eb7c56e-b304-48ae-9eea-e0f64fc3641c','FPP BU','sedf','asdf',2,'2026-06-01',NULL,NULL,1,1,'2026-06-01 13:40:37','2026-06-01 13:40:51'),('7b4b508d-ce6a-4dba-b98e-19dcbf95d4aa','FPP BU','FG8820','HDPE Bottle 1L',1800,'2026-01-01',NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30'),('acfc8aaf-df97-46fc-b31b-28e14069a0c7','FPP BU','lojm','guyk',752,'2026-06-02',NULL,NULL,1,1,'2026-06-02 11:56:20','2026-06-02 11:56:34'),('b0f2fc1a-0d7b-40b9-89db-a86347cca610','IPP BU','FG7701','PET Jar 500ml',3000,'2026-01-01',NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30'),('b238aa9f-e4bc-47f8-9d6f-6f0dde71bb2d','FPP BU','FG9406','PP Cap 28mm',2400,'2026-01-01',NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30'),('c3dd3a0e-5920-4ba9-a16a-c8c7fe2deb96','FPP BU','asdf','asdf',541,'2026-06-01',NULL,NULL,1,1,'2026-06-01 13:40:37','2026-06-01 13:41:07');
/*!40000 ALTER TABLE `box_qty_records` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-04 12:36:15
