-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: zamil_mes
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `locations` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `code` varchar(50) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `type` varchar(20) DEFAULT NULL,
  `plant` varchar(20) DEFAULT NULL,
  `createdBy` varchar(100) DEFAULT NULL,
  `updatedBy` varchar(100) DEFAULT NULL,
  `isActive` tinyint(1) DEFAULT '1',
  `isDeleted` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `division` varchar(20) DEFAULT NULL,
  `area` varchar(100) DEFAULT NULL,
  `section` varchar(100) DEFAULT NULL,
  `level` varchar(20) DEFAULT 'L1',
  `locator` varchar(50) DEFAULT NULL,
  `barcode` varchar(80) DEFAULT NULL,
  `locType` varchar(30) DEFAULT 'FLOOR',
  `status` varchar(20) DEFAULT 'Active',
  `minUnits` int DEFAULT '0',
  `maxUnits` int DEFAULT '0',
  `maxLPN` int DEFAULT '9',
  `usedLPN` int DEFAULT '0',
  `uom` varchar(20) DEFAULT 'BOX',
  `multiSKU` varchar(5) DEFAULT 'Yes',
  `partialPick` varchar(5) DEFAULT 'Yes',
  `specificSKU` varchar(80) DEFAULT NULL,
  `maxWeight` decimal(12,2) DEFAULT '2000.00',
  `owner` varchar(50) DEFAULT NULL,
  `authUsers` json DEFAULT NULL,
  `accessRestriction` varchar(30) DEFAULT 'AuthList',
  `notes` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  UNIQUE KEY `code_2` (`code`),
  UNIQUE KEY `code_3` (`code`),
  UNIQUE KEY `code_4` (`code`),
  UNIQUE KEY `code_5` (`code`),
  UNIQUE KEY `code_6` (`code`),
  UNIQUE KEY `code_7` (`code`),
  UNIQUE KEY `code_8` (`code`),
  UNIQUE KEY `code_9` (`code`),
  UNIQUE KEY `code_10` (`code`),
  UNIQUE KEY `code_11` (`code`),
  UNIQUE KEY `code_12` (`code`),
  UNIQUE KEY `code_13` (`code`),
  UNIQUE KEY `code_14` (`code`),
  UNIQUE KEY `code_15` (`code`),
  UNIQUE KEY `code_16` (`code`),
  UNIQUE KEY `code_17` (`code`),
  UNIQUE KEY `code_18` (`code`),
  UNIQUE KEY `code_19` (`code`),
  UNIQUE KEY `code_20` (`code`),
  UNIQUE KEY `code_21` (`code`),
  UNIQUE KEY `code_22` (`code`),
  UNIQUE KEY `code_23` (`code`),
  UNIQUE KEY `code_24` (`code`),
  UNIQUE KEY `locator` (`locator`),
  UNIQUE KEY `barcode` (`barcode`),
  UNIQUE KEY `code_25` (`code`),
  UNIQUE KEY `code_26` (`code`),
  UNIQUE KEY `locator_2` (`locator`),
  UNIQUE KEY `barcode_2` (`barcode`),
  UNIQUE KEY `code_27` (`code`),
  UNIQUE KEY `locator_3` (`locator`),
  UNIQUE KEY `barcode_3` (`barcode`),
  UNIQUE KEY `code_28` (`code`),
  UNIQUE KEY `locator_4` (`locator`),
  UNIQUE KEY `barcode_4` (`barcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` VALUES ('0d935539-e71b-4374-94fa-d157f0b17e4c','SCRAP-01','Scrap Yard Zone A','scrap','FPP BU',NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30',NULL,NULL,NULL,'L1',NULL,NULL,'FLOOR','Active',0,0,9,0,'BOX','Yes','Yes',NULL,2000.00,NULL,NULL,'AuthList',NULL),('66ee3f60-1b47-4834-873a-22ad5824f56c','FPP-STG-01','FPP Staging Area 1','staging','FPP BU',NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30',NULL,NULL,NULL,'L1',NULL,NULL,'FLOOR','Active',0,0,9,0,'BOX','Yes','Yes',NULL,2000.00,NULL,NULL,'AuthList',NULL),('a61b5b60-90ee-4c89-963a-d1896ab2056e','IPP-WH-01','IPP Warehouse Main','warehouse','IPP BU',NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30',NULL,NULL,NULL,'L1',NULL,NULL,'FLOOR','Active',0,0,9,0,'BOX','Yes','Yes',NULL,2000.00,NULL,NULL,'AuthList',NULL),('bac0a418-e2b6-450f-bfe3-a51724436561','FPP-WH-03','FPP Warehouse Bay 3','warehouse','FPP BU',NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30',NULL,NULL,NULL,'L1',NULL,NULL,'FLOOR','Active',0,0,9,0,'BOX','Yes','Yes',NULL,2000.00,NULL,NULL,'AuthList',NULL),('c9fbe69a-a91f-44c5-896e-08559fa917bf','IPP-WH-02','IPP Warehouse Bay 2','warehouse','IPP BU',NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30',NULL,NULL,NULL,'L1',NULL,NULL,'FLOOR','Active',0,0,9,0,'BOX','Yes','Yes',NULL,2000.00,NULL,NULL,'AuthList',NULL),('dfe52b84-84f3-4f11-8825-05d7059f5e46','FPP-WH-02','FPP Warehouse Bay 2','warehouse','FPP BU',NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30',NULL,NULL,NULL,'L1',NULL,NULL,'FLOOR','Active',0,0,9,0,'BOX','Yes','Yes',NULL,2000.00,NULL,NULL,'AuthList',NULL),('e526905c-1127-48a1-b01b-423a91545930','FPP-WH-01','FPP Warehouse Bay 1','warehouse','FPP BU',NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30',NULL,NULL,NULL,'L1',NULL,NULL,'FLOOR','Active',0,0,9,0,'BOX','Yes','Yes',NULL,2000.00,NULL,NULL,'AuthList',NULL),('fa9b473b-9372-4539-9a7d-421375b59337','ZPC-WH-01','ZPC Warehouse Main','warehouse','ZPC BU',NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30',NULL,NULL,NULL,'L1',NULL,NULL,'FLOOR','Active',0,0,9,0,'BOX','Yes','Yes',NULL,2000.00,NULL,NULL,'AuthList',NULL);
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-04 12:36:16
