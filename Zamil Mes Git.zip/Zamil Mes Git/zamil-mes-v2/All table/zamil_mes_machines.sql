-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: zamil_mes
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `machines`
--

DROP TABLE IF EXISTS `machines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `machines` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `code` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` varchar(50) DEFAULT NULL,
  `plant` varchar(100) DEFAULT NULL,
  `dept` varchar(100) DEFAULT NULL,
  `area` varchar(100) DEFAULT NULL,
  `locator` varchar(50) DEFAULT NULL,
  `oem` varchar(100) DEFAULT NULL,
  `model` varchar(100) DEFAULT NULL,
  `serial` varchar(100) DEFAULT NULL,
  `tonnage` varchar(30) DEFAULT NULL,
  `cycleTime` decimal(10,2) DEFAULT NULL,
  `cavities` int DEFAULT NULL,
  `ip` varchar(50) DEFAULT NULL,
  `plcType` varchar(50) DEFAULT NULL,
  `commProtocol` varchar(50) DEFAULT NULL,
  `mesCode` varchar(50) DEFAULT NULL,
  `pmFreq` varchar(50) DEFAULT NULL,
  `lastPmDate` date DEFAULT NULL,
  `status` enum('running','idle','maintenance','breakdown') DEFAULT 'idle',
  `specs` json DEFAULT NULL,
  `createdBy` varchar(100) DEFAULT NULL,
  `updatedBy` varchar(100) DEFAULT NULL,
  `isActive` tinyint(1) DEFAULT '1',
  `isDeleted` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  UNIQUE KEY `code_2` (`code`),
  UNIQUE KEY `code_3` (`code`),
  UNIQUE KEY `code_4` (`code`),
  UNIQUE KEY `code_5` (`code`),
  UNIQUE KEY `code_6` (`code`),
  UNIQUE KEY `code_7` (`code`),
  UNIQUE KEY `code_8` (`code`),
  UNIQUE KEY `code_9` (`code`),
  UNIQUE KEY `code_10` (`code`),
  UNIQUE KEY `code_11` (`code`),
  UNIQUE KEY `code_12` (`code`),
  UNIQUE KEY `code_13` (`code`),
  UNIQUE KEY `code_14` (`code`),
  UNIQUE KEY `code_15` (`code`),
  UNIQUE KEY `code_16` (`code`),
  UNIQUE KEY `code_17` (`code`),
  UNIQUE KEY `code_18` (`code`),
  UNIQUE KEY `code_19` (`code`),
  UNIQUE KEY `code_20` (`code`),
  UNIQUE KEY `code_21` (`code`),
  UNIQUE KEY `code_22` (`code`),
  UNIQUE KEY `code_23` (`code`),
  UNIQUE KEY `code_24` (`code`),
  UNIQUE KEY `code_25` (`code`),
  UNIQUE KEY `code_26` (`code`),
  UNIQUE KEY `code_27` (`code`),
  UNIQUE KEY `code_28` (`code`),
  UNIQUE KEY `code_29` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `machines`
--

LOCK TABLES `machines` WRITE;
/*!40000 ALTER TABLE `machines` DISABLE KEYS */;
INSERT INTO `machines` VALUES ('1d84cb0c-03b2-4376-be64-0636d05ad8a7','ZFP-01','ZFP 01 – Film Press','Film Press','FPP','BLOWMOLDIN',NULL,NULL,'BMB','SB-600','SN001','600T',28.00,4,'192.168.1.10',NULL,NULL,'MES-ZFP-01','Monthly',NULL,'running','{}',NULL,NULL,1,0,'2026-06-01 06:46:29','2026-06-01 06:46:29'),('3c3ee371-889a-47a1-a688-8d161896295e','INJ-106','INJ-106 – Injection 500T','Injection','IPP','INJECTION',NULL,NULL,'TOYO','SI500','SN106','500T',35.00,16,'192.168.1.106',NULL,NULL,'MES-INJ-106','Monthly',NULL,'running','{}',NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30'),('42e54abb-e651-4848-8063-163ec571007f','INJ-077','INJ-077 – Injection 280T','Injection','IPP','INJECTION',NULL,NULL,'JSW','J280','SN077','280T',22.00,4,'192.168.1.77',NULL,NULL,'MES-INJ-077','Monthly',NULL,'maintenance','{}',NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30'),('4e15554d-666d-4528-a56e-c22824175652','INJ-103','INJ-103 – Injection 500T','Injection','IPP','INJECTION',NULL,NULL,'TOYO','SI500','SN103','500T',35.00,16,'192.168.1.103',NULL,NULL,'MES-INJ-103','Monthly',NULL,'idle','{}',NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30'),('5e8e3295-7fb6-4c95-9335-a8cf3e28bad3','ZPC-01','ZPC-01 – Closure Press','Closure','ZPC','ASSEMBLY',NULL,NULL,'ENGEL','E-200','SN201','200T',18.00,32,'192.168.2.01',NULL,NULL,'MES-ZPC-01','Monthly',NULL,'running','{}',NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30'),('bb4bb162-56d9-42fc-aca9-c002336ffc07','ZFP-03','ZFP 03 – Film Press','Film Press','FPP','BLOWMOLDIN',NULL,NULL,'BMB','SB-400','SN003','400T',24.00,2,'192.168.1.12',NULL,NULL,'MES-ZFP-03','Monthly',NULL,'running','{}',NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30'),('c27d6fa4-82ee-4689-a653-50e2dd55372b','INJ-083','INJ-083 – Injection 280T','Injection','IPP','INJECTION',NULL,NULL,'JSW','J280','SN083','280T',22.00,8,'192.168.1.83',NULL,NULL,'MES-INJ-083','Quarterly',NULL,'running','{}',NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30'),('d4495f0b-21bf-4d45-a6d2-73bd54f83012','ZFP-10','ZFP 10 – Film Press','Film Press','FPP','BLOWMOLDIN',NULL,NULL,'BMB','SB-800','SN010','800T',32.00,6,'192.168.1.20',NULL,NULL,'MES-ZFP-10','Quarterly',NULL,'running','{}',NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30'),('eb903f78-9b50-4ea1-ad09-bb927dc5121f','ZFP-02','ZFP 02 – Film Press','Film Press','FPP','BLOWMOLDIN',NULL,NULL,'BMB','SB-600','SN002','600T',28.00,4,'192.168.1.11',NULL,NULL,'MES-ZFP-02','Monthly',NULL,'idle','{}',NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30');
/*!40000 ALTER TABLE `machines` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-04 12:36:16
