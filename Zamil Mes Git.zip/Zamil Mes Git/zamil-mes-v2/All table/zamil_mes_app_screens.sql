-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: zamil_mes
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `app_screens`
--

DROP TABLE IF EXISTS `app_screens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_screens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(80) NOT NULL,
  `label` varchar(150) NOT NULL,
  `module` varchar(100) NOT NULL,
  `icon` varchar(20) DEFAULT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_screens`
--

LOCK TABLES `app_screens` WRITE;
/*!40000 ALTER TABLE `app_screens` DISABLE KEYS */;
INSERT INTO `app_screens` VALUES (1,'production','Production Scheduling','Production','P',10,1,'2026-06-02 15:19:01','2026-06-02 15:19:01'),(2,'technician','Process Tech Dashboard','Production','T',20,1,'2026-06-02 15:19:01','2026-06-02 15:19:01'),(3,'operator','Operator Print Screen','Production','O',30,1,'2026-06-02 15:19:01','2026-06-02 15:19:01'),(4,'qcoverview','QC Overview','Quality','Q',40,1,'2026-06-02 15:19:01','2026-06-02 15:19:01'),(5,'qcdetail','QC Inspection Detail','Quality','Q',50,1,'2026-06-02 15:19:01','2026-06-02 15:19:01'),(6,'lineclearance','Line Clearance Form','Quality','L',60,1,'2026-06-02 15:19:01','2026-06-02 15:19:01'),(7,'lcrpt','Line Clearance Report','Quality','R',70,1,'2026-06-02 15:19:01','2026-06-02 15:19:01'),(8,'packer','Packer Dashboard','Packing','P',80,1,'2026-06-02 15:19:01','2026-06-02 15:19:01'),(9,'packerdetail','Pallet Builder & Label','Packing','L',90,1,'2026-06-02 15:19:01','2026-06-02 15:19:01'),(10,'dtform','Downtime Entry Form','Downtime','D',100,1,'2026-06-02 15:19:01','2026-06-02 15:19:01'),(11,'dtreport','Downtime Report','Downtime','R',110,1,'2026-06-02 15:19:01','2026-06-02 15:19:01'),(12,'setup_bq','Setup - Box Quantity','Setup','B',120,1,'2026-06-02 15:19:01','2026-06-02 15:19:01'),(13,'setup_mc','Setup - Machines','Setup','M',130,1,'2026-06-02 15:19:01','2026-06-02 15:19:01'),(14,'setup_loc','Setup - Locations','Setup','L',140,1,'2026-06-02 15:19:01','2026-06-02 15:19:01'),(15,'setup_users','User Access Management','Setup','U',150,1,'2026-06-02 15:19:01','2026-06-02 15:19:01');
/*!40000 ALTER TABLE `app_screens` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-04 12:36:14
