-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: zamil_mes
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `downtime_records`
--

DROP TABLE IF EXISTS `downtime_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `downtime_records` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `machineId` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `woId` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `reportedById` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `org` varchar(50) DEFAULT NULL,
  `machine` varchar(50) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `product` varchar(100) DEFAULT NULL,
  `desc` varchar(200) DEFAULT NULL,
  `routing` varchar(50) DEFAULT NULL,
  `hours` int DEFAULT '0',
  `minute` int DEFAULT '0',
  `dtType` varchar(20) DEFAULT NULL,
  `shift` varchar(50) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `process` varchar(200) DEFAULT NULL,
  `reason` text,
  `startTime` datetime DEFAULT NULL,
  `endTime` datetime DEFAULT NULL,
  `durationMinutes` int DEFAULT NULL,
  `subcategory` varchar(100) DEFAULT NULL,
  `actionTaken` text,
  `status` enum('open','in_progress','resolved') DEFAULT 'open',
  `resolvedById` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `createdBy` varchar(100) DEFAULT NULL,
  `updatedBy` varchar(100) DEFAULT NULL,
  `isActive` tinyint(1) DEFAULT '1',
  `isDeleted` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `machineId` (`machineId`),
  KEY `woId` (`woId`),
  CONSTRAINT `downtime_records_ibfk_53` FOREIGN KEY (`machineId`) REFERENCES `machines` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `downtime_records_ibfk_54` FOREIGN KEY (`woId`) REFERENCES `work_orders` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `downtime_records`
--

LOCK TABLES `downtime_records` WRITE;
/*!40000 ALTER TABLE `downtime_records` DISABLE KEYS */;
INSERT INTO `downtime_records` VALUES ('0a6e1074-8a22-4b97-b9ed-fb8fb94ea877',NULL,NULL,NULL,'FPP BU','ZFP 01','2026-05-25','FG9406','PP Cap 28mm',NULL,2,30,'PDT','AB','Changeover','Mold swap','Scheduled changeover',NULL,NULL,NULL,NULL,NULL,'open',NULL,NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30'),('0fc488c4-b223-4a9c-86fd-87712ac2694a',NULL,NULL,NULL,'IPP BU','INJ-083','2026-05-23','FG7701','PET Jar 500ml',NULL,4,0,'STNU','AB','No Schedule','No job','No WO assigned',NULL,NULL,NULL,NULL,NULL,'open',NULL,NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30'),('3fcc1b59-2211-4eb7-ab61-873e224c0fd2',NULL,NULL,NULL,'FPP BU','ZFP 02','2026-05-24','FG8820','HDPE Bottle 1L',NULL,1,45,'UPDT','CD','Breakdown','Hydraulic fail','Oil leak detected',NULL,NULL,NULL,NULL,NULL,'open',NULL,NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30'),('8936fa69-6279-48de-ab1e-5c4d1e0bcd87',NULL,NULL,NULL,'IPP BU','INJ-106','2026-05-21','FG6601','LDPE Bag 1kg',NULL,0,45,'UPDT','CD','Breakdown','Controller fault','PLC alarm triggered',NULL,NULL,NULL,NULL,NULL,'open',NULL,NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30'),('a07f050e-5a5d-4166-a508-cd3f5a6410d3',NULL,NULL,NULL,'FPP BU','ZFP 03','2026-05-22','FG7722','PP Granule 3kg',NULL,3,0,'PDT','AB','Preventive Maintenance','PM service','Monthly PM schedule',NULL,NULL,NULL,NULL,NULL,'open',NULL,NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30');
/*!40000 ALTER TABLE `downtime_records` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-04 12:36:15
