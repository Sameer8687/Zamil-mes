-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: zamil_mes
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `empId` varchar(20) NOT NULL,
  `username` varchar(100) NOT NULL,
  `passwordHash` varchar(255) NOT NULL,
  `fullName` varchar(150) NOT NULL,
  `email` varchar(200) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `role` varchar(100) DEFAULT NULL,
  `plant` varchar(100) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `shift` varchar(50) DEFAULT NULL,
  `language` varchar(10) DEFAULT 'en',
  `theme` varchar(20) DEFAULT 'black',
  `lastLoginAt` datetime DEFAULT NULL,
  `mustChangePassword` tinyint(1) DEFAULT '0',
  `screenPermissions` json DEFAULT NULL,
  `createdBy` varchar(100) DEFAULT NULL,
  `updatedBy` varchar(100) DEFAULT NULL,
  `isActive` tinyint(1) DEFAULT '1',
  `isDeleted` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `roleId` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `empId` (`empId`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `empId_2` (`empId`),
  UNIQUE KEY `username_2` (`username`),
  UNIQUE KEY `empId_3` (`empId`),
  UNIQUE KEY `username_3` (`username`),
  UNIQUE KEY `empId_4` (`empId`),
  UNIQUE KEY `username_4` (`username`),
  UNIQUE KEY `empId_5` (`empId`),
  UNIQUE KEY `username_5` (`username`),
  UNIQUE KEY `empId_6` (`empId`),
  UNIQUE KEY `username_6` (`username`),
  UNIQUE KEY `empId_7` (`empId`),
  UNIQUE KEY `username_7` (`username`),
  UNIQUE KEY `empId_8` (`empId`),
  UNIQUE KEY `username_8` (`username`),
  UNIQUE KEY `empId_9` (`empId`),
  UNIQUE KEY `username_9` (`username`),
  UNIQUE KEY `empId_10` (`empId`),
  UNIQUE KEY `username_10` (`username`),
  UNIQUE KEY `empId_11` (`empId`),
  UNIQUE KEY `username_11` (`username`),
  UNIQUE KEY `empId_12` (`empId`),
  UNIQUE KEY `username_12` (`username`),
  UNIQUE KEY `empId_13` (`empId`),
  UNIQUE KEY `username_13` (`username`),
  UNIQUE KEY `empId_14` (`empId`),
  UNIQUE KEY `username_14` (`username`),
  UNIQUE KEY `empId_15` (`empId`),
  UNIQUE KEY `username_15` (`username`),
  UNIQUE KEY `empId_16` (`empId`),
  UNIQUE KEY `username_16` (`username`),
  UNIQUE KEY `empId_17` (`empId`),
  UNIQUE KEY `username_17` (`username`),
  UNIQUE KEY `empId_18` (`empId`),
  UNIQUE KEY `username_18` (`username`),
  UNIQUE KEY `empId_19` (`empId`),
  UNIQUE KEY `username_19` (`username`),
  UNIQUE KEY `empId_20` (`empId`),
  UNIQUE KEY `username_20` (`username`),
  UNIQUE KEY `empId_21` (`empId`),
  UNIQUE KEY `username_21` (`username`),
  UNIQUE KEY `empId_22` (`empId`),
  UNIQUE KEY `username_22` (`username`),
  UNIQUE KEY `empId_23` (`empId`),
  UNIQUE KEY `username_23` (`username`),
  UNIQUE KEY `empId_24` (`empId`),
  UNIQUE KEY `username_24` (`username`),
  UNIQUE KEY `empId_25` (`empId`),
  UNIQUE KEY `username_25` (`username`),
  UNIQUE KEY `empId_26` (`empId`),
  UNIQUE KEY `username_26` (`username`),
  UNIQUE KEY `empId_27` (`empId`),
  UNIQUE KEY `username_27` (`username`),
  UNIQUE KEY `empId_28` (`empId`),
  UNIQUE KEY `username_28` (`username`),
  UNIQUE KEY `empId_29` (`empId`),
  UNIQUE KEY `username_29` (`username`),
  UNIQUE KEY `empId_30` (`empId`),
  UNIQUE KEY `username_30` (`username`),
  UNIQUE KEY `empId_31` (`empId`),
  UNIQUE KEY `username_31` (`username`),
  KEY `roleId` (`roleId`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`roleId`) REFERENCES `roles` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('0fb0ad09-c71c-4658-ad9b-cc7401b7ff4b','EMP-2172','zaid.sayyed','$2a$12$1mPxRKnM1cbW8GApkMuHKe48VFKi3BhurUVf6J4Po1oAXplotpN4y','Zaid Jameel Sayyed','zaid.sayyed@zamilplastic.com',NULL,'Process Technician','IPP','IT','ANY','en','black',NULL,0,'{}',NULL,NULL,1,0,'2026-06-03 07:26:28','2026-06-03 07:29:47','4a07e80c-5e96-11f1-8ba2-3c528254cec1'),('1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5','xyz-001','xyz001','$2a$12$dMcXwu02xDMxeOsUe.MINO3qtJY7l.Lo.IecnPnr2MqgbrjnT9ebS','xyz','xyz@gmail.com',NULL,'System Admin','BOTH',NULL,'ANY','en','black',NULL,0,'{}',NULL,NULL,1,0,'2026-06-03 11:16:40','2026-06-03 11:17:46','4a06d82b-5e96-11f1-8ba2-3c528254cec1'),('2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a','1234','1324','$2a$12$ZMzj4XNXU93o0.H1q.9mQO6b9k7N49Wf1wrq0kqHjcoCnRIM1BKei','1234','1234@gmail.com',NULL,'Operator','FPP',NULL,'ANY','en','black',NULL,0,'{\"scope\": [\"zg\"], \"security\": {\"audit\": true, \"hours\": \"ANY\", \"pwStr\": \"medium\", \"twoFA\": false, \"device\": \"ANY\", \"lockout\": \"5\", \"pwReset\": \"30d\", \"timeout\": \"240\", \"ipRestrict\": false, \"emailNotify\": true}}',NULL,NULL,1,0,'2026-06-03 11:57:09','2026-06-03 14:08:38','4a081548-5e96-11f1-8ba2-3c528254cec1'),('3dacfc56-9677-40db-97dd-1d702604e29a','EMP-0001','admin','$2a$12$em.OKe8lSTrPYUCRqfFE7Oer58jhGWD1hk2qQ4kZfiGARMYRJuxR2','System Administrator','',NULL,'System Admin','Zamil Plastics',NULL,'ANY','en','black',NULL,0,'{}',NULL,NULL,1,0,'2026-06-01 06:45:29','2026-06-02 11:30:22',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-04 12:36:16
