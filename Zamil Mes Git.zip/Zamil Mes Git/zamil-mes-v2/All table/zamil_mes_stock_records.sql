-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: zamil_mes
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `stock_records`
--

DROP TABLE IF EXISTS `stock_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_records` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `woId` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `locationId` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `palletId` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `org` varchar(100) DEFAULT NULL,
  `plant` varchar(100) DEFAULT NULL,
  `machine` varchar(50) DEFAULT NULL,
  `productCode` varchar(50) DEFAULT NULL,
  `productName` varchar(200) DEFAULT NULL,
  `woNum` varchar(30) DEFAULT NULL,
  `boxNo` varchar(20) DEFAULT NULL,
  `palletCode` varchar(50) DEFAULT NULL,
  `locatorCode` varchar(50) DEFAULT NULL,
  `quantity` int DEFAULT '0',
  `reservedQty` int DEFAULT '0',
  `qcStatus` enum('appr','rejt','pend') DEFAULT 'pend',
  `status` enum('in_stock','reserved','dispatched','damaged') DEFAULT 'in_stock',
  `receivedAt` datetime DEFAULT NULL,
  `dispatchedAt` datetime DEFAULT NULL,
  `createdBy` varchar(100) DEFAULT NULL,
  `updatedBy` varchar(100) DEFAULT NULL,
  `isActive` tinyint(1) DEFAULT '1',
  `isDeleted` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `woId` (`woId`),
  KEY `locationId` (`locationId`),
  CONSTRAINT `stock_records_ibfk_49` FOREIGN KEY (`woId`) REFERENCES `work_orders` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `stock_records_ibfk_50` FOREIGN KEY (`locationId`) REFERENCES `locations` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_records`
--

LOCK TABLES `stock_records` WRITE;
/*!40000 ALTER TABLE `stock_records` DISABLE KEYS */;
INSERT INTO `stock_records` VALUES ('150080bf-df9b-482d-9ba9-f2b50941faea',NULL,NULL,NULL,'Zamil Operations','ZPC BU','ZPC-01',NULL,'Closure Cap','ZPC-WO-099','B01','','ZPC-WH-01',5000,0,'pend','in_stock','2026-06-01 06:46:30',NULL,NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30'),('19d5a912-2bc5-4fcb-b7df-ab704e499b89',NULL,NULL,NULL,'Zamil Operations','FPP BU','ZFP 01',NULL,'PP Cap 28mm','FPP-WO-414','B01','PLT-001','FPP-WH-01',2400,0,'appr','in_stock','2026-06-01 06:46:30',NULL,NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30'),('1e1e321f-bb72-4c4a-9853-22e71080b4c2',NULL,NULL,NULL,'Zamil Operations','IPP BU','INJ-103',NULL,'LDPE Bag 1kg','IPP-WO-188','B01','PLT-003','IPP-WH-02',1200,0,'appr','in_stock','2026-06-01 06:46:30',NULL,NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30'),('339a785e-d3f8-442f-986b-d04988d79ff5',NULL,NULL,NULL,'Zamil Operations','IPP BU','INJ-083',NULL,'PET Jar 500ml','IPP-WO-201','B01','','IPP-WH-01',3000,0,'pend','in_stock','2026-06-01 06:46:30',NULL,NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30'),('54f55832-7261-492e-8c9c-c894d0463f41',NULL,NULL,NULL,'Zamil Operations','FPP BU','ZFP 01',NULL,'PP Cap 28mm','FPP-WO-414','B02','PLT-001','FPP-WH-01',2400,0,'appr','in_stock','2026-06-01 06:46:30',NULL,NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30'),('70de48de-a0a5-4fd1-8619-6da83ab73243',NULL,NULL,NULL,'Zamil Operations','FPP BU','ZFP 02',NULL,'HDPE Bottle 1L','FPP-WO-494','B02','PLT-002','FPP-WH-02',1800,0,'rejt','damaged','2026-06-01 06:46:30',NULL,NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30'),('d4b0dbf5-7d87-4f01-ad91-d81083ea8d46',NULL,NULL,NULL,'Zamil Operations','FPP BU','ZFP 03',NULL,'PP Granule 3kg','FPP-WO-477','B01','PLT-004','FPP-WH-03',2700,0,'appr','in_stock','2026-06-01 06:46:30',NULL,NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30'),('d6b4206a-5c85-4111-8d88-89b3d12d119a',NULL,NULL,NULL,'Zamil Operations','FPP BU','ZFP 02',NULL,'HDPE Bottle 1L','FPP-WO-494','B01','PLT-002','FPP-WH-02',1800,0,'appr','in_stock','2026-06-01 06:46:30',NULL,NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30');
/*!40000 ALTER TABLE `stock_records` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-04 12:36:17
