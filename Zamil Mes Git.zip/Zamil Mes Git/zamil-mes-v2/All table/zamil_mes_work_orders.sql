-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: zamil_mes
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `work_orders`
--

DROP TABLE IF EXISTS `work_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `work_orders` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `woNumber` varchar(30) NOT NULL,
  `product` varchar(200) NOT NULL,
  `productCode` varchar(50) DEFAULT NULL,
  `customer` varchar(200) DEFAULT NULL,
  `plant` varchar(100) DEFAULT NULL,
  `plannedQty` int DEFAULT '0',
  `producedQty` int DEFAULT '0',
  `targetQty` int DEFAULT '0',
  `boxQty` int DEFAULT '0',
  `status` enum('pending','active','paused','completed','cancelled') DEFAULT 'pending',
  `priority` enum('low','normal','high','urgent') DEFAULT 'normal',
  `scheduledDate` date DEFAULT NULL,
  `completedDate` date DEFAULT NULL,
  `notes` text,
  `createdBy` varchar(100) DEFAULT NULL,
  `updatedBy` varchar(100) DEFAULT NULL,
  `isActive` tinyint(1) DEFAULT '1',
  `isDeleted` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `machineId` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `locatorCode` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `woNumber` (`woNumber`),
  UNIQUE KEY `woNumber_2` (`woNumber`),
  UNIQUE KEY `woNumber_3` (`woNumber`),
  UNIQUE KEY `woNumber_4` (`woNumber`),
  UNIQUE KEY `woNumber_5` (`woNumber`),
  UNIQUE KEY `woNumber_6` (`woNumber`),
  UNIQUE KEY `woNumber_7` (`woNumber`),
  UNIQUE KEY `woNumber_8` (`woNumber`),
  UNIQUE KEY `woNumber_9` (`woNumber`),
  UNIQUE KEY `woNumber_10` (`woNumber`),
  UNIQUE KEY `woNumber_11` (`woNumber`),
  UNIQUE KEY `woNumber_12` (`woNumber`),
  UNIQUE KEY `woNumber_13` (`woNumber`),
  UNIQUE KEY `woNumber_14` (`woNumber`),
  UNIQUE KEY `woNumber_15` (`woNumber`),
  UNIQUE KEY `woNumber_16` (`woNumber`),
  UNIQUE KEY `woNumber_17` (`woNumber`),
  UNIQUE KEY `woNumber_18` (`woNumber`),
  UNIQUE KEY `woNumber_19` (`woNumber`),
  UNIQUE KEY `woNumber_20` (`woNumber`),
  UNIQUE KEY `woNumber_21` (`woNumber`),
  UNIQUE KEY `woNumber_22` (`woNumber`),
  UNIQUE KEY `woNumber_23` (`woNumber`),
  UNIQUE KEY `woNumber_24` (`woNumber`),
  UNIQUE KEY `woNumber_25` (`woNumber`),
  UNIQUE KEY `woNumber_26` (`woNumber`),
  UNIQUE KEY `woNumber_27` (`woNumber`),
  UNIQUE KEY `woNumber_28` (`woNumber`),
  KEY `machineId` (`machineId`),
  CONSTRAINT `work_orders_ibfk_1` FOREIGN KEY (`machineId`) REFERENCES `machines` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `work_orders`
--

LOCK TABLES `work_orders` WRITE;
/*!40000 ALTER TABLE `work_orders` DISABLE KEYS */;
INSERT INTO `work_orders` VALUES ('0ed1b9d1-a422-4b89-825f-845050657dd5','IPP-WO-188','LDPE Bag 1kg','FG6601','Saudi Exports','IPP BU',3000,2900,0,20,'active','low','2026-06-01',NULL,NULL,NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-02 12:42:16','c27d6fa4-82ee-4689-a653-50e2dd55372b','FPP-STG-01'),('17cf5305-e35e-45b2-bda9-fd4f81dc4ea5','FPP-WO-414','PP Cap 28mm','FG9406','Zamil Steel','FPP BU',15000,11200,0,50,'cancelled','normal','2026-06-01',NULL,NULL,NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:49:22',NULL,NULL),('7ab50f9d-38db-4a35-8cf6-2040975072fb','FPP-WO-494','HDPE Bottle 1L','FG8820','Saudi Aramco','FPP BU',8000,3400,0,100,'paused','low','2026-06-01',NULL,NULL,NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-02 12:31:21','42e54abb-e651-4848-8063-163ec571007f',NULL),('7e837919-4bb1-4ef3-9e04-250128e7540d','IPP-WO-201','PET Jar 500ml','FG7701','Al-Marai','IPP BU',2000,1650,0,10,'paused','normal','2026-06-01',NULL,NULL,NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-02 12:22:11',NULL,NULL),('8fed2604-74e3-45a2-9789-b5662765579c','FPP-WO-477','PP Granule 3kg','FG7722','SABIC','FPP BU',5000,5000,0,25,'completed','low','2026-06-01',NULL,NULL,NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 12:19:43',NULL,NULL),('f5d6db49-363f-45bf-99e9-c6b374df12e5','ZPC-WO-099','Closure Cap','ZPC-CC','ZPC Customer','ZPC BU',50000,42000,0,200,'paused','urgent','2026-06-01',NULL,NULL,NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-03 06:09:53','c27d6fa4-82ee-4689-a653-50e2dd55372b',NULL);
/*!40000 ALTER TABLE `work_orders` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-04 12:36:12
