-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: zamil_mes
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pallets`
--

DROP TABLE IF EXISTS `pallets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pallets` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `palletNumber` varchar(50) DEFAULT NULL,
  `woId` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `createdById` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `boxCount` int DEFAULT '0',
  `totalQty` int DEFAULT '0',
  `totalWeight` decimal(10,3) DEFAULT NULL,
  `status` enum('building','complete','shipped') DEFAULT 'building',
  `labelPrinted` tinyint(1) DEFAULT '0',
  `createdBy` varchar(100) DEFAULT NULL,
  `updatedBy` varchar(100) DEFAULT NULL,
  `isActive` tinyint(1) DEFAULT '1',
  `isDeleted` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `palletNumber` (`palletNumber`),
  UNIQUE KEY `palletNumber_2` (`palletNumber`),
  UNIQUE KEY `palletNumber_3` (`palletNumber`),
  UNIQUE KEY `palletNumber_4` (`palletNumber`),
  UNIQUE KEY `palletNumber_5` (`palletNumber`),
  UNIQUE KEY `palletNumber_6` (`palletNumber`),
  UNIQUE KEY `palletNumber_7` (`palletNumber`),
  UNIQUE KEY `palletNumber_8` (`palletNumber`),
  UNIQUE KEY `palletNumber_9` (`palletNumber`),
  UNIQUE KEY `palletNumber_10` (`palletNumber`),
  UNIQUE KEY `palletNumber_11` (`palletNumber`),
  UNIQUE KEY `palletNumber_12` (`palletNumber`),
  UNIQUE KEY `palletNumber_13` (`palletNumber`),
  UNIQUE KEY `palletNumber_14` (`palletNumber`),
  UNIQUE KEY `palletNumber_15` (`palletNumber`),
  UNIQUE KEY `palletNumber_16` (`palletNumber`),
  UNIQUE KEY `palletNumber_17` (`palletNumber`),
  UNIQUE KEY `palletNumber_18` (`palletNumber`),
  UNIQUE KEY `palletNumber_19` (`palletNumber`),
  UNIQUE KEY `palletNumber_20` (`palletNumber`),
  UNIQUE KEY `palletNumber_21` (`palletNumber`),
  UNIQUE KEY `palletNumber_22` (`palletNumber`),
  UNIQUE KEY `palletNumber_23` (`palletNumber`),
  UNIQUE KEY `palletNumber_24` (`palletNumber`),
  UNIQUE KEY `palletNumber_25` (`palletNumber`),
  UNIQUE KEY `palletNumber_26` (`palletNumber`),
  UNIQUE KEY `palletNumber_27` (`palletNumber`),
  KEY `woId` (`woId`),
  KEY `createdById` (`createdById`),
  CONSTRAINT `pallets_ibfk_51` FOREIGN KEY (`woId`) REFERENCES `work_orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pallets_ibfk_52` FOREIGN KEY (`createdById`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pallets`
--

LOCK TABLES `pallets` WRITE;
/*!40000 ALTER TABLE `pallets` DISABLE KEYS */;
INSERT INTO `pallets` VALUES ('bfe2224d-351d-41c4-9ef7-bd688a86063e','PLT-1780403707361',NULL,'51429cf7-5f77-4947-801b-9d4cb531dee1',0,0,NULL,'complete',1,NULL,NULL,1,0,'2026-06-02 12:35:07','2026-06-02 12:35:07'),('dab775c1-8390-43d4-bdf8-c5d7c481eeb0','PLT-1780403888231',NULL,'51429cf7-5f77-4947-801b-9d4cb531dee1',0,0,NULL,'complete',1,NULL,NULL,1,0,'2026-06-02 12:38:08','2026-06-02 12:38:08'),('ed3bc14b-5ee8-499c-8f13-a048acbbac2b','PLT-1780309024981',NULL,'3dacfc56-9677-40db-97dd-1d702604e29a',5,100,NULL,'complete',1,NULL,NULL,1,0,'2026-06-01 10:17:04','2026-06-01 10:17:05');
/*!40000 ALTER TABLE `pallets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-04 12:36:18
