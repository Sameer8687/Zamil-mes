-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: zamil_mes
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user_feature_permissions`
--

DROP TABLE IF EXISTS `user_feature_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_feature_permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` char(36) NOT NULL,
  `feature_id` bigint unsigned NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=628 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_feature_permissions`
--

LOCK TABLES `user_feature_permissions` WRITE;
/*!40000 ALTER TABLE `user_feature_permissions` DISABLE KEYS */;
INSERT INTO `user_feature_permissions` VALUES (32,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',1,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(33,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',2,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(34,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',3,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(35,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',4,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(36,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',5,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(37,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',6,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(38,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',7,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(39,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',8,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(40,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',9,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(41,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',10,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(42,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',11,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(43,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',12,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(44,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',13,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(45,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',14,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(46,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',15,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(47,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',16,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(48,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',17,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(49,'1b83a60b-d4ac-483d-8ddb-92dfc0ae0ff5',18,1,'2026-06-03 11:16:41','2026-06-03 11:16:41'),(597,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',1,1,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(598,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',2,0,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(599,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',3,0,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(600,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',4,0,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(601,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',5,0,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(602,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',6,0,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(603,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',7,0,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(604,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',8,0,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(605,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',9,0,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(606,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',10,0,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(607,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',11,0,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(608,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',12,0,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(609,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',13,0,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(610,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',14,0,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(611,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',15,0,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(612,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',16,0,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(613,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',17,0,'2026-06-04 05:33:03','2026-06-04 05:33:03'),(614,'2b383fdb-9e14-4fc1-b2f0-a8ef3ead918a',18,0,'2026-06-04 05:33:03','2026-06-04 05:33:03');
/*!40000 ALTER TABLE `user_feature_permissions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-04 12:36:16
