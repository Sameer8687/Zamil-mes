-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: zamil_mes
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `boxes`
--

DROP TABLE IF EXISTS `boxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `boxes` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `barcode` varchar(50) DEFAULT NULL,
  `woId` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `machineId` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `packedById` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `quantity` int DEFAULT '0',
  `weight` decimal(10,3) DEFAULT NULL,
  `status` enum('open','packed','palletized','shipped') DEFAULT 'open',
  `qcStatus` enum('pend','appr','rejt') DEFAULT 'pend',
  `qcNotes` text,
  `qcChecks` json DEFAULT NULL,
  `palletId` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `packedAt` datetime DEFAULT NULL,
  `createdBy` varchar(100) DEFAULT NULL,
  `updatedBy` varchar(100) DEFAULT NULL,
  `isActive` tinyint(1) DEFAULT '1',
  `isDeleted` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `labelSeq` varchar(50) DEFAULT NULL,
  `labelPrinted` tinyint(1) DEFAULT '1',
  `printedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `barcode` (`barcode`),
  UNIQUE KEY `barcode_2` (`barcode`),
  UNIQUE KEY `barcode_3` (`barcode`),
  UNIQUE KEY `barcode_4` (`barcode`),
  UNIQUE KEY `barcode_5` (`barcode`),
  UNIQUE KEY `barcode_6` (`barcode`),
  UNIQUE KEY `barcode_7` (`barcode`),
  UNIQUE KEY `barcode_8` (`barcode`),
  UNIQUE KEY `barcode_9` (`barcode`),
  UNIQUE KEY `barcode_10` (`barcode`),
  UNIQUE KEY `barcode_11` (`barcode`),
  UNIQUE KEY `barcode_12` (`barcode`),
  UNIQUE KEY `barcode_13` (`barcode`),
  UNIQUE KEY `barcode_14` (`barcode`),
  UNIQUE KEY `barcode_15` (`barcode`),
  UNIQUE KEY `barcode_16` (`barcode`),
  UNIQUE KEY `barcode_17` (`barcode`),
  UNIQUE KEY `barcode_18` (`barcode`),
  UNIQUE KEY `barcode_19` (`barcode`),
  UNIQUE KEY `barcode_20` (`barcode`),
  UNIQUE KEY `barcode_21` (`barcode`),
  UNIQUE KEY `barcode_22` (`barcode`),
  UNIQUE KEY `barcode_23` (`barcode`),
  UNIQUE KEY `barcode_24` (`barcode`),
  UNIQUE KEY `barcode_25` (`barcode`),
  UNIQUE KEY `barcode_26` (`barcode`),
  KEY `woId` (`woId`),
  KEY `machineId` (`machineId`),
  KEY `packedById` (`packedById`),
  KEY `palletId` (`palletId`),
  CONSTRAINT `boxes_ibfk_100` FOREIGN KEY (`woId`) REFERENCES `work_orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `boxes_ibfk_101` FOREIGN KEY (`machineId`) REFERENCES `machines` (`id`),
  CONSTRAINT `boxes_ibfk_102` FOREIGN KEY (`packedById`) REFERENCES `users` (`id`),
  CONSTRAINT `boxes_ibfk_103` FOREIGN KEY (`palletId`) REFERENCES `pallets` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `boxes`
--

LOCK TABLES `boxes` WRITE;
/*!40000 ALTER TABLE `boxes` DISABLE KEYS */;
INSERT INTO `boxes` VALUES ('138c6764-79a7-4a85-b2b0-13ac0b096eca','P010626-0001','f5d6db49-363f-45bf-99e9-c6b374df12e5','42e54abb-e651-4848-8063-163ec571007f','3dacfc56-9677-40db-97dd-1d702604e29a',200,NULL,'packed','appr',NULL,'{}',NULL,'2026-06-01 10:42:44',NULL,NULL,1,0,'2026-06-01 10:42:44','2026-06-01 12:59:20','P010626-0001',1,'2026-06-01 10:42:44'),('4118e412-751b-474b-a331-c9fa20cb6ae9','P020626-0001','7ab50f9d-38db-4a35-8cf6-2040975072fb','42e54abb-e651-4848-8063-163ec571007f','51429cf7-5f77-4947-801b-9d4cb531dee1',100,NULL,'packed','pend',NULL,'{}',NULL,'2026-06-02 12:26:02',NULL,NULL,1,0,'2026-06-02 12:26:02','2026-06-02 12:26:02','P020626-0001',1,'2026-06-02 12:26:02'),('41aa8a94-0243-4e69-bd2b-4f2f76ecefd9','P010626-0006','0ed1b9d1-a422-4b89-825f-845050657dd5','42e54abb-e651-4848-8063-163ec571007f','3dacfc56-9677-40db-97dd-1d702604e29a',20,NULL,'packed','appr',NULL,'{}',NULL,'2026-06-01 10:26:10',NULL,NULL,1,0,'2026-06-01 10:26:10','2026-06-01 12:59:13','P010626-0006',1,'2026-06-01 10:26:10'),('4ab71b10-6281-4ceb-a627-36d8c8ce9666','BOX-1780307533274-201','0ed1b9d1-a422-4b89-825f-845050657dd5','42e54abb-e651-4848-8063-163ec571007f','3dacfc56-9677-40db-97dd-1d702604e29a',20,NULL,'packed','appr','this right','{\"fit\": true, \"weight\": true, \"marking\": true, \"packaging\": true, \"appearance\": true, \"dimensions\": true}','ed3bc14b-5ee8-499c-8f13-a048acbbac2b','2026-06-01 09:52:13',NULL,NULL,1,0,'2026-06-01 09:52:13','2026-06-01 10:18:39',NULL,1,NULL),('62d45834-3ed0-4dc6-bda2-de90596b008a','P020626-0004','f5d6db49-363f-45bf-99e9-c6b374df12e5','c27d6fa4-82ee-4689-a653-50e2dd55372b','51429cf7-5f77-4947-801b-9d4cb531dee1',200,NULL,'packed','pend',NULL,'{}',NULL,'2026-06-02 06:57:59',NULL,NULL,1,0,'2026-06-02 06:57:59','2026-06-02 06:57:59','P020626-0004',1,'2026-06-02 06:57:59'),('70a33402-26fc-435a-adaa-956dace728ad','BOX-1780308613491-720','0ed1b9d1-a422-4b89-825f-845050657dd5','42e54abb-e651-4848-8063-163ec571007f','3dacfc56-9677-40db-97dd-1d702604e29a',20,NULL,'packed','appr','','{}','ed3bc14b-5ee8-499c-8f13-a048acbbac2b','2026-06-01 10:10:13',NULL,NULL,1,0,'2026-06-01 10:10:13','2026-06-01 10:19:05',NULL,1,NULL),('7cc75cb3-766d-4a00-aef5-9b10870ad8cc','BOX-1780308387080-926','0ed1b9d1-a422-4b89-825f-845050657dd5','42e54abb-e651-4848-8063-163ec571007f','3dacfc56-9677-40db-97dd-1d702604e29a',20,NULL,'packed','appr','','{}','ed3bc14b-5ee8-499c-8f13-a048acbbac2b','2026-06-01 10:06:27',NULL,NULL,1,0,'2026-06-01 10:06:27','2026-06-01 10:19:01',NULL,1,NULL),('b9259bf6-6e6a-425a-b460-2ec27435e1ef','P010626-0002','f5d6db49-363f-45bf-99e9-c6b374df12e5','42e54abb-e651-4848-8063-163ec571007f','3dacfc56-9677-40db-97dd-1d702604e29a',200,NULL,'packed','appr',NULL,'{}',NULL,'2026-06-01 12:57:00',NULL,NULL,1,0,'2026-06-01 12:57:00','2026-06-01 12:59:20','P010626-0002',1,'2026-06-01 12:57:00'),('bce5be2b-56c0-431a-9544-863c4120b8e5','P010626-0003','f5d6db49-363f-45bf-99e9-c6b374df12e5','42e54abb-e651-4848-8063-163ec571007f','3dacfc56-9677-40db-97dd-1d702604e29a',200,NULL,'packed','appr',NULL,'{}',NULL,'2026-06-01 12:57:55',NULL,NULL,1,0,'2026-06-01 12:57:55','2026-06-01 12:59:20','P010626-0003',1,'2026-06-01 12:57:55'),('c8289c76-b1ce-4253-b29b-ed948868d71a','P020626-0007','0ed1b9d1-a422-4b89-825f-845050657dd5','42e54abb-e651-4848-8063-163ec571007f','51429cf7-5f77-4947-801b-9d4cb531dee1',20,NULL,'packed','pend',NULL,'{}',NULL,'2026-06-02 12:33:53',NULL,NULL,1,0,'2026-06-02 12:33:53','2026-06-02 12:33:53','P020626-0007',1,'2026-06-02 12:33:53'),('c9cacac6-8901-4f87-85ca-3998508dcb61','P020626-0006','f5d6db49-363f-45bf-99e9-c6b374df12e5','c27d6fa4-82ee-4689-a653-50e2dd55372b','51429cf7-5f77-4947-801b-9d4cb531dee1',200,NULL,'packed','pend',NULL,'{}',NULL,'2026-06-02 07:00:56',NULL,NULL,1,0,'2026-06-02 07:00:56','2026-06-02 07:00:56','P020626-0006',1,'2026-06-02 07:00:56'),('dd7838f8-bce7-41a0-b9fe-7fb03ddd3b43','BOX-1780308517377-344','0ed1b9d1-a422-4b89-825f-845050657dd5','42e54abb-e651-4848-8063-163ec571007f','3dacfc56-9677-40db-97dd-1d702604e29a',20,NULL,'packed','appr','','{}','ed3bc14b-5ee8-499c-8f13-a048acbbac2b','2026-06-01 10:08:37',NULL,NULL,1,0,'2026-06-01 10:08:37','2026-06-01 10:19:03',NULL,1,NULL),('e278297b-ae62-4c8e-bfa8-55e27a8fbef4','P020626-0005','f5d6db49-363f-45bf-99e9-c6b374df12e5','c27d6fa4-82ee-4689-a653-50e2dd55372b','51429cf7-5f77-4947-801b-9d4cb531dee1',200,NULL,'packed','pend',NULL,'{}',NULL,'2026-06-02 06:58:08',NULL,NULL,1,0,'2026-06-02 06:58:08','2026-06-02 06:58:08','P020626-0005',1,'2026-06-02 06:58:08'),('f949def3-9a64-4651-ba7b-1c234cbf5a2a','BOX-1780307746997-780','0ed1b9d1-a422-4b89-825f-845050657dd5','42e54abb-e651-4848-8063-163ec571007f','3dacfc56-9677-40db-97dd-1d702604e29a',20,NULL,'packed','appr','','{}','ed3bc14b-5ee8-499c-8f13-a048acbbac2b','2026-06-01 09:55:46',NULL,NULL,1,0,'2026-06-01 09:55:46','2026-06-01 10:18:55',NULL,1,NULL);
/*!40000 ALTER TABLE `boxes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-04 12:36:16
