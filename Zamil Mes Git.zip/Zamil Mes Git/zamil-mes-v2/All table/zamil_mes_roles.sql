-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: zamil_mes
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `permissions` json DEFAULT NULL,
  `createdBy` varchar(100) DEFAULT NULL,
  `updatedBy` varchar(100) DEFAULT NULL,
  `isActive` tinyint(1) DEFAULT '1',
  `isDeleted` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `role_id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(50) DEFAULT NULL,
  `icon` varchar(20) DEFAULT NULL,
  `color` varchar(20) DEFAULT NULL,
  `isSystem` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `name_2` (`name`),
  UNIQUE KEY `name_3` (`name`),
  UNIQUE KEY `name_4` (`name`),
  UNIQUE KEY `name_5` (`name`),
  UNIQUE KEY `name_6` (`name`),
  UNIQUE KEY `name_7` (`name`),
  UNIQUE KEY `name_8` (`name`),
  UNIQUE KEY `name_9` (`name`),
  UNIQUE KEY `name_10` (`name`),
  UNIQUE KEY `name_11` (`name`),
  UNIQUE KEY `name_12` (`name`),
  UNIQUE KEY `name_13` (`name`),
  UNIQUE KEY `name_14` (`name`),
  UNIQUE KEY `name_15` (`name`),
  UNIQUE KEY `name_16` (`name`),
  UNIQUE KEY `name_17` (`name`),
  UNIQUE KEY `name_18` (`name`),
  UNIQUE KEY `name_19` (`name`),
  UNIQUE KEY `name_20` (`name`),
  UNIQUE KEY `name_21` (`name`),
  UNIQUE KEY `name_22` (`name`),
  UNIQUE KEY `name_23` (`name`),
  UNIQUE KEY `name_24` (`name`),
  UNIQUE KEY `name_25` (`name`),
  UNIQUE KEY `name_26` (`name`),
  UNIQUE KEY `name_27` (`name`),
  UNIQUE KEY `name_28` (`name`),
  UNIQUE KEY `name_29` (`name`),
  UNIQUE KEY `name_30` (`name`),
  UNIQUE KEY `role_id` (`role_id`),
  UNIQUE KEY `name_31` (`name`),
  UNIQUE KEY `name_32` (`name`),
  UNIQUE KEY `role_id_2` (`role_id`),
  UNIQUE KEY `name_33` (`name`),
  UNIQUE KEY `role_id_3` (`role_id`),
  UNIQUE KEY `name_34` (`name`),
  UNIQUE KEY `role_id_4` (`role_id`),
  UNIQUE KEY `name_35` (`name`),
  UNIQUE KEY `role_id_5` (`role_id`),
  UNIQUE KEY `name_36` (`name`),
  UNIQUE KEY `role_id_6` (`role_id`),
  UNIQUE KEY `name_37` (`name`),
  UNIQUE KEY `role_id_7` (`role_id`),
  UNIQUE KEY `name_38` (`name`),
  UNIQUE KEY `role_id_8` (`role_id`),
  UNIQUE KEY `name_39` (`name`),
  UNIQUE KEY `role_id_9` (`role_id`),
  UNIQUE KEY `code` (`code`),
  UNIQUE KEY `code_2` (`code`),
  UNIQUE KEY `code_3` (`code`),
  UNIQUE KEY `code_4` (`code`),
  UNIQUE KEY `code_5` (`code`),
  UNIQUE KEY `code_6` (`code`),
  UNIQUE KEY `code_7` (`code`),
  UNIQUE KEY `code_8` (`code`),
  UNIQUE KEY `code_9` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES ('2778ecd2-50af-472a-95c6-350e61d2d3be','Label Printer','','{}',NULL,NULL,1,0,'2026-06-03 12:56:19','2026-06-03 12:56:19',9,'label_printer','?','#f25f5c',0),('4a06d82b-5e96-11f1-8ba2-3c528254cec1','System Admin','Full access to every module, all settings and user management.',NULL,NULL,NULL,1,0,'2026-06-02 20:48:20','2026-06-02 20:48:20',1,'system_admin','?','#a78bfa',0),('4a07e80c-5e96-11f1-8ba2-3c528254cec1','Process Technician','Manage work orders, start/hold/terminate, production scheduling.',NULL,NULL,NULL,1,0,'2026-06-02 20:48:20','2026-06-02 20:48:20',2,'process_technician','?','#4f8ef7',0),('4a081548-5e96-11f1-8ba2-3c528254cec1','Operator','Print-only access to running work orders.',NULL,NULL,NULL,1,0,'2026-06-02 20:48:20','2026-06-02 20:48:20',3,'operator','?','#2dd4a0',0),('4a081cb2-5e96-11f1-8ba2-3c528254cec1','QC Inspector','Box inspection, line clearance, quality dashboards.',NULL,NULL,NULL,1,0,'2026-06-02 20:48:20','2026-06-02 20:48:20',4,'qc_inspector','?','#22d3ee',0),('4a082331-5e96-11f1-8ba2-3c528254cec1','Packer','Packer dashboard, pallet builder, label printing.',NULL,NULL,NULL,1,0,'2026-06-02 20:48:20','2026-06-02 20:48:20',5,'packer','?','#84cc16',0),('4a08283f-5e96-11f1-8ba2-3c528254cec1','Supervisor','View all screens and reports.',NULL,NULL,NULL,1,0,'2026-06-02 20:48:20','2026-06-02 20:48:20',6,'supervisor','?','#f5a623',0),('4a083ab3-5e96-11f1-8ba2-3c528254cec1','Maintenance','Downtime entry and machine status.',NULL,NULL,NULL,1,0,'2026-06-02 20:48:20','2026-06-02 20:48:20',7,'maintenance','⚙','#ff8c42',0),('4a08411d-5e96-11f1-8ba2-3c528254cec1','Read Only','View dashboards and reports only.',NULL,NULL,NULL,1,0,'2026-06-02 20:48:20','2026-06-02 20:48:20',8,'read_only','?','#d946ef',0);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-04 12:36:17
