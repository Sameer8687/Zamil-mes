-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: zamil_mes
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `line_clearances`
--

DROP TABLE IF EXISTS `line_clearances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `line_clearances` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `woId` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `machineId` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `conductedById` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `approvedById` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `plant` varchar(50) DEFAULT NULL,
  `machine` varchar(50) DEFAULT NULL,
  `jobOrder` varchar(50) DEFAULT NULL,
  `productCode` varchar(50) DEFAULT NULL,
  `productName` varchar(200) DEFAULT NULL,
  `submissionShift` varchar(20) DEFAULT NULL,
  `submissionDate` date DEFAULT NULL,
  `clearanceType` varchar(50) DEFAULT NULL,
  `requestNo` varchar(50) DEFAULT NULL,
  `techName` varchar(100) DEFAULT NULL,
  `qiName` varchar(100) DEFAULT NULL,
  `checkedCount` int DEFAULT '0',
  `checkedTotal` int DEFAULT '0',
  `note` text,
  `controlNbr` varchar(50) DEFAULT NULL,
  `shift` varchar(50) DEFAULT NULL,
  `checklistData` json DEFAULT NULL,
  `hygieneChecks` json DEFAULT NULL,
  `operationChecks` json DEFAULT NULL,
  `moldChecks` json DEFAULT NULL,
  `operatorSignature` text,
  `supervisorSignature` text,
  `status` enum('draft','submitted','approved','rejected') DEFAULT 'draft',
  `submittedAt` datetime DEFAULT NULL,
  `approvedAt` datetime DEFAULT NULL,
  `rejectionReason` text,
  `createdBy` varchar(100) DEFAULT NULL,
  `updatedBy` varchar(100) DEFAULT NULL,
  `isActive` tinyint(1) DEFAULT '1',
  `isDeleted` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `woId` (`woId`),
  KEY `machineId` (`machineId`),
  CONSTRAINT `line_clearances_ibfk_49` FOREIGN KEY (`woId`) REFERENCES `work_orders` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `line_clearances_ibfk_50` FOREIGN KEY (`machineId`) REFERENCES `machines` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `line_clearances`
--

LOCK TABLES `line_clearances` WRITE;
/*!40000 ALTER TABLE `line_clearances` DISABLE KEYS */;
INSERT INTO `line_clearances` VALUES ('c0f472f9-b727-487b-8155-a6612b3e3312',NULL,NULL,NULL,NULL,'FPP BU','ZFP 01','4518870','FG9406','PP Cap 28mm','Day Shift','2026-05-25','Changing Mold','LC-2026-0101','Syed Hussaini','Mustafa Al Maqrodh',23,23,NULL,NULL,NULL,'{}','[]','[]','[]',NULL,NULL,'approved',NULL,NULL,NULL,NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30'),('e419c452-1a63-46df-bbed-7dec2d7a2e96',NULL,NULL,NULL,NULL,'IPP BU','INJ-083','4517701','FG7701','PET Jar 500ml','Day Shift','2026-05-23','Startup','LC-2026-0099','Syed Hussaini','Mustafa Al Maqrodh',23,23,NULL,NULL,NULL,'{}','[]','[]','[]',NULL,NULL,'approved',NULL,NULL,NULL,NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30'),('f79efe7b-26d5-42b8-8085-8657763805cb',NULL,NULL,NULL,NULL,'FPP BU','ZFP 02','4518920','FG8820','HDPE Bottle 1L','Night Shift','2026-05-24','Product Change','LC-2026-0100','Amro Faisal','Mustafa Al Maqrodh',20,23,NULL,NULL,NULL,'{}','[]','[]','[]',NULL,NULL,'submitted',NULL,NULL,NULL,NULL,NULL,1,0,'2026-06-01 06:46:30','2026-06-01 06:46:30');
/*!40000 ALTER TABLE `line_clearances` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-04 12:36:15
