-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: zamil_mes
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `app_features`
--

DROP TABLE IF EXISTS `app_features`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_features` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(80) NOT NULL,
  `label` varchar(150) NOT NULL,
  `category` varchar(100) NOT NULL,
  `description` text,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_features`
--

LOCK TABLES `app_features` WRITE;
/*!40000 ALTER TABLE `app_features` DISABLE KEYS */;
INSERT INTO `app_features` VALUES (1,'print_labels','Print Labels','Production','Print box labels from operator screen',10,1,'2026-06-02 15:19:07','2026-06-02 15:19:07'),(2,'start_wo','Start / Hold Work Orders','Production','Change WO status',20,1,'2026-06-02 15:19:07','2026-06-02 15:19:07'),(3,'add_wo','Add Work Orders','Production','Manually add work orders',30,1,'2026-06-02 15:19:07','2026-06-02 15:19:07'),(4,'set_priority','Set WO Priority','Production','Change priority on work orders',40,1,'2026-06-02 15:19:07','2026-06-02 15:19:07'),(5,'change_machine','Reassign Machine','Production','Move WO to a different machine',50,1,'2026-06-02 15:19:07','2026-06-02 15:19:07'),(6,'qc_approve','Approve / Reject Boxes','Quality','Approve or reject quality inspection',60,1,'2026-06-02 15:19:07','2026-06-02 15:19:07'),(7,'qc_bulk','Bulk QC Actions','Quality','Approve all / reject all at once',70,1,'2026-06-02 15:19:07','2026-06-02 15:19:07'),(8,'lc_submit','Submit Line Clearance','Quality','Submit line clearance for approval',80,1,'2026-06-02 15:19:07','2026-06-02 15:19:07'),(9,'lc_approve','Approve Line Clearance','Quality','Final approval of LC records',90,1,'2026-06-02 15:19:07','2026-06-02 15:19:07'),(10,'build_pallet','Build Pallets','Packing','Create pallet and generate label',100,1,'2026-06-02 15:19:07','2026-06-02 15:19:07'),(11,'print_pallet','Print Pallet Labels','Packing','Print pallet barcode label',110,1,'2026-06-02 15:19:07','2026-06-02 15:19:07'),(12,'dt_submit','Submit Downtime','Downtime','Create downtime entry records',120,1,'2026-06-02 15:19:07','2026-06-02 15:19:07'),(13,'dt_edit','Edit/Delete Downtime','Downtime','Modify or delete downtime records',130,1,'2026-06-02 15:19:07','2026-06-02 15:19:07'),(14,'export_data','Export to Excel','Reports','Download reports as Excel',140,1,'2026-06-02 15:19:07','2026-06-02 15:19:07'),(15,'view_all_divs','View All Divisions','Data Access','See FPP and IPP data simultaneously',150,1,'2026-06-02 15:19:07','2026-06-02 15:19:07'),(16,'setup_edit','Edit Setup Data','Setup','Modify machines, locations, box quantity',160,1,'2026-06-02 15:19:07','2026-06-02 15:19:07'),(17,'user_manage','Manage Users','Setup','Create, edit, delete user accounts',170,1,'2026-06-02 15:19:07','2026-06-02 15:19:07'),(18,'change_theme','Change Theme','UI','Switch between themes',180,1,'2026-06-02 15:19:07','2026-06-02 15:19:07');
/*!40000 ALTER TABLE `app_features` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-04 12:36:15
