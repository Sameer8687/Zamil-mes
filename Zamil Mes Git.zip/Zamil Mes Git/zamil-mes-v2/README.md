# Zamil MES System

A full-stack Manufacturing Execution System built with **React + Vite** (frontend) and **Express.js + Sequelize** (backend), converted from a monolithic HTML prototype.

---

## Tech Stack

| Layer     | Technology                                      |
|-----------|-------------------------------------------------|
| Frontend  | React 18, Vite, React Router v6, Axios          |
| Styling   | Custom CSS (3 themes: Black / White / Zamil Green) |
| Backend   | Node.js 18+, Express 4, ESM modules             |
| ORM       | Sequelize 6 (SQLite / PostgreSQL / MySQL)       |
| Auth      | JWT (jsonwebtoken) + bcryptjs                   |
| Logging   | Winston + morgan                                |

---

## Project Structure

```
zamil-mes-system/
├── frontend/               # React + Vite SPA
│   └── src/
│       ├── App.jsx         # Router (login / app / install)
│       ├── index.css       # All CSS + 3 theme variables
│       ├── contexts/       # AuthContext, AppContext
│       ├── layouts/        # AuthLayout, DashboardLayout
│       ├── pages/          # 15 screen pages
│       │   ├── auth/       # Login
│       │   ├── production/ # ProductionScheduling
│       │   ├── operator/   # OperatorScreen
│       │   ├── qc/         # QCOverview, QCDetail
│       │   ├── waste/      # WasteRecording
│       │   ├── downtime/   # DowntimeForm, DowntimeReport
│       │   ├── packer/     # PackerOverview, PalletLabel
│       │   ├── lineclearance/ # LineClearance, LineClearanceReport
│       │   ├── stock/      # StockRegister
│       │   ├── setup/      # Setup (5 tabs)
│       │   ├── admin/      # UserAdmin
│       │   └── install/    # InstallWizard
│       ├── components/     # Topbar, Navbar, Toast, UI kit
│       ├── services/       # api.js (Axios + all service modules)
│       ├── data/           # mockData.js (demo data)
│       ├── hooks/          # useClock
│       └── utils/          # formatters.js
│
└── backend/                # Express.js API
    └── src/
        ├── server.js       # Entry point, all middleware + routes
        ├── config/         # env.js, db.js
        ├── models/         # 16 Sequelize models
        ├── controllers/    # 10 controller modules
        ├── routes/         # 11 route files
        ├── middleware/     # auth, errorHandler, logger, validate
        ├── utils/          # logger.js (Winston), response.js
        └── database/       # migrate.js, seed.js
```

---

## Quick Start

### 1. Clone & install

```bash
cd zamil-mes-system
npm run install:all
```

### 2. Configure backend

```bash
cd backend
cp .env.example .env
# Edit .env — for development, SQLite works out of the box
```

### 3. Run migrations + seed demo data

```bash
npm run migrate   # Creates all tables
npm run seed      # Loads demo users, machines, work orders
```

### 4. Start dev servers

```bash
# From root — starts both API (port 5000) and Vite (port 5173)
npm run dev
```

Then open **http://localhost:5173**

---

## Demo Accounts

| Name                  | EmpID     | Role     | Password   |
|-----------------------|-----------|----------|------------|
| Muhannad Ali Saeed    | EMP-0001  | Admin    | Admin@1234 |
| Syed Hussaini         | EMP-2479  | Tech     | Demo@1234  |
| Ahmed Hassan          | EMP-5012  | Operator | Demo@1234  |
| Mustafa Al Maqrodh   | EMP-1001  | QC       | Demo@1234  |
| Ahmed Al Rashidi      | EMP-3301  | Packer   | Demo@1234  |
| Amro Faisal           | EMP-2122  | Tech     | Demo@1234  |

---

## Screens

| Screen               | Route Key              | Roles              |
|----------------------|------------------------|--------------------|
| Production Scheduling | `production`          | Admin, Tech        |
| Process Tech         | `operator`             | Tech, Operator     |
| QC Overview          | `qc-overview`          | QC, Admin          |
| QC Detail            | `qc-detail`            | QC                 |
| Waste Recording      | `waste`                | All                |
| Downtime Form        | `downtime`             | All                |
| Downtime Report      | `downtime-report`      | Admin, Tech        |
| Packer Overview      | `packer`               | Packer             |
| Pallet & Label       | `pallet`               | Packer             |
| Line Clearance       | `line-clearance`       | Tech, QC           |
| LC Report            | `lc-report`            | Admin, QC          |
| Stock Register       | `stock`                | Admin, Tech        |
| Setup                | `setup`                | Admin              |
| User Admin           | `user-admin`           | Admin              |

---

## API Endpoints

All endpoints prefixed with `/api/v1`

| Module         | Base Path              |
|----------------|------------------------|
| Auth           | `/auth`                |
| Users          | `/users`               |
| Production     | `/production`          |
| QC             | `/qc`                  |
| Waste          | `/waste`               |
| Downtime       | `/downtime`            |
| Packer         | `/packer`              |
| Line Clearance | `/line-clearance`      |
| Stock          | `/stock`               |
| Setup          | `/setup`               |
| Install        | `/install`             |

Health check: `GET /health`

---

## Themes

Switch via the topbar gear icon:
- **Black** (default dark)
- **White** (light mode)
- **Zamil Green** (brand theme)

---

## Database Support

| Dialect    | Config                         |
|------------|--------------------------------|
| SQLite     | `DB_DIALECT=sqlite` (default)  |
| PostgreSQL | `DB_DIALECT=postgres`          |
| MySQL      | `DB_DIALECT=mysql`             |

---

## Production Deploy

```bash
# Build frontend
npm run build
# Serve dist/ with nginx or express static

# Start API
NODE_ENV=production npm start
```

Set `APP_INSTALLED=true` in `.env` after running the install wizard.
