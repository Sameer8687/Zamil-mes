/**
 * Database migration runner
 * Usage: node src/database/migrate.js [rollback]
 */
import { initDatabase } from '../config/db.js';
import { initModels } from '../models/index.js';
import logger from '../utils/logger.js';

const run = async () => {
  const rollback = process.argv[2] === 'rollback';

  try {
    logger.info('Connecting to database...');
    const db = await initDatabase();
    initModels(db);

    if (rollback) {
      logger.warn('Rolling back schema (dropping all tables)...');
      await db.drop({ cascade: true });
      logger.info('All tables dropped.');
    } else {
      logger.info('Running migrations (sync with alter)...');
      await db.sync({ alter: true });
      logger.info('Migration complete — all tables up to date.');
    }

    process.exit(0);
  } catch (err) {
    logger.error('Migration failed:', err);
    process.exit(1);
  }
};

run();
