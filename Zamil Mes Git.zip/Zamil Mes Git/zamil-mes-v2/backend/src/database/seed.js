/**
 * Demo data seeder
 * Usage: node src/database/seed.js
 */
import bcrypt from 'bcryptjs';
import { initDatabase } from '../config/db.js';
import { initModels } from '../models/index.js';
import logger from '../utils/logger.js';

const seed = async () => {
  try {
    const db = await initDatabase();
    const {
      User, Machine, Location, Shift, WorkOrder,
      SystemConfig, DowntimeRecord, LineClearance, StockRecord, BoxQtyRecord,
    } = initModels(db);

    await db.sync({ alter: true });

    logger.info('Seeding demo data...');

    const adminHash = await bcrypt.hash('Admin@1234', 12);
    const demoHash  = await bcrypt.hash('Demo@1234', 12);

    // ── Users ──────────────────────────────────────────────────────────
    const usersData = [
      { empId: 'EMP-0001', username: 'admin',          passwordHash: adminHash, fullName: 'Muhannad Ali Saeed',     role: 'admin',    plant: 'Zamil Plastics' },
      { empId: 'EMP-2479', username: 'syed.hussaini',  passwordHash: demoHash,  fullName: 'Syed Hussaini',          role: 'tech',     plant: 'Zamil Plastics' },
      { empId: 'EMP-5012', username: 'ahmed.hassan',   passwordHash: demoHash,  fullName: 'Ahmed Hassan',           role: 'operator', plant: 'Zamil Plastics' },
      { empId: 'EMP-1001', username: 'mustafa.maqrodh',passwordHash: demoHash,  fullName: 'Mustafa Al Maqrodh',     role: 'qc',       plant: 'Zamil Plastics' },
      { empId: 'EMP-3301', username: 'ahmed.rashidi',  passwordHash: demoHash,  fullName: 'Ahmed Al Rashidi',       role: 'packer',   plant: 'Zamil Plastics' },
      { empId: 'EMP-2122', username: 'amro.faisal',    passwordHash: demoHash,  fullName: 'Amro Faisal',            role: 'tech',     plant: 'Zamil Plastics' },
    ];
    for (const u of usersData) {
      await User.findOrCreate({ where: { empId: u.empId }, defaults: { ...u, isActive: true } });
    }
    logger.info(`  ✓ ${usersData.length} users`);

    // ── Machines ───────────────────────────────────────────────────────
    const machinesData = [
      { code: 'ZFP-01', name: 'ZFP 01 – Film Press',      type: 'Film Press', plant: 'FPP', dept: 'BLOWMOLDIN', oem: 'BMB',  model: 'SB-600', serial: 'SN001', tonnage: '600T', cycleTime: 28, cavities: 4, ip: '192.168.1.10', mesCode: 'MES-ZFP-01', pmFreq: 'Monthly',   status: 'running' },
      { code: 'ZFP-02', name: 'ZFP 02 – Film Press',      type: 'Film Press', plant: 'FPP', dept: 'BLOWMOLDIN', oem: 'BMB',  model: 'SB-600', serial: 'SN002', tonnage: '600T', cycleTime: 28, cavities: 4, ip: '192.168.1.11', mesCode: 'MES-ZFP-02', pmFreq: 'Monthly',   status: 'idle'    },
      { code: 'ZFP-03', name: 'ZFP 03 – Film Press',      type: 'Film Press', plant: 'FPP', dept: 'BLOWMOLDIN', oem: 'BMB',  model: 'SB-400', serial: 'SN003', tonnage: '400T', cycleTime: 24, cavities: 2, ip: '192.168.1.12', mesCode: 'MES-ZFP-03', pmFreq: 'Monthly',   status: 'running' },
      { code: 'ZFP-10', name: 'ZFP 10 – Film Press',      type: 'Film Press', plant: 'FPP', dept: 'BLOWMOLDIN', oem: 'BMB',  model: 'SB-800', serial: 'SN010', tonnage: '800T', cycleTime: 32, cavities: 6, ip: '192.168.1.20', mesCode: 'MES-ZFP-10', pmFreq: 'Quarterly', status: 'running' },
      { code: 'INJ-077', name: 'INJ-077 – Injection 280T', type: 'Injection', plant: 'IPP', dept: 'INJECTION',  oem: 'JSW',  model: 'J280',   serial: 'SN077', tonnage: '280T', cycleTime: 22, cavities: 4, ip: '192.168.1.77', mesCode: 'MES-INJ-077', pmFreq: 'Monthly',   status: 'maintenance' },
      { code: 'INJ-083', name: 'INJ-083 – Injection 280T', type: 'Injection', plant: 'IPP', dept: 'INJECTION',  oem: 'JSW',  model: 'J280',   serial: 'SN083', tonnage: '280T', cycleTime: 22, cavities: 8, ip: '192.168.1.83', mesCode: 'MES-INJ-083', pmFreq: 'Quarterly', status: 'running' },
      { code: 'INJ-103', name: 'INJ-103 – Injection 500T', type: 'Injection', plant: 'IPP', dept: 'INJECTION',  oem: 'TOYO', model: 'SI500',  serial: 'SN103', tonnage: '500T', cycleTime: 35, cavities: 16,ip: '192.168.1.103',mesCode: 'MES-INJ-103', pmFreq: 'Monthly',   status: 'idle'    },
      { code: 'INJ-106', name: 'INJ-106 – Injection 500T', type: 'Injection', plant: 'IPP', dept: 'INJECTION',  oem: 'TOYO', model: 'SI500',  serial: 'SN106', tonnage: '500T', cycleTime: 35, cavities: 16,ip: '192.168.1.106',mesCode: 'MES-INJ-106', pmFreq: 'Monthly',   status: 'running' },
      { code: 'ZPC-01', name: 'ZPC-01 – Closure Press',    type: 'Closure',   plant: 'ZPC', dept: 'ASSEMBLY',   oem: 'ENGEL',model: 'E-200',  serial: 'SN201', tonnage: '200T', cycleTime: 18, cavities: 32,ip: '192.168.2.01', mesCode: 'MES-ZPC-01',  pmFreq: 'Monthly',   status: 'running' },
    ];
    for (const m of machinesData) {
      await Machine.findOrCreate({ where: { code: m.code }, defaults: m });
    }
    logger.info(`  ✓ ${machinesData.length} machines`);

    // ── Locations ──────────────────────────────────────────────────────
    const locData = [
      { code: 'FPP-WH-01', name: 'FPP Warehouse Bay 1',  type: 'warehouse', plant: 'FPP BU' },
      { code: 'FPP-WH-02', name: 'FPP Warehouse Bay 2',  type: 'warehouse', plant: 'FPP BU' },
      { code: 'FPP-WH-03', name: 'FPP Warehouse Bay 3',  type: 'warehouse', plant: 'FPP BU' },
      { code: 'IPP-WH-01', name: 'IPP Warehouse Main',   type: 'warehouse', plant: 'IPP BU' },
      { code: 'IPP-WH-02', name: 'IPP Warehouse Bay 2',  type: 'warehouse', plant: 'IPP BU' },
      { code: 'ZPC-WH-01', name: 'ZPC Warehouse Main',   type: 'warehouse', plant: 'ZPC BU' },
      { code: 'FPP-STG-01',name: 'FPP Staging Area 1',  type: 'staging',   plant: 'FPP BU' },
      { code: 'SCRAP-01',  name: 'Scrap Yard Zone A',    type: 'scrap',     plant: 'FPP BU' },
    ];
    for (const l of locData) {
      await Location.findOrCreate({ where: { code: l.code }, defaults: l });
    }
    logger.info(`  ✓ ${locData.length} locations`);

    // ── Shifts ─────────────────────────────────────────────────────────
    const shiftData = [
      { name: 'AB – Day Shift',   startTime: '06:00', endTime: '18:00', plant: 'FPP BU' },
      { name: 'CD – Night Shift', startTime: '18:00', endTime: '06:00', plant: 'FPP BU' },
      { name: 'A Morning',        startTime: '06:00', endTime: '14:00', plant: 'IPP BU' },
      { name: 'B Afternoon',      startTime: '14:00', endTime: '22:00', plant: 'IPP BU' },
    ];
    for (const s of shiftData) {
      await Shift.findOrCreate({ where: { name: s.name }, defaults: s });
    }
    logger.info(`  ✓ ${shiftData.length} shifts`);

    // ── Work Orders ────────────────────────────────────────────────────
    const woData = [
      { woNumber: 'FPP-WO-414', product: 'PP Cap 28mm',    productCode: 'FG9406', customer: 'Zamil Steel',   plant: 'FPP BU', plannedQty: 15000, producedQty: 11200, status: 'active',    boxQty: 50  },
      { woNumber: 'FPP-WO-494', product: 'HDPE Bottle 1L', productCode: 'FG8820', customer: 'Saudi Aramco',  plant: 'FPP BU', plannedQty: 8000,  producedQty: 3400,  status: 'active',    boxQty: 100 },
      { woNumber: 'FPP-WO-477', product: 'PP Granule 3kg', productCode: 'FG7722', customer: 'SABIC',         plant: 'FPP BU', plannedQty: 5000,  producedQty: 5000,  status: 'completed', boxQty: 25  },
      { woNumber: 'IPP-WO-201', product: 'PET Jar 500ml',  productCode: 'FG7701', customer: 'Al-Marai',      plant: 'IPP BU', plannedQty: 2000,  producedQty: 1650,  status: 'active',    boxQty: 10  },
      { woNumber: 'IPP-WO-188', product: 'LDPE Bag 1kg',   productCode: 'FG6601', customer: 'Saudi Exports', plant: 'IPP BU', plannedQty: 3000,  producedQty: 2900,  status: 'active',    boxQty: 20  },
      { woNumber: 'ZPC-WO-099', product: 'Closure Cap',    productCode: 'ZPC-CC', customer: 'ZPC Customer',  plant: 'ZPC BU', plannedQty: 50000, producedQty: 42000, status: 'active',    boxQty: 200 },
    ];
    for (const wo of woData) {
      await WorkOrder.findOrCreate({
        where: { woNumber: wo.woNumber },
        defaults: { ...wo, scheduledDate: new Date(), priority: 'normal' },
      });
    }
    logger.info(`  ✓ ${woData.length} work orders`);

    // ── System Configs ─────────────────────────────────────────────────
    const configs = [
      { key: 'app_name',         value: 'Zamil MES System',       category: 'general' },
      { key: 'plant_name',       value: 'Zamil Plastics Factory',  category: 'general' },
      { key: 'default_box_qty',  value: '50',                      category: 'packing' },
      { key: 'qc_sample_size',   value: '5',                       category: 'qc'      },
      { key: 'pallet_max_boxes', value: '50',                      category: 'packing' },
      { key: 'currency',         value: 'SAR',                     category: 'general' },
    ];
    for (const c of configs) {
      await SystemConfig.findOrCreate({ where: { key: c.key }, defaults: c });
    }
    logger.info(`  ✓ ${configs.length} system configs`);

    // ── Box Qty Records ────────────────────────────────────────────────
    const bqData = [
      { org: 'FPP BU', productCode: 'FG9406', productDesc: 'PP Cap 28mm',    qtyPerBox: 2400, effectiveDate: '2026-01-01' },
      { org: 'FPP BU', productCode: 'FG8820', productDesc: 'HDPE Bottle 1L', qtyPerBox: 1800, effectiveDate: '2026-01-01' },
      { org: 'IPP BU', productCode: 'FG7701', productDesc: 'PET Jar 500ml',  qtyPerBox: 3000, effectiveDate: '2026-01-01' },
      { org: 'IPP BU', productCode: 'FG6601', productDesc: 'LDPE Bag 1kg',   qtyPerBox: 1200, effectiveDate: '2026-01-01' },
      { org: 'FPP BU', productCode: 'FG7722', productDesc: 'PP Granule 3kg', qtyPerBox: 2700, effectiveDate: '2026-01-01' },
      { org: 'ZPC BU', productCode: 'ZPC-CC', productDesc: 'Closure Cap',    qtyPerBox: 5000, effectiveDate: '2026-01-01' },
    ];
    for (const b of bqData) {
      await BoxQtyRecord.findOrCreate({ where: { org: b.org, productCode: b.productCode }, defaults: b });
    }
    logger.info(`  ✓ ${bqData.length} box qty records`);

    // ── Downtime Records ───────────────────────────────────────────────
    const dtData = [
      { org: 'FPP BU', machine: 'ZFP 01', date: '2026-05-25', product: 'FG9406', desc: 'PP Cap 28mm',    shift: 'AB', dtType: 'PDT',  category: 'Changeover',           process: 'Mold swap',      reason: 'Scheduled changeover', hours: 2, minute: 30 },
      { org: 'FPP BU', machine: 'ZFP 02', date: '2026-05-24', product: 'FG8820', desc: 'HDPE Bottle 1L', shift: 'CD', dtType: 'UPDT', category: 'Breakdown',            process: 'Hydraulic fail', reason: 'Oil leak detected',    hours: 1, minute: 45 },
      { org: 'IPP BU', machine: 'INJ-083',date: '2026-05-23', product: 'FG7701', desc: 'PET Jar 500ml',  shift: 'AB', dtType: 'STNU', category: 'No Schedule',          process: 'No job',         reason: 'No WO assigned',       hours: 4, minute: 0  },
      { org: 'FPP BU', machine: 'ZFP 03', date: '2026-05-22', product: 'FG7722', desc: 'PP Granule 3kg', shift: 'AB', dtType: 'PDT',  category: 'Preventive Maintenance',process: 'PM service',     reason: 'Monthly PM schedule',  hours: 3, minute: 0  },
      { org: 'IPP BU', machine: 'INJ-106',date: '2026-05-21', product: 'FG6601', desc: 'LDPE Bag 1kg',   shift: 'CD', dtType: 'UPDT', category: 'Breakdown',            process: 'Controller fault',reason: 'PLC alarm triggered',  hours: 0, minute: 45 },
    ];
    for (const dt of dtData) {
      const existing = await DowntimeRecord.findOne({ where: { org: dt.org, machine: dt.machine, date: dt.date } });
      if (!existing) await DowntimeRecord.create({ ...dt, status: 'open' });
    }
    logger.info(`  ✓ ${dtData.length} downtime records`);

    // ── Line Clearance Records ─────────────────────────────────────────
    const lcData = [
      { plant: 'FPP BU', machine: 'ZFP 01', jobOrder: '4518870', submissionDate: '2026-05-25', productCode: 'FG9406', productName: 'PP Cap 28mm',    submissionShift: 'Day Shift',   clearanceType: 'Changing Mold',  requestNo: 'LC-2026-0101', techName: 'Syed Hussaini', qiName: 'Mustafa Al Maqrodh', checkedCount: 23, checkedTotal: 23, status: 'approved' },
      { plant: 'FPP BU', machine: 'ZFP 02', jobOrder: '4518920', submissionDate: '2026-05-24', productCode: 'FG8820', productName: 'HDPE Bottle 1L', submissionShift: 'Night Shift',  clearanceType: 'Product Change', requestNo: 'LC-2026-0100', techName: 'Amro Faisal',    qiName: 'Mustafa Al Maqrodh', checkedCount: 20, checkedTotal: 23, status: 'submitted' },
      { plant: 'IPP BU', machine: 'INJ-083',jobOrder: '4517701', submissionDate: '2026-05-23', productCode: 'FG7701', productName: 'PET Jar 500ml',  submissionShift: 'Day Shift',   clearanceType: 'Startup',        requestNo: 'LC-2026-0099', techName: 'Syed Hussaini', qiName: 'Mustafa Al Maqrodh', checkedCount: 23, checkedTotal: 23, status: 'approved' },
    ];
    for (const lc of lcData) {
      const existing = await LineClearance.findOne({ where: { requestNo: lc.requestNo } });
      if (!existing) await LineClearance.create({ ...lc, status: lc.status });
    }
    logger.info(`  ✓ ${lcData.length} line clearance records`);

    // ── Stock Records ──────────────────────────────────────────────────
    const stockData = [
      { org: 'Zamil Operations', plant: 'FPP BU', machine: 'ZFP 01',  productName: 'PP Cap 28mm',    woNum: 'FPP-WO-414', quantity: 2400, boxNo: 'B01', palletCode: 'PLT-001', locatorCode: 'FPP-WH-01', qcStatus: 'appr', status: 'in_stock' },
      { org: 'Zamil Operations', plant: 'FPP BU', machine: 'ZFP 01',  productName: 'PP Cap 28mm',    woNum: 'FPP-WO-414', quantity: 2400, boxNo: 'B02', palletCode: 'PLT-001', locatorCode: 'FPP-WH-01', qcStatus: 'appr', status: 'in_stock' },
      { org: 'Zamil Operations', plant: 'FPP BU', machine: 'ZFP 02',  productName: 'HDPE Bottle 1L', woNum: 'FPP-WO-494', quantity: 1800, boxNo: 'B01', palletCode: 'PLT-002', locatorCode: 'FPP-WH-02', qcStatus: 'appr', status: 'in_stock' },
      { org: 'Zamil Operations', plant: 'FPP BU', machine: 'ZFP 02',  productName: 'HDPE Bottle 1L', woNum: 'FPP-WO-494', quantity: 1800, boxNo: 'B02', palletCode: 'PLT-002', locatorCode: 'FPP-WH-02', qcStatus: 'rejt', status: 'damaged'  },
      { org: 'Zamil Operations', plant: 'IPP BU', machine: 'INJ-083', productName: 'PET Jar 500ml',  woNum: 'IPP-WO-201', quantity: 3000, boxNo: 'B01', palletCode: '',        locatorCode: 'IPP-WH-01', qcStatus: 'pend', status: 'in_stock' },
      { org: 'Zamil Operations', plant: 'IPP BU', machine: 'INJ-103', productName: 'LDPE Bag 1kg',   woNum: 'IPP-WO-188', quantity: 1200, boxNo: 'B01', palletCode: 'PLT-003', locatorCode: 'IPP-WH-02', qcStatus: 'appr', status: 'in_stock' },
      { org: 'Zamil Operations', plant: 'FPP BU', machine: 'ZFP 03',  productName: 'PP Granule 3kg', woNum: 'FPP-WO-477', quantity: 2700, boxNo: 'B01', palletCode: 'PLT-004', locatorCode: 'FPP-WH-03', qcStatus: 'appr', status: 'in_stock' },
      { org: 'Zamil Operations', plant: 'ZPC BU', machine: 'ZPC-01',  productName: 'Closure Cap',    woNum: 'ZPC-WO-099', quantity: 5000, boxNo: 'B01', palletCode: '',        locatorCode: 'ZPC-WH-01', qcStatus: 'pend', status: 'in_stock' },
    ];
    for (const s of stockData) {
      const existing = await StockRecord.findOne({ where: { woNum: s.woNum, boxNo: s.boxNo } });
      if (!existing) await StockRecord.create({ ...s, receivedAt: new Date() });
    }
    logger.info(`  ✓ ${stockData.length} stock records`);

    logger.info('✅ Seeding complete!');
    process.exit(0);
  } catch (err) {
    logger.error('Seeding failed:', err);
    process.exit(1);
  }
};

seed();
