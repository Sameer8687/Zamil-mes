/**
 * Reference Data Controller
 * Serves all static dropdown/checklist reference data from backend
 * so the frontend has ZERO hardcoded values.
 */
import { success } from '../utils/response.js';

// ── Defect Types ─────────────────────────────────────────────────────
const DEFECT_TYPES = [
  { id: 'flash',           label: 'Flash',             category: 'visual'      },
  { id: 'short_shot',      label: 'Short Shot',         category: 'dimensional' },
  { id: 'sink_mark',       label: 'Sink Mark',          category: 'visual'      },
  { id: 'weld_line',       label: 'Weld Line',          category: 'structural'  },
  { id: 'colour_off',      label: 'Colour Off',         category: 'visual'      },
  { id: 'dimension_oos',   label: 'Dimension OOS',      category: 'dimensional' },
  { id: 'surface_scratch', label: 'Surface Scratch',    category: 'visual'      },
  { id: 'black_spot',      label: 'Black Spot',         category: 'contamination'},
  { id: 'warpage',         label: 'Warpage',            category: 'dimensional' },
  { id: 'contamination',   label: 'Contamination',      category: 'contamination'},
  { id: 'other',           label: 'Other',              category: 'other'       },
];

// ── Waste Types ──────────────────────────────────────────────────────
const WASTE_TYPES = [
  { id: 'runner_sprue',    label: 'Runner/Sprue',       category: 'plastic'     },
  { id: 'short_shot',      label: 'Short Shot',         category: 'plastic'     },
  { id: 'flash_burr',      label: 'Flash/Burr',         category: 'plastic'     },
  { id: 'sink_mark',       label: 'Sink Mark',          category: 'plastic'     },
  { id: 'contamination',   label: 'Contamination',      category: 'plastic'     },
  { id: 'colour_mismatch', label: 'Colour Mismatch',    category: 'plastic'     },
  { id: 'dimensional_oos', label: 'Dimensional OOS',    category: 'plastic'     },
  { id: 'purging',         label: 'Purging Waste',      category: 'plastic'     },
  { id: 'startup_scrap',   label: 'Start-up Scrap',     category: 'plastic'     },
  { id: 'packaging',       label: 'Packaging Waste',    category: 'packaging'   },
  { id: 'chemical',        label: 'Chemical Waste',     category: 'chemical'    },
  { id: 'other',           label: 'Other',              category: 'other'       },
];

// ── Waste Categories ──────────────────────────────────────────────────
const WASTE_CATEGORIES = [
  { id: 'plastic_waste',   label: 'Plastic Waste' },
  { id: 'metal_scrap',     label: 'Metal Scrap'   },
  { id: 'chemical_waste',  label: 'Chemical Waste'},
  { id: 'packaging_waste', label: 'Packaging Waste'},
  { id: 'other',           label: 'Other'         },
];

// ── Disposal Methods ──────────────────────────────────────────────────
const DISPOSAL_METHODS = [
  { id: 'recycled_internal', label: 'Recycled Internally' },
  { id: 'recycler',          label: 'Sent to Recycler'    },
  { id: 'landfill',          label: 'Landfill'            },
  { id: 'incineration',      label: 'Incineration'        },
  { id: 'other',             label: 'Other'               },
];

// ── Downtime Categories ───────────────────────────────────────────────
const DOWNTIME_CATEGORIES = [
  {
    id: 'mechanical',     label: 'Mechanical Breakdown',
    subcategories: ['Hydraulic','Pneumatic','Drive Belt','Motor','Barrel/Screw','Ejector','Clamp Unit','Cooling System'],
  },
  {
    id: 'electrical',     label: 'Electrical Fault',
    subcategories: ['PLC Fault','Sensor Failure','Heater Band','Control Panel','Cable/Wiring'],
  },
  {
    id: 'material_change',label: 'Material Change',
    subcategories: ['Colour Change','Material Grade Change','Purging Required'],
  },
  {
    id: 'mold_change',    label: 'Mold Change',
    subcategories: ['Scheduled Change','Emergency Change','Mold Maintenance'],
  },
  {
    id: 'planned_maint',  label: 'Planned Maintenance',
    subcategories: ['PM Schedule','Lubrication','Calibration'],
  },
  {
    id: 'quality_hold',   label: 'Quality Hold',
    subcategories: ['Inspection Required','Defect Investigation','Hold for QC Release'],
  },
  {
    id: 'operator_absence',label: 'Operator Absence',
    subcategories: ['No Operator','Break','Training'],
  },
  {
    id: 'power_failure',  label: 'Power Failure',
    subcategories: ['Utility Outage','Generator Switch','Load Shedding'],
  },
  {
    id: 'setup_changeover',label: 'Setup/Changeover',
    subcategories: ['First Article','ISIR Setup','Changeover'],
  },
  {
    id: 'other',          label: 'Other',
    subcategories: ['Not Specified'],
  },
];

// ── LC Checklist ──────────────────────────────────────────────────────
const LC_HYGIENE = [
  {sno:1,  section:'hygiene', en:'Excess scrap cleaned up from surrounding area', ar:'المنتجات التالفة تم إزالتها من محيط الماكنة', resp:'Process Technician'},
  {sno:2,  section:'hygiene', en:'Old labels removed / cleared from machine', ar:'الليبل القديم تم ازالته من الماكنه', resp:'Process Technician'},
  {sno:3,  section:'hygiene', en:'All previous molded part removed from surrounding area', ar:'المنتجات الجاهزة من التي تم تشغيلها مسبقا تم إزالتها', resp:'Process Technician'},
  {sno:4,  section:'hygiene', en:'No oil & water leakage', ar:'لا وجود لزيوت او مياه', resp:'Process Technician'},
  {sno:5,  section:'hygiene', en:'Excess check labels / tag discarded by QC', ar:'بطاقة التعريف للمنتج السابق تم إتلافها من قبل الجودة', resp:'QC Inspector'},
  {sno:6,  section:'hygiene', en:'All previous packaging removed', ar:'مواد التغليف للمنتج السابق تم إزالتها', resp:'Process Technician'},
  {sno:7,  section:'hygiene', en:'Conveyor / stacking table cleaned and sanitized', ar:'طاولة و سير التجميع تم تنظيفه و تعقيمه', resp:'QC Inspector / Packer'},
  {sno:8,  section:'hygiene', en:'Mold cleaned and sanitized', ar:'القالب تم تنظيفه و تعقيمه', resp:'Process Technician'},
  {sno:9,  section:'hygiene', en:'Robot dummy cleaned / sanitized', ar:'الروبوت تم تنظيفه و تعقيمه', resp:'Process Technician'},
  {sno:10, section:'hygiene', en:'No foreign bodies (screw, washer, etc.)', ar:'لا وجود لاجسام غريبة على الماكنة', resp:'QC Inspector / Packer'},
];
const LC_OPS = [
  {sno:11, section:'operations', en:'New packaging prepared', ar:'تم التأكد من مواد التغليف للمنتج المراد تشغيله', resp:'Process Technician'},
  {sno:12, section:'operations', en:'New label fixed on the magazine', ar:'تم تحضير الليبل للمنتج المراد تشغيله', resp:'Process Technician'},
  {sno:13, section:'operations', en:'Vision system works fine without any issue', ar:'نظام الكامرة يعمل بون مشاكل', resp:'Process Technician', specialYesNA:true},
  {sno:14, section:'operations', en:'Packing instruction in place', ar:'تم تزويد عمال الانتاج بتعليمات التعبئة', resp:'Process Technician'},
  {sno:15, section:'operations', en:'QC checked the part specification', ar:'تم التأكد من مواصفات المنتج النهائي من قبل الجودة', resp:'QC Inspector'},
  {sno:16, section:'operations', en:'QC provided packers with defect types and needed information', ar:'تم تزويد عمال الانتاج بالمعلومات اللازمة', resp:'Process Technician'},
  {sno:17, section:'operations', en:'Inspection of 5 continuous shots visually', ar:'تم فحص 5 دفعات متواصلة من المنتج', resp:'QC Inspector'},
  {sno:18, section:'operations', en:'Air, Water, Heater cables properly fixed and connected', ar:'يتم إصلاح الهواء والماء وكابلات سخان بشكل صحيح', resp:'Process Technician'},
];
const LC_MOLD = [
  {sno:19, section:'mold', en:'Mold polished and previous material purged (if required)', ar:'ازالة المتبقي من المواد من نظام الحقن و صقل القالب', resp:'Process Technician / TR'},
  {sno:20, section:'mold', en:'Mold setup is perfect and mold holder inspected', ar:'إعداد القالب مثالي', resp:'Process Technician'},
  {sno:21, section:'mold', en:'Correct mold hoses connection', ar:'اتصال خرطوم القالب الصحيح', resp:'Process Technician'},
  {sno:22, section:'mold', en:'Machine logbook updated', ar:'سجل الآلة محدث', resp:'Process Technician'},
  {sno:23, section:'mold', en:'Machine cleaned from oil and grease', ar:'تم تنظيف الماكنة من بقايا الزيت والشحم', resp:'Process Technician / QC'},
];

// ── QC Checklist ──────────────────────────────────────────────────────
const QC_CHECK_ITEMS = [
  {id:'appearance',  label:'Visual Appearance',       description:'Check for visual defects — colour, surface, flash'},
  {id:'dimensions',  label:'Dimensional Check',       description:'Measure critical dimensions against drawing tolerance'},
  {id:'weight',      label:'Weight Verification',     description:'Verify part weight within ±5% of target'},
  {id:'fit',         label:'Assembly Fit Check',      description:'Verify parts fit and assemble correctly'},
  {id:'marking',     label:'Part Marking / Label',    description:'Verify part marking, date codes and traceability'},
  {id:'packaging',   label:'Packaging Condition',     description:'Inspect packaging for damage, correct label'},
];

// ── Controllers ───────────────────────────────────────────────────────
export const getDefectTypes         = (_req, res) => success(res, DEFECT_TYPES);
export const getWasteTypes          = (_req, res) => success(res, WASTE_TYPES);
export const getWasteCategories     = (_req, res) => success(res, WASTE_CATEGORIES);
export const getDisposalMethods     = (_req, res) => success(res, DISPOSAL_METHODS);
export const getDowntimeCategories  = (_req, res) => success(res, DOWNTIME_CATEGORIES);
export const getLCChecklist         = (_req, res) => success(res, { hygiene: LC_HYGIENE, operations: LC_OPS, mold: LC_MOLD, all: [...LC_HYGIENE,...LC_OPS,...LC_MOLD] });
export const getQCChecklist         = (_req, res) => success(res, QC_CHECK_ITEMS);

export default {
  getDefectTypes, getWasteTypes, getWasteCategories, getDisposalMethods,
  getDowntimeCategories, getLCChecklist, getQCChecklist,
};
