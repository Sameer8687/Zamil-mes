import bcrypt from 'bcryptjs';
import { Sequelize } from 'sequelize';
import env from '../config/env.js';
import { initDatabase } from '../config/db.js';
import { initModels } from '../models/index.js';
import { success, error, badRequest } from '../utils/response.js';
import logger from '../utils/logger.js';

// ── Step 1 — test DB connection ───────────────────────────────────────────
export const testConnection = async (req, res) => {
  const { dialect, host, port, database, username, password, storage } = req.body;
  try {
    let seq;
    if (dialect === 'sqlite') {
      seq = new Sequelize({ dialect: 'sqlite', storage: storage || ':memory:', logging: false });
    } else {
      seq = new Sequelize(database, username, password, {
        host, port, dialect: dialect === 'postgresql' ? 'postgres' : dialect, logging: false,
        dialectOptions: { connectTimeout: 5000 },
      });
    }
    await seq.authenticate();
    await seq.close();
    return success(res, null, 'Connection successful');
  } catch (err) {
    return badRequest(res, `Connection failed: ${err.message}`);
  }
};

// ── Step 2 — create schema ────────────────────────────────────────────────
export const createSchema = async (req, res) => {
  try {
    const db = await initDatabase();
    const models = initModels(db);
    await db.sync({ force: false, alter: false });
    logger.info('Schema created via sync');
    return success(res, { tables: Object.keys(models) }, 'Schema created successfully');
  } catch (err) {
    logger.error('Schema creation failed:', err);
    return error(res, `Schema error: ${err.message}`);
  }
};

// ── Step 3 — create admin + seed demo data ────────────────────────────────
export const seedData = async (req, res) => {
  try {
    const { adminName, adminEmpId, adminPassword, seedDemoData } = req.body;
    const { User, Machine, Location, Shift, WorkOrder, SystemConfig } = initModels(
      await initDatabase()
    );

    // Admin user
    const hash = await bcrypt.hash(adminPassword || 'Admin@1234', 12);
    const [admin] = await User.findOrCreate({
      where: { empId: adminEmpId || 'ADMIN-001' },
      defaults: {
        empId: adminEmpId || 'ADMIN-001',
        username: 'admin',
        passwordHash: hash,
        fullName: adminName || 'System Administrator',
        role: 'admin',
        plant: 'Zamil Plastics',
        isActive: true,
      },
    });

    if (seedDemoData) {
      // Demo users
      const demoUsers = [
        { empId: 'EMP-2479', username: 'syed.hussaini', fullName: 'Syed Hussaini', role: 'tech' },
        { empId: 'EMP-5012', username: 'ahmed.hassan', fullName: 'Ahmed Hassan', role: 'operator' },
        { empId: 'EMP-1001', username: 'mustafa.maqrodh', fullName: 'Mustafa Al Maqrodh', role: 'qc' },
        { empId: 'EMP-3301', username: 'ahmed.rashidi', fullName: 'Ahmed Al Rashidi', role: 'packer' },
        { empId: 'EMP-2122', username: 'amro.faisal', fullName: 'Amro Faisal', role: 'tech' },
      ];
      const demoHash = await bcrypt.hash('Demo@1234', 12);
      for (const u of demoUsers) {
        await User.findOrCreate({ where: { empId: u.empId }, defaults: { ...u, passwordHash: demoHash, plant: 'Zamil Plastics', isActive: true } });
      }

      // Machines
      const machines = [
        { code: 'ZFP001', name: 'Zamil Film Press 001', type: 'Film Press', status: 'running' },
        { code: 'ZFP002', name: 'Zamil Film Press 002', type: 'Film Press', status: 'idle' },
        { code: 'ZBL010', name: 'Zamil Blow Liner 010', type: 'Blow Liner', status: 'running' },
        { code: 'ZPK005', name: 'Zamil Packer 005', type: 'Packer', status: 'running' },
        { code: 'INJ-077', name: 'Injection Mold 077', type: 'Injection', status: 'maintenance' },
        { code: 'INJ-083', name: 'Injection Mold 083', type: 'Injection', status: 'running' },
        { code: 'INJ-103', name: 'Injection Mold 103', type: 'Injection', status: 'idle' },
        { code: 'INJ-106', name: 'Injection Mold 106', type: 'Injection', status: 'running' },
      ];
      for (const m of machines) {
        await Machine.findOrCreate({ where: { code: m.code }, defaults: { ...m, plant: 'Zamil Plastics' } });
      }

      // Locations
      const locations = [
        { code: 'WH-A', name: 'Warehouse A', type: 'warehouse' },
        { code: 'WH-B', name: 'Warehouse B', type: 'warehouse' },
        { code: 'STAGING', name: 'Staging Area', type: 'staging' },
        { code: 'DISPATCH', name: 'Dispatch Bay', type: 'dispatch' },
      ];
      for (const l of locations) {
        await Location.findOrCreate({ where: { code: l.code }, defaults: { ...l, plant: 'Zamil Plastics' } });
      }

      // Shifts
      const shifts = [
        { name: 'Morning', startTime: '06:00', endTime: '14:00' },
        { name: 'Afternoon', startTime: '14:00', endTime: '22:00' },
        { name: 'Night', startTime: '22:00', endTime: '06:00' },
      ];
      for (const s of shifts) {
        await Shift.findOrCreate({ where: { name: s.name }, defaults: { ...s, plant: 'Zamil Plastics' } });
      }

      // Work Orders
      const wos = [
        { woNumber: 'FPP-WO-414', product: 'HDPE Film 200µm', productCode: 'FPP-200', customer: 'Zamil Steel', plannedQty: 15000, producedQty: 11200, status: 'active' },
        { woNumber: 'FPP-WO-494', product: 'LDPE Liner Bag 100µm', productCode: 'FPP-100', customer: 'Saudi Aramco', plannedQty: 8000, producedQty: 3400, status: 'active' },
        { woNumber: 'FPP-WO-477', product: 'PP Woven Sack 50kg', productCode: 'FPP-WS50', customer: 'SABIC', plannedQty: 5000, producedQty: 5000, status: 'completed' },
        { woNumber: 'IPP-WO-221', product: 'PP Crate 60L Blue', productCode: 'IPP-C60B', customer: 'Al-Marai', plannedQty: 2000, producedQty: 1650, status: 'active' },
        { woNumber: 'IPP-WO-198', product: 'HDPE Jerry Can 20L', productCode: 'IPP-JC20', customer: 'Saudi Exports', plannedQty: 3000, producedQty: 2900, status: 'active' },
      ];
      for (const wo of wos) {
        await WorkOrder.findOrCreate({ where: { woNumber: wo.woNumber }, defaults: { ...wo, plant: 'Zamil Plastics', scheduledDate: new Date() } });
      }

      // System configs
      await SystemConfig.findOrCreate({ where: { key: 'default_box_qty' }, defaults: { key: 'default_box_qty', value: '50', category: 'packing', description: 'Default pieces per box' } });
      await SystemConfig.findOrCreate({ where: { key: 'app_name' }, defaults: { key: 'app_name', value: 'Zamil MES System', category: 'general' } });
      await SystemConfig.findOrCreate({ where: { key: 'plant_name' }, defaults: { key: 'plant_name', value: 'Zamil Plastics Factory', category: 'general' } });
    }

    return success(res, { adminId: admin.id }, 'Data seeded successfully');
  } catch (err) {
    logger.error('Seed error:', err);
    return error(res, `Seed error: ${err.message}`);
  }
};

// ── Step 4 — finalize install ─────────────────────────────────────────────
export const finalizeInstall = async (req, res) => {
  try {
    // In production, write APP_INSTALLED=true to .env or a flag file
    logger.info('Installation finalized');
    return success(res, { installed: true }, 'Installation complete. Please restart the server.');
  } catch (err) {
    return error(res, err.message);
  }
};

export const checkInstall = async (req, res) => {
  return success(res, { installed: env.APP_INSTALLED });
};

export default { testConnection, createSchema, seedData, finalizeInstall, checkInstall };
