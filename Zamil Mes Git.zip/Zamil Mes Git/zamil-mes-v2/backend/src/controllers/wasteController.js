import { getModels } from '../models/index.js';
import { success, created, notFound, error, paginated } from '../utils/response.js';

const mapRecord = (r) => ({
  id:     r.id,
  time:   r.createdAt ? new Date(r.createdAt).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }) : '—',
  wo:     r.workOrder?.woNumber || r.woId || '—',
  cmp:    r.wasteType   || '—',
  qty:    r.quantity    || 0,
  uom:    r.unit        || 'KG',
  reason: r.category    || '—',
  by:     r.createdBy   || '—',
  type:   r.disposalMethod || 'scrap',
  notes:  r.notes,
  costTotal: r.totalCost,
});

export const getWasteRecords = async (req, res) => {
  try {
    const { WasteRecord, WorkOrder } = getModels();
    const { page = 1, limit = 50, woId, machineId, category } = req.query;
    const where = { isDeleted: false };
    if (woId)      where.woId      = woId;
    if (machineId) where.machineId = machineId;
    if (category)  where.category  = category;
    const result = await WasteRecord.findAndCountAll({
      where,
      limit: parseInt(limit),
      offset: (parseInt(page) - 1) * parseInt(limit),
      order: [['createdAt', 'DESC']],
      include: [{ model: WorkOrder, as: 'workOrder', attributes: ['woNumber'], required: false }],
    });
    const mapped = { ...result, rows: result.rows.map(mapRecord) };
    return paginated(res, mapped, page, limit);
  } catch (err) {
    return error(res, err.message);
  }
};

export const createWasteRecord = async (req, res) => {
  try {
    const { WasteRecord } = getModels();
    const { component, reason, mode, qty, subinv, locator, ...rest } = req.body;
    const record = await WasteRecord.create({
      ...rest,
      wasteType:      component || rest.wasteType,
      quantity:       qty       || rest.quantity,
      unit:           rest.unit || 'KG',
      category:       reason    || rest.category,
      disposalMethod: mode      || rest.disposalMethod || 'scrap',
      notes:          rest.notes,
      recordedById:   req.user?.id,
      createdBy:      req.user?.username || req.user?.empId,
    });
    return created(res, mapRecord(record), 'Waste record created');
  } catch (err) {
    return error(res, err.message);
  }
};

export const updateWasteRecord = async (req, res) => {
  try {
    const { WasteRecord } = getModels();
    const rec = await WasteRecord.findOne({ where: { id: req.params.id, isDeleted: false } });
    if (!rec) return notFound(res);
    await rec.update({ ...req.body, updatedBy: req.user?.username });
    return success(res, null, 'Waste record updated');
  } catch (err) {
    return error(res, err.message);
  }
};

export const deleteWasteRecord = async (req, res) => {
  try {
    const { WasteRecord } = getModels();
    const rec = await WasteRecord.findOne({ where: { id: req.params.id, isDeleted: false } });
    if (!rec) return notFound(res);
    await rec.update({ isDeleted: true });
    return success(res, null, 'Waste record deleted');
  } catch (err) {
    return error(res, err.message);
  }
};

export const getWasteSummary = async (req, res) => {
  try {
    const { WasteRecord, sequelize } = getModels();
    const { Op } = await import('sequelize');
    const today = new Date(); today.setHours(0,0,0,0);
    const todayRecords = await WasteRecord.findAll({
      where: { isDeleted: false, createdAt: { [Op.gte]: today } },
    });
    const totalQty    = todayRecords.reduce((s, r) => s + (r.quantity || 0), 0);
    const totalCost   = todayRecords.reduce((s, r) => s + (r.totalCost || 0), 0);
    const returns     = todayRecords.filter(r => r.disposalMethod === 'return').length;
    // Top reason
    const reasonCounts = {};
    todayRecords.forEach(r => { if (r.category) reasonCounts[r.category] = (reasonCounts[r.category] || 0) + 1; });
    const topReason = Object.entries(reasonCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || '—';
    return success(res, { totalQty, totalCost, returns, topReason, count: todayRecords.length });
  } catch (err) {
    return error(res, err.message);
  }
};

export default { getWasteRecords, createWasteRecord, updateWasteRecord, deleteWasteRecord, getWasteSummary };
