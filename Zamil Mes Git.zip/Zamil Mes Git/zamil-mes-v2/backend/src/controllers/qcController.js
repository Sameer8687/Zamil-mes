import { getModels } from '../models/index.js';
import { success, created, notFound, error, paginated } from '../utils/response.js';

export const getQCResults = async (req, res) => {
  try {
    const { QCResult } = getModels();
    const { page = 1, limit = 50, woId, machineId, result: overallResult } = req.query;
    const where = { isDeleted: false };
    if (woId) where.woId = woId;
    if (machineId) where.machineId = machineId;
    if (overallResult) where.overallResult = overallResult;
    const res2 = await QCResult.findAndCountAll({
      where, limit: parseInt(limit),
      offset: (parseInt(page) - 1) * parseInt(limit),
      order: [['createdAt', 'DESC']],
    });
    return paginated(res, res2, page, limit);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getQCResult = async (req, res) => {
  try {
    const { QCResult } = getModels();
    const qc = await QCResult.findOne({ where: { id: req.params.id, isDeleted: false } });
    if (!qc) return notFound(res, 'QC record not found');
    return success(res, qc);
  } catch (err) {
    return error(res, err.message);
  }
};

export const createQCResult = async (req, res) => {
  try {
    const { QCResult } = getModels();
    const qc = await QCResult.create({ ...req.body, inspectorId: req.user?.id, createdBy: req.user?.username });
    return created(res, qc, 'QC result recorded');
  } catch (err) {
    return error(res, err.message);
  }
};

export const updateQCResult = async (req, res) => {
  try {
    const { QCResult } = getModels();
    const qc = await QCResult.findOne({ where: { id: req.params.id, isDeleted: false } });
    if (!qc) return notFound(res);
    await qc.update({ ...req.body, updatedBy: req.user?.username });
    return success(res, null, 'QC result updated');
  } catch (err) {
    return error(res, err.message);
  }
};

export const getQCSummary = async (req, res) => {
  try {
    const { QCResult } = getModels();
    const { sequelize } = await import('../config/db.js');
    const summary = await QCResult.findAll({
      where: { isDeleted: false },
      attributes: [
        'overallResult',
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
      ],
      group: ['overallResult'],
    });
    return success(res, summary);
  } catch (err) {
    return error(res, err.message);
  }
};

export default { getQCResults, getQCResult, createQCResult, updateQCResult, getQCSummary };
