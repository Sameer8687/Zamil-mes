import { getModels } from '../models/index.js';
import { success, created, notFound, error, paginated } from '../utils/response.js';

const mapStock = (r) => ({
  id: r.id,
  org: r.org || 'Zamil Operations',
  plant: r.plant,
  machine: r.machine,
  product: r.productName,
  wo: r.woNum,
  qty: r.quantity,
  boxNo: r.boxNo,
  pallet: r.palletCode || '—',
  locator: r.locatorCode,
  printedAt: r.createdAt ? r.createdAt.toISOString().slice(0, 16).replace('T', ' ') : '',
  qcStatus: r.qcStatus || 'pend',
  status: r.status,
});

export const getStockRecords = async (req, res) => {
  try {
    const { StockRecord } = getModels();
    const { page = 1, limit = 50, status, qcStatus, plant } = req.query;
    const where = { isDeleted: false };
    if (status) where.status = status;
    if (qcStatus) where.qcStatus = qcStatus;
    if (plant) where.plant = plant;
    const result = await StockRecord.findAndCountAll({
      where,
      limit: parseInt(limit),
      offset: (parseInt(page) - 1) * parseInt(limit),
      order: [['createdAt', 'DESC']],
    });
    const mapped = result.rows.map(mapStock);
    return paginated(res, { count: result.count, rows: mapped }, page, limit);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getStockRecord = async (req, res) => {
  try {
    const { StockRecord } = getModels();
    const rec = await StockRecord.findOne({ where: { id: req.params.id, isDeleted: false } });
    if (!rec) return notFound(res, 'Stock record not found');
    return success(res, mapStock(rec));
  } catch (err) {
    return error(res, err.message);
  }
};

export const createStockRecord = async (req, res) => {
  try {
    const { StockRecord } = getModels();
    const rec = await StockRecord.create({
      ...req.body,
      createdBy: req.user?.username,
      receivedAt: new Date(),
    });
    return created(res, mapStock(rec), 'Stock record created');
  } catch (err) {
    return error(res, err.message);
  }
};

export const updateStockRecord = async (req, res) => {
  try {
    const { StockRecord } = getModels();
    const rec = await StockRecord.findOne({ where: { id: req.params.id, isDeleted: false } });
    if (!rec) return notFound(res);
    if (req.body.status === 'dispatched' && !rec.dispatchedAt) req.body.dispatchedAt = new Date();
    await rec.update({ ...req.body, updatedBy: req.user?.username });
    return success(res, null, 'Stock record updated');
  } catch (err) {
    return error(res, err.message);
  }
};

export const getStockSummary = async (req, res) => {
  try {
    const { StockRecord } = getModels();
    const { sequelize } = await import('../config/db.js');
    const summary = await StockRecord.findAll({
      where: { isDeleted: false },
      attributes: [
        'qcStatus',
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
        [sequelize.fn('SUM', sequelize.col('quantity')), 'totalQty'],
      ],
      group: ['qcStatus'],
    });
    return success(res, summary);
  } catch (err) {
    return error(res, err.message);
  }
};

export default { getStockRecords, getStockRecord, createStockRecord, updateStockRecord, getStockSummary };
