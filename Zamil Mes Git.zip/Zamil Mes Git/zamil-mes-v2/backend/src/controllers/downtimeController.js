import { getModels } from '../models/index.js';
import { success, created, notFound, error, paginated } from '../utils/response.js';

export const getDowntimeRecords = async (req, res) => {
  try {
    const { DowntimeRecord } = getModels();
    const { page = 1, limit = 50, org, machine, status } = req.query;
    const where = { isDeleted: false };
    if (org) where.org = org;
    if (machine) where.machine = machine;
    if (status) where.status = status;
    const result = await DowntimeRecord.findAndCountAll({
      where,
      limit: parseInt(limit),
      offset: (parseInt(page) - 1) * parseInt(limit),
      order: [['createdAt', 'DESC']],
    });
    const mapped = result.rows.map((r, i) => ({
      id: r.id,
      resId: `DT-${String(r.id).slice(-6).toUpperCase()}`,
      org: r.org,
      machine: r.machine,
      date: r.date,
      product: r.product,
      desc: r.desc,
      shift: r.shift,
      dtType: r.dtType,
      category: r.category,
      process: r.process,
      reason: r.reason,
      hrs: r.hours,
      min: r.minute,
    }));
    return paginated(res, { count: result.count, rows: mapped }, page, limit);
  } catch (err) {
    return error(res, err.message);
  }
};

export const createDowntimeRecord = async (req, res) => {
  try {
    const { DowntimeRecord } = getModels();
    const record = await DowntimeRecord.create({
      ...req.body,
      reportedById: req.user?.id,
      createdBy: req.user?.username,
    });
    return created(res, {
      id: record.id,
      resId: `DT-${String(record.id).slice(-6).toUpperCase()}`,
      org: record.org,
      machine: record.machine,
      date: record.date,
      product: record.product,
      desc: record.desc,
      shift: record.shift,
      dtType: record.dtType,
      category: record.category,
      process: record.process,
      reason: record.reason,
      hrs: record.hours,
      min: record.minute,
    }, 'Downtime recorded');
  } catch (err) {
    return error(res, err.message);
  }
};

export const updateDowntimeRecord = async (req, res) => {
  try {
    const { DowntimeRecord } = getModels();
    const rec = await DowntimeRecord.findOne({ where: { id: req.params.id, isDeleted: false } });
    if (!rec) return notFound(res);
    if (req.body.status === 'resolved') {
      req.body.resolvedById = req.user?.id;
      if (rec.startTime && !req.body.endTime) req.body.endTime = new Date();
      if (rec.startTime && req.body.endTime) {
        req.body.durationMinutes = Math.round(
          (new Date(req.body.endTime) - new Date(rec.startTime)) / 60000
        );
      }
    }
    await rec.update({ ...req.body, updatedBy: req.user?.username });
    return success(res, null, 'Downtime record updated');
  } catch (err) {
    return error(res, err.message);
  }
};

export const getDowntimeSummary = async (req, res) => {
  try {
    const { DowntimeRecord } = getModels();
    const { sequelize } = await import('../config/db.js');
    const summary = await DowntimeRecord.findAll({
      where: { isDeleted: false },
      attributes: [
        'category',
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
        [sequelize.fn('SUM', sequelize.col('hours')), 'totalHours'],
        [sequelize.fn('SUM', sequelize.col('minute')), 'totalMinutes'],
      ],
      group: ['category'],
    });
    return success(res, summary);
  } catch (err) {
    return error(res, err.message);
  }
};

export default { getDowntimeRecords, createDowntimeRecord, updateDowntimeRecord, getDowntimeSummary };
