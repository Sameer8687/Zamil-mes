import { getModels } from '../models/index.js';
import { success, created, notFound, error, paginated } from '../utils/response.js';
import { v4 as uuidv4 } from 'uuid';

// ── Boxes ─────────────────────────────────────────────────────────────────
export const getBoxes = async (req, res) => {
  try {
    const { Box, WorkOrder } = getModels();
    const where = { isDeleted: false };
    if (req.query.woId)     where.woId     = req.query.woId;
    if (req.query.status)   where.status   = req.query.status;
    if (req.query.qcStatus) where.qcStatus = req.query.qcStatus;
    const boxes = await Box.findAll({
      where,
      order: [['createdAt', 'ASC']],
      limit: 500,
      include: [{ model: WorkOrder, as: 'workOrder', attributes: ['woNumber', 'product'], required: false }],
    });
    const mapped = boxes.map((b, i) => ({
      ...b.toJSON(),
      boxNumber: String(i + 1).padStart(2, '0'),
      woNumber: b.workOrder?.woNumber || null,
      product:  b.workOrder?.product  || null,
    }));
    return success(res, mapped);
  } catch (err) {
    return error(res, err.message);
  }
};

export const createBox = async (req, res) => {
  try {
    const { Box } = getModels();

    const barcode = req.body.labelSeq || `BOX-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

    const box = await Box.create({
      ...req.body,
      barcode,
      labelPrinted: true,
      printedAt: new Date(),
      packedById: req.user?.id,
      createdBy: req.user?.username,
      packedAt: new Date(),
    });

    return created(res, box, 'Box label printed');
  } catch (err) {
    return error(res, err.message);
  }
};

export const updateBox = async (req, res) => {
  try {
    const { Box } = getModels();
    const box = await Box.findOne({ where: { id: req.params.id, isDeleted: false } });
    if (!box) return notFound(res, 'Box not found');
    await box.update({ ...req.body, updatedBy: req.user?.username });
    return success(res, null, 'Box updated');
  } catch (err) {
    return error(res, err.message);
  }
};

// ── Pallets ───────────────────────────────────────────────────────────────
export const getPallets = async (req, res) => {
  try {
    const { Pallet, Box } = getModels();
    const where = { isDeleted: false };
    if (req.query.woId) where.woId = req.query.woId;
    const pallets = await Pallet.findAll({
      where,
      include: [{ model: Box, as: 'boxes', where: { isDeleted: false }, required: false }],
      order: [['createdAt', 'DESC']],
    });
    return success(res, pallets);
  } catch (err) {
    return error(res, err.message);
  }
};

export const createPallet = async (req, res) => {
  try {
    const { Pallet } = getModels();
    const palletNumber = `PLT-${Date.now()}`;
    const pallet = await Pallet.create({
      ...req.body,
      palletNumber,
      createdById: req.user?.id,
      createdBy: req.user?.username,
    });
    return created(res, pallet, 'Pallet created');
  } catch (err) {
    return error(res, err.message);
  }
};

export const addBoxToPallet = async (req, res) => {
  try {
    const { Pallet, Box } = getModels();
    const pallet = await Pallet.findOne({ where: { id: req.params.id, isDeleted: false } });
    if (!pallet) return notFound(res, 'Pallet not found');
    const box = await Box.findOne({ where: { id: req.body.boxId, isDeleted: false } });
    if (!box) return notFound(res, 'Box not found');

    await box.update({ palletId: pallet.id, status: 'palletized' });
    await pallet.increment('boxCount');
    await pallet.increment('totalQty', { by: box.quantity });
    return success(res, null, 'Box added to pallet');
  } catch (err) {
    return error(res, err.message);
  }
};

export const finalizePallet = async (req, res) => {
  try {
    const { Pallet } = getModels();
    const pallet = await Pallet.findOne({ where: { id: req.params.id, isDeleted: false } });
    if (!pallet) return notFound(res);
    await pallet.update({ status: 'complete', labelPrinted: true, updatedBy: req.user?.username });
    return success(res, pallet, 'Pallet finalized');
  } catch (err) {
    return error(res, err.message);
  }
};

export default { getBoxes, createBox, updateBox, getPallets, createPallet, addBoxToPallet, finalizePallet };
