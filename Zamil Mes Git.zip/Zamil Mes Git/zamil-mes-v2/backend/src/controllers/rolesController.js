import { Op } from "sequelize";
import { getModels } from "../models/index.js";
import {
  success,
  created,
  notFound,
  badRequest,
  error,
  paginated,
} from "../utils/response.js";

const allowedFields = [
  "code",
  "name",
  "description",
  "permissions",
  "icon",
  "color",
  "isSystem",
  "isActive",
];

const buildPayload = (body, username) => {
  const payload = {};

  allowedFields.forEach((field) => {
    if (body[field] !== undefined) payload[field] = body[field];
  });

  if (typeof payload.permissions === "string") {
    payload.permissions = JSON.parse(payload.permissions || "{}");
  }

  if (payload.code === "") payload.code = null;
  if (payload.icon === "") payload.icon = null;
  if (payload.color === "") payload.color = null;

  return payload;
};

export const getRoles = async (req, res) => {
  try {
    const { Role } = getModels();
    const {
      page = 1,
      limit = 50,
      search,
      isActive,
      includeDeleted = "false",
    } = req.query;

    const where = {};

    if (includeDeleted !== "true") where.isDeleted = false;

    if (isActive !== undefined) {
      where.isActive = isActive === "true" || isActive === "1";
    }

    if (search) {
      where[Op.or] = [
        { name: { [Op.like]: `%${search}%` } },
        { code: { [Op.like]: `%${search}%` } },
        { description: { [Op.like]: `%${search}%` } },
      ];
    }

    const result = await Role.findAndCountAll({
      where,
      limit: Number(limit),
      offset: (Number(page) - 1) * Number(limit),
      order: [["role_id", "ASC"]],
    });

    return paginated(res, result, page, limit);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getRole = async (req, res) => {
  try {
    const { Role } = getModels();

    const role = await Role.findOne({
      where: {
        [Op.or]: [{ id: req.params.id }, { role_id: req.params.id }],
        isDeleted: false,
      },
    });

    if (!role) return notFound(res, "Role not found");

    return success(res, role);
  } catch (err) {
    return error(res, err.message);
  }
};

export const createRole = async (req, res) => {
  try {
    const { Role } = getModels();

    if (!req.body.name) {
      return badRequest(res, "Role name is required");
    }

    const payload = buildPayload(req.body, req.user?.username);

    const role = await Role.create({
      ...payload,
      createdBy: req.user?.username,
      updatedBy: req.user?.username,
      isActive: payload.isActive ?? true,
      isDeleted: false,
    });

    return created(res, role, "Role created");
  } catch (err) {
    if (err.name === "SequelizeUniqueConstraintError") {
      return badRequest(res, "Role name or code already exists");
    }
    return error(res, err.message);
  }
};

export const updateRole = async (req, res) => {
  try {
    const { Role } = getModels();

    const role = await Role.findOne({
      where: {
        [Op.or]: [{ id: req.params.id }, { role_id: req.params.id }],
        isDeleted: false,
      },
    });

    if (!role) return notFound(res, "Role not found");

    const payload = buildPayload(req.body, req.user?.username);

    await role.update({
      ...payload,
      updatedBy: req.user?.username,
    });

    return success(res, role, "Role updated");
  } catch (err) {
    if (err.name === "SequelizeUniqueConstraintError") {
      return badRequest(res, "Role name or code already exists");
    }
    return error(res, err.message);
  }
};

export const deleteRole = async (req, res) => {
  try {
    const { Role, UserRole } = getModels();

    const role = await Role.findOne({
      where: {
        [Op.or]: [{ id: req.params.id }, { role_id: req.params.id }],
        isDeleted: false,
      },
    });

    if (!role) return notFound(res, "Role not found");

    if (role.isSystem) {
      return badRequest(res, "System role cannot be deleted");
    }

    const assignedCount = await UserRole.count({
      where: { role_id: role.role_id },
    });

    if (assignedCount > 0) {
      return badRequest(
        res,
        "Role is assigned to users. Remove user role mapping first.",
      );
    }

    await role.update({
      isDeleted: true,
      isActive: false,
      updatedBy: req.user?.username,
    });

    return success(res, null, "Role deleted");
  } catch (err) {
    return error(res, err.message);
  }
};

export const toggleRoleStatus = async (req, res) => {
  try {
    const { Role } = getModels();

    const role = await Role.findOne({
      where: {
        [Op.or]: [{ id: req.params.id }, { role_id: req.params.id }],
        isDeleted: false,
      },
    });

    if (!role) return notFound(res, "Role not found");

    await role.update({
      isActive: !role.isActive,
      updatedBy: req.user?.username,
    });

    return success(res, role, "Role status updated");
  } catch (err) {
    return error(res, err.message);
  }
};

export const updateRolePermissions = async (req, res) => {
  try {
    const { Role } = getModels();

    const role = await Role.findOne({
      where: {
        [Op.or]: [{ id: req.params.id }, { role_id: req.params.id }],
        isDeleted: false,
      },
    });

    if (!role) return notFound(res, "Role not found");

    await role.update({
      permissions: req.body.permissions || {},
      updatedBy: req.user?.username,
    });

    return success(res, role, "Role permissions updated");
  } catch (err) {
    return error(res, err.message);
  }
};
