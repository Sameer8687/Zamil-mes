import { getModels } from '../models/index.js';
import { success, created, notFound, error, paginated } from '../utils/response.js';

const mapLC = (r) => ({
  id: r.id,
  plant: r.plant,
  machine: r.machine,
  jobOrder: r.jobOrder,
  date: r.submissionDate || (r.createdAt ? r.createdAt.toISOString().slice(0, 10) : null),
  productCode: r.productCode,
  productName: r.productName,
  shift: r.submissionShift,
  type: r.clearanceType,
  checked: `${r.checkedCount || 0}/${r.checkedTotal || 0}`,
  tech: r.techName,
  qi: r.qiName,
  requestNo: r.requestNo,
  status: r.status ? (r.status.charAt(0).toUpperCase() + r.status.slice(1)) : 'Draft',
  checklistData: r.checklistData,
  note: r.note,
  controlNbr: r.controlNbr,
});

export const getLineClearances = async (req, res) => {
  try {
    const { LineClearance } = getModels();
    const { page = 1, limit = 50, status, plant, machine } = req.query;
    const where = { isDeleted: false };
    if (status) where.status = status.toLowerCase();
    if (plant) where.plant = plant;
    if (machine) where.machine = machine;
    const result = await LineClearance.findAndCountAll({
      where,
      limit: parseInt(limit),
      offset: (parseInt(page) - 1) * parseInt(limit),
      order: [['createdAt', 'DESC']],
    });
    const mapped = result.rows.map(mapLC);
    return paginated(res, { count: result.count, rows: mapped }, page, limit);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getLineClearance = async (req, res) => {
  try {
    const { LineClearance } = getModels();
    const lc = await LineClearance.findOne({ where: { id: req.params.id, isDeleted: false } });
    if (!lc) return notFound(res, 'Line clearance not found');
    return success(res, mapLC(lc));
  } catch (err) {
    return error(res, err.message);
  }
};

export const createLineClearance = async (req, res) => {
  try {
    const { LineClearance } = getModels();
    const { checks, totalItems, completedItems, status: frontStatus, reqNo, comment, ...rest } = req.body;
    const lc = await LineClearance.create({
      ...rest,
      requestNo: reqNo || rest.requestNo,
      note: comment || rest.note,
      checklistData: checks || {},
      checkedCount: completedItems || 0,
      checkedTotal: totalItems || 0,
      status: (frontStatus || 'draft').toLowerCase(),
      conductedById: req.user?.id,
      createdBy: req.user?.username,
    });
    return created(res, mapLC(lc), 'Line clearance created');
  } catch (err) {
    return error(res, err.message);
  }
};

export const updateLineClearance = async (req, res) => {
  try {
    const { LineClearance } = getModels();
    const lc = await LineClearance.findOne({ where: { id: req.params.id, isDeleted: false } });
    if (!lc) return notFound(res);
    const { checks, totalItems, completedItems, status: frontStatus, reqNo, comment, ...rest } = req.body;
    const updateData = {
      ...rest,
      updatedBy: req.user?.username,
    };
    if (checks !== undefined) updateData.checklistData = checks;
    if (completedItems !== undefined) updateData.checkedCount = completedItems;
    if (totalItems !== undefined) updateData.checkedTotal = totalItems;
    if (reqNo !== undefined) updateData.requestNo = reqNo;
    if (comment !== undefined) updateData.note = comment;
    if (frontStatus) {
      updateData.status = frontStatus.toLowerCase();
      if (frontStatus.toLowerCase() === 'submitted') updateData.submittedAt = new Date();
    }
    await lc.update(updateData);
    return success(res, null, 'Line clearance updated');
  } catch (err) {
    return error(res, err.message);
  }
};

export const approveLineClearance = async (req, res) => {
  try {
    const { LineClearance } = getModels();
    const lc = await LineClearance.findOne({ where: { id: req.params.id, isDeleted: false } });
    if (!lc) return notFound(res);
    const { action, reason } = req.body;
    await lc.update({
      status: action === 'approve' ? 'approved' : 'rejected',
      approvedById: req.user?.id,
      approvedAt: action === 'approve' ? new Date() : null,
      rejectionReason: action === 'reject' ? reason : null,
      updatedBy: req.user?.username,
    });
    return success(res, null, `Line clearance ${action}d`);
  } catch (err) {
    return error(res, err.message);
  }
};

export default { getLineClearances, getLineClearance, createLineClearance, updateLineClearance, approveLineClearance };
