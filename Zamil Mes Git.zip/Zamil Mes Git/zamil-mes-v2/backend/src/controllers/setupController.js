import { Op } from 'sequelize';
import { getModels } from '../models/index.js';
import { success, created, notFound, error } from '../utils/response.js';

const STATUS_TO_DISPLAY = { running: 'Running', idle: 'Idle', maintenance: 'Maintenance', breakdown: 'Fault' };
const STATUS_TO_DB = { Running: 'running', Idle: 'idle', Maintenance: 'maintenance', Fault: 'breakdown' };

const mapMachine = (m) => ({
  id: m.id,
  machineId: m.code,
  name: m.name,
  type: m.type,
  plant: m.plant,
  dept: m.dept,
  area: m.area,
  locator: m.locator,
  oem: m.oem,
  model: m.model,
  serial: m.serial,
  tonnage: m.tonnage,
  cycleTime: m.cycleTime,
  cavities: m.cavities,
  ip: m.ip,
  plcType: m.plcType,
  commProtocol: m.commProtocol,
  mesCode: m.mesCode,
  pmFreq: m.pmFreq,
  lastPmDate: m.lastPmDate,
  status: STATUS_TO_DISPLAY[m.status] || 'Idle',
});

// ── Machines ──────────────────────────────────────────────────────────────
export const getMachines = async (req, res) => {
  try {
    const { Machine } = getModels();
    const machines = await Machine.findAll({ where: { isDeleted: false }, order: [['code', 'ASC']] });
    return success(res, machines.map(mapMachine));
  } catch (err) { return error(res, err.message); }
};

export const createMachine = async (req, res) => {
  try {
    const { Machine } = getModels();
    const { machineId, status, ...rest } = req.body;
    const m = await Machine.create({
      ...rest,
      code: machineId || rest.code,
      status: STATUS_TO_DB[status] || status?.toLowerCase() || 'idle',
      createdBy: req.user?.username,
    });
    return created(res, mapMachine(m), 'Machine created');
  } catch (err) { return error(res, err.message); }
};

export const updateMachine = async (req, res) => {
  try {
    const { Machine } = getModels();
    const m = await Machine.findOne({ where: { id: req.params.id, isDeleted: false } });
    if (!m) return notFound(res, 'Machine not found');
    const { machineId, status, ...rest } = req.body;
    await m.update({
      ...rest,
      code: machineId || rest.code || m.code,
      status: STATUS_TO_DB[status] || status?.toLowerCase() || m.status,
      updatedBy: req.user?.username,
    });
    return success(res, mapMachine(m), 'Machine updated');
  } catch (err) { return error(res, err.message); }
};

export const deleteMachine = async (req, res) => {
  try {
    const { Machine } = getModels();
    const m = await Machine.findOne({ where: { id: req.params.id, isDeleted: false } });
    if (!m) return notFound(res);
    await m.update({ isDeleted: true });
    return success(res, null, 'Machine deleted');
  } catch (err) { return error(res, err.message); }
};

// ── Locations ─────────────────────────────────────────────────────────────
const LOC_ZONE_VALUES = ['PRD', 'SIL', 'STG', 'ASM', 'QA', 'RJT', 'HLD'];
const LOC_DIV_VALUES = ['FPP', 'IPP', 'ZPC'];

const normalizeDiv = (value) => {
  const v = String(value || '').trim().toUpperCase().replace(' BU', '');
  return LOC_DIV_VALUES.includes(v) ? v : 'FPP';
};

const normalizeZone = (value) => {
  const v = String(value || '').trim().toUpperCase();
  if (['PRODUCTION', 'PROD', 'MACHINE'].includes(v)) return 'PRD';
  if (v === 'SILO') return 'SIL';
  if (['WAREHOUSE', 'WH', 'STAGING'].includes(v)) return 'STG';
  if (v === 'ASSEMBLY') return 'ASM';
  if (['QUALITY', 'QC'].includes(v)) return 'QA';
  if (['SCRAP', 'REJECT', 'REJECTED'].includes(v)) return 'RJT';
  if (['HOLD', 'BLOCKED'].includes(v)) return 'HLD';
  return LOC_ZONE_VALUES.includes(v) ? v : 'PRD';
};

const cleanCodePart = (value) => String(value || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '');

const buildLocatorCode = ({ zone, area, section, level }) => {
  const code = `${normalizeZone(zone)}${cleanCodePart(area)}${cleanCodePart(section)}${cleanCodePart(level || 'L1')}`;
  return code || `PRDLOC${Date.now()}`;
};

const parseAuthUsers = (value) => {
  if (Array.isArray(value)) return value;
  if (!value) return [];
  if (typeof value === 'string') {
    try {
      const parsed = JSON.parse(value);
      if (Array.isArray(parsed)) return parsed;
    } catch (_) {
      return value.split(',').map(v => v.trim()).filter(Boolean);
    }
  }
  return [];
};

const mapLocation = (loc) => {
  const json = loc.toJSON ? loc.toJSON() : loc;
  const division = normalizeDiv(json.division || json.plant || json.div);
  const zone = normalizeZone(json.type || json.zone || json.locationZone || json.plant);
  const area = json.area || json.name || '';
  const section = json.section || '';
  const level = json.level || 'L1';
  const locator = (json.locator || json.code || buildLocatorCode({ zone, area, section, level })).toUpperCase();
  const barcode = (json.barcode || `LOC-${locator}`).toUpperCase();

  return {
    id: json.id,
    code: locator,
    name: json.name || area,
    type: zone,
    plant: zone,
    zone,
    div: division,
    division,
    area,
    section,
    level,
    locator,
    barcode,
    locType: json.locType || 'FLOOR',
    status: json.status || (json.isActive === false ? 'Inactive' : 'Active'),
    minUnits: Number(json.minUnits || 0),
    maxUnits: Number(json.maxUnits || 0),
    maxLPN: Number(json.maxLPN || 9),
    usedLPN: Number(json.usedLPN || 0),
    uom: json.uom || 'BOX',
    multiSKU: json.multiSKU || 'Yes',
    partialPick: json.partialPick || 'Yes',
    specificSKU: json.specificSKU || '',
    maxWeight: Number(json.maxWeight || 2000),
    owner: json.owner || '',
    authUsers: parseAuthUsers(json.authUsers),
    access: json.accessRestriction || 'AuthList',
    accessRestriction: json.accessRestriction || 'AuthList',
    notes: json.notes || '',
    createdBy: json.createdBy,
    updatedBy: json.updatedBy,
    isActive: json.isActive,
    isDeleted: json.isDeleted,
    createdAt: json.createdAt,
    updatedAt: json.updatedAt,
  };
};

const buildLocationPayload = (body = {}, user) => {
  const division = normalizeDiv(body.division || body.div || body.org || body.plant);
  const zone = normalizeZone(body.zone || body.locationZone || body.type || body.locPlant || body.plantZone);
  const area = String(body.area || body.name || '').trim().toUpperCase();
  const section = String(body.section || '').trim().toUpperCase();
  const level = String(body.level || 'L1').trim().toUpperCase();
  const locator = String(body.locator || body.code || buildLocatorCode({ zone, area, section, level })).trim().toUpperCase();
  const barcode = String(body.barcode || `LOC-${locator}`).trim().toUpperCase();
  const maxLPN = Number(body.maxLPN) || 9;
  const usedLPN = Math.min(maxLPN, Number(body.usedLPN) || 0);
  const status = body.status || (body.isActive === false ? 'Inactive' : 'Active');

  return {
    code: locator,
    name: area || locator,
    type: zone,
    plant: division,
    division,
    area,
    section,
    level,
    locator,
    barcode,
    locType: body.locType || 'FLOOR',
    status,
    minUnits: Number(body.minUnits) || 0,
    maxUnits: Number(body.maxUnits) || maxLPN * 500,
    maxLPN,
    usedLPN,
    uom: body.uom || 'BOX',
    multiSKU: body.multiSKU || 'Yes',
    partialPick: body.partialPick || 'Yes',
    specificSKU: body.specificSKU || null,
    maxWeight: Number(body.maxWeight) || 2000,
    owner: body.owner || null,
    authUsers: parseAuthUsers(body.authUsers),
    accessRestriction: body.accessRestriction || body.access || 'AuthList',
    notes: body.notes || null,
    isActive: status !== 'Inactive' && body.isActive !== false,
    ...(user ? { updatedBy: user.username } : {}),
  };
};

export const getLocations = async (req, res) => {
  try {
    const { Location } = getModels();
    const { div, division, plant, zone, type, status, search } = req.query;
    const where = { isDeleted: false };
    const divFilter = div || division;
    const zoneFilter = zone || type || plant;

    if (divFilter) where.plant = normalizeDiv(divFilter);
    if (zoneFilter) where.type = normalizeZone(zoneFilter);
    if (status) where.status = status;
    if (search) {
      const q = `%${search}%`;
      where[Op.or] = [
        { code: { [Op.like]: q } },
        { locator: { [Op.like]: q } },
        { barcode: { [Op.like]: q } },
        { name: { [Op.like]: q } },
        { area: { [Op.like]: q } },
        { owner: { [Op.like]: q } },
      ];
    }

    const locs = await Location.findAll({ where, order: [['code', 'ASC']] });
    return success(res, locs.map(mapLocation));
  } catch (err) { return error(res, err.message); }
};

export const createLocation = async (req, res) => {
  try {
    const { Location } = getModels();
    const payload = buildLocationPayload(req.body, req.user);
    if (!payload.area) return error(res, 'Area is required', 400);
    if (!payload.owner) return error(res, 'Primary owner is required', 400);
    const loc = await Location.create({ ...payload, createdBy: req.user?.username });
    return created(res, mapLocation(loc), 'Location created');
  } catch (err) { return error(res, err.message); }
};

export const updateLocation = async (req, res) => {
  try {
    const { Location } = getModels();
    const loc = await Location.findOne({ where: { id: req.params.id, isDeleted: false } });
    if (!loc) return notFound(res, 'Location not found');
    const payload = buildLocationPayload(req.body, req.user);
    if (!payload.area) return error(res, 'Area is required', 400);
    if (!payload.owner) return error(res, 'Primary owner is required', 400);
    await loc.update(payload);
    return success(res, mapLocation(loc), 'Location updated');
  } catch (err) { return error(res, err.message); }
};

export const deleteLocation = async (req, res) => {
  try {
    const { Location } = getModels();
    const loc = await Location.findOne({ where: { id: req.params.id, isDeleted: false } });
    if (!loc) return notFound(res, 'Location not found');
    await loc.update({ isDeleted: true, updatedBy: req.user?.username });
    return success(res, null, 'Location deleted');
  } catch (err) { return error(res, err.message); }
};

// ── Shifts ────────────────────────────────────────────────────────────────
export const getShifts = async (req, res) => {
  try {
    const { Shift } = getModels();
    const shifts = await Shift.findAll({ where: { isDeleted: false }, order: [['name', 'ASC']] });
    return success(res, shifts);
  } catch (err) { return error(res, err.message); }
};

export const createShift = async (req, res) => {
  try {
    const { Shift } = getModels();
    const s = await Shift.create({ ...req.body, createdBy: req.user?.username });
    return created(res, s, 'Shift created');
  } catch (err) { return error(res, err.message); }
};

export const updateShift = async (req, res) => {
  try {
    const { Shift } = getModels();
    const s = await Shift.findOne({ where: { id: req.params.id, isDeleted: false } });
    if (!s) return notFound(res);
    await s.update({ ...req.body, updatedBy: req.user?.username });
    return success(res, null, 'Shift updated');
  } catch (err) { return error(res, err.message); }
};

export const deleteShift = async (req, res) => {
  try {
    const { Shift } = getModels();
    const s = await Shift.findOne({ where: { id: req.params.id, isDeleted: false } });
    if (!s) return notFound(res);
    await s.update({ isDeleted: true });
    return success(res, null, 'Shift deleted');
  } catch (err) { return error(res, err.message); }
};

// ── System Config ─────────────────────────────────────────────────────────
export const getConfigs = async (req, res) => {
  try {
    const { SystemConfig } = getModels();
    const where = { isDeleted: false };
    if (req.query.category) where.category = req.query.category;
    const configs = await SystemConfig.findAll({ where });
    return success(res, configs);
  } catch (err) { return error(res, err.message); }
};

export const upsertConfig = async (req, res) => {
  try {
    const { SystemConfig } = getModels();
    const { key, value, category, description } = req.body;
    const [cfg, created_] = await SystemConfig.findOrCreate({
      where: { key },
      defaults: { key, value, category, description, createdBy: req.user?.username },
    });
    if (!created_) await cfg.update({ value, updatedBy: req.user?.username });
    return success(res, cfg, 'Config saved');
  } catch (err) { return error(res, err.message); }
};

// ── Box Qty Records ───────────────────────────────────────────────────────
export const getBoxQtyReport = async (req, res) => {
  try {
    const { BoxQtyRecord } = getModels();
    const { org, code } = req.query;
    const where = { isDeleted: false };
    if (org) where.org = org;
    if (code) where.productCode = { [Op.like]: `%${code}%` };
    const records = await BoxQtyRecord.findAll({ where, order: [['createdAt', 'DESC']] });
    const mapped = records.map(r => ({
      id: r.id,
      org: r.org,
      code: r.productCode,
      desc: r.productDesc,
      qty: r.qtyPerBox,
      effectiveDate: r.effectiveDate,
    }));
    return success(res, mapped);
  } catch (err) { return error(res, err.message); }
};

export const createBoxQtyRecord = async (req, res) => {
  try {
    const { BoxQtyRecord } = getModels();
    const { org, items = [], date: effectiveDate, user: createdByUser } = req.body;
    if (!org) return error(res, 'org is required', 400);
    const records = await Promise.all(items.map(it =>
      BoxQtyRecord.create({
        org,
        productCode: it.code,
        productDesc: it.desc,
        qtyPerBox: Number(it.qty) || 0,
        effectiveDate,
        createdBy: createdByUser || req.user?.username,
      })
    ));
    return created(res, records.map(r => ({ id: r.id, org: r.org, code: r.productCode, desc: r.productDesc, qty: r.qtyPerBox })),
      `${records.length} box quantity record(s) saved`);
  } catch (err) { return error(res, err.message); }
};

export const deleteBoxQtyRecord = async (req, res) => {
  try {
    const { BoxQtyRecord } = getModels();
    const rec = await BoxQtyRecord.findOne({ where: { id: req.params.id, isDeleted: false } });
    if (!rec) return notFound(res);
    await rec.update({ isDeleted: true });
    return success(res, null, 'Box qty record deleted');
  } catch (err) { return error(res, err.message); }
};

export default {
  getMachines, createMachine, updateMachine, deleteMachine,
  getLocations, createLocation, updateLocation, deleteLocation,
  getShifts, createShift, updateShift, deleteShift,
  getConfigs, upsertConfig,
  getBoxQtyReport, createBoxQtyRecord, deleteBoxQtyRecord,
};
