import { QueryTypes } from "sequelize";
import { getModels } from "../models/index.js";
import { success, error, notFound } from "../utils/response.js";

const buildTree = (rows, parentId = null) => {
  return rows
    .filter((row) => row.parent_id === parentId)
    .map((row) => ({
      id: row.code,
      dbId: row.id,
      name: row.name,
      icon: row.icon,
      unitType: row.unit_type,
      children: buildTree(rows, row.id),
    }));
};

const mapScreenPerms = (rows) => {
  const screens = {};

  rows.forEach((row) => {
    screens[row.code] = {
      view: !!row.can_view,
      create: !!row.can_create,
      edit: !!row.can_edit,
      delete: !!row.can_delete,
      export: !!row.can_export,
    };
  });

  return screens;
};

const mapFeaturePerms = (rows) => {
  const features = {};

  rows.forEach((row) => {
    features[row.code] = !!row.is_enabled;
  });

  return features;
};

const normalizeSecurity = (security = {}) => ({
  pwReset: security.pwReset || "none",
  pwStr: security.pwStr || "medium",
  lockout: String(security.lockout || "5"),
  timeout: String(security.timeout || "240"),
  hours: security.hours || "ANY",
  device: security.device || "ANY",
  audit: security.audit !== false,
  emailNotify: security.emailNotify !== false,
  twoFA: !!security.twoFA,
  ipRestrict: !!security.ipRestrict,
});

const saveSecuritySettings = async (
  sequelize,
  userId,
  security,
  transaction = null,
) => {
  const s = normalizeSecurity(security);

  await sequelize.query(
    `
    INSERT INTO user_security_settings
    (
      user_id,
      force_password_reset,
      password_strength,
      lockout_after,
      session_timeout_minutes,
      allowed_login_hours,
      allowed_device,
      audit_enabled,
      email_notify,
      two_fa_enabled,
      ip_restrict_enabled
    )
    VALUES
    (
      :userId,
      :pwReset,
      :pwStr,
      :lockout,
      :timeout,
      :hours,
      :device,
      :audit,
      :emailNotify,
      :twoFA,
      :ipRestrict
    )
    ON DUPLICATE KEY UPDATE
      force_password_reset = VALUES(force_password_reset),
      password_strength = VALUES(password_strength),
      lockout_after = VALUES(lockout_after),
      session_timeout_minutes = VALUES(session_timeout_minutes),
      allowed_login_hours = VALUES(allowed_login_hours),
      allowed_device = VALUES(allowed_device),
      audit_enabled = VALUES(audit_enabled),
      email_notify = VALUES(email_notify),
      two_fa_enabled = VALUES(two_fa_enabled),
      ip_restrict_enabled = VALUES(ip_restrict_enabled),
      updated_at = CURRENT_TIMESTAMP
    `,
    {
      replacements: {
        userId,
        pwReset: s.pwReset,
        pwStr: s.pwStr,
        lockout: Number(s.lockout),
        timeout: Number(s.timeout),
        hours: s.hours,
        device: s.device,
        audit: s.audit ? 1 : 0,
        emailNotify: s.emailNotify ? 1 : 0,
        twoFA: s.twoFA ? 1 : 0,
        ipRestrict: s.ipRestrict ? 1 : 0,
      },
      transaction,
    },
  );

  return s;
};
const rebuildUserPermissions = async (sequelize, userId, transaction) => {
  // Clear existing effective permissions
  await sequelize.query(
    `DELETE FROM user_screen_permissions WHERE user_id = :userId`,
    {
      replacements: { userId },
      transaction,
    },
  );

  await sequelize.query(
    `DELETE FROM user_feature_permissions WHERE user_id = :userId`,
    {
      replacements: { userId },
      transaction,
    },
  );

  // Rebuild screen permissions from all assigned roles
  await sequelize.query(
    `
    INSERT INTO user_screen_permissions
      (
        user_id,
        screen_id,
        can_view,
        can_create,
        can_edit,
        can_delete,
        can_export
      )
    SELECT
      :userId AS user_id,
      rsp.screen_id,
      MAX(rsp.can_view) AS can_view,
      MAX(rsp.can_create) AS can_create,
      MAX(rsp.can_edit) AS can_edit,
      MAX(rsp.can_delete) AS can_delete,
      MAX(rsp.can_export) AS can_export
    FROM user_roles ur
    JOIN role_screen_permissions rsp
      ON rsp.role_id = ur.role_id
    WHERE ur.user_id = :userId
    GROUP BY rsp.screen_id
    `,
    {
      replacements: { userId },
      transaction,
    },
  );

  // Rebuild feature permissions from all assigned roles
  await sequelize.query(
    `
    INSERT INTO user_feature_permissions
      (
        user_id,
        feature_id,
        is_enabled
      )
    SELECT
      :userId AS user_id,
      rfp.feature_id,
      MAX(rfp.is_enabled) AS is_enabled
    FROM user_roles ur
    JOIN role_feature_permissions rfp
      ON rfp.role_id = ur.role_id
    WHERE ur.user_id = :userId
    GROUP BY rfp.feature_id
    `,
    {
      replacements: { userId },
      transaction,
    },
  );
};

export const bootstrap = async (_req, res) => {
  try {
    const { User } = getModels();
    const sequelize = User.sequelize;

    const screens = await sequelize.query(
      `
      SELECT
        id,
        code,
        label,
       module,
        icon,
        sort_order
      FROM app_screens
      WHERE is_active = 1
      ORDER BY sort_order, id
      `,
      { type: QueryTypes.SELECT },
    );

    const features = await sequelize.query(
      `
      SELECT
        id,
        code,
        label,
        category,
        description ,
        sort_order
      FROM app_features
      WHERE is_active = 1
      ORDER BY sort_order, id
      `,
      { type: QueryTypes.SELECT },
    );

    const roles = await sequelize.query(
      `
      SELECT
        role_id,
        id,
        code,
        name,
        icon,
        color,
        description,
        isSystem
      FROM roles
      WHERE isActive = 1
        AND isDeleted = 0
      ORDER BY role_id
      `,
      { type: QueryTypes.SELECT },
    );

    for (const role of roles) {
      const screenRows = await sequelize.query(
        `
        SELECT
          s.code,
          rsp.can_view,
          rsp.can_create,
          rsp.can_edit,
          rsp.can_delete,
          rsp.can_export
        FROM role_screen_permissions rsp
        JOIN app_screens s ON s.id = rsp.screen_id
        WHERE rsp.role_id = :roleId
        ORDER BY s.sort_order, s.id
        `,
        {
          replacements: { roleId: role.role_id },
          type: QueryTypes.SELECT,
        },
      );

      const featureRows = await sequelize.query(
        `
        SELECT
          f.code,
          rfp.is_enabled
        FROM role_feature_permissions rfp
        JOIN app_features f ON f.id = rfp.feature_id
        WHERE rfp.role_id = :roleId
        ORDER BY f.sort_order, f.id
        `,
        {
          replacements: { roleId: role.role_id },
          type: QueryTypes.SELECT,
        },
      );

      //   role.id = role.code;
      role.screens = mapScreenPerms(screenRows);
      role.features = mapFeaturePerms(featureRows);
    }

    const orgRows = await sequelize.query(
      `
      SELECT
        id,
        code,
        name,
        unit_type,
        parent_id,
        icon,
        sort_order
      FROM org_units
      WHERE is_active = 1
      ORDER BY sort_order, id
      `,
      { type: QueryTypes.SELECT },
    );

    return success(
      res,
      {
        screens: screens.map((s) => ({
          id: s.code,
          label: s.label,
          mod: s.module,
          icon: s.icon,
        })),
        features: features.map((f) => ({
          id: f.code,
          label: f.label,
          cat: f.category,
          desc: f.description,
        })),
        roles,
        orgTree: buildTree(orgRows),
      },
      "Access master data loaded",
    );
  } catch (err) {
    return error(res, err.message);
  }
};

export const getUserAccess = async (req, res) => {
  try {
    const { User } = getModels();
    const sequelize = User.sequelize;
    const { userId } = req.params;

    const user = await User.findOne({
      where: {
        id: userId,
        isDeleted: false,
      },
      attributes: ["id", "role", "screenPermissions"],
    });

    if (!user) return notFound(res, "User not found");

    const roleRows = await sequelize.query(
      `
      SELECT
        r.role_id,
        r.id,
        r.code,
        r.name,
        r.icon,
        r.color,
        ur.is_primary
      FROM user_roles ur
      JOIN roles r ON r.role_id = ur.role_id
      WHERE ur.user_id = :userId
      ORDER BY ur.is_primary DESC, r.name
      `,
      {
        replacements: { userId },
        type: QueryTypes.SELECT,
      },
    );

    const screenRows = await sequelize.query(
      `
      SELECT
        s.code,
        usp.can_view,
        usp.can_create,
        usp.can_edit,
        usp.can_delete,
        usp.can_export
      FROM user_screen_permissions usp
      JOIN app_screens s ON s.id = usp.screen_id
      WHERE usp.user_id = :userId
      ORDER BY s.sort_order, s.id
      `,
      {
        replacements: { userId },
        type: QueryTypes.SELECT,
      },
    );

    const featureRows = await sequelize.query(
      `
      SELECT
        f.code,
        ufp.is_enabled
      FROM user_feature_permissions ufp
      JOIN app_features f ON f.id = ufp.feature_id
      WHERE ufp.user_id = :userId
      ORDER BY f.sort_order, f.id
      `,
      {
        replacements: { userId },
        type: QueryTypes.SELECT,
      },
    );

    const scopeRows = await sequelize.query(
      `
      SELECT o.code
      FROM user_scope us
      JOIN org_units o ON o.id = us.org_unit_id
      WHERE us.user_id = :userId
      `,
      {
        replacements: { userId },
        type: QueryTypes.SELECT,
      },
    );

    const securityRows = await sequelize.query(
      `
      SELECT
        force_password_reset AS pwReset,
        password_strength AS pwStr,
        lockout_after AS lockout,
        session_timeout_minutes AS timeout,
        allowed_login_hours AS hours,
        allowed_device AS device,
        audit_enabled AS audit,
        email_notify AS emailNotify,
        two_fa_enabled AS twoFA,
        ip_restrict_enabled AS ipRestrict
      FROM user_security_settings
      WHERE user_id = :userId
      LIMIT 1
      `,
      {
        replacements: { userId },
        type: QueryTypes.SELECT,
      },
    );

    return success(
      res,
      {
        roles: roleRows,
        screens: mapScreenPerms(screenRows),
        features: mapFeaturePerms(featureRows),
        scope: scopeRows.map((r) => r.code),
        security: securityRows[0] || null,
      },
      "User access loaded",
    );
  } catch (err) {
    return error(res, err.message);
  }
};

export const saveUserAccess = async (req, res) => {
  const { User, AuditLog } = getModels();
  const sequelize = User.sequelize;
  const t = await sequelize.transaction();

  try {
    const { userId } = req.params;
    const { screens = {}, features = {}, scope = [], security = {} } = req.body;

    const user = await User.findOne({
      where: {
        id: userId,
        isDeleted: false,
      },
      transaction: t,
    });

    if (!user) {
      await t.rollback();
      return notFound(res, "User not found");
    }

    const oldData = {
      screens,
      features,
      scope,
      security,
    };

    await sequelize.query(
      `DELETE FROM user_screen_permissions WHERE user_id = :userId`,
      {
        replacements: { userId },
        transaction: t,
      },
    );

    for (const [screenCode, perms] of Object.entries(screens)) {
      const screenRows = await sequelize.query(
        `SELECT id FROM app_screens WHERE code = :code LIMIT 1`,
        {
          replacements: { code: screenCode },
          type: QueryTypes.SELECT,
          transaction: t,
        },
      );

      if (!screenRows.length) continue;

      await sequelize.query(
        `
        INSERT INTO user_screen_permissions
          (
            user_id,
            screen_id,
            can_view,
            can_create,
            can_edit,
            can_delete,
            can_export
          )
        VALUES
          (
            :userId,
            :screenId,
            :canView,
            :canCreate,
            :canEdit,
            :canDelete,
            :canExport
          )
        ON DUPLICATE KEY UPDATE
          can_view = VALUES(can_view),
          can_create = VALUES(can_create),
          can_edit = VALUES(can_edit),
          can_delete = VALUES(can_delete),
          can_export = VALUES(can_export),
          updated_at = CURRENT_TIMESTAMP
        `,
        {
          replacements: {
            userId,
            screenId: screenRows[0].id,
            canView: perms.view ? 1 : 0,
            canCreate: perms.create ? 1 : 0,
            canEdit: perms.edit ? 1 : 0,
            canDelete: perms.delete ? 1 : 0,
            canExport: perms.export ? 1 : 0,
          },
          transaction: t,
        },
      );
    }

    await sequelize.query(
      `DELETE FROM user_feature_permissions WHERE user_id = :userId`,
      {
        replacements: { userId },
        transaction: t,
      },
    );

    for (const [featureCode, enabled] of Object.entries(features)) {
      const featureRows = await sequelize.query(
        `SELECT id FROM app_features WHERE code = :code LIMIT 1`,
        {
          replacements: { code: featureCode },
          type: QueryTypes.SELECT,
          transaction: t,
        },
      );

      if (!featureRows.length) continue;

      await sequelize.query(
        `
        INSERT INTO user_feature_permissions
          (user_id, feature_id, is_enabled)
        VALUES
          (:userId, :featureId, :isEnabled)
        ON DUPLICATE KEY UPDATE
          is_enabled = VALUES(is_enabled),
          updated_at = CURRENT_TIMESTAMP
        `,
        {
          replacements: {
            userId,
            featureId: featureRows[0].id,
            isEnabled: enabled ? 1 : 0,
          },
          transaction: t,
        },
      );
    }

    await user.update(
      {
        screenPermissions: {
          scope,
          security,
        },
        updatedBy: req.user?.empId || req.user?.username || req.user?.id,
      },
      { transaction: t },
    );

    if (AuditLog) {
      await AuditLog.create(
        {
          userId: req.user?.id || null,
          action: "UPDATE",
          module: "USER_ACCESS",
          recordId: user.id,
          oldData,
          newData: {
            screens,
            features,
            scope,
            security,
          },
          ipAddress: req.ip,
          userAgent: req.headers["user-agent"],
        },
        { transaction: t },
      );
    }

    await t.commit();

    return success(
      res,
      {
        screens,
        features,
        scope,
        security,
      },
      "User access saved",
    );
  } catch (err) {
    await t.rollback();
    return error(res, err.message);
  }
};
export const getRolePermissions = async (req, res) => {
  try {
    const { User } = getModels();
    const sequelize = User.sequelize;
    const { roleId } = req.params;

    const screenRows = await sequelize.query(
      `
      SELECT 
        s.id,
        s.code,
        s.label,
        s.module,
        s.icon,
        COALESCE(rsp.can_view, 0) AS can_view,
        COALESCE(rsp.can_create, 0) AS can_create,
        COALESCE(rsp.can_edit, 0) AS can_edit,
        COALESCE(rsp.can_delete, 0) AS can_delete,
        COALESCE(rsp.can_export, 0) AS can_export
      FROM app_screens s
      LEFT JOIN role_screen_permissions rsp
        ON rsp.screen_id = s.id
       AND rsp.role_id = :roleId
      WHERE s.is_active = 1
      ORDER BY s.sort_order, s.id
      `,
      {
        replacements: { roleId },
        type: QueryTypes.SELECT,
      },
    );

    const featureRows = await sequelize.query(
      `
      SELECT
        f.id,
        f.code,
        f.label,
        f.category,
        f.description,
        COALESCE(rfp.is_enabled, 0) AS is_enabled
      FROM app_features f
      LEFT JOIN role_feature_permissions rfp
        ON rfp.feature_id = f.id
       AND rfp.role_id = :roleId
      WHERE f.is_active = 1
      ORDER BY f.sort_order, f.id
      `,
      {
        replacements: { roleId },
        type: QueryTypes.SELECT,
      },
    );

    return success(
      res,
      {
        screens: mapScreenPerms(screenRows),
        features: mapFeaturePerms(featureRows),
        screenRows,
        featureRows,
      },
      "Role permissions loaded",
    );
  } catch (err) {
    return error(res, err.message);
  }
};
export const createRolePermissions = async (req, res) => {
  return updateRolePermissions(req, res);
};
export const updateRolePermissions = async (req, res) => {
  const { User } = getModels();
  const sequelize = User.sequelize;
  const t = await sequelize.transaction();

  try {
    const { roleId } = req.params;
    const { screens = {}, features = {} } = req.body;

    for (const [screenCode, perms] of Object.entries(screens)) {
      const screenRows = await sequelize.query(
        `SELECT id FROM app_screens WHERE code = :code LIMIT 1`,
        {
          replacements: { code: screenCode },
          type: QueryTypes.SELECT,
          transaction: t,
        },
      );

      if (!screenRows.length) continue;

      await sequelize.query(
        `
        INSERT INTO role_screen_permissions
          (role_id, screen_id, can_view, can_create, can_edit, can_delete, can_export)
        VALUES
          (:roleId, :screenId, :canView, :canCreate, :canEdit, :canDelete, :canExport)
        ON DUPLICATE KEY UPDATE
          can_view = VALUES(can_view),
          can_create = VALUES(can_create),
          can_edit = VALUES(can_edit),
          can_delete = VALUES(can_delete),
          can_export = VALUES(can_export),
          updated_at = CURRENT_TIMESTAMP
        `,
        {
          replacements: {
            roleId,
            screenId: screenRows[0].id,
            canView: perms.view ? 1 : 0,
            canCreate: perms.create ? 1 : 0,
            canEdit: perms.edit ? 1 : 0,
            canDelete: perms.delete ? 1 : 0,
            canExport: perms.export ? 1 : 0,
          },
          transaction: t,
        },
      );
    }

    for (const [featureCode, enabled] of Object.entries(features)) {
      const featureRows = await sequelize.query(
        `SELECT id FROM app_features WHERE code = :code LIMIT 1`,
        {
          replacements: { code: featureCode },
          type: QueryTypes.SELECT,
          transaction: t,
        },
      );

      if (!featureRows.length) continue;

      await sequelize.query(
        `
        INSERT INTO role_feature_permissions
          (role_id, feature_id, is_enabled)
        VALUES
          (:roleId, :featureId, :isEnabled)
        ON DUPLICATE KEY UPDATE
          is_enabled = VALUES(is_enabled),
          updated_at = CURRENT_TIMESTAMP
        `,
        {
          replacements: {
            roleId,
            featureId: featureRows[0].id,
            isEnabled: enabled ? 1 : 0,
          },
          transaction: t,
        },
      );
    }

    await t.commit();

    return success(
      res,
      { roleId, screens, features },
      "Role permissions saved",
    );
  } catch (err) {
    await t.rollback();
    return error(res, err.message);
  }
};
export const deleteRolePermissions = async (req, res) => {
  const { User } = getModels();
  const sequelize = User.sequelize;
  const t = await sequelize.transaction();

  try {
    const { roleId } = req.params;

    await sequelize.query(
      `DELETE FROM role_screen_permissions WHERE role_id = :roleId`,
      {
        replacements: { roleId },
        transaction: t,
      },
    );

    await sequelize.query(
      `DELETE FROM role_feature_permissions WHERE role_id = :roleId`,
      {
        replacements: { roleId },
        transaction: t,
      },
    );

    await t.commit();

    return success(res, { roleId }, "Role permissions deleted");
  } catch (err) {
    await t.rollback();
    return error(res, err.message);
  }
};
export const getScreens = async (_req, res) => {
  try {
    const { User } = getModels();
    const sequelize = User.sequelize;

    const rows = await sequelize.query(
      `
      SELECT *
      FROM app_screens
      WHERE is_active = 1
      ORDER BY sort_order, id
      `,
      { type: QueryTypes.SELECT },
    );

    return success(res, rows, "Screens loaded");
  } catch (err) {
    return error(res, err.message);
  }
};
export const createScreen = async (req, res) => {
  try {
    const { User } = getModels();
    const sequelize = User.sequelize;

    const { code, label, module, icon = null, sort_order = 0 } = req.body;

    await sequelize.query(
      `
      INSERT INTO app_screens
        (code, label, module, icon, sort_order, is_active)
      VALUES
        (:code, :label, :module, :icon, :sortOrder, 1)
      `,
      {
        replacements: {
          code,
          label,
          module,
          icon,
          sortOrder: sort_order,
        },
      },
    );

    return success(res, req.body, "Screen created");
  } catch (err) {
    return error(res, err.message);
  }
};
export const updateScreen = async (req, res) => {
  try {
    const { User } = getModels();
    const sequelize = User.sequelize;

    const { code, label, module, icon = null, sort_order = 0 } = req.body;

    await sequelize.query(
      `
      UPDATE app_screens
      SET
        code = :code,
        label = :label,
        module = :module,
        icon = :icon,
        sort_order = :sortOrder
      WHERE id = :id
      `,
      {
        replacements: {
          id: req.params.id,
          code,
          label,
          module,
          icon,
          sortOrder: sort_order,
        },
      },
    );

    return success(res, req.body, "Screen updated");
  } catch (err) {
    return error(res, err.message);
  }
};
export const deleteScreen = async (req, res) => {
  try {
    const { User } = getModels();
    const sequelize = User.sequelize;

    await sequelize.query(
      `
      UPDATE app_screens
      SET is_active = 0
      WHERE id = :id
      `,
      {
        replacements: { id: req.params.id },
      },
    );

    return success(res, { id: req.params.id }, "Screen deleted");
  } catch (err) {
    return error(res, err.message);
  }
};
export const getFeatures = async (_req, res) => {
  try {
    const { User } = getModels();
    const sequelize = User.sequelize;

    const rows = await sequelize.query(
      `
      SELECT *
      FROM app_features
      WHERE is_active = 1
      ORDER BY sort_order, id
      `,
      { type: QueryTypes.SELECT },
    );

    return success(res, rows, "Features loaded");
  } catch (err) {
    return error(res, err.message);
  }
};

export const createFeature = async (req, res) => {
  try {
    const { User } = getModels();
    const sequelize = User.sequelize;

    const {
      code,
      label,
      category,
      description = null,
      sort_order = 0,
    } = req.body;

    await sequelize.query(
      `
      INSERT INTO app_features
        (code, label, category, description, sort_order, is_active)
      VALUES
        (:code, :label, :category, :description, :sortOrder, 1)
      `,
      {
        replacements: {
          code,
          label,
          category,
          description,
          sortOrder: sort_order,
        },
      },
    );

    return success(res, req.body, "Feature created");
  } catch (err) {
    return error(res, err.message);
  }
};

export const updateFeature = async (req, res) => {
  try {
    const { User } = getModels();
    const sequelize = User.sequelize;

    const {
      code,
      label,
      category,
      description = null,
      sort_order = 0,
    } = req.body;

    await sequelize.query(
      `
      UPDATE app_features
      SET
        code = :code,
        label = :label,
        category = :category,
        description = :description,
        sort_order = :sortOrder
      WHERE id = :id
      `,
      {
        replacements: {
          id: req.params.id,
          code,
          label,
          category,
          description,
          sortOrder: sort_order,
        },
      },
    );

    return success(res, req.body, "Feature updated");
  } catch (err) {
    return error(res, err.message);
  }
};

export const deleteFeature = async (req, res) => {
  try {
    const { User } = getModels();
    const sequelize = User.sequelize;

    await sequelize.query(
      `
      UPDATE app_features
      SET is_active = 0
      WHERE id = :id
      `,
      {
        replacements: { id: req.params.id },
      },
    );

    return success(res, { id: req.params.id }, "Feature deleted");
  } catch (err) {
    return error(res, err.message);
  }
};

export const addUserRole = async (req, res) => {
  const { User } = getModels();
  const sequelize = User.sequelize;
  const t = await sequelize.transaction();

  try {
    const { userId } = req.params;
    const { role_id, is_primary = false } = req.body;

    const userRows = await sequelize.query(
      `
      SELECT id
      FROM users
      WHERE id = :userId
        AND isDeleted = 0
      LIMIT 1
      `,
      {
        replacements: { userId },
        type: QueryTypes.SELECT,
        transaction: t,
      },
    );

    if (!userRows.length) {
      await t.rollback();
      return notFound(res, "User not found");
    }

    const roleRows = await sequelize.query(
      `
      SELECT role_id, name
      FROM roles
      WHERE role_id = :roleId
        AND isActive = 1
        AND isDeleted = 0
      LIMIT 1
      `,
      {
        replacements: { roleId: role_id },
        type: QueryTypes.SELECT,
        transaction: t,
      },
    );

    if (!roleRows.length) {
      await t.rollback();
      return notFound(res, "Role not found");
    }

    if (is_primary) {
      await sequelize.query(
        `
        UPDATE user_roles
        SET is_primary = 0
        WHERE user_id = :userId
        `,
        {
          replacements: { userId },
          transaction: t,
        },
      );
    }

    await sequelize.query(
      `
      INSERT INTO user_roles
        (user_id, role_id, is_primary)
      VALUES
        (:userId, :roleId, :isPrimary)
      ON DUPLICATE KEY UPDATE
        is_primary = VALUES(is_primary)
      `,
      {
        replacements: {
          userId,
          roleId: role_id,
          isPrimary: is_primary ? 1 : 0,
        },
        transaction: t,
      },
    );

    // If this is the first role, make it primary
    await sequelize.query(
      `
      UPDATE user_roles ur
      JOIN (
        SELECT user_id, MIN(role_id) AS first_role_id
        FROM user_roles
        WHERE user_id = :userId
        GROUP BY user_id
      ) x ON x.user_id = ur.user_id
      SET ur.is_primary = 1
      WHERE ur.user_id = :userId
        AND ur.role_id = x.first_role_id
        AND NOT EXISTS (
          SELECT 1
          FROM (
            SELECT *
            FROM user_roles
            WHERE user_id = :userId
              AND is_primary = 1
          ) p
        )
      `,
      {
        replacements: { userId },
        transaction: t,
      },
    );

    await rebuildUserPermissions(sequelize, userId, t);

    await t.commit();

    return success(
      res,
      {
        userId,
        role_id,
      },
      "Role assigned to user",
    );
  } catch (err) {
    await t.rollback();
    return error(res, err.message);
  }
};
export const removeUserRole = async (req, res) => {
  const { User } = getModels();
  const sequelize = User.sequelize;
  const t = await sequelize.transaction();

  try {
    const { userId, roleId } = req.params;

    await sequelize.query(
      `
      DELETE FROM user_roles
      WHERE user_id = :userId
        AND role_id = :roleId
      `,
      {
        replacements: { userId, roleId },
        transaction: t,
      },
    );

    // If no primary role exists, make first remaining role primary
    await sequelize.query(
      `
      UPDATE user_roles ur
      JOIN (
        SELECT user_id, MIN(role_id) AS first_role_id
        FROM user_roles
        WHERE user_id = :userId
        GROUP BY user_id
      ) x ON x.user_id = ur.user_id
      SET ur.is_primary = 1
      WHERE ur.user_id = :userId
        AND ur.role_id = x.first_role_id
        AND NOT EXISTS (
          SELECT 1
          FROM (
            SELECT *
            FROM user_roles
            WHERE user_id = :userId
              AND is_primary = 1
          ) p
        )
      `,
      {
        replacements: { userId },
        transaction: t,
      },
    );

    await rebuildUserPermissions(sequelize, userId, t);

    await t.commit();

    return success(
      res,
      {
        userId,
        roleId,
      },
      "Role removed from user",
    );
  } catch (err) {
    await t.rollback();
    return error(res, err.message);
  }
};
export const setPrimaryUserRole = async (req, res) => {
  const { User } = getModels();
  const sequelize = User.sequelize;
  const t = await sequelize.transaction();

  try {
    const { userId, roleId } = req.params;

    const rows = await sequelize.query(
      `
      SELECT id
      FROM user_roles
      WHERE user_id = :userId
        AND role_id = :roleId
      LIMIT 1
      `,
      {
        replacements: { userId, roleId },
        type: QueryTypes.SELECT,
        transaction: t,
      },
    );

    if (!rows.length) {
      await t.rollback();
      return notFound(res, "User role not found");
    }

    await sequelize.query(
      `
      UPDATE user_roles
      SET is_primary = 0
      WHERE user_id = :userId
      `,
      {
        replacements: { userId },
        transaction: t,
      },
    );

    await sequelize.query(
      `
      UPDATE user_roles
      SET is_primary = 1
      WHERE user_id = :userId
        AND role_id = :roleId
      `,
      {
        replacements: { userId, roleId },
        transaction: t,
      },
    );

    await t.commit();

    return success(
      res,
      {
        userId,
        roleId,
      },
      "Primary role updated",
    );
  } catch (err) {
    await t.rollback();
    return error(res, err.message);
  }
};

export const saveUserSecurity = async (req, res) => {
  const { User, AuditLog } = getModels();
  const sequelize = User.sequelize;
  const t = await sequelize.transaction();

  try {
    const { userId } = req.params;

    const user = await User.findOne({
      where: {
        id: userId,
        isDeleted: false,
      },
      transaction: t,
    });

    if (!user) {
      await t.rollback();
      return notFound(res, "User not found");
    }

    const savedSecurity = await saveSecuritySettings(
      sequelize,
      userId,
      req.body,
      t,
    );

    if (AuditLog) {
      await AuditLog.create(
        {
          userId: req.user?.id || null,
          action: "UPDATE",
          module: "USER_SECURITY",
          recordId: user.id,
          oldData: null,
          newData: savedSecurity,
          ipAddress: req.ip,
          userAgent: req.headers["user-agent"],
        },
        { transaction: t },
      );
    }

    await t.commit();

    return success(res, savedSecurity, "Security settings saved");
  } catch (err) {
    await t.rollback();
    return error(res, err.message);
  }
};

export const forceLogoutUser = async (req, res) => {
  const { User, AuditLog } = getModels();
  const sequelize = User.sequelize;
  const t = await sequelize.transaction();

  try {
    const { userId } = req.params;

    const user = await User.findOne({
      where: {
        id: userId,
        isDeleted: false,
      },
      transaction: t,
    });

    if (!user) {
      await t.rollback();
      return notFound(res, "User not found");
    }

    await sequelize.query(
      `
      UPDATE user_security_settings
      SET
        updated_at = CURRENT_TIMESTAMP
      WHERE user_id = :userId
      `,
      {
        replacements: { userId },
        transaction: t,
      },
    );

    if (AuditLog) {
      await AuditLog.create(
        {
          userId: req.user?.id || null,
          action: "FORCE_LOGOUT",
          module: "USER_SECURITY",
          recordId: user.id,
          oldData: null,
          newData: { userId },
          ipAddress: req.ip,
          userAgent: req.headers["user-agent"],
        },
        { transaction: t },
      );
    }

    await t.commit();

    return success(res, { userId }, "User session invalidated");
  } catch (err) {
    await t.rollback();
    return error(res, err.message);
  }
};

export default {
  bootstrap,
  getUserAccess,
  saveUserAccess,

  addUserRole,
  removeUserRole,
  setPrimaryUserRole,
  saveUserSecurity,
  forceLogoutUser,

  getRolePermissions,
  createRolePermissions,
  updateRolePermissions,
  deleteRolePermissions,

  getScreens,
  createScreen,
  updateScreen,
  deleteScreen,

  getFeatures,
  createFeature,
  updateFeature,
  deleteFeature,
};
