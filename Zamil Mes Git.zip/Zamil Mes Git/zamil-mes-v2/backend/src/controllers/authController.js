import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { getModels } from '../models/index.js';
import env from '../config/env.js';
import { success, badRequest, error } from '../utils/response.js';
import logger from '../utils/logger.js';

const sign = (payload) => jwt.sign(payload, env.JWT_SECRET, { expiresIn: env.JWT_EXPIRES_IN || '8h' });

export const login = async (req, res) => {
  try {
    const { empId, password } = req.body;
    if (!empId || !password) return badRequest(res, 'Employee ID and password are required');

    const { User } = getModels();
    const user = await User.findOne({ where: { empId, isActive: true } });
    if (!user) return badRequest(res, 'Invalid Employee ID or password');

    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) return badRequest(res, 'Invalid Employee ID or password');

    const token = sign({ id: user.id, empId: user.empId, role: user.role });
    const safeUser = {
      id: user.id, empId: user.empId, fullName: user.fullName,
      email: user.email, role: user.role, plant: user.plant,
      screenPermissions: user.screenPermissions,
    };
    logger.info(`Login: ${user.empId} [${user.role}]`);
    return success(res, { token, user: safeUser }, 'Login successful');
  } catch (err) {
    return error(res, err.message);
  }
};

export const logout = async (req, res) => success(res, null, 'Logged out');

export const me = async (req, res) => {
  try {
    const { User } = getModels();
    const user = await User.findByPk(req.user.id, {
      attributes: { exclude: ['passwordHash'] },
    });
    if (!user) return badRequest(res, 'User not found');
    return success(res, user);
  } catch (err) {
    return error(res, err.message);
  }
};

export const changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const { User } = getModels();
    const user = await User.findByPk(req.user.id);
    if (!user) return badRequest(res, 'User not found');
    const valid = await bcrypt.compare(currentPassword, user.passwordHash);
    if (!valid) return badRequest(res, 'Current password is incorrect');
    const hash = await bcrypt.hash(newPassword, 12);
    await user.update({ passwordHash: hash });
    return success(res, null, 'Password changed successfully');
  } catch (err) {
    return error(res, err.message);
  }
};

export default { login, logout, me, changePassword };
