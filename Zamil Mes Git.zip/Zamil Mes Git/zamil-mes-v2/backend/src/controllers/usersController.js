import bcrypt from "bcryptjs";
import { Op } from "sequelize";
import { getModels } from "../models/index.js";
import {
  success,
  created,
  notFound,
  error,
  paginated,
} from "../utils/response.js";

export const getUsers = async (req, res) => {
  try {
    const { User } = getModels();
    const { page = 1, limit = 50, search, role } = req.query;
    const where = { isDeleted: false };
    if (role) where.role = role;
    if (search)
      where[Op.or] = [
        { fullName: { [Op.like]: `%${search}%` } },
        { empId: { [Op.like]: `%${search}%` } },
        { email: { [Op.like]: `%${search}%` } },
      ];
    const result = await User.findAndCountAll({
      where,
      attributes: { exclude: ["passwordHash"] },
      limit: +limit,
      offset: (+page - 1) * +limit,
      order: [["fullName", "ASC"]],
    });
    return paginated(res, result, page, limit);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getUser = async (req, res) => {
  try {
    const { User } = getModels();
    const u = await User.findOne({
      where: { id: req.params.id, isDeleted: false },
      attributes: { exclude: ["passwordHash"] },
    });
    if (!u) return notFound(res);
    return success(res, u);
  } catch (err) {
    return error(res, err.message);
  }
};

export const createUser = async (req, res) => {
  const { User, Role, UserRole } = getModels();
  const sequelize = User.sequelize;
  const transaction = await sequelize.transaction();

  try {
    const { password, role_id, ...rest } = req.body;

    const role = await Role.findOne({
      where: {
        role_id,
        isActive: true,
        isDeleted: false,
      },
      transaction,
    });

    if (!role) {
      await transaction.rollback();
      return error(res, "Invalid role selected");
    }

    const payload = {
      ...rest,
      department: rest.dept || null,
      role: role.name,
      roleId: role.id,
    };

    delete payload.dept;

    const hash = await bcrypt.hash(password || "User@123", 12);

    const u = await User.create(
      {
        ...payload,
        passwordHash: hash,
        isActive: true,
        createdBy: req.user?.username,
      },
      { transaction }
    );

    // users table primary key is id CHAR(36)
    const userId = u.id;

    // Save selected role for user
    await UserRole.create(
      {
        user_id: userId,
        role_id: role.role_id,
        is_primary: true,
      },
      { transaction }
    );

    // Copy role feature permissions to user feature permissions
    await sequelize.query(
      `
      INSERT INTO user_feature_permissions
        (user_id, feature_id, is_enabled)
      SELECT
        :userId,
        feature_id,
        is_enabled
      FROM role_feature_permissions
      WHERE role_id = :roleId
      `,
      {
        replacements: {
          userId,
          roleId: role.role_id,
        },
        transaction,
      }
    );

    // Copy role screen permissions to user screen permissions
    await sequelize.query(
      `
      INSERT INTO user_screen_permissions
        (
          user_id,
          screen_id,
          can_view,
          can_create,
          can_edit,
          can_delete,
          can_export
        )
      SELECT
        :userId,
        screen_id,
        can_view,
        can_create,
        can_edit,
        can_delete,
        can_export
      FROM role_screen_permissions
      WHERE role_id = :roleId
      `,
      {
        replacements: {
          userId,
          roleId: role.role_id,
        },
        transaction,
      }
    );

    await transaction.commit();

    const { passwordHash: _, ...safe } = u.toJSON();

    return created(
      res,
      {
        ...safe,
        role_id: role.role_id,
        roleName: role.name,
      },
      "User created"
    );
  } catch (err) {
    await transaction.rollback();
    return error(res, err.message);
  }
};

export const updateUser = async (req, res) => {
  try {
    const { User } = getModels();
    const u = await User.findOne({
      where: { id: req.params.id, isDeleted: false },
    });
    if (!u) return notFound(res);
    const { password, ...rest } = req.body;
    const updates = {
      ...rest,
      department: rest.department || rest.dept || null,
      updatedBy: req.user?.username,
    };
    delete updates.dept;
    if (password) updates.passwordHash = await bcrypt.hash(password, 12);
    await u.update(updates);
    return success(res, null, "User updated");
  } catch (err) {
    return error(res, err.message);
  }
};

export const deleteUser = async (req, res) => {
  try {
    const { User } = getModels();
    const u = await User.findOne({
      where: { id: req.params.id, isDeleted: false },
    });
    if (!u) return notFound(res);
    await u.update({ isDeleted: true });
    return success(res, null, "User deleted");
  } catch (err) {
    return error(res, err.message);
  }
};

export const updatePermissions = async (req, res) => {
  try {
    const { User } = getModels();
    const u = await User.findOne({
      where: { id: req.params.id, isDeleted: false },
    });
    if (!u) return notFound(res);
    await u.update({ screenPermissions: req.body.permissions });
    return success(res, null, "Permissions updated");
  } catch (err) {
    return error(res, err.message);
  }
};

export const getRoles = async (_req, res) => {
  try {
    const { Role } = getModels();

    const roles = await Role.findAll({
      where: {
        isActive: true,
        isDeleted: false,
      },
      attributes: [
        "id",
        "role_id",
        "code",
        "name",
        "description",
        "icon",
        "color",
        "isSystem",
      ],
      order: [["role_id", "ASC"]],
    });

    return success(res, roles);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getActivityLog = async (req, res) => {
  try {
    const { AuditLog } = getModels();
    const logs = await AuditLog.findAll({
      where: { userId: req.params.id },
      limit: 50,
      order: [["createdAt", "DESC"]],
    });
    return success(res, logs);
  } catch (err) {
    return error(res, err.message);
  }
};

export default {
  getUsers,
  getUser,
  createUser,
  updateUser,
  deleteUser,
  updatePermissions,
  getRoles,
  getActivityLog,
};
