import { Op } from 'sequelize';
import { getModels } from '../models/index.js';
import { success, created, notFound, error, paginated } from '../utils/response.js';

const buildWhere = (q) => {
  const w = { isDeleted: false };
  if (q.status) w.status = q.status;
  if (q.machineId) w.machineId = q.machineId;
  if (q.priority) w.priority = q.priority;
  if (q.search) w[Op.or] = [
    { woNumber:     { [Op.like]: `%${q.search}%` } },
    { product:      { [Op.like]: `%${q.search}%` } },
    { productCode:  { [Op.like]: `%${q.search}%` } },
    { customer:     { [Op.like]: `%${q.search}%` } },
  ];
  return w;
};

export const getWorkOrders = async (req, res) => {
  try {
    const { WorkOrder } = getModels();
    const { page=1, limit=20 } = req.query;
    const result = await WorkOrder.findAndCountAll({
      where: buildWhere(req.query),
      limit: +limit, offset: (+page-1)*+limit,
      order: [['createdAt','DESC']],
    });
    return paginated(res, result, page, limit);
  } catch (err) { return error(res, err.message); }
};

export const getWorkOrder = async (req, res) => {
  try {
    const { WorkOrder } = getModels();
    const wo = await WorkOrder.findOne({ where: { id: req.params.id, isDeleted: false } });
    if (!wo) return notFound(res, 'Work order not found');
    return success(res, wo);
  } catch (err) { return error(res, err.message); }
};

export const createWorkOrder = async (req, res) => {
  try {
    const { WorkOrder } = getModels();
    const wo = await WorkOrder.create({ ...req.body, plant: req.user?.plant || 'Zamil Plastics', createdBy: req.user?.username });
    return created(res, wo, 'Work order created');
  } catch (err) { return error(res, err.message); }
};

export const updateWorkOrder = async (req, res) => {
  try {
    const { WorkOrder } = getModels();
    const wo = await WorkOrder.findOne({ where: { id: req.params.id, isDeleted: false } });
    if (!wo) return notFound(res);
    await wo.update({ ...req.body, updatedBy: req.user?.username });
    return success(res, null, 'Work order updated');
  } catch (err) { return error(res, err.message); }
};

export const deleteWorkOrder = async (req, res) => {
  try {
    const { WorkOrder } = getModels();
    const wo = await WorkOrder.findOne({ where: { id: req.params.id, isDeleted: false } });
    if (!wo) return notFound(res);
    await wo.update({ isDeleted: true });
    return success(res, null, 'Work order deleted');
  } catch (err) { return error(res, err.message); }
};

export const getLogs = async (req, res) => {
  try {
    const { ProductionLog } = getModels();
    const { page=1, limit=20 } = req.query;
    const where = {};
    if (req.query.woId) where.woId = req.query.woId;
    if (req.query.machineId) where.machineId = req.query.machineId;
    const result = await ProductionLog.findAndCountAll({
      where, limit:+limit, offset:(+page-1)*+limit, order:[['createdAt','DESC']],
    });
    return paginated(res, result, page, limit);
  } catch (err) { return error(res, err.message); }
};

export const createLog = async (req, res) => {
  try {
    const { ProductionLog, WorkOrder } = getModels();
    const log = await ProductionLog.create({ ...req.body, createdBy: req.user?.username });
    // Update WO produced qty
    if (req.body.woId && req.body.quantity) {
      const wo = await WorkOrder.findByPk(req.body.woId);
      if (wo) await wo.update({ producedQty: (wo.producedQty||0) + +req.body.quantity });
    }
    return created(res, log, 'Production log created');
  } catch (err) { return error(res, err.message); }
};

export const getMachines = async (req, res) => {
  try {
    const { Machine } = getModels();
    const machines = await Machine.findAll({ where: { isDeleted: false }, order:[['code','ASC']] });
    return success(res, machines);
  } catch (err) { return error(res, err.message); }
};

export const getDashboard = async (req, res) => {
  try {
    const { WorkOrder, ProductionLog, WasteRecord, DowntimeRecord } = getModels();
    const [total, active, completed, logs] = await Promise.all([
      WorkOrder.count({ where: { isDeleted: false } }),
      WorkOrder.count({ where: { status: 'active', isDeleted: false } }),
      WorkOrder.count({ where: { status: 'completed', isDeleted: false } }),
      ProductionLog.count(),
    ]);
    return success(res, { workOrders: { total, active, completed }, productionLogs: logs });
  } catch (err) { return error(res, err.message); }
};

export default { getWorkOrders, getWorkOrder, createWorkOrder, updateWorkOrder, deleteWorkOrder, getLogs, createLog, getMachines, getDashboard };
