import { DataTypes } from "sequelize";

// ─── Audit mixin fields ────────────────────────────────────────────────────
export const auditFields = {
  createdBy: { type: DataTypes.STRING(100), allowNull: true },
  updatedBy: { type: DataTypes.STRING(100), allowNull: true },
  isActive: { type: DataTypes.BOOLEAN, defaultValue: true },
  isDeleted: { type: DataTypes.BOOLEAN, defaultValue: false },
};

// ─── Models ───────────────────────────────────────────────────────────────
let models = {};

export const initModels = (sequelize) => {
  // ── Role ──────────────────────────────────────────────────────────────
  const Role = sequelize.define(
    "Role",
    {
      role_id: {
        type: DataTypes.BIGINT.UNSIGNED,
        autoIncrement: true,
        unique: true,
        allowNull: false,
      },
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
      },
      code: {
        type: DataTypes.STRING(50),
        unique: true,
      },
      name: {
        type: DataTypes.STRING(50),
        allowNull: false,
        unique: true,
      },
      description: {
        type: DataTypes.STRING(255),
      },
      icon: {
        type: DataTypes.STRING(20),
      },
      color: {
        type: DataTypes.STRING(20),
      },
      isSystem: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
      permissions: {
        type: DataTypes.JSON,
        defaultValue: {},
      },
      ...auditFields,
    },
    { tableName: "roles" },
  );

  // ── User ──────────────────────────────────────────────────────────────
  const User = sequelize.define(
    "User",
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
      },
      empId: { type: DataTypes.STRING(20), allowNull: false, unique: true },
      username: { type: DataTypes.STRING(100), allowNull: false, unique: true },
      passwordHash: { type: DataTypes.STRING(255), allowNull: false },
      fullName: { type: DataTypes.STRING(150), allowNull: false },
      email: { type: DataTypes.STRING(200) },
      phone: { type: DataTypes.STRING(30) },
      role: { type: DataTypes.STRING(100), allowNull: false },
      plant: { type: DataTypes.STRING(100) },
      department: { type: DataTypes.STRING(100) },
      shift: { type: DataTypes.STRING(50) },
      language: { type: DataTypes.STRING(10), defaultValue: "en" },
      theme: { type: DataTypes.STRING(20), defaultValue: "black" },
      lastLoginAt: { type: DataTypes.DATE },
      mustChangePassword: { type: DataTypes.BOOLEAN, defaultValue: false },
      screenPermissions: { type: DataTypes.JSON, defaultValue: {} },
      roleId: {
        type: DataTypes.UUID,
        allowNull: true,
      },
      ...auditFields,
    },
    { tableName: "users" },
  );

  // ── UserRole ──────────────────────────────────────────────────────────
  const UserRole = sequelize.define(
    "UserRole",
    {
      id: {
        type: DataTypes.BIGINT.UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
      },
      user_id: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      role_id: {
        type: DataTypes.BIGINT.UNSIGNED,
        allowNull: false,
      },
      is_primary: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
      },
    },
    {
      tableName: "user_roles",
      timestamps: true,
      createdAt: "created_at",
      updatedAt: false,
      indexes: [
        {
          unique: true,
          fields: ["user_id", "role_id"],
        },
      ],
    },
  );

  // ── Machine ───────────────────────────────────────────────────────────
  const Machine = sequelize.define(
    "Machine",
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
      },
      code: { type: DataTypes.STRING(20), allowNull: false, unique: true },
      name: { type: DataTypes.STRING(100), allowNull: false },
      type: { type: DataTypes.STRING(50) },
      plant: { type: DataTypes.STRING(100) },
      dept: { type: DataTypes.STRING(100) },
      area: { type: DataTypes.STRING(100) },
      locator: { type: DataTypes.STRING(50) },
      oem: { type: DataTypes.STRING(100) },
      model: { type: DataTypes.STRING(100) },
      serial: { type: DataTypes.STRING(100) },
      tonnage: { type: DataTypes.STRING(30) },
      cycleTime: { type: DataTypes.DECIMAL(10, 2) },
      cavities: { type: DataTypes.INTEGER },
      ip: { type: DataTypes.STRING(50) },
      plcType: { type: DataTypes.STRING(50) },
      commProtocol: { type: DataTypes.STRING(50) },
      mesCode: { type: DataTypes.STRING(50) },
      pmFreq: { type: DataTypes.STRING(50) },
      lastPmDate: { type: DataTypes.DATEONLY },
      status: {
        type: DataTypes.ENUM("running", "idle", "maintenance", "breakdown"),
        defaultValue: "idle",
      },
      specs: { type: DataTypes.JSON, defaultValue: {} },
      ...auditFields,
    },
    { tableName: "machines" },
  );

  // ── Location ──────────────────────────────────────────────────────────
  const Location = sequelize.define(
    "Location",
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
      },
      // code/name/type/plant are kept for old API compatibility.
      // code = locator, type = location zone, plant = division/BU.
      code: { type: DataTypes.STRING(50), unique: true },
      name: { type: DataTypes.STRING(100), allowNull: false },
      type: { type: DataTypes.STRING(20) },
      plant: { type: DataTypes.STRING(20) },

      // HTML Setup -> Locations fields
      division: { type: DataTypes.STRING(20) },
area: { type: DataTypes.STRING(100) },
section: { type: DataTypes.STRING(100) },
level: { type: DataTypes.STRING(20), defaultValue: "L1" },
locator: { type: DataTypes.STRING(50), unique: true },
barcode: { type: DataTypes.STRING(80), unique: true },
locType: { type: DataTypes.STRING(30), defaultValue: "FLOOR" },
status: { type: DataTypes.STRING(20), defaultValue: "Active" },

minUnits: { type: DataTypes.INTEGER, defaultValue: 0 },
maxUnits: { type: DataTypes.INTEGER, defaultValue: 0 },
maxLPN: { type: DataTypes.INTEGER, defaultValue: 9 },
usedLPN: { type: DataTypes.INTEGER, defaultValue: 0 },
uom: { type: DataTypes.STRING(20), defaultValue: "BOX" },
multiSKU: { type: DataTypes.STRING(5), defaultValue: "Yes" },
partialPick: { type: DataTypes.STRING(5), defaultValue: "Yes" },
specificSKU: { type: DataTypes.STRING(80) },
maxWeight: { type: DataTypes.DECIMAL(12, 2), defaultValue: 2000 },

owner: { type: DataTypes.STRING(50) },
authUsers: { type: DataTypes.JSON, defaultValue: [] },
accessRestriction: { type: DataTypes.STRING(30), defaultValue: "AuthList" },
notes: { type: DataTypes.STRING(500) },
      ...auditFields,
    },
    { tableName: "locations" },
  );

  // ── Shift ─────────────────────────────────────────────────────────────
  const Shift = sequelize.define(
    "Shift",
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
      },
      name: { type: DataTypes.STRING(50), allowNull: false },
      startTime: { type: DataTypes.STRING(10) },
      endTime: { type: DataTypes.STRING(10) },
      plant: { type: DataTypes.STRING(100) },
      ...auditFields,
    },
    { tableName: "shifts" },
  );

  // ── WorkOrder ─────────────────────────────────────────────────────────
  const WorkOrder = sequelize.define(
    "WorkOrder",
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
      },
      woNumber: { type: DataTypes.STRING(30), allowNull: false, unique: true },
      product: { type: DataTypes.STRING(200), allowNull: false },
      productCode: { type: DataTypes.STRING(50) },
      customer: { type: DataTypes.STRING(200) },
      plant: { type: DataTypes.STRING(100) },
      plannedQty: { type: DataTypes.INTEGER, defaultValue: 0 },
      producedQty: { type: DataTypes.INTEGER, defaultValue: 0 },
      targetQty: { type: DataTypes.INTEGER, defaultValue: 0 },
      boxQty: { type: DataTypes.INTEGER, defaultValue: 0 },
      status: {
        type: DataTypes.ENUM(
          "pending",
          "active",
          "paused",
          "completed",
          "cancelled",
        ),
        defaultValue: "pending",
      },
      priority: {
        type: DataTypes.ENUM("low", "normal", "high", "urgent"),
        defaultValue: "normal",
      },
      scheduledDate: { type: DataTypes.DATEONLY },
      completedDate: { type: DataTypes.DATEONLY },
      notes: { type: DataTypes.TEXT },
      machineId: {
        type: DataTypes.UUID,
        references: { model: "machines", key: "id" },
      },
      locatorCode: {
        type: DataTypes.STRING(50),
        allowNull: true,
      },
      ...auditFields,
    },
    { tableName: "work_orders" },
  );

  // ── ProductionLog ─────────────────────────────────────────────────────
  const ProductionLog = sequelize.define(
    "ProductionLog",
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
      },
      woId: {
        type: DataTypes.UUID,
        references: { model: "work_orders", key: "id" },
      },
      machineId: {
        type: DataTypes.UUID,
        references: { model: "machines", key: "id" },
      },
      operatorId: {
        type: DataTypes.UUID,
        references: { model: "users", key: "id" },
      },
      shift: { type: DataTypes.STRING(50) },
      startTime: { type: DataTypes.DATE },
      endTime: { type: DataTypes.DATE },
      qtyProduced: { type: DataTypes.INTEGER, defaultValue: 0 },
      qtyRejected: { type: DataTypes.INTEGER, defaultValue: 0 },
      cavityCount: { type: DataTypes.INTEGER },
      cycleTime: { type: DataTypes.DECIMAL(10, 2) },
      notes: { type: DataTypes.TEXT },
      ...auditFields,
    },
    { tableName: "production_logs" },
  );

  // ── QCResult ──────────────────────────────────────────────────────────
  const QCResult = sequelize.define(
    "QCResult",
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
      },
      woId: {
        type: DataTypes.UUID,
        references: { model: "work_orders", key: "id" },
      },
      machineId: {
        type: DataTypes.UUID,
        references: { model: "machines", key: "id" },
      },
      inspectorId: {
        type: DataTypes.UUID,
        references: { model: "users", key: "id" },
      },
      shift: { type: DataTypes.STRING(50) },
      checkType: {
        type: DataTypes.ENUM("start", "hourly", "end", "random"),
        defaultValue: "hourly",
      },
      sampleSize: { type: DataTypes.INTEGER, defaultValue: 5 },
      passCount: { type: DataTypes.INTEGER, defaultValue: 0 },
      failCount: { type: DataTypes.INTEGER, defaultValue: 0 },
      overallResult: {
        type: DataTypes.ENUM("pass", "fail", "conditional"),
        defaultValue: "pass",
      },
      dimensions: { type: DataTypes.JSON, defaultValue: {} },
      visualChecks: { type: DataTypes.JSON, defaultValue: {} },
      measurements: { type: DataTypes.JSON, defaultValue: {} },
      defects: { type: DataTypes.JSON, defaultValue: [] },
      notes: { type: DataTypes.TEXT },
      ...auditFields,
    },
    { tableName: "qc_results" },
  );

  // ── WasteRecord ───────────────────────────────────────────────────────
  const WasteRecord = sequelize.define(
    "WasteRecord",
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
      },
      woId: {
        type: DataTypes.UUID,
        references: { model: "work_orders", key: "id" },
      },
      machineId: {
        type: DataTypes.UUID,
        references: { model: "machines", key: "id" },
      },
      recordedById: {
        type: DataTypes.UUID,
        references: { model: "users", key: "id" },
      },
      shift: { type: DataTypes.STRING(50) },
      wasteType: { type: DataTypes.STRING(100) },
      category: { type: DataTypes.STRING(100) },
      quantity: { type: DataTypes.DECIMAL(10, 3) },
      unit: { type: DataTypes.STRING(20), defaultValue: "kg" },
      costPerUnit: { type: DataTypes.DECIMAL(10, 2) },
      totalCost: { type: DataTypes.DECIMAL(12, 2) },
      disposalMethod: { type: DataTypes.STRING(100) },
      notes: { type: DataTypes.TEXT },
      ...auditFields,
    },
    { tableName: "waste_records" },
  );

  // ── DowntimeRecord ────────────────────────────────────────────────────
  const DowntimeRecord = sequelize.define(
    "DowntimeRecord",
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
      },
      machineId: { type: DataTypes.UUID, allowNull: true },
      woId: { type: DataTypes.UUID, allowNull: true },
      reportedById: { type: DataTypes.UUID, allowNull: true },
      // Direct entry fields
      org: { type: DataTypes.STRING(50) },
      machine: { type: DataTypes.STRING(50) },
      date: { type: DataTypes.DATEONLY },
      product: { type: DataTypes.STRING(100) },
      desc: { type: DataTypes.STRING(200) },
      routing: { type: DataTypes.STRING(50) },
      hours: { type: DataTypes.INTEGER, defaultValue: 0 },
      minute: { type: DataTypes.INTEGER, defaultValue: 0 },
      dtType: { type: DataTypes.STRING(20) },
      shift: { type: DataTypes.STRING(50) },
      category: { type: DataTypes.STRING(100) },
      process: { type: DataTypes.STRING(200) },
      reason: { type: DataTypes.TEXT },
      // Legacy fields
      startTime: { type: DataTypes.DATE },
      endTime: { type: DataTypes.DATE },
      durationMinutes: { type: DataTypes.INTEGER },
      subcategory: { type: DataTypes.STRING(100) },
      actionTaken: { type: DataTypes.TEXT },
      status: {
        type: DataTypes.ENUM("open", "in_progress", "resolved"),
        defaultValue: "open",
      },
      resolvedById: { type: DataTypes.UUID },
      ...auditFields,
    },
    { tableName: "downtime_records" },
  );

  // ── Box ───────────────────────────────────────────────────────────────
  const Box = sequelize.define(
    "Box",
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
      },
      barcode: { type: DataTypes.STRING(50), unique: true },
      woId: {
        type: DataTypes.UUID,
        references: { model: "work_orders", key: "id" },
      },
      machineId: {
        type: DataTypes.UUID,
        references: { model: "machines", key: "id" },
      },
      packedById: {
        type: DataTypes.UUID,
        references: { model: "users", key: "id" },
      },
      quantity: { type: DataTypes.INTEGER, defaultValue: 0 },
      weight: { type: DataTypes.DECIMAL(10, 3) },
      status: {
        type: DataTypes.ENUM("open", "packed", "palletized", "shipped"),
        defaultValue: "open",
      },
      qcStatus: {
        type: DataTypes.ENUM("pend", "appr", "rejt"),
        defaultValue: "pend",
      },
      qcNotes: { type: DataTypes.TEXT },
      qcChecks: { type: DataTypes.JSON, defaultValue: {} },
      palletId: { type: DataTypes.UUID, allowNull: true },
      packedAt: { type: DataTypes.DATE },
      labelSeq: { type: DataTypes.STRING(50) },
      labelPrinted: { type: DataTypes.BOOLEAN, defaultValue: true },
      printedAt: { type: DataTypes.DATE },
      ...auditFields,
    },
    { tableName: "boxes" },
  );

  // ── Pallet ────────────────────────────────────────────────────────────
  const Pallet = sequelize.define(
    "Pallet",
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
      },
      palletNumber: { type: DataTypes.STRING(50), unique: true },
      woId: {
        type: DataTypes.UUID,
        references: { model: "work_orders", key: "id" },
      },
      createdById: {
        type: DataTypes.UUID,
        references: { model: "users", key: "id" },
      },
      boxCount: { type: DataTypes.INTEGER, defaultValue: 0 },
      totalQty: { type: DataTypes.INTEGER, defaultValue: 0 },
      totalWeight: { type: DataTypes.DECIMAL(10, 3) },
      status: {
        type: DataTypes.ENUM("building", "complete", "shipped"),
        defaultValue: "building",
      },
      labelPrinted: { type: DataTypes.BOOLEAN, defaultValue: false },
      ...auditFields,
    },
    { tableName: "pallets" },
  );

  // ── LineClearance ─────────────────────────────────────────────────────
  const LineClearance = sequelize.define(
    "LineClearance",
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
      },
      woId: { type: DataTypes.UUID, allowNull: true },
      machineId: { type: DataTypes.UUID, allowNull: true },
      conductedById: { type: DataTypes.UUID, allowNull: true },
      approvedById: { type: DataTypes.UUID, allowNull: true },
      // Form fields
      plant: { type: DataTypes.STRING(50) },
      machine: { type: DataTypes.STRING(50) },
      jobOrder: { type: DataTypes.STRING(50) },
      productCode: { type: DataTypes.STRING(50) },
      productName: { type: DataTypes.STRING(200) },
      submissionShift: { type: DataTypes.STRING(20) },
      submissionDate: { type: DataTypes.DATEONLY },
      clearanceType: { type: DataTypes.STRING(50) },
      requestNo: { type: DataTypes.STRING(50) },
      techName: { type: DataTypes.STRING(100) },
      qiName: { type: DataTypes.STRING(100) },
      checkedCount: { type: DataTypes.INTEGER, defaultValue: 0 },
      checkedTotal: { type: DataTypes.INTEGER, defaultValue: 0 },
      note: { type: DataTypes.TEXT },
      controlNbr: { type: DataTypes.STRING(50) },
      shift: { type: DataTypes.STRING(50) },
      // Checklist JSON
      checklistData: { type: DataTypes.JSON, defaultValue: {} },
      hygieneChecks: { type: DataTypes.JSON, defaultValue: [] },
      operationChecks: { type: DataTypes.JSON, defaultValue: [] },
      moldChecks: { type: DataTypes.JSON, defaultValue: [] },
      operatorSignature: { type: DataTypes.TEXT },
      supervisorSignature: { type: DataTypes.TEXT },
      status: {
        type: DataTypes.ENUM("draft", "submitted", "approved", "rejected"),
        defaultValue: "draft",
      },
      submittedAt: { type: DataTypes.DATE },
      approvedAt: { type: DataTypes.DATE },
      rejectionReason: { type: DataTypes.TEXT },
      ...auditFields,
    },
    { tableName: "line_clearances" },
  );

  // ── StockRecord ───────────────────────────────────────────────────────
  const StockRecord = sequelize.define(
    "StockRecord",
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
      },
      woId: { type: DataTypes.UUID, allowNull: true },
      locationId: { type: DataTypes.UUID, allowNull: true },
      palletId: { type: DataTypes.UUID, allowNull: true },
      // Form fields
      org: { type: DataTypes.STRING(100) },
      plant: { type: DataTypes.STRING(100) },
      machine: { type: DataTypes.STRING(50) },
      productCode: { type: DataTypes.STRING(50) },
      productName: { type: DataTypes.STRING(200) },
      woNum: { type: DataTypes.STRING(30) },
      boxNo: { type: DataTypes.STRING(20) },
      palletCode: { type: DataTypes.STRING(50) },
      locatorCode: { type: DataTypes.STRING(50) },
      quantity: { type: DataTypes.INTEGER, defaultValue: 0 },
      reservedQty: { type: DataTypes.INTEGER, defaultValue: 0 },
      qcStatus: {
        type: DataTypes.ENUM("appr", "rejt", "pend"),
        defaultValue: "pend",
      },
      status: {
        type: DataTypes.ENUM("in_stock", "reserved", "dispatched", "damaged"),
        defaultValue: "in_stock",
      },
      receivedAt: { type: DataTypes.DATE },
      dispatchedAt: { type: DataTypes.DATE },
      ...auditFields,
    },
    { tableName: "stock_records" },
  );

  // ── BoxQtyRecord ──────────────────────────────────────────────────────
  const BoxQtyRecord = sequelize.define(
    "BoxQtyRecord",
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
      },
      org: { type: DataTypes.STRING(50), allowNull: false },
      productCode: { type: DataTypes.STRING(50), allowNull: false },
      productDesc: { type: DataTypes.STRING(200) },
      qtyPerBox: { type: DataTypes.INTEGER, defaultValue: 0 },
      effectiveDate: { type: DataTypes.DATEONLY },
      ...auditFields,
    },
    { tableName: "box_qty_records" },
  );

  // ── AuditLog ──────────────────────────────────────────────────────────
  const AuditLog = sequelize.define(
    "AuditLog",
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
      },
      userId: { type: DataTypes.UUID },
      action: { type: DataTypes.STRING(100) },
      module: { type: DataTypes.STRING(100) },
      recordId: { type: DataTypes.UUID },
      oldData: { type: DataTypes.JSON },
      newData: { type: DataTypes.JSON },
      ipAddress: { type: DataTypes.STRING(50) },
      userAgent: { type: DataTypes.TEXT },
    },
    {
      tableName: "audit_logs",
      timestamps: true,
      updatedAt: false,
      paranoid: false,
    },
  );

  // ── SystemConfig ──────────────────────────────────────────────────────
  const SystemConfig = sequelize.define(
    "SystemConfig",
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
      },
      key: { type: DataTypes.STRING(100), allowNull: false, unique: true },
      value: { type: DataTypes.TEXT },
      category: { type: DataTypes.STRING(50) },
      description: { type: DataTypes.STRING(255) },
      ...auditFields,
    },
    { tableName: "system_configs" },
  );

  // ── Associations ──────────────────────────────────────────────────────
  User.belongsTo(Role, { foreignKey: "roleId", as: "roleRef" });
  Role.hasMany(User, { foreignKey: "roleId" });

  User.belongsToMany(Role, {
    through: UserRole,
    foreignKey: "user_id",
    otherKey: "role_id",
    sourceKey: "id",
    targetKey: "role_id",
    as: "roles",
  });

  Role.belongsToMany(User, {
    through: UserRole,
    foreignKey: "role_id",
    otherKey: "user_id",
    sourceKey: "role_id",
    targetKey: "id",
    as: "users",
  });


const UserSecuritySetting = sequelize.define(
  "UserSecuritySetting",
  {
    id: {
      type: DataTypes.BIGINT.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },

    user_id: {
      type: DataTypes.UUID,
      allowNull: false,
      unique: true,
    },

    forcePasswordReset: {
      type: DataTypes.ENUM("none", "first_login", "30d", "90d"),
      allowNull: false,
      defaultValue: "none",
      field: "force_password_reset",
    },

    passwordStrength: {
      type: DataTypes.ENUM("basic", "medium", "strong"),
      allowNull: false,
      defaultValue: "medium",
      field: "password_strength",
    },

    lockoutAfter: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 5,
      field: "lockout_after",
    },

    sessionTimeoutMinutes: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 240,
      field: "session_timeout_minutes",
    },

    allowedLoginHours: {
      type: DataTypes.ENUM("ANY", "DAY", "NIGHT", "OFFICE"),
      allowNull: false,
      defaultValue: "ANY",
      field: "allowed_login_hours",
    },

    allowedDevice: {
      type: DataTypes.ENUM("ANY", "PLANT", "TABLET"),
      allowNull: false,
      defaultValue: "ANY",
      field: "allowed_device",
    },

    auditEnabled: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true,
      field: "audit_enabled",
    },

    emailNotify: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true,
      field: "email_notify",
    },

    twoFaEnabled: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
      field: "two_fa_enabled",
    },

    ipRestrictEnabled: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
      field: "ip_restrict_enabled",
    },

    forceLogoutAt: {
      type: DataTypes.DATE,
      allowNull: true,
      field: "force_logout_at",
    },
  },
  {
    tableName: "user_security_settings",
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
  },
);


  UserRole.belongsTo(User, { foreignKey: "user_id", targetKey: "id" });
  UserRole.belongsTo(Role, { foreignKey: "role_id", targetKey: "role_id" });

  WorkOrder.hasMany(ProductionLog, { foreignKey: "woId" });
  WorkOrder.hasMany(QCResult, { foreignKey: "woId" });
  WorkOrder.hasMany(WasteRecord, { foreignKey: "woId" });
  WorkOrder.hasMany(Box, { foreignKey: "woId" });
  WorkOrder.hasMany(Pallet, { foreignKey: "woId" });
  WorkOrder.hasMany(LineClearance, { foreignKey: "woId" });
  WorkOrder.hasMany(StockRecord, { foreignKey: "woId" });
  WorkOrder.hasMany(DowntimeRecord, { foreignKey: "woId" });

  Machine.hasMany(ProductionLog, { foreignKey: "machineId" });
  Machine.hasMany(QCResult, { foreignKey: "machineId" });
  Machine.hasMany(DowntimeRecord, { foreignKey: "machineId" });
  Machine.hasMany(LineClearance, { foreignKey: "machineId" });

  Pallet.hasMany(Box, { foreignKey: "palletId", as: "boxes" });
  Box.belongsTo(Pallet, { foreignKey: "palletId" });
  Box.belongsTo(WorkOrder, { foreignKey: "woId", as: "workOrder" });
  WasteRecord.belongsTo(WorkOrder, { foreignKey: "woId", as: "workOrder" });

  Location.hasMany(StockRecord, { foreignKey: "locationId" });

  models = {
    Role,
    User,
    UserRole,
    Machine,
    Location,
    Shift,
    WorkOrder,
    ProductionLog,
    QCResult,
    WasteRecord,
    DowntimeRecord,
    Box,
    Pallet,
    LineClearance,
    StockRecord,
    BoxQtyRecord,
    AuditLog,
    SystemConfig,
    UserSecuritySetting
  };

  return models;
};


// ── UserSecuritySetting ─────────────────────────────────────────────


export const getModels = () => models;
export default models;
