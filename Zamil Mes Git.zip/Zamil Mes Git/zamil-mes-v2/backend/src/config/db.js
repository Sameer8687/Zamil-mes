import { Sequelize } from 'sequelize';
import env from './env.js';
import logger from '../utils/logger.js';

let sequelize = null;

export const initDatabase = async () => {
  if (sequelize) return sequelize;
  if (env.DB_DIALECT === 'sqlite') {
    sequelize = new Sequelize({ dialect: 'sqlite', storage: env.DB_STORAGE, logging: false });
  } else {
    sequelize = new Sequelize(env.DB_NAME, env.DB_USER, env.DB_PASSWORD, {
      host: env.DB_HOST, port: env.DB_PORT,
      dialect: env.DB_DIALECT === 'postgresql' ? 'postgres' : env.DB_DIALECT,
      logging: false,
      dialectOptions: env.DB_SSL ? { ssl: { require: true, rejectUnauthorized: false } } : {},
    });
  }
  await sequelize.authenticate();
  logger.info(`DB connected [${env.DB_DIALECT}]`);
  return sequelize;
};

export { sequelize };
export default initDatabase;
