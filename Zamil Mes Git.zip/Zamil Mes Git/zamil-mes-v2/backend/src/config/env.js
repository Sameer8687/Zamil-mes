import 'dotenv/config';
export default {
  NODE_ENV:      process.env.NODE_ENV     || 'development',
  PORT:          process.env.PORT         || 5000,
  JWT_SECRET:    process.env.JWT_SECRET   || 'zamil-mes-secret-change-in-production',
  JWT_EXPIRES_IN:process.env.JWT_EXPIRES_IN || '8h',
  DB_DIALECT:    process.env.DB_DIALECT   || 'sqlite',
  DB_STORAGE:    process.env.DB_STORAGE   || './zamil_mes.sqlite',
  DB_HOST:       process.env.DB_HOST      || 'localhost',
  DB_PORT:       process.env.DB_PORT      || 5432,
  DB_NAME:       process.env.DB_NAME      || 'zamil_mes',
  DB_USER:       process.env.DB_USER      || 'postgres',
  DB_PASSWORD:   process.env.DB_PASSWORD  || '',
  DB_SSL:        process.env.DB_SSL === 'true',
  FRONTEND_URL:  process.env.FRONTEND_URL || 'http://localhost:3000',
  API_PREFIX:    process.env.API_PREFIX   || '/api/v1',
  LOG_LEVEL:     process.env.LOG_LEVEL    || 'info',
  APP_INSTALLED: process.env.APP_INSTALLED === 'true',
};
