import { Router } from "express";
import * as access from "../controllers/accessController.js";
import { authenticate, authorize } from "../middleware/auth.js";

const router = Router();

// router.use(authenticate);
// router.use(authorize("admin"));

// master
router.get("/bootstrap", access.bootstrap);

// user access
router.get("/users/:userId", access.getUserAccess);
router.put("/users/:userId", access.saveUserAccess);
router.put("/users/:userId/security", access.saveUserSecurity);
router.post("/users/:userId/force-logout", access.forceLogoutUser);

router.post("/users/:userId/roles", access.addUserRole);
router.delete("/users/:userId/roles/:roleId", access.removeUserRole);
router.put("/users/:userId/roles/:roleId/primary", access.setPrimaryUserRole);



// role permissions CRUD
router.get("/roles/:roleId/permissions", access.getRolePermissions);
router.post("/roles/:roleId/permissions", access.createRolePermissions);
router.put("/roles/:roleId/permissions", access.updateRolePermissions);
router.delete("/roles/:roleId/permissions", access.deleteRolePermissions);

// screen CRUD
router.get("/screens", access.getScreens);
router.post("/screens", access.createScreen);
router.put("/screens/:id", access.updateScreen);
router.delete("/screens/:id", access.deleteScreen);

// feature CRUD
router.get("/features", access.getFeatures);
router.post("/features", access.createFeature);
router.put("/features/:id", access.updateFeature);
router.delete("/features/:id", access.deleteFeature);

export default router;