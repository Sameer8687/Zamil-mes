import { Router } from 'express';
import { body } from 'express-validator';
import * as auth from '../controllers/authController.js';
import { authenticate } from '../middleware/auth.js';
import validate from '../middleware/validate.js';

const router = Router();

router.post('/login',
  body('empId').notEmpty().trim(),
  body('password').notEmpty(),
  validate,
  auth.login
);

router.post('/logout', authenticate, auth.logout);
router.get('/me', authenticate, auth.me);

router.put('/change-password',
  authenticate,
  body('currentPassword').notEmpty(),
  body('newPassword').isLength({ min: 6 }),
  validate,
  auth.changePassword
);

export default router;
