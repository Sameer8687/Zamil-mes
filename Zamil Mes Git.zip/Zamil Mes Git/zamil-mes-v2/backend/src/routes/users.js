import { Router } from 'express';
import * as users from '../controllers/usersController.js';
import { authenticate, authorize } from '../middleware/auth.js';

const router = Router();
// router.use(authenticate);

router.get('/roles',              users.getRoles);
router.get('/',                   users.getUsers);
router.get('/:id',                users.getUser);
router.get('/:id/activity',       users.getActivityLog);
router.post('/',     users.createUser);
router.put('/:id',   users.updateUser);
router.delete('/:id',users.deleteUser);
router.put('/:id/permissions',  users.updatePermissions);

export default router;
