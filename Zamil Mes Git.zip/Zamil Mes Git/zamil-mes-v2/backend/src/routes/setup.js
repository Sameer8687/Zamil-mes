import { Router } from 'express';
import * as setup from '../controllers/setupController.js';
import { authenticate, authorize } from '../middleware/auth.js';

const router = Router();

// Public read-only reference endpoints — needed by login page (machine dropdown) before auth
router.get('/machines', setup.getMachines);
router.get('/locations', setup.getLocations);
router.get('/shifts', setup.getShifts);

// All write and admin endpoints require auth
// router.use(authenticate, authorize('admin', 'tech'));

router.post('/machines', setup.createMachine);
router.put('/machines/:id', setup.updateMachine);
router.delete('/machines/:id', setup.deleteMachine);

router.post('/locations', setup.createLocation);
router.put('/locations/:id', setup.updateLocation);
router.delete('/locations/:id', setup.deleteLocation);

router.post('/shifts', setup.createShift);
router.put('/shifts/:id', setup.updateShift);
router.delete('/shifts/:id', setup.deleteShift);

router.get('/configs', setup.getConfigs);
router.post('/configs', setup.upsertConfig);

router.get('/box-qty-report', setup.getBoxQtyReport);
router.post('/box-qty-records', setup.createBoxQtyRecord);
router.delete('/box-qty-records/:id', setup.deleteBoxQtyRecord);

export default router;
