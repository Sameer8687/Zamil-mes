import { Router } from 'express';
import * as packer from '../controllers/packerController.js';
import { authenticate } from '../middleware/auth.js';

const router = Router();
// router.use(authenticate);

router.get('/boxes', packer.getBoxes);
router.post('/boxes', packer.createBox);
router.put('/boxes/:id', packer.updateBox);

router.get('/pallets', packer.getPallets);
router.post('/pallets', packer.createPallet);
router.post('/pallets/:id/boxes', packer.addBoxToPallet);
router.put('/pallets/:id/finalize', packer.finalizePallet);

export default router;
