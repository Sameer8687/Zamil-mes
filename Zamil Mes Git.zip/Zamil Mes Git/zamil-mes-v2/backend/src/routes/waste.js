import { Router } from 'express';
import * as waste from '../controllers/wasteController.js';
import { authenticate } from '../middleware/auth.js';

const router = Router();
// router.use(authenticate);

router.get('/summary', waste.getWasteSummary);
router.get('/', waste.getWasteRecords);
router.post('/', waste.createWasteRecord);
router.put('/:id', waste.updateWasteRecord);
router.delete('/:id', waste.deleteWasteRecord);

export default router;
