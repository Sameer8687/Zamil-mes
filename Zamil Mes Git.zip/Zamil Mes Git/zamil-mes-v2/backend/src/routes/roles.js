import { Router } from "express";
import * as roles from "../controllers/rolesController.js";
// import { authenticate, authorize } from "../middleware/auth.js";

const router = Router();

// router.use(authenticate);

router.get("/", roles.getRoles);
router.get("/:id", roles.getRole);
router.post("/", roles.createRole);
router.put("/:id", roles.updateRole);
router.delete("/:id", roles.deleteRole);
router.patch("/:id/toggle-status", roles.toggleRoleStatus);
router.put("/:id/permissions", roles.updateRolePermissions);

export default router;
