import { Router } from 'express';
import * as ref from '../controllers/referenceController.js';

const router = Router();
// Reference data is read-only; no auth required for dropdowns
router.get('/defect-types',          ref.getDefectTypes);
router.get('/waste-types',           ref.getWasteTypes);
router.get('/waste-categories',      ref.getWasteCategories);
router.get('/disposal-methods',      ref.getDisposalMethods);
router.get('/downtime-categories',   ref.getDowntimeCategories);
router.get('/lc-checklist',          ref.getLCChecklist);
router.get('/qc-checklist',          ref.getQCChecklist);

export default router;
