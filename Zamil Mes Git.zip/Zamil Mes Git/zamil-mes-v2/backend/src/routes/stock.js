import { Router } from 'express';
import * as stock from '../controllers/stockController.js';
import { authenticate } from '../middleware/auth.js';

const router = Router();
router.use(authenticate);

router.get('/', stock.getStockRecords);
router.get('/summary', stock.getStockSummary);
router.get('/:id', stock.getStockRecord);
router.post('/', stock.createStockRecord);
router.put('/:id', stock.updateStockRecord);

export default router;
