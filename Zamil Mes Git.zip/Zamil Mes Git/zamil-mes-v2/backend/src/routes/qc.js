import { Router } from 'express';
import * as qc from '../controllers/qcController.js';
import { authenticate } from '../middleware/auth.js';

const router = Router();
// router.use(authenticate);

router.get('/', qc.getQCResults);
router.get('/summary', qc.getQCSummary);
router.get('/:id', qc.getQCResult);
router.post('/', qc.createQCResult);
router.put('/:id', qc.updateQCResult);

export default router;
