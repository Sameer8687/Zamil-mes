import { Router } from 'express';
import * as prod from '../controllers/productionController.js';
import { authenticate } from '../middleware/auth.js';

const router = Router();
// router.use(authenticate);

router.get('/dashboard',                    prod.getDashboard);
router.get('/work-orders',                  prod.getWorkOrders);
router.get('/work-orders/:id',              prod.getWorkOrder);
router.post('/work-orders',                 prod.createWorkOrder);
router.put('/work-orders/:id',              prod.updateWorkOrder);
router.delete('/work-orders/:id',           prod.deleteWorkOrder);
router.get('/logs',                         prod.getLogs);
router.post('/logs',                        prod.createLog);
router.get('/machines',                     prod.getMachines);

export default router;
