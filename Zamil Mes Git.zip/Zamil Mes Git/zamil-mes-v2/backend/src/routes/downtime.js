import { Router } from 'express';
import * as dt from '../controllers/downtimeController.js';
import { authenticate } from '../middleware/auth.js';

const router = Router();
// router.use(authenticate);

router.get('/', dt.getDowntimeRecords);
router.get('/summary', dt.getDowntimeSummary);
router.post('/', dt.createDowntimeRecord);
router.put('/:id', dt.updateDowntimeRecord);

export default router;
