import { Router } from 'express';
import * as lc from '../controllers/lineclearanceController.js';
import { authenticate, authorize } from '../middleware/auth.js';

const router = Router();
// router.use(authenticate);

router.get('/', lc.getLineClearances);
router.get('/:id', lc.getLineClearance);
router.post('/', lc.createLineClearance);
router.put('/:id', lc.updateLineClearance);
router.post('/:id/approve', authorize('admin', 'qc', 'tech'), lc.approveLineClearance);

export default router;
