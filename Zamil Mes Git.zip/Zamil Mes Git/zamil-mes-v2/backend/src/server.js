import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import bcrypt from 'bcryptjs';
import env from './config/env.js';
import { initDatabase } from './config/db.js';
import { initModels, getModels } from './models/index.js';
import logger from './utils/logger.js';
import requestLogger from './middleware/logger.js';
import { errorHandler, notFoundHandler } from './middleware/errorHandler.js';

// Routes
import authRoutes         from './routes/auth.js';
import usersRoutes        from './routes/users.js';
import productionRoutes   from './routes/production.js';
import qcRoutes           from './routes/qc.js';
import wasteRoutes        from './routes/waste.js';
import downtimeRoutes     from './routes/downtime.js';
import packerRoutes       from './routes/packer.js';
import lineclearanceRoutes from './routes/lineclearance.js';
import stockRoutes        from './routes/stock.js';
import setupRoutes        from './routes/setup.js';
import installRoutes      from './routes/install.js';
import referenceRoutes    from './routes/reference.js';
import accessRoutes from './routes/access.js';
import rolesRoutes from './routes/roles.js';

const app = express();

app.use(helmet({ crossOriginEmbedderPolicy: false }));
app.use(cors({
  origin: [env.FRONTEND_URL, 'http://localhost:3000', 'http://localhost:5173', 'http://localhost:4173'],
  credentials: true,
  methods: ['GET','POST','PUT','DELETE','PATCH','OPTIONS'],
  allowedHeaders: ['Content-Type','Authorization'],
}));
app.use(compression());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(requestLogger);

// Health check
app.get('/health', (_req, res) => res.json({ status: 'ok', service: 'Zamil MES API', version: '3.0.0', timestamp: new Date().toISOString() }));

const prefix = env.API_PREFIX || '/api/v1';

app.use(`${prefix}/auth`,          authRoutes);
app.use(`${prefix}/users`,         usersRoutes);
app.use(`${prefix}/production`,    productionRoutes);
app.use(`${prefix}/qc`,            qcRoutes);
app.use(`${prefix}/waste`,         wasteRoutes);
app.use(`${prefix}/downtime`,      downtimeRoutes);
app.use(`${prefix}/packer`,        packerRoutes);
app.use(`${prefix}/line-clearance`,lineclearanceRoutes);
app.use(`${prefix}/stock`,         stockRoutes);
app.use(`${prefix}/setup`,         setupRoutes);
app.use(`${prefix}/install`,       installRoutes);
app.use(`${prefix}/reference`,     referenceRoutes);
app.use(`${prefix}/access`, accessRoutes);
app.use(`${prefix}/roles`, rolesRoutes);
app.use(notFoundHandler);
app.use(errorHandler);

const ensureDefaultAdmin = async () => {
  try {
    const { User } = getModels();
    const count = await User.count();
    if (count === 0) {
      const hash = await bcrypt.hash('Admin@1234', 12);
      await User.create({
        empId: 'EMP-0001', username: 'admin', passwordHash: hash,
        fullName: 'System Administrator', role: 'admin',
        plant: 'Zamil Plastics', isActive: true,
      });
      logger.info('Default admin created — EMP-0001 / Admin@1234');
    }
  } catch (err) {
    logger.warn('Could not verify default admin:', err.message);
  }
};

const start = async () => {
  try {
    const db = await initDatabase();
    initModels(db);
    if (env.NODE_ENV === 'development') {
      await db.sync();
      logger.info('Database synced (development)');
    } else {
      await db.sync();
    }
    await ensureDefaultAdmin();
    app.listen(env.PORT || 5000, () => {
      logger.info(`🚀 Zamil MES API — port ${env.PORT||5000} [${env.NODE_ENV}]`);
      logger.info(`   API: ${prefix}`);
    });
  } catch (err) {
    logger.error('Startup failed:', err);
    process.exit(1);
  }
};

start();
export default app;
