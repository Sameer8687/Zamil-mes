/**
 * Oracle ADW schema checker.
 *
 * Sequelize migrations are removed. Create/alter tables by running the Oracle SQL
 * scripts in SQL Developer:
 *
 *   backend/database/oracle/02_create_mes_current_schema.sql
 *   backend/database/oracle/03_create_mes_html_gap_schema.sql
 *   backend/database/oracle/04_indexes_constraints.sql
 *   backend/database/oracle/05_seed_master_data.sql
 *
 * This script only verifies that the expected MES_* tables exist in ADW.
 */

import { initOraclePool, executeRows, closeOraclePool } from '../config/oracle.js';
import logger from '../utils/logger.js';

const EXPECTED_TABLES = [
  'MES_AUDIT_LOGS',
  'MES_BOXES',
  'MES_BOX_QTY_RECORDS',
  'MES_DOWNTIME_RECORDS',
  'MES_LINE_CLEARANCES',
  'MES_LOCATIONS',
  'MES_MACHINES',
  'MES_PALLETS',
  'MES_PRODUCTION_LOGS',
  'MES_QC_RESULTS',
  'MES_ROLES',
  'MES_SHIFTS',
  'MES_STOCK_RECORDS',
  'MES_SYSTEM_CONFIGS',
  'MES_USERS',
  'MES_WASTE_RECORDS',
  'MES_WORK_ORDERS',
  'MES_ITEM_MASTER',
  'MES_WORK_ORDER_COMPONENTS',
  'MES_INVENTORY_LOTS',
  'MES_WORK_ORDER_MACHINE_ASG',
  'MES_PRODUCTION_EVENTS',
  'MES_BOX_QC_RESULTS',
  'MES_PALLET_BOX_SLOTS',
  'MES_LABEL_TEMPLATES',
  'MES_LABEL_PRINT_JOBS',
  'MES_LABEL_PRINT_HISTORY',
  'MES_WASTE_REASON_CODES',
  'MES_WASTE_TRANSACTIONS',
  'MES_DOWNTIME_REASON_CODES',
  'MES_DEFECT_TYPES',
  'MES_QC_CHECKLISTS',
  'MES_LC_CHECKLISTS',
  'MES_SCREENS',
  'MES_FEATURES',
  'MES_USER_ROLES',
  'MES_ROLE_SCREEN_PERMISSIONS',
  'MES_ROLE_FEATURE_PERMISSIONS',
  'MES_USER_SCREEN_OVERRIDES',
  'MES_USER_FEATURE_OVERRIDES',
  'MES_USER_SCOPE',
  'MES_USER_SESSIONS',
];

async function run() {
  try {
    await initOraclePool();

    const rows = await executeRows(`
      SELECT TABLE_NAME AS "tableName"
      FROM USER_TABLES
      WHERE TABLE_NAME LIKE 'MES$_%' ESCAPE '$'
      ORDER BY TABLE_NAME
    `);

    const existing = new Set(rows.map((row) => row.tableName));
    const missing = EXPECTED_TABLES.filter((tableName) => !existing.has(tableName));

    logger.info(`Found ${existing.size} MES_* table(s) in Oracle ADW.`);

    if (missing.length) {
      logger.warn('Missing MES tables:');
      missing.forEach((tableName) => logger.warn(`  - ${tableName}`));
      logger.warn('Run the Oracle schema scripts in SQL Developer before starting full API testing.');
      process.exitCode = 1;
    } else {
      logger.info('All expected MES_* tables exist.');
    }
  } catch (error) {
    logger.error('ADW schema check failed:', error);
    process.exitCode = 1;
  } finally {
    await closeOraclePool();
  }
}

run();
