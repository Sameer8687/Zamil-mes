import { initOraclePool, executeRows, executeDml, closeOraclePool } from '../config/oracle.js';
import logger from '../utils/logger.js';

const ensureColumn = async (tableName, columnName, definition) => {
  const rows = await executeRows(
    `
    SELECT COLUMN_NAME
    FROM USER_TAB_COLUMNS
    WHERE TABLE_NAME = :tableName
      AND COLUMN_NAME = :columnName
    `,
    { tableName, columnName },
  );

  if (rows.length) {
    logger.info(`${tableName}.${columnName} already exists`);
    return;
  }

  await executeDml(`ALTER TABLE ${tableName} ADD (${columnName} ${definition})`);
  logger.info(`Added ${tableName}.${columnName}`);
};

async function patchHtmlFlows() {
  try {
    await initOraclePool();

    await ensureColumn('MES_WORK_ORDERS', 'SCHEDULED_END_DATE', 'TIMESTAMP');
    await ensureColumn('MES_WORK_ORDERS', 'LOCATOR_CODE', 'VARCHAR2(100)');
    await ensureColumn('MES_WORK_ORDERS', 'EXECUTION_SEQUENCE', 'NUMBER(10)');
    await ensureColumn('MES_PALLET_BOX_SLOTS', 'CREATED_BY', 'VARCHAR2(100)');
    await ensureColumn('MES_PALLET_BOX_SLOTS', 'UPDATED_BY', 'VARCHAR2(100)');
    await ensureColumn('MES_LABEL_PRINT_JOBS', 'CREATED_BY', 'VARCHAR2(100)');
    await ensureColumn('MES_LABEL_PRINT_JOBS', 'UPDATED_BY', 'VARCHAR2(100)');
    await ensureColumn('MES_LABEL_PRINT_HISTORY', 'CREATED_BY', 'VARCHAR2(100)');
    await ensureColumn('MES_LABEL_PRINT_HISTORY', 'UPDATED_BY', 'VARCHAR2(100)');

    logger.info('HTML flow schema patch complete.');
    process.exitCode = 0;
  } catch (error) {
    logger.error('HTML flow schema patch failed:', error);
    process.exitCode = 1;
  } finally {
    await closeOraclePool();
  }
}

patchHtmlFlows();
