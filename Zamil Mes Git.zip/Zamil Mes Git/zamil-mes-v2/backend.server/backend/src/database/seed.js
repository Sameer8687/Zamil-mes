/**
 * Oracle ADW demo data seeder.
 *
 * This script uses raw Oracle DML only. It does not use Sequelize.
 * Run after the MES_* schema scripts are created in SQL Developer.
 */

import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';
import { initOraclePool, executeDml, executeRows, closeOraclePool } from '../config/oracle.js';
import logger from '../utils/logger.js';

const nowSql = 'SYSTIMESTAMP';

const mergeRow = async ({ table, keyColumn, row, updateColumns }) => {
  const insertColumns = Object.keys(row);
  const nonKeyUpdateColumns = updateColumns.filter((column) => column !== keyColumn && column !== 'ID');

  const sourceSelect = insertColumns
    .map((column) => `:${column} AS ${column}`)
    .join(', ');

  const updateSet = nonKeyUpdateColumns.length
    ? nonKeyUpdateColumns.map((column) => `t.${column} = s.${column}`).join(', ') + ', t.UPDATED_AT = SYSTIMESTAMP'
    : 't.UPDATED_AT = SYSTIMESTAMP';

  const insertValues = insertColumns.map((column) => `s.${column}`).join(', ');

  const sql = `
    MERGE INTO ${table} t
    USING (SELECT ${sourceSelect} FROM DUAL) s
       ON (t.${keyColumn} = s.${keyColumn})
    WHEN MATCHED THEN
      UPDATE SET ${updateSet}
    WHEN NOT MATCHED THEN
      INSERT (${insertColumns.join(', ')}, CREATED_AT, UPDATED_AT)
      VALUES (${insertValues}, ${nowSql}, ${nowSql})
  `;

  await executeDml(sql, row);
};

const seedRoles = async () => {
  const roles = [
    { NAME: 'admin', DESCRIPTION: 'Service Admin - full system access' },
    { NAME: 'tech', DESCRIPTION: 'Process Technician - production, work order, QC and line clearance access' },
    { NAME: 'operator', DESCRIPTION: 'Operator - operator screen, waste and downtime entry' },
    { NAME: 'qc', DESCRIPTION: 'QC Inspector - QC overview, QC detail and line clearance access' },
    { NAME: 'packer', DESCRIPTION: 'Packer - packer overview and pallet label access' },
    { NAME: 'viewer', DESCRIPTION: 'Read-only Viewer - view-only access to reports' },
  ];

  for (const role of roles) {
    await mergeRow({
      table: 'MES_ROLES',
      keyColumn: 'NAME',
      row: {
        ID: uuidv4(),
        NAME: role.NAME,
        DESCRIPTION: role.DESCRIPTION,
        PERMISSIONS_JSON: '{}',
        CREATED_BY: 'system',
        UPDATED_BY: 'system',
        IS_ACTIVE: 1,
        IS_DELETED: 0,
      },
      updateColumns: ['DESCRIPTION', 'PERMISSIONS_JSON', 'UPDATED_BY', 'IS_ACTIVE', 'IS_DELETED'],
    });
  }

  logger.info(`Seeded ${roles.length} roles`);
};

const seedUsers = async () => {
  const adminHash = await bcrypt.hash('Admin@1234', 12);
  const demoHash = await bcrypt.hash('Demo@1234', 12);

  const users = [
    { EMP_ID: 'EMP-0001', USERNAME: 'admin', PASSWORD_HASH: adminHash, FULL_NAME: 'Muhannad Ali Saeed', ROLE: 'admin', PLANT: 'Zamil Plastics' },
    { EMP_ID: 'EMP-2479', USERNAME: 'syed.hussaini', PASSWORD_HASH: demoHash, FULL_NAME: 'Syed Hussaini', ROLE: 'tech', PLANT: 'Zamil Plastics' },
    { EMP_ID: 'EMP-5012', USERNAME: 'ahmed.hassan', PASSWORD_HASH: demoHash, FULL_NAME: 'Ahmed Hassan', ROLE: 'operator', PLANT: 'Zamil Plastics' },
    { EMP_ID: 'EMP-1001', USERNAME: 'mustafa.maqrodh', PASSWORD_HASH: demoHash, FULL_NAME: 'Mustafa Al Maqrodh', ROLE: 'qc', PLANT: 'Zamil Plastics' },
    { EMP_ID: 'EMP-3301', USERNAME: 'ahmed.rashidi', PASSWORD_HASH: demoHash, FULL_NAME: 'Ahmed Al Rashidi', ROLE: 'packer', PLANT: 'Zamil Plastics' },
    { EMP_ID: 'EMP-2122', USERNAME: 'amro.faisal', PASSWORD_HASH: demoHash, FULL_NAME: 'Amro Faisal', ROLE: 'tech', PLANT: 'Zamil Plastics' },
  ];

  for (const user of users) {
    await mergeRow({
      table: 'MES_USERS',
      keyColumn: 'EMP_ID',
      row: {
        ID: uuidv4(),
        EMP_ID: user.EMP_ID,
        USERNAME: user.USERNAME,
        PASSWORD_HASH: user.PASSWORD_HASH,
        FULL_NAME: user.FULL_NAME,
        EMAIL: null,
        PHONE: null,
        ROLE_CODE: user.ROLE,
        PLANT: user.PLANT,
        DEPARTMENT: null,
        SHIFT: null,
        LANGUAGE_CODE: 'en',
        THEME: 'zamil',
        MUST_CHANGE_PASSWORD: 0,
        SCREEN_PERMISSIONS_JSON: '{}',
        CREATED_BY: 'system',
        UPDATED_BY: 'system',
        IS_ACTIVE: 1,
        IS_DELETED: 0,
      },
      updateColumns: [
        'USERNAME',
        'PASSWORD_HASH',
        'FULL_NAME',
        'EMAIL',
        'PHONE',
        'ROLE_CODE',
        'PLANT',
        'DEPARTMENT',
        'SHIFT',
        'LANGUAGE_CODE',
        'THEME',
        'MUST_CHANGE_PASSWORD',
        'SCREEN_PERMISSIONS_JSON',
        'UPDATED_BY',
        'IS_ACTIVE',
        'IS_DELETED',
      ],
    });
  }

  logger.info(`Seeded ${users.length} users`);
};

const seedMachines = async () => {
  const machines = [
    { CODE: 'ZFP-01', NAME: 'ZFP 01 – Film Press', TYPE: 'Film Press', PLANT: 'FPP', DEPT: 'BLOWMOLDIN', OEM: 'BMB', MODEL: 'SB-600', SERIAL: 'SN001', TONNAGE: '600T', CYCLE_TIME: 28, CAVITIES: 4, IP: '192.168.1.10', MES_CODE: 'MES-ZFP-01', PM_FREQ: 'Monthly', STATUS: 'running' },
    { CODE: 'ZFP-02', NAME: 'ZFP 02 – Film Press', TYPE: 'Film Press', PLANT: 'FPP', DEPT: 'BLOWMOLDIN', OEM: 'BMB', MODEL: 'SB-600', SERIAL: 'SN002', TONNAGE: '600T', CYCLE_TIME: 28, CAVITIES: 4, IP: '192.168.1.11', MES_CODE: 'MES-ZFP-02', PM_FREQ: 'Monthly', STATUS: 'idle' },
    { CODE: 'ZFP-03', NAME: 'ZFP 03 – Film Press', TYPE: 'Film Press', PLANT: 'FPP', DEPT: 'BLOWMOLDIN', OEM: 'BMB', MODEL: 'SB-400', SERIAL: 'SN003', TONNAGE: '400T', CYCLE_TIME: 24, CAVITIES: 2, IP: '192.168.1.12', MES_CODE: 'MES-ZFP-03', PM_FREQ: 'Monthly', STATUS: 'running' },
    { CODE: 'ZFP-10', NAME: 'ZFP 10 – Film Press', TYPE: 'Film Press', PLANT: 'FPP', DEPT: 'BLOWMOLDIN', OEM: 'BMB', MODEL: 'SB-800', SERIAL: 'SN010', TONNAGE: '800T', CYCLE_TIME: 32, CAVITIES: 6, IP: '192.168.1.20', MES_CODE: 'MES-ZFP-10', PM_FREQ: 'Quarterly', STATUS: 'running' },
    { CODE: 'INJ-077', NAME: 'INJ-077 – Injection 280T', TYPE: 'Injection', PLANT: 'IPP', DEPT: 'INJECTION', OEM: 'JSW', MODEL: 'J280', SERIAL: 'SN077', TONNAGE: '280T', CYCLE_TIME: 22, CAVITIES: 4, IP: '192.168.1.77', MES_CODE: 'MES-INJ-077', PM_FREQ: 'Monthly', STATUS: 'maintenance' },
    { CODE: 'INJ-083', NAME: 'INJ-083 – Injection 280T', TYPE: 'Injection', PLANT: 'IPP', DEPT: 'INJECTION', OEM: 'JSW', MODEL: 'J280', SERIAL: 'SN083', TONNAGE: '280T', CYCLE_TIME: 22, CAVITIES: 8, IP: '192.168.1.83', MES_CODE: 'MES-INJ-083', PM_FREQ: 'Quarterly', STATUS: 'running' },
    { CODE: 'INJ-103', NAME: 'INJ-103 – Injection 500T', TYPE: 'Injection', PLANT: 'IPP', DEPT: 'INJECTION', OEM: 'TOYO', MODEL: 'SI500', SERIAL: 'SN103', TONNAGE: '500T', CYCLE_TIME: 35, CAVITIES: 16, IP: '192.168.1.103', MES_CODE: 'MES-INJ-103', PM_FREQ: 'Monthly', STATUS: 'idle' },
    { CODE: 'INJ-106', NAME: 'INJ-106 – Injection 500T', TYPE: 'Injection', PLANT: 'IPP', DEPT: 'INJECTION', OEM: 'TOYO', MODEL: 'SI500', SERIAL: 'SN106', TONNAGE: '500T', CYCLE_TIME: 35, CAVITIES: 16, IP: '192.168.1.106', MES_CODE: 'MES-INJ-106', PM_FREQ: 'Monthly', STATUS: 'running' },
    { CODE: 'ZPC-01', NAME: 'ZPC-01 – Closure Press', TYPE: 'Closure', PLANT: 'ZPC', DEPT: 'ASSEMBLY', OEM: 'ENGEL', MODEL: 'E-200', SERIAL: 'SN201', TONNAGE: '200T', CYCLE_TIME: 18, CAVITIES: 32, IP: '192.168.2.01', MES_CODE: 'MES-ZPC-01', PM_FREQ: 'Monthly', STATUS: 'running' },
  ];

  for (const machine of machines) {
    await mergeRow({
      table: 'MES_MACHINES',
      keyColumn: 'CODE',
      row: {
        ID: uuidv4(),
        CODE: machine.CODE,
        NAME: machine.NAME,
        MACHINE_TYPE: machine.TYPE,
        PLANT: machine.PLANT,
        DEPARTMENT: machine.DEPT,
        AREA: null,
        LOCATOR: null,
        OEM: machine.OEM,
        MODEL: machine.MODEL,
        SERIAL_NO: machine.SERIAL,
        TONNAGE: machine.TONNAGE,
        CYCLE_TIME: machine.CYCLE_TIME,
        CAVITIES: machine.CAVITIES,
        IP_ADDRESS: machine.IP,
        PLC_TYPE: null,
        COMM_PROTOCOL: null,
        MES_CODE: machine.MES_CODE,
        PM_FREQ: machine.PM_FREQ,
        LAST_PM_DATE: null,
        STATUS: machine.STATUS,
        CREATED_BY: 'system',
        UPDATED_BY: 'system',
        IS_ACTIVE: 1,
        IS_DELETED: 0,
      },
      updateColumns: [
        'NAME',
        'MACHINE_TYPE',
        'PLANT',
        'DEPARTMENT',
        'AREA',
        'LOCATOR',
        'OEM',
        'MODEL',
        'SERIAL_NO',
        'TONNAGE',
        'CYCLE_TIME',
        'CAVITIES',
        'IP_ADDRESS',
        'PLC_TYPE',
        'COMM_PROTOCOL',
        'MES_CODE',
        'PM_FREQ',
        'LAST_PM_DATE',
        'STATUS',
        'UPDATED_BY',
        'IS_ACTIVE',
        'IS_DELETED',
      ],
    });
  }

  logger.info(`Seeded ${machines.length} machines`);
};

const seedLocations = async () => {
  const locations = [
    { CODE: 'FPP-WH-01', NAME: 'FPP Warehouse Bay 1', TYPE: 'warehouse', PLANT: 'FPP BU' },
    { CODE: 'FPP-WH-02', NAME: 'FPP Warehouse Bay 2', TYPE: 'warehouse', PLANT: 'FPP BU' },
    { CODE: 'FPP-WH-03', NAME: 'FPP Warehouse Bay 3', TYPE: 'warehouse', PLANT: 'FPP BU' },
    { CODE: 'IPP-WH-01', NAME: 'IPP Warehouse Main', TYPE: 'warehouse', PLANT: 'IPP BU' },
    { CODE: 'IPP-WH-02', NAME: 'IPP Warehouse Bay 2', TYPE: 'warehouse', PLANT: 'IPP BU' },
    { CODE: 'ZPC-WH-01', NAME: 'ZPC Warehouse Main', TYPE: 'warehouse', PLANT: 'ZPC BU' },
    { CODE: 'FPP-STG-01', NAME: 'FPP Staging Area 1', TYPE: 'staging', PLANT: 'FPP BU' },
    { CODE: 'SCRAP-01', NAME: 'Scrap Yard Zone A', TYPE: 'scrap', PLANT: 'FPP BU' },
  ];

  for (const location of locations) {
    await mergeRow({
      table: 'MES_LOCATIONS',
      keyColumn: 'CODE',
      row: {
        ID: uuidv4(),
        CODE: location.CODE,
        NAME: location.NAME,
        LOCATION_TYPE: location.TYPE,
        PLANT: location.PLANT,
        CREATED_BY: 'system',
        UPDATED_BY: 'system',
        IS_ACTIVE: 1,
        IS_DELETED: 0,
      },
      updateColumns: ['NAME', 'LOCATION_TYPE', 'PLANT', 'UPDATED_BY', 'IS_ACTIVE', 'IS_DELETED'],
    });
  }

  logger.info(`Seeded ${locations.length} locations`);
};

const seedShifts = async () => {
  const shifts = [
    { NAME: 'AB – Day Shift', START_TIME: '06:00', END_TIME: '18:00', PLANT: 'FPP BU' },
    { NAME: 'CD – Night Shift', START_TIME: '18:00', END_TIME: '06:00', PLANT: 'FPP BU' },
    { NAME: 'A Morning', START_TIME: '06:00', END_TIME: '14:00', PLANT: 'IPP BU' },
    { NAME: 'B Afternoon', START_TIME: '14:00', END_TIME: '22:00', PLANT: 'IPP BU' },
  ];

  for (const shift of shifts) {
    await mergeRow({
      table: 'MES_SHIFTS',
      keyColumn: 'NAME',
      row: {
        ID: uuidv4(),
        NAME: shift.NAME,
        START_TIME: shift.START_TIME,
        END_TIME: shift.END_TIME,
        PLANT: shift.PLANT,
        CREATED_BY: 'system',
        UPDATED_BY: 'system',
        IS_ACTIVE: 1,
        IS_DELETED: 0,
      },
      updateColumns: ['START_TIME', 'END_TIME', 'PLANT', 'UPDATED_BY', 'IS_ACTIVE', 'IS_DELETED'],
    });
  }

  logger.info(`Seeded ${shifts.length} shifts`);
};

const seedSystemConfigs = async () => {
  const configs = [
    { CONFIG_KEY: 'app_name', CONFIG_VALUE: 'Zamil MES System', CATEGORY: 'general', DESCRIPTION: 'Application name' },
    { CONFIG_KEY: 'plant_name', CONFIG_VALUE: 'Zamil Plastics Factory', CATEGORY: 'general', DESCRIPTION: 'Plant display name' },
    { CONFIG_KEY: 'default_box_qty', CONFIG_VALUE: '50', CATEGORY: 'packing', DESCRIPTION: 'Default pieces per box' },
    { CONFIG_KEY: 'qc_sample_size', CONFIG_VALUE: '5', CATEGORY: 'qc', DESCRIPTION: 'Default QC sample size' },
    { CONFIG_KEY: 'pallet_max_boxes', CONFIG_VALUE: '50', CATEGORY: 'packing', DESCRIPTION: 'Maximum boxes per pallet' },
    { CONFIG_KEY: 'currency', CONFIG_VALUE: 'SAR', CATEGORY: 'general', DESCRIPTION: 'Default currency' },
  ];

  for (const config of configs) {
    await mergeRow({
      table: 'MES_SYSTEM_CONFIGS',
      keyColumn: 'CONFIG_KEY',
      row: {
        ID: uuidv4(),
        CONFIG_KEY: config.CONFIG_KEY,
        CONFIG_VALUE: config.CONFIG_VALUE,
        CATEGORY: config.CATEGORY,
        DESCRIPTION: config.DESCRIPTION,
        CREATED_BY: 'system',
        UPDATED_BY: 'system',
        IS_ACTIVE: 1,
        IS_DELETED: 0,
      },
      updateColumns: ['CONFIG_VALUE', 'CATEGORY', 'DESCRIPTION', 'UPDATED_BY', 'IS_ACTIVE', 'IS_DELETED'],
    });
  }

  logger.info(`Seeded ${configs.length} system configs`);
};

const seedWorkOrders = async () => {
  const rows = await executeRows(`
    SELECT CODE AS "code", ID AS "id"
    FROM MES_MACHINES
    WHERE IS_DELETED = 0
  `);

  const machineMap = Object.fromEntries(rows.map((row) => [row.code, row.id]));

  const workOrders = [
    { WO_NUMBER: 'FPP-WO-414', PRODUCT: 'PP Cap 28mm', PRODUCT_CODE: 'FG9406', CUSTOMER: 'Zamil Steel', PLANT: 'FPP BU', PLANNED_QTY: 15000, PRODUCED_QTY: 11200, STATUS: 'active', BOX_QTY: 50, MACHINE_CODE: 'ZFP-01', LOCATOR_CODE: 'FPP-WH-01', EXECUTION_SEQUENCE: 1 },
    { WO_NUMBER: 'FPP-WO-494', PRODUCT: 'HDPE Bottle 1L', PRODUCT_CODE: 'FG8820', CUSTOMER: 'Saudi Aramco', PLANT: 'FPP BU', PLANNED_QTY: 8000, PRODUCED_QTY: 3400, STATUS: 'active', BOX_QTY: 100, MACHINE_CODE: 'ZFP-02', LOCATOR_CODE: 'FPP-WH-02', EXECUTION_SEQUENCE: 2 },
    { WO_NUMBER: 'FPP-WO-477', PRODUCT: 'PP Granule 3kg', PRODUCT_CODE: 'FG7722', CUSTOMER: 'SABIC', PLANT: 'FPP BU', PLANNED_QTY: 5000, PRODUCED_QTY: 5000, STATUS: 'completed', BOX_QTY: 25, MACHINE_CODE: 'ZFP-03', LOCATOR_CODE: 'FPP-WH-03', EXECUTION_SEQUENCE: 3 },
    { WO_NUMBER: 'IPP-WO-201', PRODUCT: 'PET Jar 500ml', PRODUCT_CODE: 'FG7701', CUSTOMER: 'Al-Marai', PLANT: 'IPP BU', PLANNED_QTY: 2000, PRODUCED_QTY: 1650, STATUS: 'active', BOX_QTY: 10, MACHINE_CODE: 'INJ-083', LOCATOR_CODE: 'IPP-WH-01', EXECUTION_SEQUENCE: 4 },
    { WO_NUMBER: 'IPP-WO-188', PRODUCT: 'LDPE Bag 1kg', PRODUCT_CODE: 'FG6601', CUSTOMER: 'Saudi Exports', PLANT: 'IPP BU', PLANNED_QTY: 3000, PRODUCED_QTY: 2900, STATUS: 'active', BOX_QTY: 20, MACHINE_CODE: 'INJ-103', LOCATOR_CODE: 'IPP-WH-02', EXECUTION_SEQUENCE: 5 },
    { WO_NUMBER: 'ZPC-WO-099', PRODUCT: 'Closure Cap', PRODUCT_CODE: 'ZPC-CC', CUSTOMER: 'ZPC Customer', PLANT: 'ZPC BU', PLANNED_QTY: 50000, PRODUCED_QTY: 42000, STATUS: 'active', BOX_QTY: 200, MACHINE_CODE: 'ZPC-01', LOCATOR_CODE: 'ZPC-WH-01', EXECUTION_SEQUENCE: 6 },
  ];

  for (const wo of workOrders) {
    await mergeRow({
      table: 'MES_WORK_ORDERS',
      keyColumn: 'WO_NUMBER',
      row: {
        ID: uuidv4(),
        WO_NUMBER: wo.WO_NUMBER,
        PRODUCT: wo.PRODUCT,
        PRODUCT_CODE: wo.PRODUCT_CODE,
        CUSTOMER: wo.CUSTOMER,
        PLANT: wo.PLANT,
        MACHINE_ID: wo.MACHINE_CODE,
        PLANNED_QTY: wo.PLANNED_QTY,
        PRODUCED_QTY: wo.PRODUCED_QTY,
        TARGET_QTY: wo.PLANNED_QTY,
        BOX_QTY: wo.BOX_QTY,
        STATUS: wo.STATUS,
        PRIORITY: 'normal',
        SCHEDULED_DATE: new Date(),
        SCHEDULED_END_DATE: new Date(Date.now() + 8 * 60 * 60 * 1000),
        LOCATOR_CODE: wo.LOCATOR_CODE,
        EXECUTION_SEQUENCE: wo.EXECUTION_SEQUENCE,
        COMPLETED_DATE: null,
        NOTES: null,
        CREATED_BY: 'system',
        UPDATED_BY: 'system',
        IS_ACTIVE: 1,
        IS_DELETED: 0,
      },
      updateColumns: [
        'PRODUCT',
        'PRODUCT_CODE',
        'CUSTOMER',
        'PLANT',
        'MACHINE_ID',
        'PLANNED_QTY',
        'PRODUCED_QTY',
        'TARGET_QTY',
        'BOX_QTY',
        'STATUS',
        'PRIORITY',
        'SCHEDULED_DATE',
        'SCHEDULED_END_DATE',
        'LOCATOR_CODE',
        'EXECUTION_SEQUENCE',
        'COMPLETED_DATE',
        'NOTES',
        'UPDATED_BY',
        'IS_ACTIVE',
        'IS_DELETED',
      ],
    });
  }

  logger.info(`Seeded ${workOrders.length} work orders`);
};

const seedBoxesAndStock = async () => {
  const workOrders = await executeRows(`
    SELECT
      WO.ID AS "id",
      WO.WO_NUMBER AS "woNumber",
      WO.PRODUCT AS "product",
      WO.PRODUCT_CODE AS "productCode",
      WO.PLANT AS "plant",
      WO.MACHINE_ID AS "machineId",
      WO.BOX_QTY AS "boxQty",
      WO.LOCATOR_CODE AS "locatorCode",
      M.CODE AS "machineCode"
    FROM MES_WORK_ORDERS WO
    LEFT JOIN MES_MACHINES M ON M.CODE = WO.MACHINE_ID
    WHERE WO.IS_DELETED = 0
      AND WO.STATUS = 'active'
    ORDER BY WO.EXECUTION_SEQUENCE NULLS LAST, WO.WO_NUMBER
  `);

  const users = await executeRows(`
    SELECT ID AS "id"
    FROM MES_USERS
    WHERE ROLE_CODE = 'packer'
      AND IS_DELETED = 0
    FETCH FIRST 1 ROWS ONLY
  `);
  const packerId = users[0]?.id || null;

  let boxCount = 0;
  for (const wo of workOrders.slice(0, 4)) {
    const statuses = ['appr', 'appr', 'pend', 'rejt', 'appr'];
    for (let index = 0; index < statuses.length; index += 1) {
      const boxNo = index + 1;
      const barcode = `BOX-${wo.woNumber}-${String(boxNo).padStart(3, '0')}`;
      const qcStatus = statuses[index];

      await mergeRow({
        table: 'MES_BOXES',
        keyColumn: 'BARCODE',
        row: {
          ID: uuidv4(),
          BARCODE: barcode,
          WO_ID: wo.id,
          MACHINE_ID: wo.machineId,
          PACKED_BY_ID: packerId,
          QUANTITY: wo.boxQty || 1,
          WEIGHT: null,
          STATUS: 'open',
          QC_STATUS: qcStatus,
          QC_NOTES: qcStatus === 'rejt' ? 'Demo rejected sample' : null,
          QC_CHECKS_JSON: '{}',
          PALLET_ID: null,
          PACKED_AT: new Date(Date.now() - (statuses.length - index) * 60 * 1000),
          LABEL_PRINTED: 1,
          CREATED_BY: 'system',
          UPDATED_BY: 'system',
          IS_ACTIVE: 1,
          IS_DELETED: 0,
        },
        updateColumns: [
          'WO_ID',
          'MACHINE_ID',
          'PACKED_BY_ID',
          'QUANTITY',
          'WEIGHT',
          'STATUS',
          'QC_STATUS',
          'QC_NOTES',
          'QC_CHECKS_JSON',
          'PALLET_ID',
          'PACKED_AT',
          'LABEL_PRINTED',
          'UPDATED_BY',
          'IS_ACTIVE',
          'IS_DELETED',
        ],
      });

      await mergeRow({
        table: 'MES_STOCK_RECORDS',
        keyColumn: 'BOX_NO',
        row: {
          ID: uuidv4(),
          WO_ID: wo.id,
          LOCATION_ID: null,
          PALLET_ID: null,
          ORG: wo.plant,
          PLANT: wo.plant,
          MACHINE: wo.machineCode,
          PRODUCT_CODE: wo.productCode,
          PRODUCT_NAME: wo.product,
          WO_NUM: wo.woNumber,
          BOX_NO: barcode,
          PALLET_CODE: null,
          LOCATOR_CODE: wo.locatorCode,
          QUANTITY: wo.boxQty || 1,
          RESERVED_QTY: 0,
          QC_STATUS: qcStatus,
          STATUS: 'in_stock',
          RECEIVED_AT: new Date(Date.now() - (statuses.length - index) * 60 * 1000),
          DISPATCHED_AT: null,
          CREATED_BY: 'system',
          UPDATED_BY: 'system',
          IS_ACTIVE: 1,
          IS_DELETED: 0,
        },
        updateColumns: [
          'WO_ID',
          'LOCATION_ID',
          'PALLET_ID',
          'ORG',
          'PLANT',
          'MACHINE',
          'PRODUCT_CODE',
          'PRODUCT_NAME',
          'WO_NUM',
          'PALLET_CODE',
          'LOCATOR_CODE',
          'QUANTITY',
          'RESERVED_QTY',
          'QC_STATUS',
          'STATUS',
          'RECEIVED_AT',
          'DISPATCHED_AT',
          'UPDATED_BY',
          'IS_ACTIVE',
          'IS_DELETED',
        ],
      });

      boxCount += 1;
    }
  }

  logger.info(`Seeded ${boxCount} demo boxes and stock records`);
};

async function seed() {
  try {
    await initOraclePool();

    logger.info('Seeding Oracle ADW demo data...');

    await seedRoles();
    await seedUsers();
    await seedMachines();
    await seedLocations();
    await seedShifts();
    await seedSystemConfigs();
    await seedWorkOrders();
    await seedBoxesAndStock();

    logger.info('ADW seeding complete.');
    process.exitCode = 0;
  } catch (error) {
    logger.error('ADW seeding failed:', error);
    process.exitCode = 1;
  } finally {
    await closeOraclePool();
  }
}

seed();
