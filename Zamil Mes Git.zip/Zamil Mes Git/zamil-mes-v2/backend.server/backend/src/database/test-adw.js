import { initOraclePool, executeOne, closeOraclePool } from '../config/oracle.js';

async function testAdw() {
  try {
    await initOraclePool();

    const row = await executeOne(`
      SELECT
        USER AS "currentUser",
        SYS_CONTEXT('USERENV', 'SERVICE_NAME') AS "serviceName",
        SYSDATE AS "dbDate"
      FROM DUAL
    `);

    console.log('ADW connected successfully');
    console.log(row);

    await closeOraclePool();
    process.exit(0);
  } catch (error) {
    console.error('ADW connection failed');
    console.error(error);
    process.exit(1);
  }
}

testAdw();
