import {
  TABLES,
  query,
  queryOne,
  pagedQuery,
  addEq,
  addLike,
  addDateFrom,
  addDateTo,
  insertRow,
  updateRow,
  softDeleteRow,
  toNumber,
} from './base.model.js';
import { executeCommit } from '../config/oracle.js';

const workOrderFieldMap = {
  woNumber: 'WO_NUMBER',
  product: 'PRODUCT',
  productCode: 'PRODUCT_CODE',
  customer: 'CUSTOMER',
  plant: 'PLANT',
  machineId: 'MACHINE_ID',
  plannedQty: 'PLANNED_QTY',
  producedQty: 'PRODUCED_QTY',
  targetQty: 'TARGET_QTY',
  boxQty: 'BOX_QTY',
  status: 'STATUS',
  priority: 'PRIORITY',
  scheduledDate: 'SCHEDULED_DATE',
  scheduledEndDate: 'SCHEDULED_END_DATE',
  locatorCode: 'LOCATOR_CODE',
  executionSequence: 'EXECUTION_SEQUENCE',
  completedDate: 'COMPLETED_DATE',
  startedAt: 'STARTED_AT',
  pausedAt: 'PAUSED_AT',
  notes: 'NOTES',
};

const productionLogFieldMap = {
  woId: 'WO_ID',
  machineId: 'MACHINE_ID',
  operatorId: 'OPERATOR_ID',
  shift: 'SHIFT',
  startTime: 'START_TIME',
  endTime: 'END_TIME',
  qtyProduced: 'QTY_PRODUCED',
  qtyRejected: 'QTY_REJECTED',
  cavityCount: 'CAVITY_COUNT',
  cycleTime: 'CYCLE_TIME',
  notes: 'NOTES',
};

const componentFieldMap = {
  woId: 'WO_ID',
  componentCode: 'COMPONENT_CODE',
  componentDesc: 'COMPONENT_DESC',
  componentType: 'COMPONENT_TYPE',
  requiredQty: 'REQUIRED_QTY',
  issuedQty: 'ISSUED_QTY',
  consumedQty: 'CONSUMED_QTY',
  uom: 'UOM',
  lotNo: 'LOT_NO',
  status: 'STATUS',
};

const cleanKey = (value) => {
  if (value === undefined || value === null) return null;
  const text = String(value).trim();
  return text || null;
};

const validMesWorkOrderMachineCondition = `
  (
    UPPER(WO.MACHINE_ID) LIKE 'INJ-%'
    OR UPPER(WO.MACHINE_ID) LIKE 'ZFP%'
  )
`;

const splitStatusFilterValues = (value) => {
  if (value === undefined || value === null || value === '') return [];

  const values = Array.isArray(value) ? value : String(value).split(',');

  return values
    .map((item) => String(item || '').trim())
    .filter(Boolean);
};

const normalizeStatusKey = (value) =>
  String(value || '')
    .trim()
    .toUpperCase()
    .replace(/[_-]+/g, ' ')
    .replace(/\s+/g, ' ');

const getWorkOrderStatusAliases = (value) => {
  const key = normalizeStatusKey(value);

  if (!key) return [];

  if (['RUNNING', 'RUN', 'ACTIVE', 'IN PROGRESS', 'STARTED'].includes(key)) {
    return ['ACTIVE', 'RUNNING'];
  }

  if (['RELEASED', 'RELEASE', 'ORA RELEASED'].includes(key)) {
    return ['RELEASED', 'ORA_RELEASED'];
  }

  if (['UNRELEASED', 'UN RELEASED', 'UN RELEASE', 'ORA UNRELEASED'].includes(key)) {
    return ['UNRELEASED', 'UN RELEASED', 'ORA_UNRELEASED'];
  }

  if (['COMPLETED', 'COMPLETE', 'DONE'].includes(key)) {
    return ['COMPLETED', 'COMPLETE'];
  }

  if (['TERMINATED', 'TERMINATE', 'VOID'].includes(key)) {
    return ['TERMINATED', 'CANCELED', 'CANCELLED', 'CLOSED', 'VOID'];
  }

  if (['CANCELED', 'CANCELLED', 'CANCEL'].includes(key)) {
    return ['CANCELED', 'CANCELLED'];
  }

  if (['CLOSED', 'CLOSE'].includes(key)) {
    return ['CLOSED'];
  }

  if (['PAUSED', 'PAUSE', 'ON HOLD', 'HOLD'].includes(key)) {
    return ['PAUSED'];
  }

  return [String(value).trim().toUpperCase()];
};

const addWorkOrderStatusFilter = (where, binds, value) => {
  const statuses = [
    ...new Set(
      splitStatusFilterValues(value).flatMap((item) =>
        getWorkOrderStatusAliases(item)
      )
    ),
  ];

  if (!statuses.length) return;

  const bindNames = statuses.map((status, index) => {
    const bindName = `status${index}`;
    binds[bindName] = status;
    return `:${bindName}`;
  });

  where.push(`UPPER(TRIM(WO.STATUS)) IN (${bindNames.join(', ')})`);
};

const workOrderStatusOrderBy = `
  CASE
    /* 1. RUNNING */
    WHEN REPLACE(REPLACE(REPLACE(UPPER(TRIM(WO.STATUS)), '_', ''), '-', ''), ' ', '') 
      IN ('ACTIVE', 'RUNNING', 'RUN', 'INPROGRESS', 'STARTED') THEN 1

    /* 2. RELEASED */
    WHEN REPLACE(REPLACE(REPLACE(UPPER(TRIM(WO.STATUS)), '_', ''), '-', ''), ' ', '') 
      IN ('RELEASED', 'RELEASE', 'ORARELEASED') THEN 2

    /* 3. UN RELEASED */
    WHEN REPLACE(REPLACE(REPLACE(UPPER(TRIM(WO.STATUS)), '_', ''), '-', ''), ' ', '') 
      IN ('UNRELEASED', 'UNRELEASE', 'ORAUNRELEASED', 'PENDING', 'NOTSTARTED', 'SCHEDULED', 'OPEN') THEN 3

    /* 4. COMPLETED */
    WHEN REPLACE(REPLACE(REPLACE(UPPER(TRIM(WO.STATUS)), '_', ''), '-', ''), ' ', '') 
      IN ('COMPLETED', 'COMPLETE', 'DONE') THEN 4

    /* 5. TERMINATED */
    WHEN REPLACE(REPLACE(REPLACE(UPPER(TRIM(WO.STATUS)), '_', ''), '-', ''), ' ', '') 
      IN ('TERMINATED', 'TERMINATE', 'CANCELED', 'CANCELLED', 'CANCEL', 'CLOSED', 'CLOSE', 'VOID') THEN 5

    ELSE 99
  END ASC,
  WO.EXECUTION_SEQUENCE ASC NULLS LAST,
  WO.SCHEDULED_DATE DESC NULLS LAST,
  WO.CREATED_AT DESC
`;

const cleanStatus = (value) => String(value || '').trim();

export function isLocalUnreleasedStatus(value) {
  const status = cleanStatus(value).toUpperCase();
  return status === 'UNRELEASED' || status === 'ORA_UNRELEASED' || status === 'Unreleased';
}

export function normalizeFusionStatusForLocal(value) {
  const status = cleanStatus(value);

  if (!status) return null;

  const upper = status.toUpperCase();

  if (upper === 'UNRELEASED' || upper === 'ORA_UNRELEASED' || upper === 'Unreleased') return 'Unreleased';
  if (upper === 'RELEASED' || upper === 'ORA_RELEASED' || upper === 'RELEASE') return 'Released';
  if (upper === 'COMPLETED' || upper === 'COMPLETE') return 'Completed';
  if (upper === 'CLOSED' || upper === 'CLOSE') return 'Closed';
  if (upper === 'CANCELED' || upper === 'CANCELLED') return 'Cancelled';

  return status;
}

export function localStatusMatchesFusion(localStatus, fusionItem = {}) {
  const local = normalizeFusionStatusForLocal(localStatus);
  const fusion = normalizeFusionStatusForLocal(
    fusionItem.WorkOrderStatusName ||
    fusionItem.WorkOrderSystemStatusCode ||
    fusionItem.WorkOrderStatusCode
  );

  return cleanStatus(local).toUpperCase() === cleanStatus(fusion).toUpperCase();
}

export async function getWorkOrderForFusionRelease(id) {
  const lookup = String(id ?? '').trim();

  if (!lookup) return null;

  return queryOne(
    `
    SELECT
      WO.ID AS "id",
      WO.WO_NUMBER AS "woNumber",
      WO.WORK_ORDER_ID AS "workOrderId",
      WO.STATUS AS "status",
      WO.MACHINE_ID AS "machineId",
      WO.ORGANIZATION_ID AS "organizationId",
      WO.INVENTORY_ITEM_ID AS "inventoryItemId",
      WO.PRODUCT_CODE AS "productCode",
      WO.PRODUCT AS "product",
      WO.CREATED_AT AS "createdAt",
      WO.UPDATED_AT AS "updatedAt"
    FROM ${TABLES.workOrders} WO
    WHERE NVL(WO.IS_DELETED, 0) = 0
      AND ${validMesWorkOrderMachineCondition}
      AND (
        TO_CHAR(WO.ID) = :lookup
        OR TO_CHAR(WO.WO_NUMBER) = :lookup
        OR UPPER(TRIM(WO.WO_NUMBER)) = UPPER(TRIM(:lookup))
        OR TO_CHAR(WO.WORK_ORDER_ID) = :lookup
      )
    ORDER BY
      CASE
        WHEN TO_CHAR(WO.ID) = :lookup THEN 1
        WHEN TO_CHAR(WO.WORK_ORDER_ID) = :lookup THEN 2
        WHEN UPPER(TRIM(WO.WO_NUMBER)) = UPPER(TRIM(:lookup)) THEN 3
        ELSE 4
      END,
      WO.EXECUTION_SEQUENCE ASC NULLS LAST,
      WO.SCHEDULED_DATE DESC NULLS LAST,
      WO.CREATED_AT DESC
    FETCH FIRST 1 ROWS ONLY
    `,
    { lookup }
  );
}

export async function updateLocalWorkOrderStatusFromFusion({
  id,
  fusionItem,
  onlyWhenLocalUnreleased = true,
  user = null,
}) {
  const actualId = String(id ?? '').trim();

  if (!actualId) {
    throw new Error('MES work order internal ID is required');
  }

  const fusionStatus =
    normalizeFusionStatusForLocal(
      fusionItem?.WorkOrderStatusName ||
      fusionItem?.WorkOrderSystemStatusCode ||
      fusionItem?.WorkOrderStatusCode
    ) || 'Unknown';

  const rawFusionWorkOrderId =
    fusionItem?.WorkOrderId !== undefined && fusionItem?.WorkOrderId !== null
      ? String(fusionItem.WorkOrderId).trim()
      : '';

  const hasFusionWorkOrderId = /^\d+$/.test(rawFusionWorkOrderId);

  const updatedBy =
    user?.username ||
    user?.empId ||
    user?.id ||
    'fusion-status-sync';

  const setWorkOrderIdSql = hasFusionWorkOrderId
    ? ', WORK_ORDER_ID = TO_NUMBER(:fusionWorkOrderId)'
    : '';

  const statusWhereSql = onlyWhenLocalUnreleased
    ? "AND UPPER(TRIM(STATUS)) IN ('UNRELEASED', 'ORA_UNRELEASED')"
    : '';

  const binds = {
    id: actualId,
    status: fusionStatus,
    updatedBy,
  };

  if (hasFusionWorkOrderId) {
    binds.fusionWorkOrderId = rawFusionWorkOrderId;
  }

  const result = await executeCommit(
    `
    UPDATE ${TABLES.workOrders}
    SET
      STATUS = :status
      ${setWorkOrderIdSql},
      UPDATED_BY = :updatedBy,
      UPDATED_AT = SYSTIMESTAMP
    WHERE ID = :id
      AND NVL(IS_DELETED, 0) = 0
      AND (
        UPPER(MACHINE_ID) LIKE 'INJ-%'
        OR UPPER(MACHINE_ID) LIKE 'ZFP%'
      )
      ${statusWhereSql}
    `,
    binds
  );

  return result.rowsAffected || 0;
}

export async function resolveWorkOrderNumber(value) {
  const lookup = cleanKey(value);
  if (!lookup) return null;

  const wo = await getWorkOrderById(lookup);
  return wo?.woNumber || lookup;
}

export async function resolveMachineCode(value) {
  const lookup = cleanKey(value);
  if (!lookup) return null;

  const row = await queryOne(
    `
    SELECT CODE AS "code"
    FROM ${TABLES.machines}
    WHERE NVL(IS_DELETED,0) = 0
      AND (
        UPPER(TRIM(CODE)) = UPPER(TRIM(:lookup))
        OR UPPER(TRIM(ID)) = UPPER(TRIM(:lookup))
        OR UPPER(TRIM(MES_CODE)) = UPPER(TRIM(:lookup))
      )
    FETCH FIRST 1 ROWS ONLY
    `,
    { lookup },
  );

  return row?.code || lookup;
}

export function workOrderSelect(prefix = 'WO') {
  return `
    ${prefix}.ID AS "id",
    ${prefix}.WO_NUMBER AS "woNumber",
    ${prefix}.PRODUCT AS "product",
    ${prefix}.PRODUCT_CODE AS "productCode",
    ${prefix}.CUSTOMER AS "customer",
    ${prefix}.PLANT AS "plant",
    ${prefix}.MACHINE_ID AS "machineId",
    M.CODE AS "machineCode",
    M.NAME AS "machineName",
    M.LOCATOR AS "locator",
    ${prefix}.PLANNED_QTY AS "plannedQty",
    ${prefix}.PRODUCED_QTY AS "producedQty",
    ${prefix}.TARGET_QTY AS "targetQty",
    ${prefix}.BOX_QTY AS "boxQty",
    UPPER(TRIM(${prefix}.STATUS)) AS "status",
    ${prefix}.PRIORITY AS "priority",
    ${prefix}.SCHEDULED_DATE AS "scheduledDate",
    ${prefix}.SCHEDULED_END_DATE AS "scheduledEndDate",
    ${prefix}.LOCATOR_CODE AS "locatorCode",
    ${prefix}.EXECUTION_SEQUENCE AS "executionSequence",
    ${prefix}.COMPLETED_DATE AS "completedDate",
    ${prefix}.STARTED_AT AS "startedAt",
    ${prefix}.PAUSED_AT AS "pausedAt",
    CEIL(NVL(${prefix}.PLANNED_QTY,0) / NULLIF(NVL(${prefix}.BOX_QTY,0),0)) AS "totalBoxes",
    (
      SELECT COUNT(1)
      FROM ${TABLES.boxes} B
      WHERE B.WO_ID = ${prefix}.WO_NUMBER
        AND NVL(B.IS_DELETED,0) = 0
    ) AS "boxesPrinted",
    ${prefix}.NOTES AS "notes",
    ${prefix}.IS_ACTIVE AS "isActive",
    ${prefix}.CREATED_AT AS "createdAt",
    ${prefix}.UPDATED_AT AS "updatedAt"
  `;
}

export async function listWorkOrdersLov(filters = {}) {
  const where = [
    'NVL(WO.IS_DELETED,0) = 0',
    "(UPPER(WO.MACHINE_ID) LIKE 'INJ-%' OR UPPER(WO.MACHINE_ID) LIKE 'ZFP%')"
  ];
  const binds = {};

  const organizationId =
    filters.organizationId ||
    filters.organization_id ||
    filters.organisationId ||
    filters.organisation_id ||
    null;

  const machineId =
    filters.machineId ||
    filters.machine_id ||
    filters.machine ||
    null;

  if (organizationId) {
    where.push('WO.ORGANIZATION_ID = :organizationId');
    binds.organizationId = String(organizationId).trim();
  }

  if (machineId) {
    where.push(`
      (
        WO.MACHINE_ID = :machineId
        OR UPPER(M.CODE) = UPPER(:machineId)
        OR UPPER(M.MES_CODE) = UPPER(:machineId)
      )
    `);
    binds.machineId = String(machineId).trim();
  }

  return query(
    `
    SELECT
      WO.ID AS "id",
      WO.WO_NUMBER AS "woNumber",
      WO.PRODUCT AS "product",
      WO.PRODUCT_CODE AS "productCode",
      WO.CUSTOMER AS "customer",
      WO.PLANT AS "plant",
      WO.ORGANIZATION_ID AS "organizationId",
      WO.MACHINE_ID AS "machineId",
      M.CODE AS "machineCode",
      M.NAME AS "machineName",
      M.MES_CODE AS "machineMesCode",
      WO.PLANNED_QTY AS "plannedQty",
      WO.PRODUCED_QTY AS "producedQty",
      WO.TARGET_QTY AS "targetQty",
      WO.BOX_QTY AS "boxQty",
      WO.STATUS AS "status",
      WO.PRIORITY AS "priority",
      WO.SCHEDULED_DATE AS "scheduledDate",
      WO.SCHEDULED_END_DATE AS "scheduledEndDate",
      WO.LOCATOR_CODE AS "locatorCode",
      WO.EXECUTION_SEQUENCE AS "executionSequence",
      WO.CREATED_AT AS "createdAt",
      WO.UPDATED_AT AS "updatedAt"
    FROM ${TABLES.workOrders} WO
    LEFT JOIN ${TABLES.machines} M ON M.CODE = WO.MACHINE_ID
    WHERE ${where.join(' AND ')}
    ORDER BY
      WO.EXECUTION_SEQUENCE ASC NULLS LAST,
      WO.SCHEDULED_DATE DESC NULLS LAST,
      WO.CREATED_AT DESC
    `,
    binds,
  );
}

export async function listWorkOrders(filters = {}, isMachineIpBound = false, machineCode = '', organizationId = '') {
  const where = ['NVL(WO.IS_DELETED,0) = 0'];
  const binds = {};

  const statusFilter =
    filters.status ??
    filters.woStatus ??
    filters.workOrderStatus ??
    filters.statusFilter ??
    filters.wo_status ??
    filters.status_filter ??
    null;

  addWorkOrderStatusFilter(where, binds, statusFilter);
  addEq(where, binds, 'WO.ORGANIZATION_ID', 'organizationId', filters.organizationId);
  addEq(where, binds, 'WO.PRIORITY', 'priority', filters.priority);
  addEq(where, binds, 'WO.PLANT', 'plant', filters.plant);
  const requestSource = filters?.source || null;
  const selectedMachineId =
    filters.machineId || (isMachineIpBound && machineCode && requestSource === 'IP_BOUND'
      ? machineCode
      : null);


  if (selectedMachineId) {
    where.push('UPPER(WO.MACHINE_ID) = UPPER(:machineId)');
    binds.machineId = selectedMachineId;
  } else {
    where.push("(UPPER(WO.MACHINE_ID) LIKE 'INJ-%' OR UPPER(WO.MACHINE_ID) LIKE 'ZFP%')");
  }

  addEq(where, binds, 'WO.WO_NUMBER', 'woNumber', filters.woNumber);
  addDateFrom(where, binds, 'WO.SCHEDULED_DATE', 'fromDate', filters.fromDate || filters.scheduledFrom);
  addDateTo(where, binds, 'WO.SCHEDULED_DATE', 'toDate', filters.toDate || filters.scheduledTo);

  addLike(
    where,
    binds,
    ['WO.WO_NUMBER', 'WO.PRODUCT', 'WO.PRODUCT_CODE', 'WO.CUSTOMER', 'M.CODE', 'M.NAME'],
    'search',
    filters.search
  );

  return pagedQuery({
    select: `
      ${workOrderSelect('WO')},
      (SELECT DISTINCT I.DESCRIPTION FROM XX_DIGI_ITEM_MASTER I WHERE I.INVENTORY_ITEM_ID = WO.INVENTORY_ITEM_ID AND 
      I.ORGANIZATION_ID = WO.ORGANIZATION_ID AND I.CATEGORY_SET_NAME = 'Plastic') AS productDescFusion,
      QR.QTY_PER_BOX AS "boxQtyRecorded",
      (
        SELECT NVL(SUM(B.QUANTITY), 0)
        FROM MES_BOXES B
        WHERE B.WO_ID = WO.WO_NUMBER
          AND B.MACHINE_ID = WO.MACHINE_ID
      ) AS "totalProduced",
      (
        SELECT COUNT(*)
        FROM MES_BOXES B
        WHERE B.WO_ID = WO.WO_NUMBER
          AND B.MACHINE_ID = WO.MACHINE_ID
      ) AS "totalBoxesPrinted"
    `,
    from: `${TABLES.workOrders} WO`,
    joins: `
        LEFT JOIN ${TABLES.machines} M ON M.CODE = WO.MACHINE_ID
      LEFT JOIN MES_BOX_QTY_RECORDS QR 
        ON QR.PRODUCT_CODE = WO.PRODUCT_CODE AND QR.IS_ACTIVE = 1
    `,
    where,
    binds,
    orderBy: workOrderStatusOrderBy,
    page: filters.page,
    limit: filters.limit,
  });
}

export async function getWorkOrderById(id) {
  const lookup = String(id ?? '').trim();

  if (!lookup) return null;

  return queryOne(
    `
    SELECT ${workOrderSelect('WO')},
      QR.QTY_PER_BOX AS "boxQtyRecorded",
      (
        SELECT NVL(SUM(B.QUANTITY), 0)
        FROM MES_BOXES B
        WHERE B.WO_ID = WO.WO_NUMBER
          AND B.MACHINE_ID = WO.MACHINE_ID
      ) AS "totalProduced",
      (
        SELECT COUNT(*)
        FROM MES_BOXES B
        WHERE B.WO_ID = WO.WO_NUMBER
          AND B.MACHINE_ID = WO.MACHINE_ID
      ) AS "totalBoxesPrinted"
    FROM ${TABLES.workOrders} WO
    LEFT JOIN ${TABLES.machines} M 
      ON M.CODE = WO.MACHINE_ID
    LEFT JOIN MES_BOX_QTY_RECORDS QR 
      ON QR.PRODUCT_CODE = WO.PRODUCT_CODE
     AND QR.IS_ACTIVE = 1
    WHERE NVL(WO.IS_DELETED, 0) = 0
      AND (
        UPPER(WO.MACHINE_ID) LIKE 'INJ-%'
        OR UPPER(WO.MACHINE_ID) LIKE 'ZFP%'
      )
      AND (
        TO_CHAR(WO.ID) = :lookup
        OR TO_CHAR(WO.WO_NUMBER) = :lookup
        OR UPPER(TRIM(WO.WO_NUMBER)) = UPPER(TRIM(:lookup))
        OR TO_CHAR(WO.WORK_ORDER_ID) = :lookup
      )
    ORDER BY
      CASE
        WHEN TO_CHAR(WO.ID) = :lookup THEN 1
        WHEN TO_CHAR(WO.WORK_ORDER_ID) = :lookup THEN 2
        WHEN UPPER(TRIM(WO.WO_NUMBER)) = UPPER(TRIM(:lookup)) THEN 3
        ELSE 4
      END,
      WO.EXECUTION_SEQUENCE ASC NULLS LAST,
      WO.SCHEDULED_DATE DESC NULLS LAST,
      WO.CREATED_AT DESC
    FETCH FIRST 1 ROWS ONLY
    `,
    { lookup },
  );
}

export async function createWorkOrder(data, user = null) {
  return insertRow(TABLES.workOrders, workOrderFieldMap, data, user);
}

export async function updateWorkOrder(id, data, user = null) {
  const before = await getWorkOrderById(id);

  if (!before) {
    return 0;
  }

  return updateRow(
    TABLES.workOrders,
    workOrderFieldMap,
    before.id,
    data,
    user
  );
}

export async function deleteWorkOrder(id, user = null) {
  const before = await getWorkOrderById(id);
  if (!before) return 0;
  return softDeleteRow(TABLES.workOrders, before.id, user);
}

export async function assignWorkOrderToMachine({ woId, machineId, priorityRank = null, assignedById = null, notes = null }, user = null) {
  const before = await getWorkOrderById(woId);
  if (!before) return null;

  const machineCode = await resolveMachineCode(machineId);
  const woNumber = before.woNumber;

  await updateRow(TABLES.workOrders, workOrderFieldMap, before.id, { machineId: machineCode }, user);

  const assignmentId = await insertRow(TABLES.workOrderMachineAssignments, {
    woId: 'WO_ID',
    machineId: 'MACHINE_ID',
    assignedById: 'ASSIGNED_BY_ID',
    assignedAt: 'ASSIGNED_AT',
    priorityRank: 'PRIORITY_RANK',
    status: 'STATUS',
    notes: 'NOTES',
  }, {
    woId: woNumber,
    machineId: machineCode,
    assignedById,
    assignedAt: new Date(),
    priorityRank,
    status: 'assigned',
    notes,
  }, user);

  await insertRow(TABLES.productionEvents, {
    woId: 'WO_ID',
    machineId: 'MACHINE_ID',
    userId: 'USER_ID',
    eventType: 'EVENT_TYPE',
    eventTime: 'EVENT_TIME',
    fromStatus: 'FROM_STATUS',
    toStatus: 'TO_STATUS',
    reason: 'REASON',
    data: 'DATA_JSON',
  }, {
    woId: woNumber,
    machineId: machineCode,
    userId: assignedById,
    eventType: 'machine_change',
    eventTime: new Date(),
    fromStatus: before.status || null,
    toStatus: before.status || null,
    reason: notes,
    data: {
      previousMachineId: before.machineId || null,
      newMachineId: machineCode,
      assignmentId,
    },
  }, null);

  return assignmentId;
}

export async function changeWorkOrderStatus(
  { id, status, userId = null, reason = null, qty = null },
  user = null
) {
  const lookup = String(id ?? '').trim();
  if (!lookup) return null;

  const before = await getWorkOrderById(lookup);
  if (!before) return null;

  const actualId = before.id;

  if (!actualId) {
    throw new Error('Work order internal ID not found');
  }

  if (status === 'active' && before.machineId) {
    const busy = await queryOne(
      `
      SELECT ID AS "id", WO_NUMBER AS "woNumber"
      FROM ${TABLES.workOrders}
      WHERE UPPER(TRIM(MACHINE_ID)) = UPPER(TRIM(:machineId))
        AND ID <> :actualId
        AND STATUS = 'active'
        AND NVL(IS_DELETED, 0) = 0
      FETCH FIRST 1 ROWS ONLY
      `,
      {
        machineId: before.machineId,
        actualId,
      }
    );

    if (busy) {
      throw new Error(
        `Machine already has running work order ${busy.woNumber || busy.id}`
      );
    }
  }

  const statusDates = {};

  if (status === 'active' && !before.startedAt) {
    statusDates.startedAt = new Date();
  }

  if (status === 'paused') {
    statusDates.pausedAt = new Date();
  }

  if (status === 'completed') {
    statusDates.completedDate = new Date();
  }

  await updateRow(
    TABLES.workOrders,
    workOrderFieldMap,
    actualId,
    {
      status,
      ...statusDates,
    },
    user
  );

  await insertRow(
    TABLES.productionEvents,
    {
      woId: 'WO_ID',
      machineId: 'MACHINE_ID',
      userId: 'USER_ID',
      eventType: 'EVENT_TYPE',
      eventTime: 'EVENT_TIME',
      qty: 'QTY',
      fromStatus: 'FROM_STATUS',
      toStatus: 'TO_STATUS',
      reason: 'REASON',
      data: 'DATA_JSON',
    },
    {
      woId: before?.woNumber || lookup,
      machineId: before?.machineId || null,
      userId,
      eventType: status,
      eventTime: new Date(),
      qty,
      fromStatus: before?.status || null,
      toStatus: status,
      reason,
      data: {
        reason,
        changedBy: user?.empId || user?.username || null,
        requestedId: lookup,
        actualId,
        woNumber: before?.woNumber || null,
      },
    },
    null
  );

  return getWorkOrderById(actualId);
}

export async function getActiveWorkOrderByMachine(machineId, options = {}) {
  const strictActive =
    options.strictActive === true ||
    String(options.strictActive).toLowerCase() === 'true';

  const machineCode = await resolveMachineCode(machineId);

  return queryOne(
    `
    SELECT ${workOrderSelect('WO')}, QR.QTY_PER_BOX AS "boxQtyRecorded",
      (
        SELECT NVL(SUM(B.QUANTITY), 0)
        FROM MES_BOXES B
        WHERE B.WO_ID = WO.WO_NUMBER
          AND B.MACHINE_ID = WO.MACHINE_ID
      ) AS "totalProduced",
      (
        SELECT COUNT(*)
        FROM MES_BOXES B
        WHERE B.WO_ID = WO.WO_NUMBER
          AND B.MACHINE_ID = WO.MACHINE_ID
      ) AS "totalBoxesPrinted"
    FROM ${TABLES.workOrders} WO
        LEFT JOIN ${TABLES.machines} M ON M.CODE = WO.MACHINE_ID
    LEFT JOIN MES_BOX_QTY_RECORDS QR ON QR.PRODUCT_CODE = WO.PRODUCT_CODE
    WHERE NVL(WO.IS_DELETED, 0) = 0
      AND (
        WO.MACHINE_ID = :machineId
        OR LOWER(M.CODE) = LOWER(:machineId)
        OR LOWER(M.MES_CODE) = LOWER(:machineId)
      )
      AND ${strictActive
      ? "WO.STATUS = 'active'"
      : "WO.STATUS IN ('active', 'pending', 'paused')"
    }
    ORDER BY
      CASE WO.STATUS
        WHEN 'active' THEN 1
        WHEN 'paused' THEN 2
        ELSE 3
      END,
      CASE WO.PRIORITY
        WHEN 'urgent' THEN 1
        WHEN 'high' THEN 2
        WHEN 'normal' THEN 3
        WHEN 'low' THEN 4
        ELSE 5
      END,
      WO.EXECUTION_SEQUENCE ASC NULLS LAST,
      WO.SCHEDULED_DATE ASC NULLS LAST
    FETCH FIRST 1 ROWS ONLY
    `,
    { machineId: machineCode || machineId },
  );
}

export async function reorderWorkOrders(items = [], user = null) {
  const safeItems = Array.isArray(items) ? items.filter((item) => item?.id || item?.woId || item?.woNumber) : [];
  let updatedCount = 0;

  for (const item of safeItems) {
    const lookup = item.id || item.woId || item.woNumber;
    const wo = await getWorkOrderById(lookup);
    if (!wo) continue;

    const affected = await updateRow(TABLES.workOrders, workOrderFieldMap, wo.id, {
      executionSequence: item.executionSequence ?? item.sequence ?? item.priorityRank,
    }, user);

    updatedCount += affected ? 1 : 0;
  }

  return updatedCount;
}

export async function listProductionLogs(filters = {}) {
  const where = ['NVL(PL.IS_DELETED,0) = 0'];
  const binds = {};
  const woFilter = filters.woNumber || filters.workOrderNumber || filters.woId;
  const machineFilter = filters.machineCode || filters.machineId;
  addEq(where, binds, 'PL.WO_ID', 'woId', woFilter);
  addEq(where, binds, 'PL.MACHINE_ID', 'machineId', machineFilter);
  addEq(where, binds, 'PL.OPERATOR_ID', 'operatorId', filters.operatorId);
  addDateFrom(where, binds, 'PL.START_TIME', 'fromDate', filters.fromDate);
  addDateTo(where, binds, 'PL.START_TIME', 'toDate', filters.toDate);

  return pagedQuery({
    select: `
      PL.ID AS "id", PL.WO_ID AS "woId", WO.WO_NUMBER AS "woNumber",
      PL.MACHINE_ID AS "machineId", M.CODE AS "machineCode", M.NAME AS "machineName",
      PL.OPERATOR_ID AS "operatorId", U.FULL_NAME AS "operatorName",
      PL.SHIFT AS "shift", PL.START_TIME AS "startTime", PL.END_TIME AS "endTime",
      PL.QTY_PRODUCED AS "qtyProduced", PL.QTY_REJECTED AS "qtyRejected",
      PL.CAVITY_COUNT AS "cavityCount", PL.CYCLE_TIME AS "cycleTime",
      PL.NOTES AS "notes", PL.CREATED_AT AS "createdAt", PL.UPDATED_AT AS "updatedAt"
    `,
    from: `${TABLES.productionLogs} PL`,
    joins: `
        LEFT JOIN ${TABLES.workOrders} WO ON WO.WO_NUMBER = PL.WO_ID
        LEFT JOIN ${TABLES.machines} M ON M.CODE = PL.MACHINE_ID
      LEFT JOIN ${TABLES.users} U ON U.ID = PL.OPERATOR_ID
    `,
    where,
    binds,
    orderBy: 'PL.START_TIME DESC NULLS LAST, PL.CREATED_AT DESC',
    page: filters.page,
    limit: filters.limit,
  });
}

export async function createProductionLog(data, user = null) {
  const wo = data.woId ? await getWorkOrderById(data.woId) : null;
  const woNumber = wo?.woNumber || cleanKey(data.woNumber) || cleanKey(data.workOrderNumber) || cleanKey(data.woId);
  const machineCode = await resolveMachineCode(data.machineId || data.machineCode || wo?.machineId);

  const id = await insertRow(TABLES.productionLogs, productionLogFieldMap, {
    ...data,
    woId: woNumber,
    machineId: machineCode,
  }, user);

  if (wo?.id && toNumber(data.qtyProduced, 0) > 0) {
    await executeCommit(
      `
      UPDATE ${TABLES.workOrders}
      SET PRODUCED_QTY = NVL(PRODUCED_QTY,0) + :qty,
          UPDATED_AT = SYSTIMESTAMP
      WHERE ID = :woId
      `,
      { qty: toNumber(data.qtyProduced), woId: wo.id },
    );
  }
  return id;
}

export async function listWorkOrderComponents(woId) {
  const woNumber = await resolveWorkOrderNumber(woId);
  if (!woNumber) return [];

  return query(
    `
    SELECT
      ID AS "id", WO_ID AS "woId", COMPONENT_CODE AS "componentCode",
      COMPONENT_DESC AS "componentDesc", COMPONENT_TYPE AS "componentType",
      REQUIRED_QTY AS "requiredQty", ISSUED_QTY AS "issuedQty", CONSUMED_QTY AS "consumedQty",
      UOM AS "uom", LOT_NO AS "lotNo", STATUS AS "status",
      CREATED_AT AS "createdAt", UPDATED_AT AS "updatedAt"
    FROM ${TABLES.workOrderComponents}
    WHERE UPPER(TRIM(WO_ID)) = UPPER(TRIM(:woId))
      AND NVL(IS_DELETED,0) = 0
    ORDER BY COMPONENT_CODE
    `,
    { woId: woNumber },
  );
}

export async function createWorkOrderComponent(data, user = null) {
  const woNumber = await resolveWorkOrderNumber(data.woId || data.woNumber || data.workOrderNumber);
  return insertRow(TABLES.workOrderComponents, componentFieldMap, {
    ...data,
    woId: woNumber || data.woId,
  }, user);
}

export async function getDashboardSummary() {
  const row = await queryOne(
    `
    SELECT
      COUNT(1) AS "totalWorkOrders",
      SUM(CASE WHEN STATUS = 'active' THEN 1 ELSE 0 END) AS "activeWorkOrders",
      SUM(CASE WHEN STATUS = 'pending' THEN 1 ELSE 0 END) AS "pendingWorkOrders",
      SUM(CASE WHEN STATUS = 'completed' THEN 1 ELSE 0 END) AS "completedWorkOrders",
      SUM(NVL(PLANNED_QTY,0)) AS "plannedQty",
      SUM(NVL(PRODUCED_QTY,0)) AS "producedQty"
    FROM ${TABLES.workOrders}
    WHERE NVL(IS_DELETED,0) = 0
    `,
  );

  const machineRow = await queryOne(
    `
    SELECT
      COUNT(1) AS "totalMachines",
      SUM(CASE WHEN STATUS = 'running' THEN 1 ELSE 0 END) AS "runningMachines",
      SUM(CASE WHEN STATUS = 'idle' THEN 1 ELSE 0 END) AS "idleMachines",
      SUM(CASE WHEN STATUS IN ('maintenance','breakdown') THEN 1 ELSE 0 END) AS "downMachines"
    FROM ${TABLES.machines}
    WHERE NVL(IS_DELETED,0) = 0
    `,
  );

  return { ...row, ...machineRow };
}

export async function listMachinesLov(organizationId = null) {
  const where = [];
  const binds = {};

  if (organizationId) {
    where.push('ORGANIZATION_ID = :organizationId');
    binds.organizationId = String(organizationId).trim();
  }

  return query(
    `
    SELECT
      ID AS "id",
      CODE AS "code",
      NAME AS "name",
      MACHINE_TYPE AS "machineType",
      PLANT AS "plant",
      DEPARTMENT AS "department",
      AREA AS "area",
      LOCATOR AS "locator",
      OEM AS "oem",
      MODEL AS "model",
      SERIAL_NO AS "serialNo",
      TONNAGE AS "tonnage",
      CYCLE_TIME AS "cycleTime",
      CAVITIES AS "cavities",
      IP_ADDRESS AS "ipAddress",
      PLC_TYPE AS "plcType",
      COMM_PROTOCOL AS "commProtocol",
      MES_CODE AS "mesCode",
      PM_FREQ AS "pmFreq",
      LAST_PM_DATE AS "lastPmDate",
      STATUS AS "status",
      SPECS_JSON AS "specsJson",
      CREATED_BY AS "createdBy",
      UPDATED_BY AS "updatedBy",
      IS_ACTIVE AS "isActive",
      IS_DELETED AS "isDeleted",
      CREATED_AT AS "createdAt",
      UPDATED_AT AS "updatedAt",
      RESOURCE_ID AS "resourceId",
      RESOURCE_CLASS_CODE AS "resourceClassCode",
      ORGANIZATION_ID AS "organizationId",
      UOM_CODE AS "uomCode",
      COSTED_FLAG AS "costedFlag",
      INACTIVE_DATE AS "inactiveDate",
      WORK_DEFINITION_ID AS "workDefinitionId",
      AUTO_EQUIPMENT_FLAG AS "autoEquipmentFlag"
    FROM ${TABLES.machines}
    ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
    ORDER BY CODE ASC
    `,
    binds,
  );
}
export async function listProductionMachines(filters = {}) {
  const where = ['NVL(IS_DELETED,0) = 0'];
  const binds = {};

  if (filters.id) {
    addEq(where, binds, 'ID', 'id', filters.id);
  }

  const machineFilter = filters.machineId || filters.machineCode || filters.code;
  if (machineFilter) {
    where.push(`(
      UPPER(TRIM(CODE)) = UPPER(TRIM(:machineFilter))
      OR UPPER(TRIM(ID)) = UPPER(TRIM(:machineFilter))
      OR UPPER(TRIM(MES_CODE)) = UPPER(TRIM(:machineFilter))
    )`);
    binds.machineFilter = String(machineFilter).trim();
  }

  addEq(where, binds, 'MES_CODE', 'mesCode', filters.mesCode);
  addEq(where, binds, 'STATUS', 'status', filters.status);
  addEq(where, binds, 'PLANT', 'plant', filters.plant);
  addEq(where, binds, 'AREA', 'area', filters.area);
  return query(
    `
    SELECT
      ID AS "id", CODE AS "code", NAME AS "name", MACHINE_TYPE AS "machineType",
      PLANT AS "plant", DEPARTMENT AS "department", AREA AS "area", LOCATOR AS "locator",
      STATUS AS "status", CAVITIES AS "cavities", CYCLE_TIME AS "cycleTime"
    FROM ${TABLES.machines}
    ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
    ORDER BY CODE ASC
    `,
    binds,
  );
}



export async function listWorkOrderEvents(woId) {
  const woNumber = await resolveWorkOrderNumber(woId);
  if (!woNumber) return [];
  return query(
    `
    SELECT
      PE.ID AS "id", PE.WO_ID AS "woId", WO.WO_NUMBER AS "woNumber",
      PE.MACHINE_ID AS "machineId", M.CODE AS "machineCode", M.NAME AS "machineName",
      PE.USER_ID AS "userId", U.FULL_NAME AS "userName",
      PE.EVENT_TYPE AS "eventType", PE.EVENT_TIME AS "eventTime", PE.QTY AS "qty",
      PE.FROM_STATUS AS "fromStatus", PE.TO_STATUS AS "toStatus",
      PE.REASON AS "reason", PE.DATA_JSON AS "dataJson", PE.CREATED_AT AS "createdAt"
    FROM ${TABLES.productionEvents} PE
    LEFT JOIN ${TABLES.workOrders} WO ON WO.WO_NUMBER = PE.WO_ID
    LEFT JOIN ${TABLES.machines} M ON M.CODE = PE.MACHINE_ID
    LEFT JOIN ${TABLES.users} U ON U.ID = PE.USER_ID
    WHERE UPPER(TRIM(PE.WO_ID)) = UPPER(TRIM(:woId))
    ORDER BY PE.EVENT_TIME DESC NULLS LAST, PE.CREATED_AT DESC
    `,
    { woId: woNumber },
  );
}

export async function listWorkOrderAssignmentHistory(woId) {
  const woNumber = await resolveWorkOrderNumber(woId);
  if (!woNumber) return [];
  return query(
    `
    SELECT
      A.ID AS "id", A.WO_ID AS "woId", WO.WO_NUMBER AS "woNumber",
      A.MACHINE_ID AS "machineId", M.CODE AS "machineCode", M.NAME AS "machineName",
      A.ASSIGNED_BY_ID AS "assignedById", U.FULL_NAME AS "assignedByName",
      A.ASSIGNED_AT AS "assignedAt", A.STARTED_AT AS "startedAt", A.ENDED_AT AS "endedAt",
      A.PRIORITY_RANK AS "priorityRank", A.STATUS AS "status", A.NOTES AS "notes",
      A.CREATED_AT AS "createdAt", A.UPDATED_AT AS "updatedAt"
    FROM ${TABLES.workOrderMachineAssignments} A
    LEFT JOIN ${TABLES.workOrders} WO ON WO.WO_NUMBER = A.WO_ID
    LEFT JOIN ${TABLES.machines} M ON M.CODE = A.MACHINE_ID
    LEFT JOIN ${TABLES.users} U ON U.ID = A.ASSIGNED_BY_ID
    WHERE UPPER(TRIM(A.WO_ID)) = UPPER(TRIM(:woId))
      AND NVL(A.IS_DELETED,0) = 0
    ORDER BY A.ASSIGNED_AT DESC NULLS LAST, A.CREATED_AT DESC
    `,
    { woId: woNumber },
  );
}

export async function updateWorkOrderSchedule(id, data, user = null) {
  const payload = {
    scheduledDate: data.scheduledDate || data.scheduleDate || data.startDate,
    scheduledEndDate: data.scheduledEndDate || data.scheduleEnd || data.endDate,
    locatorCode: data.locatorCode || data.locator || data.locationCode,
    executionSequence: data.executionSequence ?? data.sequence ?? data.priorityRank,
    notes: data.notes,
  };
  return updateWorkOrder(id, payload, user);
}

export async function updateWorkOrderPriorityRank(id, priorityRank, user = null) {
  const wo = await getWorkOrderById(id);
  if (!wo) return 0;
  return updateRow(TABLES.workOrders, workOrderFieldMap, wo.id, { executionSequence: priorityRank }, user);
}

export async function updateMachineStatus(id, status, user = null) {
  const machineCode = await resolveMachineCode(id);
  const result = await executeCommit(
    `
    UPDATE ${TABLES.machines}
    SET STATUS = :status,
        UPDATED_BY = :updatedBy,
        UPDATED_AT = SYSTIMESTAMP
    WHERE NVL(IS_DELETED,0) = 0
      AND (
        UPPER(TRIM(ID)) = UPPER(TRIM(:id))
        OR UPPER(TRIM(CODE)) = UPPER(TRIM(:machineCode))
        OR UPPER(TRIM(MES_CODE)) = UPPER(TRIM(:machineCode))
      )
    `,
    {
      id,
      machineCode: machineCode || id,
      status,
      updatedBy: user?.username || user?.empId || user?.id || 'system',
    },
  );
  return result.rowsAffected || 0;
}

export default {
  listWorkOrders,
  getWorkOrderById,
  createWorkOrder,
  updateWorkOrder,
  deleteWorkOrder,
  assignWorkOrderToMachine,
  changeWorkOrderStatus,
  getActiveWorkOrderByMachine,
  reorderWorkOrders,
  listProductionLogs,
  createProductionLog,
  listWorkOrderComponents,
  createWorkOrderComponent,
  getDashboardSummary,
  listWorkOrdersLov,
  listMachinesLov,
  listProductionMachines,
  listWorkOrderEvents,
  listWorkOrderAssignmentHistory,
  updateWorkOrderSchedule,
  updateWorkOrderPriorityRank,
  updateMachineStatus,
  resolveWorkOrderNumber,
  resolveMachineCode,
  getWorkOrderForFusionRelease,
  updateLocalWorkOrderStatusFromFusion,
  isLocalUnreleasedStatus,
  localStatusMatchesFusion,
  normalizeFusionStatusForLocal,
};
