import {
  TABLES,
  query,
  queryOne,
  pagedQuery,
  addEq,
  addDateFrom,
  addDateTo,
  addLike,
  insertRow,
  updateRow,
  softDeleteRow,
} from './base.model.js';
import { executeCommit } from '../config/oracle.js';

const stockFieldMap = {
  woId: 'WO_ID',
  locationId: 'LOCATION_ID',
  palletId: 'PALLET_ID',
  org: 'ORG',
  plant: 'PLANT',
  machine: 'MACHINE',
  productCode: 'PRODUCT_CODE',
  productName: 'PRODUCT_NAME',
  woNum: 'WO_NUM',
  boxNo: 'BOX_NO',
  palletCode: 'PALLET_CODE',
  locatorCode: 'LOCATOR_CODE',
  quantity: 'QUANTITY',
  reservedQty: 'RESERVED_QTY',
  qcStatus: 'QC_STATUS',
  status: 'STATUS',
  receivedAt: 'RECEIVED_AT',
  dispatchedAt: 'DISPATCHED_AT',
};

const itemFieldMap = {
  org: 'ORG',
  itemCode: 'ITEM_CODE',
  itemDescription: 'ITEM_DESCRIPTION',
  itemType: 'ITEM_TYPE',
  uom: 'UOM',
  customer: 'CUSTOMER',
  standardCost: 'STANDARD_COST',
  fgCost: 'FG_COST',
  status: 'STATUS',
};

const lotFieldMap = {
  org: 'ORG',
  itemCode: 'ITEM_CODE',
  lotNo: 'LOT_NO',
  subinventory: 'SUBINVENTORY',
  locatorCode: 'LOCATOR_CODE',
  qtyOnHand: 'QTY_ON_HAND',
  reservedQty: 'RESERVED_QTY',
  uom: 'UOM',
  expiryDate: 'EXPIRY_DATE',
  status: 'STATUS',
};

const cleanKey = (value) => {
  if (value === undefined || value === null) return null;
  const text = String(value).trim();
  return text || null;
};

async function resolveWorkOrderNumber(value) {
  const lookup = cleanKey(value);
  if (!lookup) return null;

  const row = await queryOne(
    `
    SELECT WO_NUMBER AS "woNumber"
    FROM ${TABLES.workOrders}
    WHERE NVL(IS_DELETED,0) = 0
      AND (
        UPPER(TRIM(ID)) = UPPER(TRIM(:lookup))
        OR UPPER(TRIM(WO_NUMBER)) = UPPER(TRIM(:lookup))
        OR UPPER(TRIM(WORK_ORDER_ID)) = UPPER(TRIM(:lookup))
      )
    FETCH FIRST 1 ROWS ONLY
    `,
    { lookup },
  );

  return row?.woNumber || lookup;
}

export async function listStockRecords(filters = {}) {
  const where = ['NVL(SR.IS_DELETED,0) = 0'];
  const binds = {};
  addEq(where, binds, 'SR.ORG', 'org', filters.org);
  addEq(where, binds, 'SR.PLANT', 'plant', filters.plant);
  addEq(where, binds, 'SR.PRODUCT_CODE', 'productCode', filters.productCode);
  addEq(where, binds, 'SR.WO_ID', 'woId', filters.woNumber || filters.woNum || filters.workOrderNumber || filters.woId);
  addEq(where, binds, 'SR.LOCATION_ID', 'locationId', filters.locationId);
  addEq(where, binds, 'SR.QC_STATUS', 'qcStatus', filters.qcStatus);
  addEq(where, binds, 'SR.STATUS', 'status', filters.status);
  addDateFrom(where, binds, 'SR.RECEIVED_AT', 'fromDate', filters.fromDate);
  addDateTo(where, binds, 'SR.RECEIVED_AT', 'toDate', filters.toDate);
  addLike(where, binds, ['SR.PRODUCT_CODE', 'SR.PRODUCT_NAME', 'SR.WO_NUM', 'SR.BOX_NO', 'SR.PALLET_CODE', 'SR.LOCATOR_CODE'], 'search', filters.search);

  return pagedQuery({
    select: `
      SR.ID AS "id", SR.WO_ID AS "woId", WO.WO_NUMBER AS "woNumber", SR.LOCATION_ID AS "locationId",
      L.CODE AS "locationCode", L.NAME AS "locationName", SR.PALLET_ID AS "palletId",
      SR.ORG AS "org", SR.PLANT AS "plant", SR.MACHINE AS "machine", SR.PRODUCT_CODE AS "productCode",
      SR.PRODUCT_NAME AS "productName", SR.WO_NUM AS "woNum", SR.BOX_NO AS "boxNo",
      SR.PALLET_CODE AS "palletCode", SR.LOCATOR_CODE AS "locatorCode", SR.QUANTITY AS "quantity",
      SR.RESERVED_QTY AS "reservedQty", SR.QC_STATUS AS "qcStatus", SR.STATUS AS "status",
      SR.RECEIVED_AT AS "receivedAt", SR.DISPATCHED_AT AS "dispatchedAt", SR.CREATED_AT AS "createdAt", SR.UPDATED_AT AS "updatedAt"
    `,
    from: `${TABLES.stockRecords} SR`,
    joins: `
      LEFT JOIN ${TABLES.workOrders} WO ON WO.WO_NUMBER = SR.WO_ID
      LEFT JOIN ${TABLES.locations} L ON L.ID = SR.LOCATION_ID
    `,
    where,
    binds,
    orderBy: 'SR.RECEIVED_AT DESC NULLS LAST, SR.CREATED_AT DESC',
    page: filters.page,
    limit: filters.limit,
  });
}

export async function getStockRecordById(id) {
  return queryOne(
    `
    SELECT
      ID AS "id", WO_ID AS "woId", LOCATION_ID AS "locationId", PALLET_ID AS "palletId", ORG AS "org",
      PLANT AS "plant", MACHINE AS "machine", PRODUCT_CODE AS "productCode", PRODUCT_NAME AS "productName",
      WO_NUM AS "woNum", BOX_NO AS "boxNo", PALLET_CODE AS "palletCode", LOCATOR_CODE AS "locatorCode",
      QUANTITY AS "quantity", RESERVED_QTY AS "reservedQty", QC_STATUS AS "qcStatus", STATUS AS "status",
      RECEIVED_AT AS "receivedAt", DISPATCHED_AT AS "dispatchedAt", CREATED_AT AS "createdAt", UPDATED_AT AS "updatedAt"
    FROM ${TABLES.stockRecords}
    WHERE ID = :id AND NVL(IS_DELETED,0) = 0
    FETCH FIRST 1 ROWS ONLY
    `,
    { id },
  );
}

export async function createStockRecord(data, user = null) {
  const woNumber = await resolveWorkOrderNumber(data.woId || data.woNumber || data.woNum || data.workOrderNumber);

  return insertRow(TABLES.stockRecords, stockFieldMap, {
    ...data,
    woId: woNumber || data.woId,
    woNum: data.woNum || woNumber || data.woNumber,
    receivedAt: data.receivedAt || new Date(),
    status: data.status || 'in_stock',
  }, user);
}

export async function updateStockRecord(id, data, user = null) {
  return updateRow(TABLES.stockRecords, stockFieldMap, id, data, user);
}

export async function getStockSummary(filters = {}) {
  const where = ['NVL(IS_DELETED,0) = 0'];
  const binds = {};
  addEq(where, binds, 'ORG', 'org', filters.org);
  addEq(where, binds, 'PLANT', 'plant', filters.plant);
  return queryOne(
    `
    SELECT
      COUNT(1) AS "count",
      SUM(NVL(QUANTITY,0)) AS "totalQty",
      SUM(NVL(RESERVED_QTY,0)) AS "reservedQty",
      SUM(CASE WHEN QC_STATUS = 'approved' THEN 1 ELSE 0 END) AS "approvedCount",
      SUM(CASE WHEN QC_STATUS = 'hold' THEN 1 ELSE 0 END) AS "holdCount",
      SUM(CASE WHEN STATUS = 'dispatched' THEN 1 ELSE 0 END) AS "dispatchedCount"
    FROM ${TABLES.stockRecords}
    WHERE ${where.join(' AND ')}
    `,
    binds,
  );
}

export async function exportStockRows(filters = {}) {
  const result = await listStockRecords({ ...filters, page: 1, limit: 5000 });
  return result.rows;
}

export async function listItemMaster(filters = {}) {
  const where = ['NVL(IS_DELETED,0) = 0'];
  const binds = {};
  addEq(where, binds, 'ORG', 'org', filters.org);
  addEq(where, binds, 'ITEM_TYPE', 'itemType', filters.itemType);
  addEq(where, binds, 'STATUS', 'status', filters.status);
  addLike(where, binds, ['ITEM_CODE', 'ITEM_DESCRIPTION', 'CUSTOMER'], 'search', filters.search);
  return pagedQuery({
    select: `ID AS "id", ORG AS "org", ITEM_CODE AS "itemCode", ITEM_DESCRIPTION AS "itemDescription", ITEM_TYPE AS "itemType", UOM AS "uom", CUSTOMER AS "customer", STANDARD_COST AS "standardCost", FG_COST AS "fgCost", STATUS AS "status", CREATED_AT AS "createdAt", UPDATED_AT AS "updatedAt"`,
    from: TABLES.itemMaster,
    where,
    binds,
    orderBy: 'ORG, ITEM_CODE',
    page: filters.page,
    limit: filters.limit,
  });
}

export async function createItemMaster(data, user = null) {
  return insertRow(TABLES.itemMaster, itemFieldMap, data, user);
}

export async function listInventoryLots(filters = {}) {
  const where = ['NVL(IS_DELETED,0) = 0'];
  const binds = {};
  addEq(where, binds, 'ORG', 'org', filters.org);
  addEq(where, binds, 'ITEM_CODE', 'itemCode', filters.itemCode);
  addEq(where, binds, 'LOT_NO', 'lotNo', filters.lotNo);
  addEq(where, binds, 'SUBINVENTORY', 'subinventory', filters.subinventory);
  addEq(where, binds, 'LOCATOR_CODE', 'locatorCode', filters.locatorCode);
  return pagedQuery({
    select: `ID AS "id", ORG AS "org", ITEM_CODE AS "itemCode", LOT_NO AS "lotNo", SUBINVENTORY AS "subinventory", LOCATOR_CODE AS "locatorCode", QTY_ON_HAND AS "qtyOnHand", RESERVED_QTY AS "reservedQty", UOM AS "uom", EXPIRY_DATE AS "expiryDate", STATUS AS "status", CREATED_AT AS "createdAt", UPDATED_AT AS "updatedAt"`,
    from: TABLES.inventoryLots,
    where,
    binds,
    orderBy: 'ORG, ITEM_CODE, LOT_NO',
    page: filters.page,
    limit: filters.limit,
  });
}

export async function createInventoryLot(data, user = null) {
  return insertRow(TABLES.inventoryLots, lotFieldMap, data, user);
}



export async function updateItemMaster(id, data, user = null) {
  return updateRow(TABLES.itemMaster, itemFieldMap, id, data, user);
}

export async function deleteItemMaster(id, user = null) {
  return softDeleteRow(TABLES.itemMaster, id, user);
}

export async function updateInventoryLot(id, data, user = null) {
  return updateRow(TABLES.inventoryLots, lotFieldMap, id, data, user);
}

export async function deleteInventoryLot(id, user = null) {
  return softDeleteRow(TABLES.inventoryLots, id, user);
}

export async function setStockAction(id, action, data = {}, user = null) {
  const stock = await getStockRecordById(id);
  if (!stock) return null;
  const quantity = Number(stock.quantity || 0);
  const requestedQty = Number(data.quantity ?? data.qty ?? quantity);
  const currentReserved = Number(stock.reservedQty || 0);
  let patch = {};

  if (action === 'reserve') {
    patch = { reservedQty: Math.min(quantity, currentReserved + requestedQty), status: 'reserved' };
  } else if (action === 'unreserve') {
    const nextReserved = Math.max(0, currentReserved - requestedQty);
    patch = { reservedQty: nextReserved, status: nextReserved > 0 ? 'reserved' : 'in_stock' };
  } else if (action === 'dispatch') {
    patch = { status: 'dispatched', dispatchedAt: data.dispatchedAt || new Date() };
  } else if (action === 'hold') {
    patch = { status: 'hold' };
  } else {
    patch = { status: action };
  }

  await updateStockRecord(id, patch, user);
  return getStockRecordById(id);
}

export async function getStockByBox(boxNo) {
  return queryOne(
    `
    SELECT ID AS "id", WO_ID AS "woId", BOX_NO AS "boxNo", PALLET_ID AS "palletId",
           PALLET_CODE AS "palletCode", PRODUCT_CODE AS "productCode", PRODUCT_NAME AS "productName",
           QUANTITY AS "quantity", RESERVED_QTY AS "reservedQty", QC_STATUS AS "qcStatus",
           STATUS AS "status", RECEIVED_AT AS "receivedAt", DISPATCHED_AT AS "dispatchedAt"
    FROM ${TABLES.stockRecords}
    WHERE UPPER(TRIM(BOX_NO)) = UPPER(TRIM(:boxNo)) AND NVL(IS_DELETED,0) = 0
    FETCH FIRST 1 ROWS ONLY
    `,
    { boxNo },
  );
}

export async function getStockByPallet(palletCode) {
  return query(
    `
    SELECT ID AS "id", WO_ID AS "woId", BOX_NO AS "boxNo", PALLET_ID AS "palletId",
           PALLET_CODE AS "palletCode", PRODUCT_CODE AS "productCode", PRODUCT_NAME AS "productName",
           QUANTITY AS "quantity", RESERVED_QTY AS "reservedQty", QC_STATUS AS "qcStatus",
           STATUS AS "status", RECEIVED_AT AS "receivedAt", DISPATCHED_AT AS "dispatchedAt"
    FROM ${TABLES.stockRecords}
    WHERE NVL(IS_DELETED,0) = 0
      AND (UPPER(TRIM(PALLET_CODE)) = UPPER(TRIM(:palletCode)) OR UPPER(TRIM(PALLET_ID)) = UPPER(TRIM(:palletCode)))
    ORDER BY BOX_NO
    `,
    { palletCode },
  );
}

export default {
  listStockRecords,
  getStockRecordById,
  createStockRecord,
  updateStockRecord,
  getStockSummary,
  exportStockRows,
  listItemMaster,
  createItemMaster,
  updateItemMaster,
  deleteItemMaster,
  listInventoryLots,
  createInventoryLot,
  updateInventoryLot,
  deleteInventoryLot,
  setStockAction,
  getStockByBox,
  getStockByPallet,
};
