import { randomUUID } from 'crypto';
import { getConnection, executeRows, executeOne, executeCommit } from '../config/oracle.js';

export const SETUP_TABLES = Object.freeze({
  appScreens: 'MES_APP_SCREENS',
  appFeatures: 'MES_APP_FEATURES',
  roles: 'MES_ROLES',
  users: 'MES_USERS',
  employees: 'MES_EMPLOYEES',
  roleScreenPermissions: 'MES_ROLE_SCREEN_PERMISSIONS',
  roleFeaturePermissions: 'MES_ROLE_FEATURE_PERMISSIONS',
  userScreenPermissions: 'MES_USER_SCREEN_PERMISSIONS',
  userFeaturePermissions: 'MES_USER_FEATURE_PERMISSIONS',
  userRoles: 'MES_USER_ROLES',
  userScope: 'MES_USER_SCOPE',
  userSecuritySettings: 'MES_USER_SECURITY_SETTINGS',
  orgUnits: 'MES_ORG_UNITS',
  auditLogs: 'MES_AUDIT_LOGS',
  machines: 'MES_MACHINES',
  locations: 'MES_LOCATIONS',
  shifts: 'MES_SHIFTS',
  systemConfigs: 'MES_SYSTEM_CONFIGS',
  boxQtyRecords: 'MES_BOX_QTY_RECORDS',
  userSessions: 'MES_USER_SESSIONS',
});

export function newUuid() {
  return randomUUID();
}

export function toFlag(value, fallback = 0) {
  if (value === undefined || value === null || value === '') return fallback;
  if (value === true || value === 1 || value === '1' || String(value).toLowerCase() === 'true' || String(value).toLowerCase() === 'yes') return 1;
  if (value === false || value === 0 || value === '0' || String(value).toLowerCase() === 'false' || String(value).toLowerCase() === 'no') return 0;
  return fallback;
}

export function toBool(value, fallback = false) {
  if (value === undefined || value === null || value === '') return fallback;
  return toFlag(value, fallback ? 1 : 0) === 1;
}

export function toNumber(value, fallback = null) {
  if (value === undefined || value === null || value === '') return fallback;
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

export function asJson(value, fallback = {}) {
  if (value === undefined || value === null || value === '') return fallback;
  if (typeof value === 'object') return value;
  try {
    return JSON.parse(value);
  } catch (_err) {
    return fallback;
  }
}

export function jsonString(value, fallback = {}) {
  if (value === undefined) return JSON.stringify(fallback);
  if (value === null) return null;
  return typeof value === 'string' ? value : JSON.stringify(value);
}

export function cleanObject(object = {}) {
  return Object.fromEntries(
    Object.entries(object).filter(([, value]) => value !== undefined),
  );
}

export async function nextNumber(table, column = 'ID', connection = null) {
  const sql = `SELECT NVL(MAX(${column}), 0) + 1 AS "value" FROM ${table}`;
  if (connection) {
    const result = await connection.execute(sql, {});
    return Number(result.rows?.[0]?.value || 1);
  }
  const row = await executeOne(sql);
  return Number(row?.value || 1);
}

export const withTransaction = async (callback) => {
  const connection = await getConnection();

  try {
    await connection.execute(`ALTER SESSION DISABLE PARALLEL DML`);
    await connection.execute(`ALTER SESSION DISABLE PARALLEL QUERY`);
    await connection.execute(`ALTER SESSION DISABLE PARALLEL DDL`);

    const result = await callback(connection);

    await connection.commit();
    return result;
  } catch (err) {
    try {
      await connection.rollback();
    } catch (_) {
      // ignore rollback error
    }

    throw err;
  } finally {
    try {
      await connection.close();
    } catch (_) {
      // ignore close error
    }
  }
};

export async function fetchRoleByAny(idOrRoleId, connection = null) {
  const sql = `
    SELECT
      ID AS "id",
      ROLE_ID AS "role_id",
      CODE AS "code",
      NAME AS "name",
      ICON AS "icon",
      COLOR AS "color",
      DESCRIPTION AS "description",
      PERMISSIONS AS "permissions",
      IS_SYSTEM AS "isSystem",
      IS_ACTIVE AS "isActive",
      IS_DELETED AS "isDeleted",
      CREATED_AT AS "createdAt",
      UPDATED_AT AS "updatedAt"
    FROM ${SETUP_TABLES.roles}
    WHERE NVL(IS_DELETED, 0) = 0
      AND (ID = :id OR TO_CHAR(ROLE_ID) = :id)
    FETCH FIRST 1 ROWS ONLY
  `;
  const binds = { id: String(idOrRoleId) };
  const row = connection
    ? (await connection.execute(sql, binds)).rows?.[0]
    : await executeOne(sql, binds);

  return row ? mapRole(row) : null;
}

export function mapRole(row = {}) {
  return {
    ...row,
    role_id: row.role_id === undefined || row.role_id === null ? row.role_id : Number(row.role_id),
    isActive: toBool(row.isActive, true),
    isDeleted: toBool(row.isDeleted, false),
    isSystem: toBool(row.isSystem, false),
    permissions: asJson(row.permissions, {}),
  };
}

export async function getScreenIdByCode(code, connection) {
  const result = await connection.execute(
    `SELECT ID AS "id" FROM ${SETUP_TABLES.appScreens} WHERE CODE = :code FETCH FIRST 1 ROWS ONLY`,
    { code },
  );
  return result.rows?.[0]?.id || null;
}

export async function getFeatureIdByCode(code, connection) {
  const result = await connection.execute(
    `SELECT ID AS "id" FROM ${SETUP_TABLES.appFeatures} WHERE CODE = :code FETCH FIRST 1 ROWS ONLY`,
    { code },
  );
  return result.rows?.[0]?.id || null;
}

export const mapScreenPerms = (rows = []) => {
  const screens = {};
  rows.forEach((row) => {
    screens[row.code] = {
      view: toBool(row.can_view),
      create: toBool(row.can_create),
      edit: toBool(row.can_edit),
      delete: toBool(row.can_delete),
      export: toBool(row.can_export),
    };
  });
  return screens;
};

export const mapFeaturePerms = (rows = []) => {
  const features = {};
  rows.forEach((row) => {
    features[row.code] = toBool(row.is_enabled);
  });
  return features;
};

export const normalizeSecurity = (security = {}) => ({
  pwReset: security.pwReset || security.forcePasswordReset || 'none',
  pwStr: security.pwStr || security.passwordStrength || 'medium',
  lockout: String(security.lockout || security.lockoutAfter || '5'),
  timeout: String(security.timeout || security.sessionTimeoutMinutes || '240'),
  hours: security.hours || security.allowedLoginHours || 'ANY',
  device: security.device || security.allowedDevice || 'ANY',
  audit: security.audit !== false,
  emailNotify: security.emailNotify !== false,
  twoFA: !!security.twoFA,
  ipRestrict: !!security.ipRestrict,
});

export async function saveSecuritySettings(connection, userId, security = {}) {
  const s = normalizeSecurity(security);

  await connection.execute(
    `
    DELETE FROM ${SETUP_TABLES.userSecuritySettings}
    WHERE USER_ID = :b_user_id
    `,
    {
      b_user_id: userId,
    }
  );

  const securityId = await nextNumber(
    SETUP_TABLES.userSecuritySettings,
    'ID',
    connection
  );

  await connection.execute(
    `
    INSERT INTO ${SETUP_TABLES.userSecuritySettings}
    (
      ID,
      USER_ID,
      FORCE_PASSWORD_RESET,
      PASSWORD_STRENGTH,
      LOCKOUT_AFTER,
      SESSION_TIMEOUT_MINUTES,
      ALLOWED_LOGIN_HOURS,
      ALLOWED_DEVICE,
      AUDIT_ENABLED,
      EMAIL_NOTIFY,
      TWO_FA_ENABLED,
      IP_RESTRICT_ENABLED,
      CREATED_AT,
      UPDATED_AT
    )
    VALUES
    (
      :b_id,
      :b_user_id,
      :b_pw_reset,
      :b_pw_strength,
      :b_lockout_after,
      :b_session_timeout,
      :b_allowed_hours,
      :b_allowed_device,
      :b_audit_enabled,
      :b_email_notify,
      :b_two_fa_enabled,
      :b_ip_restrict_enabled,
      SYSTIMESTAMP,
      SYSTIMESTAMP
    )
    `,
    {
      b_id: securityId,
      b_user_id: userId,
      b_pw_reset: s.pwReset,
      b_pw_strength: s.pwStr,
      b_lockout_after: Number(s.lockout || 0),
      b_session_timeout: Number(s.timeout || 0),
      b_allowed_hours: s.hours || 'ANY',
      b_allowed_device: s.device || 'ANY',
      b_audit_enabled: s.audit ? 1 : 0,
      b_email_notify: s.emailNotify ? 1 : 0,
      b_two_fa_enabled: s.twoFA ? 1 : 0,
      b_ip_restrict_enabled: s.ipRestrict ? 1 : 0,
    }
  );

  return s;
}

export async function rebuildUserPermissions(connection, userId) {
  // Get next IDs BEFORE deleting to avoid ORA-12838 (cannot read/modify object after modifying it)
  const nextScreenPermId = await nextNumber(SETUP_TABLES.userScreenPermissions, 'ID', connection);
  const nextFeaturePermId = await nextNumber(SETUP_TABLES.userFeaturePermissions, 'ID', connection);

  await connection.execute(`DELETE FROM ${SETUP_TABLES.userScreenPermissions} WHERE USER_ID = :userId`, { userId });
  await connection.execute(`DELETE FROM ${SETUP_TABLES.userFeaturePermissions} WHERE USER_ID = :userId`, { userId });

  await connection.execute(
    `
    INSERT INTO ${SETUP_TABLES.userScreenPermissions}
      (ID, USER_ID, SCREEN_ID, CAN_VIEW, CAN_CREATE, CAN_EDIT, CAN_DELETE, CAN_EXPORT, CREATED_AT, UPDATED_AT)
    SELECT
      ROW_NUMBER() OVER (ORDER BY x.SCREEN_ID) + :nextScreenPermId - 1,
      :userId,
      x.SCREEN_ID,
      x.CAN_VIEW,
      x.CAN_CREATE,
      x.CAN_EDIT,
      x.CAN_DELETE,
      x.CAN_EXPORT,
      SYSTIMESTAMP,
      SYSTIMESTAMP
    FROM (
      SELECT
        rsp.SCREEN_ID,
        MAX(rsp.CAN_VIEW) AS CAN_VIEW,
        MAX(rsp.CAN_CREATE) AS CAN_CREATE,
        MAX(rsp.CAN_EDIT) AS CAN_EDIT,
        MAX(rsp.CAN_DELETE) AS CAN_DELETE,
        MAX(rsp.CAN_EXPORT) AS CAN_EXPORT
      FROM ${SETUP_TABLES.userRoles} ur
      JOIN ${SETUP_TABLES.roleScreenPermissions} rsp ON rsp.ROLE_ID = ur.ROLE_ID
      WHERE ur.USER_ID = :userId
      GROUP BY rsp.SCREEN_ID
    ) x
    `,
    { userId, nextScreenPermId },
  );

  await connection.execute(
    `
    INSERT INTO ${SETUP_TABLES.userFeaturePermissions}
      (ID, USER_ID, FEATURE_ID, IS_ENABLED, CREATED_AT, UPDATED_AT)
    SELECT
      ROW_NUMBER() OVER (ORDER BY x.FEATURE_ID) + :nextFeaturePermId - 1,
      :userId,
      x.FEATURE_ID,
      x.IS_ENABLED,
      SYSTIMESTAMP,
      SYSTIMESTAMP
    FROM (
      SELECT
        rfp.FEATURE_ID,
        MAX(rfp.IS_ENABLED) AS IS_ENABLED
      FROM ${SETUP_TABLES.userRoles} ur
      JOIN ${SETUP_TABLES.roleFeaturePermissions} rfp ON rfp.ROLE_ID = ur.ROLE_ID
      WHERE ur.USER_ID = :userId
      GROUP BY rfp.FEATURE_ID
    ) x
    `,
    { userId, nextFeaturePermId },
  );
}

export async function audit(module, action, recordId, req, oldData = null, newData = null, connection = null) {
  const sql = `
    INSERT INTO ${SETUP_TABLES.auditLogs}
    (ID, USER_ID, ACTION, MODULE, RECORD_ID, OLD_DATA_JSON, NEW_DATA_JSON, IP_ADDRESS, USER_AGENT, CREATED_AT)
    VALUES
    (:id, :userId, :action, :module, :recordId, :oldData, :newData, :ip, :agent, SYSTIMESTAMP)
  `;
  const binds = {
    id: newUuid(),
    userId: req?.user?.id || null,
    action,
    module,
    recordId,
    oldData: oldData ? jsonString(oldData) : null,
    newData: newData ? jsonString(newData) : null,
    ip: req?.ip || null,
    agent: req?.headers?.['user-agent'] || null,
  };

  try {
    if (connection) await connection.execute(sql, binds);
    else await executeCommit(sql, binds);
  } catch (_err) {
    // Audit should never block user setup actions.
  }
}

export async function listActiveRoles() {
  const rows = await executeRows(
    `
    SELECT ID AS "id", ROLE_ID AS "role_id", CODE AS "code", NAME AS "name",
           ICON AS "icon", COLOR AS "color", DESCRIPTION AS "description",
           PERMISSIONS AS "permissions", IS_SYSTEM AS "isSystem",
           IS_ACTIVE AS "isActive", IS_DELETED AS "isDeleted",
           CREATED_AT AS "createdAt", UPDATED_AT AS "updatedAt"
    FROM ${SETUP_TABLES.roles}
    WHERE NVL(IS_ACTIVE, 1) = 1 AND NVL(IS_DELETED, 0) = 0
    ORDER BY ROLE_ID
    `,
  );
  return rows.map(mapRole);
}
