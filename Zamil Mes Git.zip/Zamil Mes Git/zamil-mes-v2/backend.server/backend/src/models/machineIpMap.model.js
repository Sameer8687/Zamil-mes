import { queryOne } from './base.model.js';

const TABLE_NAME = 'MES_MACHINES';

const normalizeMachineRow = (row) => {
  if (!row) return null;

  return {
    id: row.id,
    code: row.code,
    name: row.name,
    machineType: row.machineType,
    plant: row.plant,
    department: row.department,
    area: row.area,
    locator: row.locator,
    oem: row.oem,
    model: row.model,
    serialNo: row.serialNo,
    tonnage: row.tonnage,
    cycleTime: row.cycleTime,
    cavities: row.cavities,
    ipAddress: row.ipAddress,
    plcType: row.plcType,
    commProtocol: row.commProtocol,
    mesCode: row.mesCode,
    pmFreq: row.pmFreq,
    lastPmDate: row.lastPmDate,
    status: row.status,
    specsJson: row.specsJson,
    createdBy: row.createdBy,
    updatedBy: row.updatedBy,
    isActive: Number(row.isActive ?? 1) === 1,
    isDeleted: Number(row.isDeleted ?? 0) === 1,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
    resourceId: row.resourceId,
    resourceClassCode: row.resourceClassCode,
    organizationId: row.organizationId,
    uomCode: row.uomCode,
    costedFlag: row.costedFlag,
    inactiveDate: row.inactiveDate,
    workDefinitionId: row.workDefinitionId,
    autoEquipmentFlag: row.autoEquipmentFlag,
    matchedOn: row.matchedOn || null,
  };
};

const addMatch = (matches, seen, bindName, value, label) => {
  const cleanValue = String(value || '').trim();

  if (!cleanValue) return;

  const key = cleanValue.toLowerCase();

  if (seen.has(key)) return;

  seen.add(key);

  matches.push({
    bindName,
    value: cleanValue,
    label,
  });
};

export async function findActiveMachineDeviceByIp({
  requesterIp = null,
  privateIp = null,
  publicIp = null,
} = {}) {
  const matches = [];
  const seen = new Set();

  addMatch(matches, seen, 'privateIp', privateIp, 'PRIVATE_IP');
  addMatch(matches, seen, 'publicIp', publicIp, 'PUBLIC_IP');
  addMatch(matches, seen, 'requesterIp', requesterIp, 'REQUESTER_IP');

  if (!matches.length) return null;

  const binds = {};

  matches.forEach((match) => {
    binds[match.bindName] = match.value;
  });

  const whereSql = matches
    .map((match) => `LOWER(TRIM(IP_ADDRESS)) = LOWER(:${match.bindName})`)
    .join(' OR ');

  const matchedOnSql = matches
    .map((match) => `WHEN LOWER(TRIM(IP_ADDRESS)) = LOWER(:${match.bindName}) THEN '${match.label}'`)
    .join(' ');

  const prioritySql = matches
    .map((match, index) => `WHEN LOWER(TRIM(IP_ADDRESS)) = LOWER(:${match.bindName}) THEN ${index + 1}`)
    .join(' ');

  const row = await queryOne(
    `
    SELECT
      ID AS "id",
      CODE AS "code",
      NAME AS "name",
      MACHINE_TYPE AS "machineType",
      PLANT AS "plant",
      DEPARTMENT AS "department",
      AREA AS "area",
      LOCATOR AS "locator",
      OEM AS "oem",
      MODEL AS "model",
      SERIAL_NO AS "serialNo",
      TONNAGE AS "tonnage",
      CYCLE_TIME AS "cycleTime",
      CAVITIES AS "cavities",
      IP_ADDRESS AS "ipAddress",
      PLC_TYPE AS "plcType",
      COMM_PROTOCOL AS "commProtocol",
      MES_CODE AS "mesCode",
      PM_FREQ AS "pmFreq",
      LAST_PM_DATE AS "lastPmDate",
      STATUS AS "status",
      SPECS_JSON AS "specsJson",
      CREATED_BY AS "createdBy",
      UPDATED_BY AS "updatedBy",
      IS_ACTIVE AS "isActive",
      IS_DELETED AS "isDeleted",
      CREATED_AT AS "createdAt",
      UPDATED_AT AS "updatedAt",
      RESOURCE_ID AS "resourceId",
      RESOURCE_CLASS_CODE AS "resourceClassCode",
      ORGANIZATION_ID AS "organizationId",
      UOM_CODE AS "uomCode",
      COSTED_FLAG AS "costedFlag",
      INACTIVE_DATE AS "inactiveDate",
      WORK_DEFINITION_ID AS "workDefinitionId",
      AUTO_EQUIPMENT_FLAG AS "autoEquipmentFlag",
      CASE ${matchedOnSql} ELSE NULL END AS "matchedOn"
    FROM ${TABLE_NAME}
    WHERE NVL(IS_ACTIVE, 1) = 1
      AND NVL(IS_DELETED, 0) = 0
      AND IP_ADDRESS IS NOT NULL
      AND (${whereSql})
    ORDER BY
      CASE ${prioritySql} ELSE 99 END,
      UPDATED_AT DESC NULLS LAST,
      CREATED_AT DESC NULLS LAST
    FETCH FIRST 1 ROWS ONLY
    `,
    binds,
  );

  return normalizeMachineRow(row);
}

export default {
  findActiveMachineDeviceByIp,
};