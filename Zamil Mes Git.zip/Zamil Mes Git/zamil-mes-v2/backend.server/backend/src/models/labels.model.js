import {
  TABLES,
  queryOne,
  pagedQuery,
  addEq,
  addLike,
  insertRow,
  updateRow,
  softDeleteRow,
  parseJson,
} from './base.model.js';
import { executeCommit } from '../config/oracle.js';

const templateFieldMap = {
  templateCode: 'TEMPLATE_CODE',
  templateName: 'TEMPLATE_NAME',
  templateType: 'TEMPLATE_TYPE',
  versionNo: 'VERSION_NO',
  widthMm: 'WIDTH_MM',
  heightMm: 'HEIGHT_MM',
  templateJson: 'TEMPLATE_JSON',
  templateHtml: 'TEMPLATE_HTML',
  isDefault: 'IS_DEFAULT',
  isActive: 'IS_ACTIVE',
};

const templateSelect = `
  ID AS "id",
  TEMPLATE_CODE AS "templateCode",
  TEMPLATE_NAME AS "templateName",
  TEMPLATE_TYPE AS "templateType",
  VERSION_NO AS "versionNo",
  WIDTH_MM AS "widthMm",
  HEIGHT_MM AS "heightMm",
  TEMPLATE_JSON AS "templateJson",
  TEMPLATE_HTML AS "templateHtml",
  IS_DEFAULT AS "isDefault",
  IS_ACTIVE AS "isActive",
  CREATED_BY AS "createdBy",
  UPDATED_BY AS "updatedBy",
  CREATED_AT AS "createdAt",
  UPDATED_AT AS "updatedAt"
`;

const normalizeTemplate = (row) => {
  if (!row) return null;
  return {
    ...row,
    isDefault: Number(row.isDefault || 0) === 1,
    isActive: Number(row.isActive ?? 1) === 1,
    templateJson: parseJson(row.templateJson, row.templateJson || null),
  };
};

async function clearDefaultTemplate(templateType, excludeId = null) {
  if (!templateType) return;
  const excludeClause = excludeId ? 'AND ID <> :excludeId' : '';
  await executeCommit(
    `
    UPDATE ${TABLES.labelTemplates}
    SET IS_DEFAULT = 0,
        UPDATED_AT = SYSTIMESTAMP
    WHERE LOWER(TEMPLATE_TYPE) = LOWER(:templateType)
      ${excludeClause}
      AND NVL(IS_DELETED,0) = 0
    `,
    { templateType, ...(excludeId ? { excludeId } : {}) },
  );
}

export async function listLabelTemplates(filters = {}) {
  const where = ['NVL(IS_DELETED,0) = 0'];
  const binds = {};
  addEq(where, binds, 'LOWER(TEMPLATE_TYPE)', 'templateType', filters.templateType ? String(filters.templateType).toLowerCase() : null);
  addEq(where, binds, 'IS_DEFAULT', 'isDefault', filters.isDefault);
  addEq(where, binds, 'IS_ACTIVE', 'isActive', filters.isActive);
  addLike(where, binds, ['TEMPLATE_CODE', 'TEMPLATE_NAME', 'TEMPLATE_TYPE'], 'search', filters.search);

  const result = await pagedQuery({
    select: templateSelect,
    from: TABLES.labelTemplates,
    where,
    binds,
    orderBy: 'TEMPLATE_TYPE ASC, IS_DEFAULT DESC, VERSION_NO DESC NULLS LAST, CREATED_AT DESC',
    page: filters.page,
    limit: filters.limit || 100,
  });

  return { ...result, rows: result.rows.map(normalizeTemplate) };
}

export async function getLabelTemplateById(id) {
  const row = await queryOne(
    `
    SELECT ${templateSelect}
    FROM ${TABLES.labelTemplates}
    WHERE ID = :id AND NVL(IS_DELETED,0) = 0
    FETCH FIRST 1 ROWS ONLY
    `,
    { id },
  );
  return normalizeTemplate(row);
}

export async function getDefaultLabelTemplate(templateType) {
  const binds = { templateType };
  const row = await queryOne(
    `
    SELECT ${templateSelect}
    FROM ${TABLES.labelTemplates}
    WHERE LOWER(TEMPLATE_TYPE) = LOWER(:templateType)
      AND NVL(IS_ACTIVE,1) = 1
      AND NVL(IS_DELETED,0) = 0
    ORDER BY IS_DEFAULT DESC, VERSION_NO DESC NULLS LAST, CREATED_AT DESC
    FETCH FIRST 1 ROWS ONLY
    `,
    binds,
  );
  return normalizeTemplate(row);
}

export async function createLabelTemplate(data, user = null) {
  const templateType = data.templateType || data.type || 'box';
  const payload = {
    ...data,
    templateType,
    templateCode: data.templateCode || data.code,
    templateName: data.templateName || data.name,
    versionNo: data.versionNo || 1,
    isDefault: data.isDefault ? 1 : 0,
    isActive: data.isActive ?? 1,
  };

  if (payload.isDefault) await clearDefaultTemplate(templateType);
  const id = await insertRow(TABLES.labelTemplates, templateFieldMap, payload, user);
  return getLabelTemplateById(id);
}

export async function updateLabelTemplate(id, data, user = null) {
  const existing = await getLabelTemplateById(id);
  if (!existing) return null;

  const templateType = data.templateType || data.type || existing.templateType;
  const payload = {
    ...data,
    templateType,
    templateCode: data.templateCode || data.code,
    templateName: data.templateName || data.name,
  };

  if (Object.prototype.hasOwnProperty.call(data, 'isDefault')) payload.isDefault = data.isDefault ? 1 : 0;
  if (payload.isDefault) await clearDefaultTemplate(templateType, id);

  await updateRow(TABLES.labelTemplates, templateFieldMap, id, payload, user);
  return getLabelTemplateById(id);
}

export async function deleteLabelTemplate(id, user = null) {
  return softDeleteRow(TABLES.labelTemplates, id, user);
}

export async function listLabelPrintJobs(filters = {}) {
  const where = ['1=1'];
  const binds = {};
  addEq(where, binds, 'J.LABEL_TYPE', 'labelType', filters.labelType);
  addEq(where, binds, 'J.STATUS', 'status', filters.status);
  addEq(where, binds, 'J.REF_ID', 'refId', filters.refId);
  addLike(where, binds, ['J.PRINTER_NAME', 'T.TEMPLATE_CODE', 'T.TEMPLATE_NAME'], 'search', filters.search);

  return pagedQuery({
    select: `
      J.ID AS "id", J.TEMPLATE_ID AS "templateId", T.TEMPLATE_CODE AS "templateCode",
      T.TEMPLATE_NAME AS "templateName", J.LABEL_TYPE AS "labelType", J.REF_TABLE AS "refTable",
      J.REF_ID AS "refId", J.PRINTER_NAME AS "printerName", J.PRINT_QTY AS "printQty",
      J.STATUS AS "status", J.PAYLOAD_JSON AS "payload", J.ERROR_MESSAGE AS "errorMessage",
      J.REQUESTED_BY_ID AS "requestedById", U.FULL_NAME AS "requestedByName",
      J.REQUESTED_AT AS "requestedAt", J.PRINTED_AT AS "printedAt",
      J.CREATED_AT AS "createdAt", J.UPDATED_AT AS "updatedAt"
    `,
    from: `${TABLES.labelPrintJobs} J`,
    joins: `
      LEFT JOIN ${TABLES.labelTemplates} T ON T.ID = J.TEMPLATE_ID
      LEFT JOIN ${TABLES.users} U ON U.ID = J.REQUESTED_BY_ID
    `,
    where,
    binds,
    orderBy: 'J.REQUESTED_AT DESC NULLS LAST, J.CREATED_AT DESC',
    page: filters.page,
    limit: filters.limit || 100,
  });
}
