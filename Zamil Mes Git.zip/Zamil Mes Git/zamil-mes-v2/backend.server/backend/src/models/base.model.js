import { randomUUID } from 'crypto';
import { execute, executeCommit } from '../config/oracle.js';

export const TABLES = Object.freeze({
  roles: 'MES_ROLES',
  users: 'MES_USERS',
  machines: 'MES_MACHINES',
  locations: 'MES_LOCATIONS',
  shifts: 'MES_SHIFTS',
  systemConfigs: 'MES_SYSTEM_CONFIGS',
  workOrders: 'MES_WORK_ORDERS',
  productionLogs: 'MES_PRODUCTION_LOGS',
  qcResults: 'MES_QC_RESULTS',
  pallets: 'MES_PALLETS',
  boxes: 'MES_BOXES',
  stockRecords: 'MES_STOCK_RECORDS',
  wasteRecords: 'MES_WASTE_RECORDS',
  downtimeRecords: 'MES_DOWNTIME_RECORDS',
  lineClearances: 'MES_LINE_CLEARANCES',
  boxQtyRecords: 'MES_BOX_QTY_RECORDS',
  auditLogs: 'MES_AUDIT_LOGS',

  itemMaster: 'MES_ITEM_MASTER',
  workOrderComponents: 'MES_WORK_ORDER_COMPONENTS',
  inventoryLots: 'MES_INVENTORY_LOTS',
  workOrderMachineAssignments: 'MES_WORK_ORDER_MACHINE_ASG',
  productionEvents: 'MES_PRODUCTION_EVENTS',
  boxQcResults: 'MES_BOX_QC_RESULTS',
  palletBoxSlots: 'MES_PALLET_BOX_SLOTS',
  labelTemplates: 'MES_LABEL_TEMPLATES',
  labelPrintJobs: 'MES_LABEL_PRINT_JOBS',
  labelPrintHistory: 'MES_LABEL_PRINT_HISTORY',
  wasteReasonCodes: 'MES_WASTE_REASON_CODES',
  wasteTransactions: 'MES_WASTE_TRANSACTIONS',
  downtimeReasonCodes: 'MES_DOWNTIME_REASON_CODES',
  defectTypes: 'MES_DEFECT_TYPES',
  qcChecklists: 'MES_QC_CHECKLISTS',
  lcChecklists: 'MES_LC_CHECKLISTS',
  screens: 'MES_SCREENS',
  features: 'MES_FEATURES',
  userRoles: 'MES_USER_ROLES',
  roleScreenPermissions: 'MES_ROLE_SCREEN_PERMISSIONS',
  roleFeaturePermissions: 'MES_ROLE_FEATURE_PERMISSIONS',
  userScreenOverrides: 'MES_USER_SCREEN_OVERRIDES',
  userFeatureOverrides: 'MES_USER_FEATURE_OVERRIDES',
  userScope: 'MES_USER_SCOPE',
  userSessions: 'MES_USER_SESSIONS',
  woQtyFusionTransactions: 'MES_WO_QTY_FUS_TRANSACTIONS',
});

export const DEFAULT_PAGE_SIZE = 50;
export const MAX_PAGE_SIZE = 500;

export function newId() {
  return randomUUID();
}

export function toNumber(value, fallback = 0) {
  if (value === undefined || value === null || value === '') return fallback;
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

export function toBooleanNumber(value, fallback = 0) {
  if (value === undefined || value === null || value === '') return fallback;
  if (value === true || value === 1 || value === '1' || value === 'true' || value === 'Y' || value === 'yes') return 1;
  if (value === false || value === 0 || value === '0' || value === 'false' || value === 'N' || value === 'no') return 0;
  return fallback;
}

export function pageInfo(page = 1, limit = DEFAULT_PAGE_SIZE) {
  const safePage = Math.max(parseInt(page, 10) || 1, 1);
  const safeLimit = Math.min(Math.max(parseInt(limit, 10) || DEFAULT_PAGE_SIZE, 1), MAX_PAGE_SIZE);
  return {
    page: safePage,
    limit: safeLimit,
    offset: (safePage - 1) * safeLimit,
  };
}

export function normalizeValue(value) {
  if (value === undefined) return undefined;
  if (value === '') return null;
  if (value instanceof Date) return value;
  if (Array.isArray(value) || (value && typeof value === 'object')) return JSON.stringify(value);
  return value;
}

export function parseJson(value, fallback = null) {
  if (value === undefined || value === null || value === '') return fallback;
  if (typeof value === 'object') return value;
  try {
    return JSON.parse(value);
  } catch (_err) {
    return fallback;
  }
}

export function mapJsonFields(row, fields = []) {
  if (!row) return row;
  const copy = { ...row };
  for (const field of fields) {
    if (Object.prototype.hasOwnProperty.call(copy, field)) {
      copy[field] = parseJson(copy[field], field.endsWith('List') ? [] : {});
    }
  }
  return copy;
}

export function mapJsonRows(rows = [], fields = []) {
  return rows.map((row) => mapJsonFields(row, fields));
}

export async function query(sql, binds = {}, options = {}) {
  const result = await execute(sql, binds, options);
  return result.rows || [];
}

export async function queryOne(sql, binds = {}, options = {}) {
  const rows = await query(sql, binds, options);
  return rows[0] || null;
}

export async function scalar(sql, binds = {}, alias = 'value') {
  const row = await queryOne(sql, binds);
  if (!row) return null;
  return row[alias] ?? Object.values(row)[0] ?? null;
}

export async function pagedQuery({ select, from, joins = '', where = [], binds = {}, orderBy = 'CREATED_AT DESC', page = 1, limit = DEFAULT_PAGE_SIZE }) {
  const p = pageInfo(page, limit);
  const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';

  const countRow = await queryOne(
    `SELECT COUNT(1) AS "count" FROM ${from} ${joins} ${whereSql}`,
    binds,
  );

  const rows = await query(
    `
    SELECT ${select}
    FROM ${from}
    ${joins}
    ${whereSql}
    ORDER BY ${orderBy}
    OFFSET :offset ROWS FETCH NEXT :limit ROWS ONLY
    `,
    { ...binds, offset: p.offset, limit: p.limit },
  );

  return {
    count: Number(countRow?.count || 0),
    rows,
    page: p.page,
    limit: p.limit,
  };
}

export function addEq(where, binds, column, key, value) {
  if (value !== undefined && value !== null && value !== '') {
    where.push(`${column} = :${key}`);
    binds[key] = value;
  }
}

export function addLike(where, binds, columns, key, value) {
  if (value !== undefined && value !== null && String(value).trim() !== '') {
    const bindName = key;
    const clause = columns.map((column) => `LOWER(${column}) LIKE LOWER(:${bindName})`).join(' OR ');
    where.push(`(${clause})`);
    binds[bindName] = `%${String(value).trim()}%`;
  }
}

export function addDateFrom(where, binds, column, key, value) {
  if (value) {
    where.push(`${column} >= TO_DATE(:${key}, 'YYYY-MM-DD')`);
    binds[key] = value;
  }
}

export function addDateTo(where, binds, column, key, value) {
  if (value) {
    where.push(`${column} < TO_DATE(:${key}, 'YYYY-MM-DD') + 1`);
    binds[key] = value;
  }
}

export function pickMapped(data = {}, fieldMap = {}) {
  const picked = {};
  for (const [inputKey, column] of Object.entries(fieldMap)) {
    if (Object.prototype.hasOwnProperty.call(data, inputKey)) {
      const normalized = normalizeValue(data[inputKey]);
      if (normalized !== undefined) picked[column] = normalized;
    }
  }
  return picked;
}

export async function insertRow(table, fieldMap, data, user = null) {
  const id = data.id || newId();
  const columns = { ID: id, ...pickMapped(data, fieldMap) };

  if (user && !columns.CREATED_BY) columns.CREATED_BY = user.username || user.empId || user.id || 'system';
  if (user && !columns.UPDATED_BY) columns.UPDATED_BY = user.username || user.empId || user.id || 'system';

  const colNames = Object.keys(columns);
  const bindNames = colNames.map((col) => col.toLowerCase());
  const binds = {};
  colNames.forEach((col, idx) => { binds[bindNames[idx]] = columns[col]; });

  await executeCommit(
    `INSERT INTO ${table} (${colNames.join(', ')}) VALUES (${bindNames.map((b) => `:${b}`).join(', ')})`,
    binds,
  );

  return id;
}

export async function updateRow(table, fieldMap, id, data, user = null) {
  const columns = pickMapped(data, fieldMap);
  if (user) columns.UPDATED_BY = user.username || user.empId || user.id || 'system';

  const colNames = Object.keys(columns);
  if (!colNames.length) return 0;

  const binds = { id };
  const sets = colNames.map((col) => {
    const bind = col.toLowerCase();
    binds[bind] = columns[col];
    return `${col} = :${bind}`;
  });

  sets.push('UPDATED_AT = SYSTIMESTAMP');

  const result = await executeCommit(
    `UPDATE ${table} SET ${sets.join(', ')} WHERE ID = :id AND NVL(IS_DELETED,0) = 0`,
    binds,
  );

  return result.rowsAffected || 0;
}

export async function softDeleteRow(table, id, user = null) {
  const result = await executeCommit(
    `
    UPDATE ${table}
    SET IS_DELETED = 1,
        IS_ACTIVE = 0,
        UPDATED_BY = :updatedBy,
        UPDATED_AT = SYSTIMESTAMP
    WHERE ID = :id AND NVL(IS_DELETED,0) = 0
    `,
    { id, updatedBy: user?.username || user?.empId || user?.id || 'system' },
  );
  return result.rowsAffected || 0;
}

export async function existsById(table, id) {
  const row = await queryOne(
    `SELECT ID AS "id" FROM ${table} WHERE ID = :id AND NVL(IS_DELETED,0) = 0 FETCH FIRST 1 ROWS ONLY`,
    { id },
  );
  return !!row;
}

export function makeInClause(values = [], column, bindPrefix, where, binds) {
  const list = Array.isArray(values) ? values.filter(Boolean) : [];
  if (!list.length) return;
  const params = list.map((value, index) => {
    const key = `${bindPrefix}${index}`;
    binds[key] = value;
    return `:${key}`;
  });
  where.push(`${column} IN (${params.join(', ')})`);
}

export default {
  TABLES,
  newId,
  toNumber,
  toBooleanNumber,
  pageInfo,
  normalizeValue,
  parseJson,
  mapJsonFields,
  mapJsonRows,
  query,
  queryOne,
  scalar,
  pagedQuery,
  addEq,
  addLike,
  addDateFrom,
  addDateTo,
  pickMapped,
  insertRow,
  updateRow,
  softDeleteRow,
  existsById,
  makeInClause,
};
