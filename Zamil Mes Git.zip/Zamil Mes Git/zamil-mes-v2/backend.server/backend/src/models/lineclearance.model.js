import {
  TABLES,
  query,
  queryOne,
  pagedQuery,
  addEq,
  addDateFrom,
  addDateTo,
  addLike,
  insertRow,
  updateRow,
  parseJson,
} from './base.model.js';

const lineClearanceFieldMap = {
  woId: 'WO_ID',
  machineId: 'MACHINE_ID',
  conductedById: 'CONDUCTED_BY_ID',
  approvedById: 'APPROVED_BY_ID',
  plant: 'PLANT',
  machine: 'MACHINE',
  jobOrder: 'JOB_ORDER',
  productCode: 'PRODUCT_CODE',
  productName: 'PRODUCT_NAME',
  submissionShift: 'SUBMISSION_SHIFT',
  submissionDate: 'SUBMISSION_DATE',
  clearanceType: 'CLEARANCE_TYPE',
  requestNo: 'REQUEST_NO',
  techName: 'TECH_NAME',
  qiName: 'QI_NAME',
  checkedCount: 'CHECKED_COUNT',
  checkedTotal: 'CHECKED_TOTAL',
  note: 'NOTE',
  controlNbr: 'CONTROL_NBR',
  shift: 'SHIFT',
  checklistData: 'CHECKLIST_DATA_JSON',
  hygieneChecks: 'HYGIENE_CHECKS_JSON',
  operationChecks: 'OPERATION_CHECKS_JSON',
  moldChecks: 'MOLD_CHECKS_JSON',
  operatorSignature: 'OPERATOR_SIGNATURE',
  supervisorSignature: 'SUPERVISOR_SIGNATURE',
  status: 'STATUS',
  submittedAt: 'SUBMITTED_AT',
  approvedAt: 'APPROVED_AT',
  rejectionReason: 'REJECTION_REASON',
};

function normalizeLineClearance(row) {
  if (!row) return null;
  return {
    ...row,
    checklistData: parseJson(row.checklistData, {}),
    hygieneChecks: parseJson(row.hygieneChecks, {}),
    operationChecks: parseJson(row.operationChecks, {}),
    moldChecks: parseJson(row.moldChecks, {}),
  };
}

const cleanKey = (value) => {
  if (value === undefined || value === null) return null;
  const text = String(value).trim();
  return text || null;
};

async function resolveWorkOrderNumber(value) {
  const lookup = cleanKey(value);
  if (!lookup) return null;

  const row = await queryOne(
    `
    SELECT WO_NUMBER AS "woNumber"
    FROM ${TABLES.workOrders}
    WHERE NVL(IS_DELETED,0) = 0
      AND (
        UPPER(TRIM(ID)) = UPPER(TRIM(:lookup))
        OR UPPER(TRIM(WO_NUMBER)) = UPPER(TRIM(:lookup))
        OR UPPER(TRIM(WORK_ORDER_ID)) = UPPER(TRIM(:lookup))
      )
    FETCH FIRST 1 ROWS ONLY
    `,
    { lookup },
  );

  return row?.woNumber || lookup;
}

async function resolveMachineCode(value) {
  const lookup = cleanKey(value);
  if (!lookup) return null;

  const row = await queryOne(
    `
    SELECT CODE AS "code"
    FROM ${TABLES.machines}
    WHERE NVL(IS_DELETED,0) = 0
      AND (
        UPPER(TRIM(ID)) = UPPER(TRIM(:lookup))
        OR UPPER(TRIM(CODE)) = UPPER(TRIM(:lookup))
        OR UPPER(TRIM(MES_CODE)) = UPPER(TRIM(:lookup))
      )
    FETCH FIRST 1 ROWS ONLY
    `,
    { lookup },
  );

  return row?.code || lookup;
}

export async function listLineClearances(filters = {}) {
  const where = ['NVL(LC.IS_DELETED,0) = 0'];
  const binds = {};
  addEq(where, binds, 'LC.WO_ID', 'woId', filters.woNumber || filters.workOrderNumber || filters.woId);
  addEq(where, binds, 'LC.MACHINE_ID', 'machineId', filters.machineCode || filters.machineId);
  addEq(where, binds, 'LC.PLANT', 'plant', filters.plant);
  addEq(where, binds, 'LC.STATUS', 'status', filters.status);
  addEq(where, binds, 'LC.CLEARANCE_TYPE', 'clearanceType', filters.clearanceType);
  addDateFrom(where, binds, 'LC.SUBMISSION_DATE', 'fromDate', filters.fromDate);
  addDateTo(where, binds, 'LC.SUBMISSION_DATE', 'toDate', filters.toDate);
  addLike(where, binds, ['LC.REQUEST_NO', 'LC.JOB_ORDER', 'LC.PRODUCT_CODE', 'LC.PRODUCT_NAME', 'LC.MACHINE'], 'search', filters.search);

  const result = await pagedQuery({
    select: `
      LC.ID AS "id", LC.WO_ID AS "woId", WO.WO_NUMBER AS "woNumber",
      LC.MACHINE_ID AS "machineId", M.CODE AS "machineCode", M.NAME AS "machineName",
      LC.CONDUCTED_BY_ID AS "conductedById", LC.APPROVED_BY_ID AS "approvedById",
      LC.PLANT AS "plant", LC.MACHINE AS "machine", LC.JOB_ORDER AS "jobOrder",
      LC.PRODUCT_CODE AS "productCode", LC.PRODUCT_NAME AS "productName",
      LC.SUBMISSION_SHIFT AS "submissionShift", LC.SUBMISSION_DATE AS "submissionDate",
      LC.CLEARANCE_TYPE AS "clearanceType", LC.REQUEST_NO AS "requestNo",
      LC.TECH_NAME AS "techName", LC.QI_NAME AS "qiName",
      LC.CHECKED_COUNT AS "checkedCount", LC.CHECKED_TOTAL AS "checkedTotal",
      LC.NOTE AS "note", LC.CONTROL_NBR AS "controlNbr", LC.SHIFT AS "shift",
      LC.CHECKLIST_DATA_JSON AS "checklistData", LC.HYGIENE_CHECKS_JSON AS "hygieneChecks",
      LC.OPERATION_CHECKS_JSON AS "operationChecks", LC.MOLD_CHECKS_JSON AS "moldChecks",
      LC.STATUS AS "status", LC.SUBMITTED_AT AS "submittedAt", LC.APPROVED_AT AS "approvedAt",
      LC.REJECTION_REASON AS "rejectionReason", LC.CREATED_AT AS "createdAt", LC.UPDATED_AT AS "updatedAt"
    `,
    from: `${TABLES.lineClearances} LC`,
    joins: `
      LEFT JOIN ${TABLES.workOrders} WO ON WO.WO_NUMBER = LC.WO_ID
      LEFT JOIN ${TABLES.machines} M ON M.CODE = LC.MACHINE_ID
    `,
    where,
    binds,
    orderBy: 'LC.CREATED_AT DESC',
    page: filters.page,
    limit: filters.limit,
  });
  return { ...result, rows: result.rows.map(normalizeLineClearance) };
}

export async function getLineClearanceById(id) {
  const row = await queryOne(
    `
    SELECT
      LC.ID AS "id", LC.WO_ID AS "woId", WO.WO_NUMBER AS "woNumber",
      LC.MACHINE_ID AS "machineId", M.CODE AS "machineCode", LC.CONDUCTED_BY_ID AS "conductedById",
      LC.APPROVED_BY_ID AS "approvedById", LC.PLANT AS "plant", LC.MACHINE AS "machine",
      LC.JOB_ORDER AS "jobOrder", LC.PRODUCT_CODE AS "productCode", LC.PRODUCT_NAME AS "productName",
      LC.SUBMISSION_SHIFT AS "submissionShift", LC.SUBMISSION_DATE AS "submissionDate",
      LC.CLEARANCE_TYPE AS "clearanceType", LC.REQUEST_NO AS "requestNo", LC.TECH_NAME AS "techName",
      LC.QI_NAME AS "qiName", LC.CHECKED_COUNT AS "checkedCount", LC.CHECKED_TOTAL AS "checkedTotal",
      LC.NOTE AS "note", LC.CONTROL_NBR AS "controlNbr", LC.SHIFT AS "shift",
      LC.CHECKLIST_DATA_JSON AS "checklistData", LC.HYGIENE_CHECKS_JSON AS "hygieneChecks",
      LC.OPERATION_CHECKS_JSON AS "operationChecks", LC.MOLD_CHECKS_JSON AS "moldChecks",
      LC.OPERATOR_SIGNATURE AS "operatorSignature", LC.SUPERVISOR_SIGNATURE AS "supervisorSignature",
      LC.STATUS AS "status", LC.SUBMITTED_AT AS "submittedAt", LC.APPROVED_AT AS "approvedAt",
      LC.REJECTION_REASON AS "rejectionReason", LC.CREATED_AT AS "createdAt", LC.UPDATED_AT AS "updatedAt"
    FROM ${TABLES.lineClearances} LC
    LEFT JOIN ${TABLES.workOrders} WO ON WO.WO_NUMBER = LC.WO_ID
    LEFT JOIN ${TABLES.machines} M ON M.CODE = LC.MACHINE_ID
    WHERE LC.ID = :id AND NVL(LC.IS_DELETED,0) = 0
    FETCH FIRST 1 ROWS ONLY
    `,
    { id },
  );
  return normalizeLineClearance(row);
}

export async function createLineClearance(data, user = null) {
  const woNumber = await resolveWorkOrderNumber(data.woId || data.woNumber || data.workOrderNumber);
  const machineCode = await resolveMachineCode(data.machineId || data.machineCode);

  return insertRow(TABLES.lineClearances, lineClearanceFieldMap, {
    ...data,
    woId: woNumber || data.woId,
    machineId: machineCode || data.machineId,
    conductedById: data.conductedById || user?.id,
    status: data.status || 'draft',
    submittedAt: String(data.status || '').toLowerCase() === 'submitted' ? new Date() : data.submittedAt,
  }, user);
}

export async function updateLineClearance(id, data, user = null) {
  return updateRow(TABLES.lineClearances, lineClearanceFieldMap, id, data, user);
}

export async function approveLineClearance(id, { approved = true, rejectionReason = null } = {}, user = null) {
  return updateRow(TABLES.lineClearances, lineClearanceFieldMap, id, {
    status: approved ? 'approved' : 'rejected',
    approvedById: user?.id || null,
    approvedAt: approved ? new Date() : null,
    rejectionReason: approved ? null : rejectionReason,
  }, user);
}



export async function submitLineClearance(id, user = null) {
  return updateRow(TABLES.lineClearances, lineClearanceFieldMap, id, {
    status: 'submitted',
    submittedAt: new Date(),
  }, user);
}

export async function rejectLineClearance(id, rejectionReason = null, user = null) {
  return updateRow(TABLES.lineClearances, lineClearanceFieldMap, id, {
    status: 'rejected',
    approvedById: user?.id || null,
    approvedAt: null,
    rejectionReason,
  }, user);
}

export async function productLookup(filters = {}) {
  const where = ['NVL(WO.IS_DELETED,0) = 0'];
  const binds = {};
  addEq(where, binds, 'WO.WO_NUMBER', 'woNumber', filters.woNumber || filters.workOrderNumber || filters.woId);
  addEq(where, binds, 'WO.PRODUCT_CODE', 'productCode', filters.productCode || filters.itemCode);
  addEq(where, binds, 'WO.MACHINE_ID', 'machineId', filters.machineId || filters.machineCode);
  addLike(where, binds, ['WO.WO_NUMBER', 'WO.PRODUCT_CODE', 'WO.PRODUCT', 'M.CODE', 'M.NAME'], 'search', filters.search);
  return query(
    `
    SELECT
      WO.ID AS "id", WO.WO_NUMBER AS "woNumber", WO.PRODUCT_CODE AS "productCode",
      WO.PRODUCT AS "productName", WO.PLANT AS "plant", WO.MACHINE_ID AS "machineId",
      M.CODE AS "machineCode", M.NAME AS "machineName", WO.STATUS AS "status",
      WO.SCHEDULED_DATE AS "scheduledDate", WO.LOCATOR_CODE AS "locatorCode"
    FROM ${TABLES.workOrders} WO
    LEFT JOIN ${TABLES.machines} M ON M.CODE = WO.MACHINE_ID
    WHERE ${where.join(' AND ')}
    ORDER BY WO.SCHEDULED_DATE DESC NULLS LAST, WO.CREATED_AT DESC
    FETCH FIRST 100 ROWS ONLY
    `,
    binds,
  );
}

export async function listLCChecklist(filters = {}) {
  const where = ['NVL(IS_DELETED,0) = 0', 'NVL(IS_ACTIVE,1) = 1'];
  const binds = {};
  addEq(where, binds, 'CHECK_GROUP', 'checkGroup', filters.checkGroup);
  return query(
    `
    SELECT
      ID AS "id", CHECK_CODE AS "code", CHECK_NAME AS "name", CHECK_GROUP AS "group",
      SORT_ORDER AS "sortOrder", IS_REQUIRED AS "isRequired"
    FROM ${TABLES.lcChecklists}
    WHERE ${where.join(' AND ')}
    ORDER BY CHECK_GROUP, SORT_ORDER, CHECK_NAME
    `,
    binds,
  );
}

export default {
  listLineClearances,
  getLineClearanceById,
  createLineClearance,
  updateLineClearance,
  approveLineClearance,
  submitLineClearance,
  rejectLineClearance,
  productLookup,
  listLCChecklist,
};
