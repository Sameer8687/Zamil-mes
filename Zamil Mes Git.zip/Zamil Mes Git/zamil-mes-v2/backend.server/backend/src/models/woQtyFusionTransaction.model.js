import { randomUUID } from 'crypto';
import { TABLES, queryOne } from './base.model.js';
import { executeCommit } from '../config/oracle.js';

const TABLE_NAME = TABLES.woQtyFusionTransactions || 'MES_WO_QTY_FUS_TRANSACTIONS';

const cleanText = (value) => {
    if (value === undefined || value === null) return null;
    const text = String(value).trim();
    return text || null;
};

const cleanNumber = (value, fallback = null) => {
    const number = Number(value);
    return Number.isFinite(number) ? number : fallback;
};

const getActor = (user = null) => {
    return (
        cleanText(user?.username) ||
        cleanText(user?.empId) ||
        cleanText(user?.email) ||
        cleanText(user?.id) ||
        'system'
    );
};

const toJsonClob = (value) => {
    if (value === undefined || value === null) return null;
    if (typeof value === 'string') return value;

    try {
        return JSON.stringify(value);
    } catch {
        return JSON.stringify({
            serializationError: true,
            message: 'Unable to serialize payload',
        });
    }
};

export async function getWoQtyFusionTransactionById(id) {
    return queryOne(
        `
    SELECT
      ID AS "id",
      WO_NUMBER AS "woNumber",
      ORGANIZATION_ID AS "organizationId",
      PRODUCT_CODE AS "productCode",
      MACHINE_CODE AS "machineCode",
      BOX_ID AS "boxId",
      BOX_BARCODE AS "boxBarcode",
      TRANSACTION_QTY AS "transactionQty",
      TRANSACTION_UOM_CODE AS "transactionUomCode",
      TRANSACTION_DATE AS "transactionDate",
      SOURCE_SYSTEM_CODE AS "sourceSystemCode",
      SOURCE_SYSTEM_TYPE AS "sourceSystemType",
      TRANSACTION_SOURCE AS "transactionSource",
      FUSION_POSTED_FLAG AS "fusionPostedFlag",
      FUSION_POST_STATUS AS "fusionPostStatus",
      FUSION_POSTED_AT AS "fusionPostedAt",
      FUSION_HTTP_STATUS AS "fusionHttpStatus",
      FUSION_TRANSACTION_ID AS "fusionTransactionId",
      FUSION_REQUEST_ID AS "fusionRequestId",
      FUSION_ERROR_CODE AS "fusionErrorCode",
      FUSION_ERROR_MESSAGE AS "fusionErrorMessage",
      IS_LAST_TRANSACTION AS "isLastTransaction",
      WORK_ORDER_COMPLETED_FLAG AS "workOrderCompletedFlag",
      WORK_ORDER_COMPLETED_AT AS "workOrderCompletedAt",
      RETRY_COUNT AS "retryCount",
      LAST_RETRY_AT AS "lastRetryAt",
      REMARKS AS "remarks",
      CREATED_BY AS "createdBy",
      CREATED_AT AS "createdAt",
      UPDATED_BY AS "updatedBy",
      UPDATED_AT AS "updatedAt",
      IS_ACTIVE AS "isActive",
      IS_DELETED AS "isDeleted"
    FROM ${TABLE_NAME}
    WHERE ID = :id
      AND NVL(IS_DELETED, 0) = 0
    FETCH FIRST 1 ROWS ONLY
    `,
        { id },
    );
}

export async function createWoQtyFusionTransaction(data, user = null) {
    const id = cleanText(data.id) || randomUUID();

    await executeCommit(
        `
    INSERT INTO ${TABLE_NAME} (
      ID,
      WO_NUMBER,
      ORGANIZATION_ID,
      PRODUCT_CODE,
      MACHINE_CODE,
      BOX_ID,
      BOX_BARCODE,
      TRANSACTION_QTY,
      TRANSACTION_UOM_CODE,
      TRANSACTION_DATE,
      SOURCE_SYSTEM_CODE,
      SOURCE_SYSTEM_TYPE,
      TRANSACTION_SOURCE,
      FUSION_POSTED_FLAG,
      FUSION_POST_STATUS,
      IS_LAST_TRANSACTION,
      WORK_ORDER_COMPLETED_FLAG,
      RETRY_COUNT,
      REMARKS,
      CREATED_BY,
      CREATED_AT,
      UPDATED_BY,
      UPDATED_AT,
      IS_ACTIVE,
      IS_DELETED
    ) VALUES (
      :id,
      :woNumber,
      :organizationId,
      :productCode,
      :machineCode,
      :boxId,
      :boxBarcode,
      :transactionQty,
      :transactionUomCode,
      NVL(:transactionDate, SYSTIMESTAMP),
      :sourceSystemCode,
      :sourceSystemType,
      :transactionSource,
      0,
      'PENDING',
      :isLastTransaction,
      :workOrderCompletedFlag,
      0,
      :remarks,
      :createdBy,
      SYSTIMESTAMP,
      :updatedBy,
      SYSTIMESTAMP,
      1,
      0
    )
    `,
        {
            id,
            woNumber: cleanText(data.woNumber),
            organizationId: cleanText(data.organizationId),
            productCode: cleanText(data.productCode),
            machineCode: cleanText(data.machineCode),
            boxId: cleanText(data.boxId),
            boxBarcode: cleanText(data.boxBarcode),
            transactionQty: cleanNumber(data.transactionQty, 0),
            transactionUomCode: cleanText(data.transactionUomCode),
            transactionDate: data.transactionDate || null,
            sourceSystemCode: cleanText(data.sourceSystemCode) || 'ZAMIL_MES',
            sourceSystemType: cleanText(data.sourceSystemType) || 'EXTERNAL',
            transactionSource: cleanText(data.transactionSource) || 'MES_LABEL_PRINT',
            isLastTransaction: cleanNumber(data.isLastTransaction, 0),
            workOrderCompletedFlag: cleanNumber(data.workOrderCompletedFlag, 0),
            remarks: cleanText(data.remarks),
            createdBy: getActor(user),
            updatedBy: getActor(user),
        },
    );

    return getWoQtyFusionTransactionById(id);
}

export async function markWoQtyFusionTransactionSuccess(id, data = {}, user = null) {
    await executeCommit(
        `
    UPDATE ${TABLE_NAME}
    SET
      ORGANIZATION_ID = NVL(:organizationId, ORGANIZATION_ID),
      PRODUCT_CODE = NVL(:productCode, PRODUCT_CODE),
      MACHINE_CODE = NVL(:machineCode, MACHINE_CODE),
      BOX_ID = NVL(:boxId, BOX_ID),
      BOX_BARCODE = NVL(:boxBarcode, BOX_BARCODE),
      TRANSACTION_UOM_CODE = NVL(:transactionUomCode, TRANSACTION_UOM_CODE),
      FUSION_POSTED_FLAG = 1,
      FUSION_POST_STATUS = 'SUCCESS',
      FUSION_POSTED_AT = SYSTIMESTAMP,
      FUSION_HTTP_STATUS = :fusionHttpStatus,
      FUSION_TRANSACTION_ID = :fusionTransactionId,
      FUSION_REQUEST_ID = :fusionRequestId,
      FUSION_ERROR_CODE = NULL,
      FUSION_ERROR_MESSAGE = NULL,
      
      IS_LAST_TRANSACTION = :isLastTransaction,
      WORK_ORDER_COMPLETED_FLAG = :workOrderCompletedFlag,
      WORK_ORDER_COMPLETED_AT =
        CASE
          WHEN :workOrderCompletedFlag = 1 THEN SYSTIMESTAMP
          ELSE WORK_ORDER_COMPLETED_AT
        END,
      REMARKS = :remarks,
      UPDATED_BY = :updatedBy,
      UPDATED_AT = SYSTIMESTAMP
    WHERE ID = :id
    `,
        {
            id,
            organizationId: cleanText(data.organizationId),
            productCode: cleanText(data.productCode),
            machineCode: cleanText(data.machineCode),
            boxId: cleanText(data.boxId),
            boxBarcode: cleanText(data.boxBarcode),
            transactionUomCode: cleanText(data.transactionUomCode),
            fusionHttpStatus: cleanNumber(data.fusionHttpStatus),
            fusionTransactionId: cleanText(data.fusionTransactionId),
            fusionRequestId: cleanText(data.fusionRequestId),
            isLastTransaction: cleanNumber(data.isLastTransaction, 0),
            workOrderCompletedFlag: cleanNumber(data.workOrderCompletedFlag, 0),
            remarks: cleanText(data.remarks) || 'Fusion quantity posted successfully',
            updatedBy: getActor(user),
        },
    );

    return getWoQtyFusionTransactionById(id);
}

export async function markWoQtyFusionTransactionFailed(id, data = {}, user = null) {
    await executeCommit(
        `
    UPDATE ${TABLE_NAME}
    SET
      ORGANIZATION_ID = NVL(:organizationId, ORGANIZATION_ID),
      PRODUCT_CODE = NVL(:productCode, PRODUCT_CODE),
      MACHINE_CODE = NVL(:machineCode, MACHINE_CODE),
      BOX_BARCODE = NVL(:boxBarcode, BOX_BARCODE),
      TRANSACTION_UOM_CODE = NVL(:transactionUomCode, TRANSACTION_UOM_CODE),
      FUSION_POSTED_FLAG = 0,
      FUSION_POST_STATUS = 'FAILED',
      FUSION_HTTP_STATUS = :fusionHttpStatus,
      FUSION_ERROR_CODE = :fusionErrorCode,
      FUSION_ERROR_MESSAGE = SUBSTR(:fusionErrorMessage, 1, 4000),
      
      RETRY_COUNT = NVL(RETRY_COUNT, 0) + 1,
      LAST_RETRY_AT = SYSTIMESTAMP,
      REMARKS = :remarks,
      UPDATED_BY = :updatedBy,
      UPDATED_AT = SYSTIMESTAMP
    WHERE ID = :id
    `,
        {
            id,
            organizationId: cleanText(data.organizationId),
            productCode: cleanText(data.productCode),
            machineCode: cleanText(data.machineCode),
            boxBarcode: cleanText(data.boxBarcode),
            transactionUomCode: cleanText(data.transactionUomCode),
            fusionHttpStatus: cleanNumber(data.fusionHttpStatus),
            fusionErrorCode: cleanText(data.fusionErrorCode),
            fusionErrorMessage: cleanText(data.fusionErrorMessage) || 'Fusion quantity posting failed',
            
            remarks: cleanText(data.remarks) || 'Box qty not recorded because Fusion posting failed',
            updatedBy: getActor(user),
        },
    );

    return getWoQtyFusionTransactionById(id);
}

export async function attachBoxToWoQtyFusionTransaction(id, data = {}, user = null) {
    await executeCommit(
        `
    UPDATE ${TABLE_NAME}
    SET
      BOX_ID = :boxId,
      BOX_BARCODE = NVL(:boxBarcode, BOX_BARCODE),
      UPDATED_BY = :updatedBy,
      UPDATED_AT = SYSTIMESTAMP
    WHERE ID = :id
    `,
        {
            id,
            boxId: cleanText(data.boxId),
            boxBarcode: cleanText(data.boxBarcode),
            updatedBy: getActor(user),
        },
    );

    return getWoQtyFusionTransactionById(id);
}

export default {
    getWoQtyFusionTransactionById,
    createWoQtyFusionTransaction,
    markWoQtyFusionTransactionSuccess,
    markWoQtyFusionTransactionFailed,
    attachBoxToWoQtyFusionTransaction,
};