import {
  TABLES,
  query,
  queryOne,
  pagedQuery,
  addEq,
  addLike,
  insertRow,
  updateRow,
  softDeleteRow,
  parseJson,
} from './base.model.js';

const machineFieldMap = {
  code: 'CODE',
  name: 'NAME',
  machineType: 'MACHINE_TYPE',
  type: 'MACHINE_TYPE',
  plant: 'PLANT',
  department: 'DEPARTMENT',
  area: 'AREA',
  locator: 'LOCATOR',
  oem: 'OEM',
  model: 'MODEL',
  serialNo: 'SERIAL_NO',
  tonnage: 'TONNAGE',
  cycleTime: 'CYCLE_TIME',
  cavities: 'CAVITIES',
  ipAddress: 'IP_ADDRESS',
  plcType: 'PLC_TYPE',
  commProtocol: 'COMM_PROTOCOL',
  mesCode: 'MES_CODE',
  pmFreq: 'PM_FREQ',
  lastPmDate: 'LAST_PM_DATE',
  status: 'STATUS',
  specs: 'SPECS_JSON',
  isActive: 'IS_ACTIVE',
};

const locationFieldMap = {
  code: 'CODE',
  name: 'NAME',
  locationType: 'LOCATION_TYPE',
  type: 'LOCATION_TYPE',
  plant: 'PLANT',
  isActive: 'IS_ACTIVE',
};

const shiftFieldMap = {
  name: 'NAME',
  startTime: 'START_TIME',
  endTime: 'END_TIME',
  plant: 'PLANT',
  isActive: 'IS_ACTIVE',
};

const configFieldMap = {
  key: 'CONFIG_KEY',
  configKey: 'CONFIG_KEY',
  value: 'CONFIG_VALUE',
  configValue: 'CONFIG_VALUE',
  category: 'CATEGORY',
  description: 'DESCRIPTION',
  isActive: 'IS_ACTIVE',
};

const boxQtyFieldMap = {
  org: 'ORG',
  productCode: 'PRODUCT_CODE',
  productDesc: 'PRODUCT_DESC',
  qtyPerBox: 'QTY_PER_BOX',
  effectiveDate: 'EFFECTIVE_DATE',
  isActive: 'IS_ACTIVE',
};

export function normalizeMachine(row) {
  if (!row) return null;
  return {
    ...row,
    isActive: Number(row.isActive ?? 1) === 1,
    isDeleted: Number(row.isDeleted || 0) === 1,
    specs: parseJson(row.specs, {}),
  };
}

export function normalizeLocation(row) {
  if (!row) return null;
  return {
    ...row,
    type: row.locationType || row.type,
    isActive: Number(row.isActive ?? 1) === 1,
    isDeleted: Number(row.isDeleted || 0) === 1,
  };
}

export function normalizeShift(row) {
  if (!row) return null;
  return {
    ...row,
    isActive: Number(row.isActive ?? 1) === 1,
    isDeleted: Number(row.isDeleted || 0) === 1,
  };
}

export async function listMachines(filters = {}) {
  const where = ['NVL(IS_DELETED,0) = 0'];
  const binds = {};

  addEq(where, binds, 'ID', 'id', filters.id || filters.machineIdValue);
  addEq(where, binds, 'CODE', 'code', filters.code || filters.machineCode || filters.machineId);
  addEq(where, binds, 'MES_CODE', 'mesCode', filters.mesCode);
  addEq(where, binds, 'STATUS', 'status', filters.rawStatus || filters.status);
  addEq(where, binds, 'PLANT', 'plant', filters.plant);
  addEq(where, binds, 'DEPARTMENT', 'department', filters.department || filters.dept);
  addEq(where, binds, 'AREA', 'area', filters.area);
  addLike(where, binds, ['CODE', 'NAME', 'LOCATOR', 'MES_CODE', 'OEM', 'MODEL', 'SERIAL_NO'], 'search', filters.search);

  const result = await pagedQuery({
    select: `
      ID AS "id",
      CODE AS "code",
      NAME AS "name",
      MACHINE_TYPE AS "machineType",
      PLANT AS "plant",
      DEPARTMENT AS "department",
      AREA AS "area",
      LOCATOR AS "locator",
      OEM AS "oem",
      MODEL AS "model",
      SERIAL_NO AS "serialNo",
      TONNAGE AS "tonnage",
      CYCLE_TIME AS "cycleTime",
      CAVITIES AS "cavities",
      IP_ADDRESS AS "ipAddress",
      PLC_TYPE AS "plcType",
      COMM_PROTOCOL AS "commProtocol",
      MES_CODE AS "mesCode",
      PM_FREQ AS "pmFreq",
      LAST_PM_DATE AS "lastPmDate",
      STATUS AS "status",
      SPECS_JSON AS "specs",
      IS_ACTIVE AS "isActive",
      IS_DELETED AS "isDeleted",
      CREATED_AT AS "createdAt",
      UPDATED_AT AS "updatedAt"
    `,
    from: TABLES.machines,
    where,
    binds,
    orderBy: 'CODE ASC',
    page: filters.page || 1,
    limit: filters.limit || 500,
  });

  return { ...result, rows: result.rows.map(normalizeMachine) };
}

export async function getMachineById(id) {
  const row = await queryOne(
    `
    SELECT
      ID AS "id", CODE AS "code", NAME AS "name", MACHINE_TYPE AS "machineType",
      PLANT AS "plant", DEPARTMENT AS "department", AREA AS "area", LOCATOR AS "locator",
      OEM AS "oem", MODEL AS "model", SERIAL_NO AS "serialNo", TONNAGE AS "tonnage",
      CYCLE_TIME AS "cycleTime", CAVITIES AS "cavities", IP_ADDRESS AS "ipAddress",
      PLC_TYPE AS "plcType", COMM_PROTOCOL AS "commProtocol", MES_CODE AS "mesCode",
      PM_FREQ AS "pmFreq", LAST_PM_DATE AS "lastPmDate", STATUS AS "status",
      SPECS_JSON AS "specs", IS_ACTIVE AS "isActive", IS_DELETED AS "isDeleted",
      CREATED_AT AS "createdAt", UPDATED_AT AS "updatedAt"
    FROM ${TABLES.machines}
    WHERE ID = :id AND NVL(IS_DELETED,0) = 0
    FETCH FIRST 1 ROWS ONLY
    `,
    { id },
  );
  return normalizeMachine(row);
}

export async function createMachine(data, user = null) {
  return insertRow(TABLES.machines, machineFieldMap, data, user);
}

export async function updateMachine(id, data, user = null) {
  return updateRow(TABLES.machines, machineFieldMap, id, data, user);
}

export async function deleteMachine(id, user = null) {
  return softDeleteRow(TABLES.machines, id, user);
}

export async function listLocations(filters = {}) {
  const where = ['NVL(IS_DELETED,0) = 0'];
  const binds = {};
  addEq(where, binds, 'ID', 'id', filters.id);
  addEq(where, binds, 'CODE', 'code', filters.code || filters.locationCode);
  addEq(where, binds, 'PLANT', 'plant', filters.plant);
  addEq(where, binds, 'LOCATION_TYPE', 'locationType', filters.locationType || filters.type);
  if (filters.status === 'Active') addEq(where, binds, 'IS_ACTIVE', 'isActive', 1);
  if (filters.status === 'Inactive') addEq(where, binds, 'IS_ACTIVE', 'isActive', 0);
  addLike(where, binds, ['CODE', 'NAME', 'LOCATION_TYPE', 'PLANT'], 'search', filters.search);

  const result = await pagedQuery({
    select: `
      ID AS "id",
      CODE AS "code",
      NAME AS "name",
      LOCATION_TYPE AS "locationType",
      LOCATION_TYPE AS "type",
      PLANT AS "plant",
      IS_ACTIVE AS "isActive",
      IS_DELETED AS "isDeleted",
      CREATED_AT AS "createdAt",
      UPDATED_AT AS "updatedAt"
    `,
    from: TABLES.locations,
    where,
    binds,
    orderBy: 'CODE ASC',
    page: filters.page || 1,
    limit: filters.limit || 500,
  });
  return { ...result, rows: result.rows.map(normalizeLocation) };
}

export async function getLocationById(id) {
  const row = await queryOne(
    `
    SELECT
      ID AS "id",
      CODE AS "code",
      NAME AS "name",
      LOCATION_TYPE AS "locationType",
      LOCATION_TYPE AS "type",
      PLANT AS "plant",
      IS_ACTIVE AS "isActive",
      IS_DELETED AS "isDeleted",
      CREATED_AT AS "createdAt",
      UPDATED_AT AS "updatedAt"
    FROM ${TABLES.locations}
    WHERE ID = :id AND NVL(IS_DELETED,0) = 0
    FETCH FIRST 1 ROWS ONLY
    `,
    { id },
  );
  return normalizeLocation(row);
}

export async function createLocation(data, user = null) {
  return insertRow(TABLES.locations, locationFieldMap, data, user);
}

export async function updateLocation(id, data, user = null) {
  return updateRow(TABLES.locations, locationFieldMap, id, data, user);
}

export async function deleteLocation(id, user = null) {
  return softDeleteRow(TABLES.locations, id, user);
}

export async function listShifts(filters = {}) {
  const where = ['NVL(IS_DELETED,0) = 0'];
  const binds = {};
  addEq(where, binds, 'ID', 'id', filters.id);
  addEq(where, binds, 'PLANT', 'plant', filters.plant);
  if (filters.status === 'Active') addEq(where, binds, 'IS_ACTIVE', 'isActive', 1);
  if (filters.status === 'Inactive') addEq(where, binds, 'IS_ACTIVE', 'isActive', 0);
  addLike(where, binds, ['NAME', 'PLANT', 'START_TIME', 'END_TIME'], 'search', filters.search);

  const result = await pagedQuery({
    select: `
      ID AS "id",
      NAME AS "name",
      START_TIME AS "startTime",
      END_TIME AS "endTime",
      PLANT AS "plant",
      IS_ACTIVE AS "isActive",
      IS_DELETED AS "isDeleted",
      CREATED_AT AS "createdAt",
      UPDATED_AT AS "updatedAt"
    `,
    from: TABLES.shifts,
    where,
    binds,
    orderBy: 'PLANT ASC, START_TIME ASC, NAME ASC',
    page: filters.page || 1,
    limit: filters.limit || 200,
  });
  return { ...result, rows: result.rows.map(normalizeShift) };
}

export async function getShiftById(id) {
  const row = await queryOne(
    `
    SELECT
      ID AS "id", NAME AS "name", START_TIME AS "startTime", END_TIME AS "endTime",
      PLANT AS "plant", IS_ACTIVE AS "isActive", IS_DELETED AS "isDeleted",
      CREATED_AT AS "createdAt", UPDATED_AT AS "updatedAt"
    FROM ${TABLES.shifts}
    WHERE ID = :id AND NVL(IS_DELETED,0) = 0
    FETCH FIRST 1 ROWS ONLY
    `,
    { id },
  );
  return normalizeShift(row);
}

export async function createShift(data, user = null) {
  return insertRow(TABLES.shifts, shiftFieldMap, data, user);
}

export async function updateShift(id, data, user = null) {
  return updateRow(TABLES.shifts, shiftFieldMap, id, data, user);
}

export async function deleteShift(id, user = null) {
  return softDeleteRow(TABLES.shifts, id, user);
}

export async function listConfigs(filters = {}) {
  const where = ['NVL(IS_DELETED,0) = 0'];
  const binds = {};
  addEq(where, binds, 'CONFIG_KEY', 'key', filters.key || filters.configKey);
  addEq(where, binds, 'CATEGORY', 'category', filters.category);
  return query(
    `
    SELECT
      ID AS "id", CONFIG_KEY AS "key", CONFIG_VALUE AS "value", CATEGORY AS "category",
      DESCRIPTION AS "description", IS_ACTIVE AS "isActive", CREATED_AT AS "createdAt", UPDATED_AT AS "updatedAt"
    FROM ${TABLES.systemConfigs}
    ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
    ORDER BY CATEGORY, CONFIG_KEY
    `,
    binds,
  );
}

export async function upsertConfig(data, user = null) {
  const existing = await queryOne(
    `SELECT ID AS "id" FROM ${TABLES.systemConfigs} WHERE CONFIG_KEY = :key AND NVL(IS_DELETED,0) = 0 FETCH FIRST 1 ROWS ONLY`,
    { key: data.key || data.configKey },
  );
  if (existing) return updateRow(TABLES.systemConfigs, configFieldMap, existing.id, data, user);
  return insertRow(TABLES.systemConfigs, configFieldMap, data, user);
}

export async function listBoxQtyRecords(filters = {}) {
  const where = ['NVL(IS_DELETED,0) = 0'];
  const binds = {};
  addEq(where, binds, 'ORG', 'org', filters.org);
  addEq(where, binds, 'PRODUCT_CODE', 'productCode', filters.productCode || filters.code);
  addLike(where, binds, ['ORG', 'PRODUCT_CODE', 'PRODUCT_DESC'], 'search', filters.search);
  return pagedQuery({
    select: `
      ID AS "id",
      ORG AS "org",
      PRODUCT_CODE AS "productCode",
      PRODUCT_DESC AS "productDesc",
      QTY_PER_BOX AS "qtyPerBox",
      EFFECTIVE_DATE AS "effectiveDate",
      IS_ACTIVE AS "isActive",
      CREATED_AT AS "createdAt",
      UPDATED_AT AS "updatedAt"
    `,
    from: TABLES.boxQtyRecords,
    where,
    binds,
    orderBy: 'ORG ASC, PRODUCT_CODE ASC, EFFECTIVE_DATE DESC',
    page: filters.page || 1,
    limit: filters.limit || 500,
  });
}

export async function getBoxQtyRecordById(id) {
  return queryOne(
    `
    SELECT
      ID AS "id", ORG AS "org", PRODUCT_CODE AS "productCode", PRODUCT_DESC AS "productDesc",
      QTY_PER_BOX AS "qtyPerBox", EFFECTIVE_DATE AS "effectiveDate", IS_ACTIVE AS "isActive",
      CREATED_AT AS "createdAt", UPDATED_AT AS "updatedAt"
    FROM ${TABLES.boxQtyRecords}
    WHERE ID = :id AND NVL(IS_DELETED,0) = 0
    FETCH FIRST 1 ROWS ONLY
    `,
    { id },
  );
}

export async function createBoxQtyRecord(data, user = null) {
  return insertRow(TABLES.boxQtyRecords, boxQtyFieldMap, data, user);
}

export async function updateBoxQtyRecord(id, data, user = null) {
  return updateRow(TABLES.boxQtyRecords, boxQtyFieldMap, id, data, user);
}

export async function deleteBoxQtyRecord(id, user = null) {
  return softDeleteRow(TABLES.boxQtyRecords, id, user);
}

export default {
  listMachines,
  getMachineById,
  createMachine,
  updateMachine,
  deleteMachine,
  listLocations,
  getLocationById,
  createLocation,
  updateLocation,
  deleteLocation,
  listShifts,
  getShiftById,
  createShift,
  updateShift,
  deleteShift,
  listConfigs,
  upsertConfig,
  listBoxQtyRecords,
  getBoxQtyRecordById,
  createBoxQtyRecord,
  updateBoxQtyRecord,
  deleteBoxQtyRecord,
};
