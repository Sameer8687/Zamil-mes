import {
  TABLES,
  query,
  queryOne,
  pagedQuery,
  addEq,
  addDateFrom,
  addDateTo,
  addLike,
  insertRow,
  updateRow,
} from './base.model.js';

const downtimeFieldMap = {
  machineId: 'MACHINE_ID',
  woId: 'WO_ID',
  reportedById: 'REPORTED_BY_ID',
  org: 'ORG',
  machine: 'MACHINE',
  downtimeDate: 'DOWNTIME_DATE',
  product: 'PRODUCT',
  description: 'DESCRIPTION',
  routing: 'ROUTING',
  hours: 'HOURS',
  minute: 'MINUTE',
  dtType: 'DT_TYPE',
  shift: 'SHIFT',
  category: 'CATEGORY',
  process: 'PROCESS',
  reason: 'REASON',
  startTime: 'START_TIME',
  endTime: 'END_TIME',
  durationMinutes: 'DURATION_MINUTES',
  subcategory: 'SUBCATEGORY',
  actionTaken: 'ACTION_TAKEN',
  status: 'STATUS',
  resolvedById: 'RESOLVED_BY_ID',
};

const cleanKey = (value) => {
  if (value === undefined || value === null) return null;
  const text = String(value).trim();
  return text || null;
};

async function resolveWorkOrderNumber(value) {
  const lookup = cleanKey(value);
  if (!lookup) return null;

  const row = await queryOne(
    `
    SELECT WO_NUMBER AS "woNumber"
    FROM ${TABLES.workOrders}
    WHERE NVL(IS_DELETED,0) = 0
      AND (
        UPPER(TRIM(ID)) = UPPER(TRIM(:lookup))
        OR UPPER(TRIM(WO_NUMBER)) = UPPER(TRIM(:lookup))
        OR UPPER(TRIM(WORK_ORDER_ID)) = UPPER(TRIM(:lookup))
      )
    FETCH FIRST 1 ROWS ONLY
    `,
    { lookup },
  );

  return row?.woNumber || lookup;
}

async function resolveMachineCode(value) {
  const lookup = cleanKey(value);
  if (!lookup) return null;

  const row = await queryOne(
    `
    SELECT CODE AS "code"
    FROM ${TABLES.machines}
    WHERE NVL(IS_DELETED,0) = 0
      AND (
        UPPER(TRIM(ID)) = UPPER(TRIM(:lookup))
        OR UPPER(TRIM(CODE)) = UPPER(TRIM(:lookup))
        OR UPPER(TRIM(MES_CODE)) = UPPER(TRIM(:lookup))
      )
    FETCH FIRST 1 ROWS ONLY
    `,
    { lookup },
  );

  return row?.code || lookup;
}

export async function listDowntimeRecords(filters = {}) {
  const where = ['NVL(DT.IS_DELETED,0) = 0'];
  const binds = {};
  addEq(where, binds, 'DT.MACHINE_ID', 'machineId', filters.machineCode || filters.machineId);
  addEq(where, binds, 'DT.WO_ID', 'woId', filters.woNumber || filters.workOrderNumber || filters.woId);
  addEq(where, binds, 'DT.STATUS', 'status', filters.status);
  addEq(where, binds, 'DT.CATEGORY', 'category', filters.category);
  addEq(where, binds, 'DT.DT_TYPE', 'dtType', filters.dtType);
  addEq(where, binds, 'DT.ORG', 'org', filters.org);
  addDateFrom(where, binds, 'DT.DOWNTIME_DATE', 'fromDate', filters.fromDate);
  addDateTo(where, binds, 'DT.DOWNTIME_DATE', 'toDate', filters.toDate);
  addLike(where, binds, ['M.CODE', 'DT.MACHINE', 'DT.PRODUCT', 'DT.DESCRIPTION', 'DT.REASON'], 'search', filters.search);

  return pagedQuery({
    select: `
      DT.ID AS "id", DT.MACHINE_ID AS "machineId", M.CODE AS "machineCode", M.NAME AS "machineName",
      DT.WO_ID AS "woId", WO.WO_NUMBER AS "woNumber", DT.REPORTED_BY_ID AS "reportedById",
      U.FULL_NAME AS "reportedByName", DT.ORG AS "org", DT.MACHINE AS "machine",
      DT.DOWNTIME_DATE AS "downtimeDate", DT.PRODUCT AS "product", DT.DESCRIPTION AS "description",
      DT.ROUTING AS "routing", DT.HOURS AS "hours", DT.MINUTE AS "minute", DT.DT_TYPE AS "dtType",
      DT.SHIFT AS "shift", DT.CATEGORY AS "category", DT.PROCESS AS "process", DT.REASON AS "reason",
      DT.START_TIME AS "startTime", DT.END_TIME AS "endTime", DT.DURATION_MINUTES AS "durationMinutes",
      DT.SUBCATEGORY AS "subcategory", DT.ACTION_TAKEN AS "actionTaken", DT.STATUS AS "status",
      DT.RESOLVED_BY_ID AS "resolvedById", DT.CREATED_AT AS "createdAt", DT.UPDATED_AT AS "updatedAt"
    `,
    from: `${TABLES.downtimeRecords} DT`,
    joins: `
      LEFT JOIN ${TABLES.machines} M ON M.CODE = DT.MACHINE_ID
      LEFT JOIN ${TABLES.workOrders} WO ON WO.WO_NUMBER = DT.WO_ID
      LEFT JOIN ${TABLES.users} U ON U.ID = DT.REPORTED_BY_ID
    `,
    where,
    binds,
    orderBy: 'DT.DOWNTIME_DATE DESC NULLS LAST, DT.CREATED_AT DESC',
    page: filters.page,
    limit: filters.limit,
  });
}

export async function getDowntimeRecordById(id) {
  return queryOne(
    `
    SELECT
      DT.ID AS "id", DT.MACHINE_ID AS "machineId", M.CODE AS "machineCode", DT.WO_ID AS "woId",
      WO.WO_NUMBER AS "woNumber", DT.REPORTED_BY_ID AS "reportedById", DT.ORG AS "org",
      DT.MACHINE AS "machine", DT.DOWNTIME_DATE AS "downtimeDate", DT.PRODUCT AS "product",
      DT.DESCRIPTION AS "description", DT.ROUTING AS "routing", DT.HOURS AS "hours", DT.MINUTE AS "minute",
      DT.DT_TYPE AS "dtType", DT.SHIFT AS "shift", DT.CATEGORY AS "category", DT.PROCESS AS "process",
      DT.REASON AS "reason", DT.START_TIME AS "startTime", DT.END_TIME AS "endTime",
      DT.DURATION_MINUTES AS "durationMinutes", DT.SUBCATEGORY AS "subcategory", DT.ACTION_TAKEN AS "actionTaken",
      DT.STATUS AS "status", DT.RESOLVED_BY_ID AS "resolvedById", DT.CREATED_AT AS "createdAt", DT.UPDATED_AT AS "updatedAt"
    FROM ${TABLES.downtimeRecords} DT
    LEFT JOIN ${TABLES.machines} M ON M.CODE = DT.MACHINE_ID
    LEFT JOIN ${TABLES.workOrders} WO ON WO.WO_NUMBER = DT.WO_ID
    WHERE DT.ID = :id AND NVL(DT.IS_DELETED,0) = 0
    FETCH FIRST 1 ROWS ONLY
    `,
    { id },
  );
}

export async function createDowntimeRecord(data, user = null) {
  const woNumber = await resolveWorkOrderNumber(data.woId || data.woNumber || data.workOrderNumber);
  const machineCode = await resolveMachineCode(data.machineId || data.machineCode);

  return insertRow(TABLES.downtimeRecords, downtimeFieldMap, {
    ...data,
    woId: woNumber || data.woId,
    machineId: machineCode || data.machineId,
    reportedById: data.reportedById || user?.id,
    status: data.status || 'open',
  }, user);
}

export async function updateDowntimeRecord(id, data, user = null) {
  return updateRow(TABLES.downtimeRecords, downtimeFieldMap, id, data, user);
}

export async function getDowntimeSummary(filters = {}) {
  const where = ['NVL(IS_DELETED,0) = 0'];
  const binds = {};
  addDateFrom(where, binds, 'DOWNTIME_DATE', 'fromDate', filters.fromDate);
  addDateTo(where, binds, 'DOWNTIME_DATE', 'toDate', filters.toDate);
  addEq(where, binds, 'ORG', 'org', filters.org);
  return queryOne(
    `
    SELECT
      COUNT(1) AS "count",
      SUM(NVL(DURATION_MINUTES,0)) AS "totalMinutes",
      ROUND(SUM(NVL(DURATION_MINUTES,0)) / 60, 2) AS "totalHours",
      SUM(CASE WHEN STATUS = 'open' THEN 1 ELSE 0 END) AS "openCount",
      SUM(CASE WHEN STATUS = 'resolved' THEN 1 ELSE 0 END) AS "resolvedCount"
    FROM ${TABLES.downtimeRecords}
    WHERE ${where.join(' AND ')}
    `,
    binds,
  );
}



export async function deleteDowntimeRecord(id, user = null) {
  return softDeleteRow(TABLES.downtimeRecords, id, user);
}

export async function resolveDowntimeRecord(id, data = {}, user = null) {
  return updateRow(TABLES.downtimeRecords, downtimeFieldMap, id, {
    status: 'resolved',
    actionTaken: data.actionTaken || data.notes || data.reason || null,
    resolvedById: data.resolvedById || user?.id,
    endTime: data.endTime || new Date(),
    durationMinutes: data.durationMinutes,
  }, user);
}

export async function reopenDowntimeRecord(id, data = {}, user = null) {
  return updateRow(TABLES.downtimeRecords, downtimeFieldMap, id, {
    status: 'open',
    actionTaken: data.actionTaken || data.notes || null,
    resolvedById: null,
    endTime: null,
  }, user);
}

export async function machineProductLookup(filters = {}) {
  const where = ['NVL(WO.IS_DELETED,0) = 0'];
  const binds = {};
  addEq(where, binds, 'WO.MACHINE_ID', 'machineId', filters.machineId || filters.machineCode);
  addLike(where, binds, ['WO.WO_NUMBER', 'WO.PRODUCT', 'WO.PRODUCT_CODE', 'M.CODE', 'M.NAME'], 'search', filters.search);
  return query(
    `
    SELECT
      WO.ID AS "id", WO.WO_NUMBER AS "woNumber", WO.PRODUCT AS "product",
      WO.PRODUCT_CODE AS "productCode", WO.MACHINE_ID AS "machineId",
      M.CODE AS "machineCode", M.NAME AS "machineName", WO.STATUS AS "status"
    FROM ${TABLES.workOrders} WO
    LEFT JOIN ${TABLES.machines} M ON M.CODE = WO.MACHINE_ID
    WHERE ${where.join(' AND ')}
    ORDER BY CASE WHEN WO.STATUS = 'active' THEN 1 ELSE 2 END, WO.SCHEDULED_DATE DESC NULLS LAST
    FETCH FIRST 100 ROWS ONLY
    `,
    binds,
  );
}

export async function listDowntimeReasonCodes(filters = {}) {
  const where = ['NVL(IS_DELETED,0) = 0', 'NVL(IS_ACTIVE,1) = 1'];
  const binds = {};
  addEq(where, binds, 'CATEGORY', 'category', filters.category);
  addEq(where, binds, 'DT_TYPE', 'dtType', filters.dtType);
  return query(
    `
    SELECT
      ID AS "id", REASON_CODE AS "reasonCode", REASON_NAME AS "reasonName",
      CATEGORY AS "category", SUBCATEGORY AS "subcategory", DT_TYPE AS "dtType"
    FROM ${TABLES.downtimeReasonCodes}
    WHERE ${where.join(' AND ')}
    ORDER BY CATEGORY, REASON_NAME
    `,
    binds,
  );
}

export default {
  listDowntimeRecords,
  getDowntimeRecordById,
  createDowntimeRecord,
  updateDowntimeRecord,
  deleteDowntimeRecord,
  resolveDowntimeRecord,
  reopenDowntimeRecord,
  machineProductLookup,
  getDowntimeSummary,
  listDowntimeReasonCodes,
};
