import {
  TABLES,
  query,
  queryOne,
  pagedQuery,
  addEq,
  addDateFrom,
  addDateTo,
  addLike,
  insertRow,
  updateRow,
  softDeleteRow,
  toNumber,
} from './base.model.js';
import { executeCommit } from '../config/oracle.js';

const wasteFieldMap = {
  woId: 'WO_ID',
  machineId: 'MACHINE_ID',
  recordedById: 'RECORDED_BY_ID',
  shift: 'SHIFT',
  wasteType: 'WASTE_TYPE',
  category: 'CATEGORY',
  quantity: 'QUANTITY',
  unit: 'UNIT',
  costPerUnit: 'COST_PER_UNIT',
  totalCost: 'TOTAL_COST',
  disposalMethod: 'DISPOSAL_METHOD',
  notes: 'NOTES',
};

const wasteTxnFieldMap = {
  wasteRecordId: 'WASTE_RECORD_ID',
  woId: 'WO_ID',
  machineId: 'MACHINE_ID',
  componentCode: 'COMPONENT_CODE',
  reasonCodeId: 'REASON_CODE_ID',
  lotNo: 'LOT_NO',
  quantity: 'QUANTITY',
  uom: 'UOM',
  costPerUnit: 'COST_PER_UNIT',
  totalCost: 'TOTAL_COST',
  destination: 'DESTINATION',
  transactionDate: 'TRANSACTION_DATE',
  recordedById: 'RECORDED_BY_ID',
  notes: 'NOTES',
};

const cleanKey = (value) => {
  if (value === undefined || value === null) return null;
  const text = String(value).trim();
  return text || null;
};

async function resolveWorkOrderNumber(value) {
  const lookup = cleanKey(value);
  if (!lookup) return null;

  const row = await queryOne(
    `
    SELECT WO_NUMBER AS "woNumber"
    FROM ${TABLES.workOrders}
    WHERE NVL(IS_DELETED,0) = 0
      AND (
        UPPER(TRIM(ID)) = UPPER(TRIM(:lookup))
        OR UPPER(TRIM(WO_NUMBER)) = UPPER(TRIM(:lookup))
        OR UPPER(TRIM(WORK_ORDER_ID)) = UPPER(TRIM(:lookup))
      )
    FETCH FIRST 1 ROWS ONLY
    `,
    { lookup },
  );

  return row?.woNumber || lookup;
}

async function resolveMachineCode(value) {
  const lookup = cleanKey(value);
  if (!lookup) return null;

  const row = await queryOne(
    `
    SELECT CODE AS "code"
    FROM ${TABLES.machines}
    WHERE NVL(IS_DELETED,0) = 0
      AND (
        UPPER(TRIM(ID)) = UPPER(TRIM(:lookup))
        OR UPPER(TRIM(CODE)) = UPPER(TRIM(:lookup))
        OR UPPER(TRIM(MES_CODE)) = UPPER(TRIM(:lookup))
      )
    FETCH FIRST 1 ROWS ONLY
    `,
    { lookup },
  );

  return row?.code || lookup;
}

export async function listWasteRecords(filters = {}) {
  const where = ['NVL(WR.IS_DELETED,0) = 0'];
  const binds = {};
  addEq(where, binds, 'WR.WO_ID', 'woId', filters.woNumber || filters.workOrderNumber || filters.woId);
  addEq(where, binds, 'WR.MACHINE_ID', 'machineId', filters.machineCode || filters.machineId);
  addEq(where, binds, 'WR.CATEGORY', 'category', filters.category);
  addEq(where, binds, 'WR.WASTE_TYPE', 'wasteType', filters.wasteType);
  addDateFrom(where, binds, 'WR.CREATED_AT', 'fromDate', filters.fromDate);
  addDateTo(where, binds, 'WR.CREATED_AT', 'toDate', filters.toDate);
  addLike(where, binds, ['WO.WO_NUMBER', 'M.CODE', 'WR.WASTE_TYPE', 'WR.CATEGORY', 'WR.NOTES'], 'search', filters.search);

  return pagedQuery({
    select: `
      WR.ID AS "id", WR.WO_ID AS "woId", WO.WO_NUMBER AS "woNumber",
      WR.MACHINE_ID AS "machineId", M.CODE AS "machineCode", M.NAME AS "machineName",
      WR.RECORDED_BY_ID AS "recordedById", U.FULL_NAME AS "recordedByName",
      WR.SHIFT AS "shift", WR.WASTE_TYPE AS "wasteType", WR.CATEGORY AS "category",
      WR.QUANTITY AS "quantity", WR.UNIT AS "unit", WR.COST_PER_UNIT AS "costPerUnit",
      WR.TOTAL_COST AS "totalCost", WR.DISPOSAL_METHOD AS "disposalMethod",
      WR.NOTES AS "notes", WR.CREATED_AT AS "createdAt", WR.UPDATED_AT AS "updatedAt"
    `,
    from: `${TABLES.wasteRecords} WR`,
    joins: `
      LEFT JOIN ${TABLES.workOrders} WO ON WO.WO_NUMBER = WR.WO_ID
      LEFT JOIN ${TABLES.machines} M ON M.CODE = WR.MACHINE_ID
      LEFT JOIN ${TABLES.users} U ON U.ID = WR.RECORDED_BY_ID
    `,
    where,
    binds,
    orderBy: 'WR.CREATED_AT DESC',
    page: filters.page,
    limit: filters.limit,
  });
}

export async function getWasteRecordById(id) {
  return queryOne(
    `
    SELECT
      WR.ID AS "id", WR.WO_ID AS "woId", WO.WO_NUMBER AS "woNumber", WR.MACHINE_ID AS "machineId",
      M.CODE AS "machineCode", WR.RECORDED_BY_ID AS "recordedById", WR.SHIFT AS "shift",
      WR.WASTE_TYPE AS "wasteType", WR.CATEGORY AS "category", WR.QUANTITY AS "quantity",
      WR.UNIT AS "unit", WR.COST_PER_UNIT AS "costPerUnit", WR.TOTAL_COST AS "totalCost",
      WR.DISPOSAL_METHOD AS "disposalMethod", WR.NOTES AS "notes", WR.CREATED_AT AS "createdAt", WR.UPDATED_AT AS "updatedAt"
    FROM ${TABLES.wasteRecords} WR
    LEFT JOIN ${TABLES.workOrders} WO ON WO.WO_NUMBER = WR.WO_ID
    LEFT JOIN ${TABLES.machines} M ON M.CODE = WR.MACHINE_ID
    WHERE WR.ID = :id AND NVL(WR.IS_DELETED,0) = 0
    FETCH FIRST 1 ROWS ONLY
    `,
    { id },
  );
}

export async function createWasteRecord(data, user = null) {
  const quantity = toNumber(data.quantity ?? data.qty, 0);
  const costPerUnit = toNumber(data.costPerUnit, 0);
  const totalCost = data.totalCost ?? (quantity * costPerUnit);
  const woNumber = await resolveWorkOrderNumber(data.woId || data.woNumber || data.workOrderNumber);
  const machineCode = await resolveMachineCode(data.machineId || data.machineCode);

  return insertRow(TABLES.wasteRecords, wasteFieldMap, {
    ...data,
    woId: woNumber || data.woId,
    machineId: machineCode || data.machineId,
    wasteType: data.wasteType || data.component,
    category: data.category || data.reason,
    quantity,
    unit: data.unit || data.uom || 'KG',
    costPerUnit,
    totalCost,
    disposalMethod: data.disposalMethod || data.mode || 'scrap',
    recordedById: data.recordedById || user?.id,
  }, user);
}

export async function updateWasteRecord(id, data, user = null) {
  return updateRow(TABLES.wasteRecords, wasteFieldMap, id, data, user);
}

export async function deleteWasteRecord(id, user = null) {
  return softDeleteRow(TABLES.wasteRecords, id, user);
}

export async function getWasteSummary(filters = {}) {
  const where = ['NVL(IS_DELETED,0) = 0'];
  const binds = {};
  addDateFrom(where, binds, 'CREATED_AT', 'fromDate', filters.fromDate);
  addDateTo(where, binds, 'CREATED_AT', 'toDate', filters.toDate);
  return queryOne(
    `
    SELECT
      COUNT(1) AS "count",
      SUM(NVL(QUANTITY,0)) AS "totalQty",
      SUM(NVL(TOTAL_COST,0)) AS "totalCost",
      SUM(CASE WHEN DISPOSAL_METHOD = 'return' THEN 1 ELSE 0 END) AS "returns"
    FROM ${TABLES.wasteRecords}
    WHERE ${where.join(' AND ')}
    `,
    binds,
  );
}

export async function listWasteReasonCodes(filters = {}) {
  const where = ['NVL(IS_DELETED,0) = 0', 'NVL(IS_ACTIVE,1) = 1'];
  const binds = {};
  addEq(where, binds, 'CATEGORY', 'category', filters.category);
  addEq(where, binds, 'WASTE_TYPE', 'wasteType', filters.wasteType);
  return query(
    `
    SELECT
      ID AS "id", REASON_CODE AS "reasonCode", REASON_NAME AS "reasonName",
      CATEGORY AS "category", WASTE_TYPE AS "wasteType", DEFAULT_UOM AS "defaultUom",
      DISPOSAL_METHOD AS "disposalMethod"
    FROM ${TABLES.wasteReasonCodes}
    WHERE ${where.join(' AND ')}
    ORDER BY CATEGORY, REASON_NAME
    `,
    binds,
  );
}

export async function createWasteTransaction(data, user = null) {
  const woNumber = await resolveWorkOrderNumber(data.woId || data.woNumber || data.workOrderNumber);
  const machineCode = await resolveMachineCode(data.machineId || data.machineCode);

  return insertRow(TABLES.wasteTransactions, wasteTxnFieldMap, {
    ...data,
    woId: woNumber || data.woId,
    machineId: machineCode || data.machineId,
    transactionDate: data.transactionDate || new Date(),
    recordedById: data.recordedById || user?.id,
  }, user);
}

export async function listWasteTransactions(filters = {}) {
  const where = ['1=1'];
  const binds = {};
  addEq(where, binds, 'WT.WASTE_RECORD_ID', 'wasteRecordId', filters.wasteRecordId);
  addEq(where, binds, 'WT.WO_ID', 'woId', filters.woNumber || filters.workOrderNumber || filters.woId);
  addEq(where, binds, 'WT.MACHINE_ID', 'machineId', filters.machineCode || filters.machineId);
  addDateFrom(where, binds, 'WT.TRANSACTION_DATE', 'fromDate', filters.fromDate);
  addDateTo(where, binds, 'WT.TRANSACTION_DATE', 'toDate', filters.toDate);
  return pagedQuery({
    select: `
      WT.ID AS "id", WT.WASTE_RECORD_ID AS "wasteRecordId", WT.WO_ID AS "woId", WO.WO_NUMBER AS "woNumber",
      WT.MACHINE_ID AS "machineId", M.CODE AS "machineCode", WT.COMPONENT_CODE AS "componentCode",
      WRC.REASON_CODE AS "reasonCode", WRC.REASON_NAME AS "reasonName", WT.LOT_NO AS "lotNo",
      WT.QUANTITY AS "quantity", WT.UOM AS "uom", WT.COST_PER_UNIT AS "costPerUnit",
      WT.TOTAL_COST AS "totalCost", WT.DESTINATION AS "destination", WT.TRANSACTION_DATE AS "transactionDate",
      WT.RECORDED_BY_ID AS "recordedById", WT.NOTES AS "notes", WT.CREATED_AT AS "createdAt"
    `,
    from: `${TABLES.wasteTransactions} WT`,
    joins: `
      LEFT JOIN ${TABLES.workOrders} WO ON WO.WO_NUMBER = WT.WO_ID
      LEFT JOIN ${TABLES.machines} M ON M.CODE = WT.MACHINE_ID
      LEFT JOIN ${TABLES.wasteReasonCodes} WRC ON WRC.ID = WT.REASON_CODE_ID
    `,
    where,
    binds,
    orderBy: 'WT.TRANSACTION_DATE DESC, WT.CREATED_AT DESC',
    page: filters.page,
    limit: filters.limit,
  });
}



export async function getWasteTransactionById(id) {
  const row = await queryOne(
    `
    SELECT
      WT.ID AS "id", WT.WASTE_RECORD_ID AS "wasteRecordId", WT.WO_ID AS "woId", WO.WO_NUMBER AS "woNumber",
      WT.MACHINE_ID AS "machineId", M.CODE AS "machineCode", WT.COMPONENT_CODE AS "componentCode",
      WRC.REASON_CODE AS "reasonCode", WRC.REASON_NAME AS "reasonName", WT.REASON_CODE_ID AS "reasonCodeId",
      WT.LOT_NO AS "lotNo", WT.QUANTITY AS "quantity", WT.UOM AS "uom",
      WT.COST_PER_UNIT AS "costPerUnit", WT.TOTAL_COST AS "totalCost", WT.DESTINATION AS "destination",
      WT.TRANSACTION_DATE AS "transactionDate", WT.RECORDED_BY_ID AS "recordedById",
      WT.NOTES AS "notes", WT.CREATED_AT AS "createdAt", WT.UPDATED_AT AS "updatedAt"
    FROM ${TABLES.wasteTransactions} WT
    LEFT JOIN ${TABLES.workOrders} WO ON WO.WO_NUMBER = WT.WO_ID
    LEFT JOIN ${TABLES.machines} M ON M.CODE = WT.MACHINE_ID
    LEFT JOIN ${TABLES.wasteReasonCodes} WRC ON WRC.ID = WT.REASON_CODE_ID
    WHERE WT.ID = :id
    FETCH FIRST 1 ROWS ONLY
    `,
    { id },
  );
  return row;
}

export async function updateWasteTransaction(id, data, user = null) {
  const quantity = data.quantity === undefined && data.qty === undefined ? undefined : toNumber(data.quantity ?? data.qty, 0);
  const costPerUnit = data.costPerUnit === undefined ? undefined : toNumber(data.costPerUnit, 0);
  const totalCost = data.totalCost ?? (quantity !== undefined && costPerUnit !== undefined ? quantity * costPerUnit : undefined);
  const values = {
    wasteRecordId: data.wasteRecordId,
    woId: data.woId,
    machineId: data.machineId,
    componentCode: data.componentCode,
    reasonCodeId: data.reasonCodeId,
    lotNo: data.lotNo,
    quantity,
    uom: data.uom,
    costPerUnit,
    totalCost,
    destination: data.destination,
    transactionDate: data.transactionDate,
    recordedById: data.recordedById || user?.id,
    notes: data.notes,
  };
  const colMap = {
    wasteRecordId: 'WASTE_RECORD_ID', woId: 'WO_ID', machineId: 'MACHINE_ID', componentCode: 'COMPONENT_CODE',
    reasonCodeId: 'REASON_CODE_ID', lotNo: 'LOT_NO', quantity: 'QUANTITY', uom: 'UOM', costPerUnit: 'COST_PER_UNIT',
    totalCost: 'TOTAL_COST', destination: 'DESTINATION', transactionDate: 'TRANSACTION_DATE', recordedById: 'RECORDED_BY_ID', notes: 'NOTES',
  };
  const sets = [];
  const binds = { id };
  for (const [key, column] of Object.entries(colMap)) {
    if (values[key] !== undefined) {
      binds[key] = values[key];
      sets.push(`${column} = :${key}`);
    }
  }
  if (!sets.length) return 0;
  sets.push('UPDATED_AT = SYSTIMESTAMP');
  const result = await executeCommit(`UPDATE ${TABLES.wasteTransactions} SET ${sets.join(', ')} WHERE ID = :id`, binds);
  return result.rowsAffected || 0;
}

export async function deleteWasteTransaction(id) {
  const result = await executeCommit(`DELETE FROM ${TABLES.wasteTransactions} WHERE ID = :id`, { id });
  return result.rowsAffected || 0;
}

export async function reverseWasteTransaction(id, data = {}, user = null) {
  const original = await getWasteTransactionById(id);
  if (!original) return null;
  const newId = await createWasteTransaction({
    wasteRecordId: original.wasteRecordId,
    woId: original.woId,
    machineId: original.machineId,
    componentCode: original.componentCode,
    reasonCodeId: original.reasonCodeId,
    lotNo: original.lotNo,
    quantity: -Math.abs(Number(original.quantity || 0)),
    uom: original.uom,
    costPerUnit: original.costPerUnit,
    totalCost: -Math.abs(Number(original.totalCost || 0)),
    destination: data.destination || original.destination || 'return',
    transactionDate: data.transactionDate || new Date(),
    recordedById: data.recordedById || user?.id,
    notes: data.notes || `Reversal of waste transaction ${id}`,
  }, user);
  return getWasteTransactionById(newId);
}

export async function approveWasteTransaction(id, data = {}, user = null) {
  const txn = await getWasteTransactionById(id);
  if (!txn) return null;
  const note = [txn.notes, data.notes || 'Approved'].filter(Boolean).join(' | ');
  await updateWasteTransaction(id, { notes: note, recordedById: txn.recordedById || user?.id }, user);
  return getWasteTransactionById(id);
}

export async function listWasteWorkOrders(filters = {}) {
  const where = ['NVL(WO.IS_DELETED,0) = 0'];
  const binds = {};
  addEq(where, binds, 'WO.STATUS', 'status', filters.status || 'active');
  addEq(where, binds, 'WO.MACHINE_ID', 'machineId', filters.machineId || filters.machineCode);
  addLike(where, binds, ['WO.WO_NUMBER', 'WO.PRODUCT', 'WO.PRODUCT_CODE'], 'search', filters.search);
  return query(
    `
    SELECT WO.ID AS "id", WO.WO_NUMBER AS "woNumber", WO.PRODUCT AS "product",
           WO.PRODUCT_CODE AS "productCode", WO.MACHINE_ID AS "machineId",
           WO.PLANNED_QTY AS "plannedQty", WO.PRODUCED_QTY AS "producedQty",
           WO.STATUS AS "status"
    FROM ${TABLES.workOrders} WO
    WHERE ${where.join(' AND ')}
    ORDER BY WO.SCHEDULED_DATE DESC NULLS LAST, WO.CREATED_AT DESC
    FETCH FIRST 200 ROWS ONLY
    `,
    binds,
  );
}

export async function listWasteComponents(woId) {
  const woNumber = await resolveWorkOrderNumber(woId);
  return query(
    `
    SELECT ID AS "id", WO_ID AS "woId", COMPONENT_CODE AS "componentCode",
           COMPONENT_DESC AS "componentDesc", COMPONENT_TYPE AS "componentType",
           REQUIRED_QTY AS "requiredQty", ISSUED_QTY AS "issuedQty", CONSUMED_QTY AS "consumedQty",
           UOM AS "uom", LOT_NO AS "lotNo", STATUS AS "status"
    FROM ${TABLES.workOrderComponents}
    WHERE UPPER(TRIM(WO_ID)) = UPPER(TRIM(:woId)) AND NVL(IS_DELETED,0) = 0
    ORDER BY COMPONENT_CODE
    `,
    { woId: woNumber },
  );
}

export async function listWasteLots(filters = {}) {
  const where = ['NVL(IS_DELETED,0) = 0'];
  const binds = {};
  addEq(where, binds, 'ORG', 'org', filters.org);
  addEq(where, binds, 'ITEM_CODE', 'itemCode', filters.itemCode || filters.componentCode);
  addEq(where, binds, 'LOT_NO', 'lotNo', filters.lotNo);
  addEq(where, binds, 'LOCATOR_CODE', 'locatorCode', filters.locatorCode);
  return query(
    `
    SELECT ID AS "id", ORG AS "org", ITEM_CODE AS "itemCode", LOT_NO AS "lotNo",
           SUBINVENTORY AS "subinventory", LOCATOR_CODE AS "locatorCode", QTY_ON_HAND AS "qtyOnHand",
           RESERVED_QTY AS "reservedQty", UOM AS "uom", EXPIRY_DATE AS "expiryDate", STATUS AS "status"
    FROM ${TABLES.inventoryLots}
    WHERE ${where.join(' AND ')}
    ORDER BY ITEM_CODE, LOT_NO
    FETCH FIRST 500 ROWS ONLY
    `,
    binds,
  );
}

export default {
  listWasteRecords,
  getWasteRecordById,
  createWasteRecord,
  updateWasteRecord,
  deleteWasteRecord,
  getWasteSummary,
  listWasteReasonCodes,
  createWasteTransaction,
  listWasteTransactions,
  getWasteTransactionById,
  updateWasteTransaction,
  deleteWasteTransaction,
  reverseWasteTransaction,
  approveWasteTransaction,
  listWasteWorkOrders,
  listWasteComponents,
  listWasteLots,
};
