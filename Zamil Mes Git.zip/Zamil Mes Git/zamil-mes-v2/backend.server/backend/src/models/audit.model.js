import { TABLES, query, insertRow, pageInfo } from './base.model.js';

const MAX_AUDIT_VALUE_LENGTH = 3900;

function safeAuditValue(value) {
  if (value === undefined || value === null || value === '') return null;
  const text = typeof value === 'string' ? value : JSON.stringify(value);
  if (text.length <= MAX_AUDIT_VALUE_LENGTH) return text;
  return `${text.slice(0, MAX_AUDIT_VALUE_LENGTH - 30)}... [TRUNCATED]`;
}


const auditFieldMap = {
  userId: 'USER_ID',
  action: 'ACTION',
  module: 'MODULE',
  recordId: 'RECORD_ID',
  oldData: 'OLD_DATA_JSON',
  newData: 'NEW_DATA_JSON',
  ipAddress: 'IP_ADDRESS',
  userAgent: 'USER_AGENT',
};

export async function createAuditLog(data) {
  return insertRow(TABLES.auditLogs, auditFieldMap, {
    ...data,
    oldData: safeAuditValue(data.oldData),
    newData: safeAuditValue(data.newData),
  });
}

export async function listUserActivity(userId, { page = 1, limit = 50 } = {}) {
  const p = pageInfo(page, limit);
  return query(
    `
    SELECT
      ID AS "id",
      USER_ID AS "userId",
      ACTION AS "action",
      MODULE AS "module",
      RECORD_ID AS "recordId",
      OLD_DATA_JSON AS "oldData",
      NEW_DATA_JSON AS "newData",
      IP_ADDRESS AS "ipAddress",
      USER_AGENT AS "userAgent",
      CREATED_AT AS "createdAt"
    FROM ${TABLES.auditLogs}
    WHERE USER_ID = :userId
    ORDER BY CREATED_AT DESC
    OFFSET :offset ROWS FETCH NEXT :limit ROWS ONLY
    `,
    { userId, offset: p.offset, limit: p.limit },
  );
}

export default { createAuditLog, listUserActivity };
