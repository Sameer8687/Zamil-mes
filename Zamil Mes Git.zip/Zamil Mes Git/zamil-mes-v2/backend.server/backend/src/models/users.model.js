import {
  TABLES,
  query,
  queryOne,
  pagedQuery,
  addEq,
  addLike,
  insertRow,
  updateRow,
  softDeleteRow,
  parseJson,
  toBooleanNumber,
  newId,
} from './base.model.js';
import { executeCommit } from '../config/oracle.js';
import { listUserActivity } from './audit.model.js';

const userFieldMap = {
  empId: 'EMP_ID',
  username: 'USERNAME',
  passwordHash: 'PASSWORD_HASH',
  fullName: 'FULL_NAME',
  email: 'EMAIL',
  phone: 'PHONE',
  role: 'ROLE_CODE',
  roleCode: 'ROLE_CODE',
  roleId: 'ROLE_ID',
  plant: 'PLANT',
  department: 'DEPARTMENT',
  shift: 'SHIFT',
  language: 'LANGUAGE_CODE',
  languageCode: 'LANGUAGE_CODE',
  theme: 'THEME',
  mustChangePassword: 'MUST_CHANGE_PASSWORD',
  screenPermissions: 'SCREEN_PERMISSIONS_JSON',
  screenPermissionsJson: 'SCREEN_PERMISSIONS_JSON',
  isActive: 'IS_ACTIVE',
};

const roleFieldMap = {
  name: 'NAME',
  description: 'DESCRIPTION',
  permissions: 'PERMISSIONS_JSON',
  permissionsJson: 'PERMISSIONS_JSON',
  isActive: 'IS_ACTIVE',
};

const userRoleFieldMap = {
  userId: 'USER_ID',
  roleId: 'ROLE_ID',
  isPrimary: 'IS_PRIMARY',
  assignedById: 'ASSIGNED_BY_ID',
  assignedAt: 'ASSIGNED_AT',
};

const userScopeFieldMap = {
  userId: 'USER_ID',
  scopeType: 'SCOPE_TYPE',
  scopeCode: 'SCOPE_CODE',
  scopeName: 'SCOPE_NAME',
  isAllowed: 'IS_ALLOWED',
};

const screenOverrideFieldMap = {
  userId: 'USER_ID',
  screenCode: 'SCREEN_CODE',
  canView: 'CAN_VIEW',
  canCreate: 'CAN_CREATE',
  canUpdate: 'CAN_UPDATE',
  canDelete: 'CAN_DELETE',
  canApprove: 'CAN_APPROVE',
  overrideReason: 'OVERRIDE_REASON',
};

const featureOverrideFieldMap = {
  userId: 'USER_ID',
  featureCode: 'FEATURE_CODE',
  isAllowed: 'IS_ALLOWED',
  isEnabled: 'IS_ALLOWED',
  overrideReason: 'OVERRIDE_REASON',
};

const roleScreenFieldMap = {
  roleId: 'ROLE_ID',
  screenCode: 'SCREEN_CODE',
  canView: 'CAN_VIEW',
  canCreate: 'CAN_CREATE',
  canUpdate: 'CAN_UPDATE',
  canDelete: 'CAN_DELETE',
  canApprove: 'CAN_APPROVE',
};

const roleFeatureFieldMap = {
  roleId: 'ROLE_ID',
  featureCode: 'FEATURE_CODE',
  isAllowed: 'IS_ALLOWED',
};

const userSelect = `
  U.ID AS "id",
  U.EMP_ID AS "empId",
  U.USERNAME AS "username",
  U.FULL_NAME AS "fullName",
  U.EMAIL AS "email",
  U.PHONE AS "phone",
  U.ROLE_CODE AS "role",
  U.ROLE_ID AS "roleId",
  R.NAME AS "roleName",
  U.PLANT AS "plant",
  U.DEPARTMENT AS "department",
  U.SHIFT AS "shift",
  U.LANGUAGE_CODE AS "language",
  U.THEME AS "theme",
  U.LAST_LOGIN_AT AS "lastLoginAt",
  U.MUST_CHANGE_PASSWORD AS "mustChangePassword",
  U.SCREEN_PERMISSIONS_JSON AS "screenPermissions",
  U.IS_ACTIVE AS "isActive",
  U.CREATED_AT AS "createdAt",
  U.UPDATED_AT AS "updatedAt"
`;

function toSafeScalar(value) {
  if (value === undefined) return undefined;
  if (value === '') return null;
  if (value === null) return null;
  if (value instanceof Date) return value;
  if (typeof value === 'boolean') return value ? 1 : 0;
  if (Array.isArray(value)) return JSON.stringify(value);
  if (typeof value === 'object') {
    return value.id ?? value.roleId ?? value.userId ?? value.code ?? value.name ?? JSON.stringify(value);
  }
  return value;
}

function cleanPayload(data = {}) {
  const payload = {};
  Object.entries(data || {}).forEach(([key, value]) => {
    const safe = toSafeScalar(value);
    if (safe !== undefined) payload[key] = safe;
  });
  return payload;
}

function normalizeFlag(value, fallback = 0) {
  return toBooleanNumber(toSafeScalar(value), fallback);
}

function normalizePermissions(value = {}) {
  if (!value) return {};
  if (typeof value === 'string') return parseJson(value, {});
  return value;
}

function normalizeUser(row) {
  if (!row) return null;
  return {
    ...row,
    name: row.fullName,
    dept: row.department,
    status: Number(row.isActive || 0) === 1 ? 'ACTIVE' : 'INACTIVE',
    isActive: Number(row.isActive || 0) === 1,
    mustChangePassword: Number(row.mustChangePassword || 0) === 1,
    screenPermissions: parseJson(row.screenPermissions, {}),
  };
}

function normalizeUserWritePayload(data = {}, mode = 'update') {
  const payload = cleanPayload(data);

  if (payload.name && !payload.fullName) payload.fullName = payload.name;
  if (payload.dept && !payload.department) payload.department = payload.dept;
  if (payload.roleCode && !payload.role) payload.role = payload.roleCode;

  delete payload.name;
  delete payload.dept;
  delete payload.password;
  delete payload.title; // no TITLE column in MES_USERS
  delete payload.status; // UI status maps to IS_ACTIVE in controller

  if (mode === 'create') {
    payload.username = payload.username || payload.empId;
    payload.isActive = normalizeFlag(payload.isActive, 1);
    payload.mustChangePassword = normalizeFlag(payload.mustChangePassword, 0);
  } else {
    ['empId', 'username', 'fullName'].forEach((key) => {
      if (payload[key] === null || payload[key] === '') delete payload[key];
    });
  }

  if (Object.prototype.hasOwnProperty.call(payload, 'isActive')) {
    payload.isActive = normalizeFlag(payload.isActive, 1);
  }

  if (Object.prototype.hasOwnProperty.call(payload, 'mustChangePassword')) {
    payload.mustChangePassword = normalizeFlag(payload.mustChangePassword, 0);
  }

  if (Object.prototype.hasOwnProperty.call(payload, 'screenPermissions')) {
    payload.screenPermissions = normalizePermissions(payload.screenPermissions);
  }

  if (Object.prototype.hasOwnProperty.call(payload, 'screenPermissionsJson')) {
    payload.screenPermissionsJson = normalizePermissions(payload.screenPermissionsJson);
  }

  return payload;
}

function normalizeRoleWritePayload(data = {}, mode = 'update') {
  const payload = cleanPayload(data);
  if (payload.label && !payload.name) payload.name = payload.label;
  if (payload.desc && !payload.description) payload.description = payload.desc;
  delete payload.label;
  delete payload.desc;
  delete payload.icon;
  delete payload.color;
  delete payload.system;

  if (payload.permissions !== undefined) payload.permissions = normalizePermissions(payload.permissions);
  if (payload.permissionsJson !== undefined) payload.permissionsJson = normalizePermissions(payload.permissionsJson);

  if (mode === 'create') payload.isActive = normalizeFlag(payload.isActive, 1);
  else if (Object.prototype.hasOwnProperty.call(payload, 'isActive')) payload.isActive = normalizeFlag(payload.isActive, 1);

  if (mode === 'update') {
    Object.keys(payload).forEach((key) => {
      if (payload[key] === undefined || payload[key] === null || payload[key] === '') delete payload[key];
    });
  }
  return payload;
}

function normalizeScreenRow(row = {}) {
  return {
    id: row.screenCode,
    screenCode: row.screenCode,
    label: row.screenName,
    screenName: row.screenName,
    moduleCode: row.moduleCode,
    mod: row.moduleCode,
    routePath: row.routePath,
    sortOrder: Number(row.sortOrder || 0),
    isActive: Number(row.isActive || 0) === 1,
  };
}

function normalizeFeatureRow(row = {}) {
  return {
    id: row.featureCode,
    featureCode: row.featureCode,
    label: row.featureName,
    featureName: row.featureName,
    screenCode: row.screenCode,
    moduleCode: row.moduleCode,
    cat: row.moduleCode || 'General',
    description: row.description,
    isActive: Number(row.isActive || 0) === 1,
  };
}

function normalizeRole(row) {
  if (!row) return null;
  const permissions = parseJson(row.permissions, {});
  return {
    ...row,
    label: row.label || row.name,
    permissions,
    icon: permissions.icon || '🎭',
    color: permissions.color || '#a78bfa',
    system: !!permissions.system,
    screens: permissions.screens || {},
    features: permissions.features || {},
    isActive: Number(row.isActive || 0) === 1,
  };
}

function permissionObjectToRows(permissions = {}, roleId) {
  if (Array.isArray(permissions)) return permissions;
  return Object.entries(permissions || {})
    .filter(([screenCode]) => screenCode !== 'ALL')
    .map(([screenCode, value]) => ({ roleId, screenCode, ...(value || {}) }));
}

function featureObjectToRows(features = {}, roleId) {
  if (Array.isArray(features)) return features;
  if (features?.ALL) return [];
  return Object.entries(features || {}).map(([featureCode, value]) => ({
    roleId,
    featureCode,
    isAllowed: typeof value === 'object' ? value.isAllowed ?? value.enabled ?? value.value : value,
  }));
}

export async function listUsers(filters = {}) {
  const where = ['NVL(U.IS_DELETED,0) = 0'];
  const binds = {};
  addEq(where, binds, 'U.ROLE_CODE', 'role', filters.role);
  addEq(where, binds, 'U.PLANT', 'plant', filters.plant);
  addEq(where, binds, 'U.DEPARTMENT', 'department', filters.department);

  if (filters.status === 'ACTIVE') where.push('NVL(U.IS_ACTIVE,0) = 1');
  if (filters.status === 'INACTIVE') where.push('NVL(U.IS_ACTIVE,0) = 0');

  addLike(where, binds, ['U.FULL_NAME', 'U.EMP_ID', 'U.USERNAME', 'U.EMAIL'], 'search', filters.search);

  const result = await pagedQuery({
    select: userSelect,
    from: `${TABLES.users} U`,
    joins: `LEFT JOIN ${TABLES.roles} R ON R.ID = U.ROLE_ID`,
    where,
    binds,
    orderBy: 'U.FULL_NAME ASC',
    page: filters.page,
    limit: filters.limit,
  });

  return { ...result, rows: result.rows.map(normalizeUser) };
}

export async function getUserById(id) {
  const row = await queryOne(
    `
    SELECT ${userSelect}
    FROM ${TABLES.users} U
    LEFT JOIN ${TABLES.roles} R ON R.ID = U.ROLE_ID
    WHERE U.ID = :id AND NVL(U.IS_DELETED,0) = 0
    FETCH FIRST 1 ROWS ONLY
    `,
    { id: toSafeScalar(id) },
  );
  return normalizeUser(row);
}

export async function getUserByEmpId(empId) {
  const row = await queryOne(
    `
    SELECT ${userSelect}
    FROM ${TABLES.users} U
    LEFT JOIN ${TABLES.roles} R ON R.ID = U.ROLE_ID
    WHERE LOWER(U.EMP_ID) = LOWER(:empId) AND NVL(U.IS_DELETED,0) = 0
    FETCH FIRST 1 ROWS ONLY
    `,
    { empId: toSafeScalar(empId) },
  );
  return normalizeUser(row);
}

export async function createUser(data, user = null) {
  return insertRow(TABLES.users, userFieldMap, normalizeUserWritePayload(data, 'create'), user);
}

export async function updateUser(id, data, user = null) {
  return updateRow(TABLES.users, userFieldMap, toSafeScalar(id), normalizeUserWritePayload(data, 'update'), user);
}

export async function deleteUser(id, user = null) {
  return softDeleteRow(TABLES.users, toSafeScalar(id), user);
}

export async function updatePermissions(id, permissions, user = null) {
  return updateRow(TABLES.users, userFieldMap, toSafeScalar(id), { screenPermissions: normalizePermissions(permissions || {}) }, user);
}

export async function listRoles() {
  const rows = await query(
    `
    SELECT
      ID AS "id",
      NAME AS "name",
      NAME AS "label",
      DESCRIPTION AS "description",
      PERMISSIONS_JSON AS "permissions",
      IS_ACTIVE AS "isActive"
    FROM ${TABLES.roles}
    WHERE NVL(IS_DELETED,0) = 0
    ORDER BY NAME
    `,
  );
  return rows.map(normalizeRole);
}

export async function getRoleById(id) {
  const row = await queryOne(
    `
    SELECT
      ID AS "id",
      NAME AS "name",
      NAME AS "label",
      DESCRIPTION AS "description",
      PERMISSIONS_JSON AS "permissions",
      IS_ACTIVE AS "isActive"
    FROM ${TABLES.roles}
    WHERE ID = :id AND NVL(IS_DELETED,0) = 0
    FETCH FIRST 1 ROWS ONLY
    `,
    { id: toSafeScalar(id) },
  );
  return normalizeRole(row);
}

export async function createRole(data, user = null) {
  return insertRow(TABLES.roles, roleFieldMap, normalizeRoleWritePayload(data, 'create'), user);
}

export async function updateRole(id, data, user = null) {
  return updateRow(TABLES.roles, roleFieldMap, toSafeScalar(id), normalizeRoleWritePayload(data, 'update'), user);
}

export async function deleteRole(id, user = null) {
  return softDeleteRow(TABLES.roles, toSafeScalar(id), user);
}

export async function listScreens() {
  const rows = await query(
    `
    SELECT
      SCREEN_CODE AS "screenCode",
      SCREEN_NAME AS "screenName",
      MODULE_CODE AS "moduleCode",
      ROUTE_PATH AS "routePath",
      SORT_ORDER AS "sortOrder",
      IS_ACTIVE AS "isActive"
    FROM ${TABLES.screens}
    WHERE NVL(IS_ACTIVE,1) = 1
    ORDER BY SORT_ORDER, SCREEN_NAME
    `,
  );
  return rows.map(normalizeScreenRow);
}

export async function listFeatures() {
  const rows = await query(
    `
    SELECT
      FEATURE_CODE AS "featureCode",
      FEATURE_NAME AS "featureName",
      SCREEN_CODE AS "screenCode",
      MODULE_CODE AS "moduleCode",
      DESCRIPTION AS "description",
      IS_ACTIVE AS "isActive"
    FROM ${TABLES.features}
    WHERE NVL(IS_ACTIVE,1) = 1
    ORDER BY MODULE_CODE, FEATURE_NAME
    `,
  );
  return rows.map(normalizeFeatureRow);
}

export async function listRoleScreenPermissions(roleId) {
  return query(
    `
    SELECT
      ID AS "id",
      ROLE_ID AS "roleId",
      SCREEN_CODE AS "screenCode",
      CAN_VIEW AS "canView",
      CAN_CREATE AS "canCreate",
      CAN_UPDATE AS "canUpdate",
      CAN_DELETE AS "canDelete",
      CAN_APPROVE AS "canApprove"
    FROM ${TABLES.roleScreenPermissions}
    WHERE ROLE_ID = :roleId
    ORDER BY SCREEN_CODE
    `,
    { roleId: toSafeScalar(roleId) },
  );
}

export async function replaceRoleScreenPermissions(roleId, permissions = []) {
  const safeRoleId = toSafeScalar(roleId);
  await executeCommit(`DELETE FROM ${TABLES.roleScreenPermissions} WHERE ROLE_ID = :roleId`, { roleId: safeRoleId });
  const rows = permissionObjectToRows(permissions, safeRoleId);
  const ids = [];
  for (const row of rows.filter((item) => item?.screenCode)) {
    ids.push(await insertRow(TABLES.roleScreenPermissions, roleScreenFieldMap, {
      roleId: safeRoleId,
      screenCode: row.screenCode,
      canView: normalizeFlag(row.canView ?? row.view),
      canCreate: normalizeFlag(row.canCreate ?? row.create),
      canUpdate: normalizeFlag(row.canUpdate ?? row.update ?? row.edit),
      canDelete: normalizeFlag(row.canDelete ?? row.delete),
      canApprove: normalizeFlag(row.canApprove ?? row.approve ?? row.export),
    }));
  }
  return ids;
}

export async function listRoleFeaturePermissions(roleId) {
  return query(
    `
    SELECT
      ID AS "id",
      ROLE_ID AS "roleId",
      FEATURE_CODE AS "featureCode",
      IS_ALLOWED AS "isAllowed"
    FROM ${TABLES.roleFeaturePermissions}
    WHERE ROLE_ID = :roleId
    ORDER BY FEATURE_CODE
    `,
    { roleId: toSafeScalar(roleId) },
  );
}

export async function replaceRoleFeaturePermissions(roleId, permissions = []) {
  const safeRoleId = toSafeScalar(roleId);
  await executeCommit(`DELETE FROM ${TABLES.roleFeaturePermissions} WHERE ROLE_ID = :roleId`, { roleId: safeRoleId });
  const rows = featureObjectToRows(permissions, safeRoleId);
  const ids = [];
  for (const row of rows.filter((item) => item?.featureCode)) {
    ids.push(await insertRow(TABLES.roleFeaturePermissions, roleFeatureFieldMap, {
      roleId: safeRoleId,
      featureCode: row.featureCode,
      isAllowed: normalizeFlag(row.isAllowed ?? row.isEnabled ?? row.enabled ?? row.value, 0),
    }));
  }
  return ids;
}

export async function saveRoleAccess(roleId, { screens = null, features = null, permissions = null } = {}, user = null) {
  const safeRoleId = toSafeScalar(roleId);
  const role = await getRoleById(safeRoleId);
  if (!role) return null;

  const nextPermissions = {
    ...(role.permissions || {}),
    ...(permissions || {}),
  };

  if (screens !== null) {
    nextPermissions.screens = screens;
    await replaceRoleScreenPermissions(safeRoleId, screens);
  }

  if (features !== null) {
    nextPermissions.features = features;
    await replaceRoleFeaturePermissions(safeRoleId, features);
  }

  await updateRole(safeRoleId, { permissions: nextPermissions }, user);
  return getRoleById(safeRoleId);
}

export async function assignUserRole({ userId, roleId, isPrimary = 0, assignedById = null }) {
  const safeUserId = toSafeScalar(userId);
  const safeRoleId = toSafeScalar(roleId);
  const primaryFlag = normalizeFlag(isPrimary, 0);

  if (primaryFlag) {
    await executeCommit(`UPDATE ${TABLES.userRoles} SET IS_PRIMARY = 0 WHERE USER_ID = :userId`, { userId: safeUserId });
  }

  const existing = await queryOne(
    `SELECT ID AS "id" FROM ${TABLES.userRoles} WHERE USER_ID = :userId AND ROLE_ID = :roleId FETCH FIRST 1 ROWS ONLY`,
    { userId: safeUserId, roleId: safeRoleId },
  );

  if (existing?.id) {
    await executeCommit(
      `UPDATE ${TABLES.userRoles} SET IS_PRIMARY = :isPrimary, UPDATED_AT = SYSTIMESTAMP WHERE ID = :id`,
      { id: existing.id, isPrimary: primaryFlag },
    );
    return existing.id;
  }

  return insertRow(TABLES.userRoles, userRoleFieldMap, {
    userId: safeUserId,
    roleId: safeRoleId,
    isPrimary: primaryFlag,
    assignedById: toSafeScalar(assignedById),
    assignedAt: new Date(),
  });
}

export async function replaceUserRoles(userId, roles = [], assignedById = null) {
  const safeUserId = toSafeScalar(userId);
  await executeCommit(`DELETE FROM ${TABLES.userRoles} WHERE USER_ID = :userId`, { userId: safeUserId });

  const normalized = (Array.isArray(roles) ? roles : []).filter((role) => role?.roleId || role?.id);
  const ids = [];
  for (const [index, role] of normalized.entries()) {
    ids.push(await insertRow(TABLES.userRoles, userRoleFieldMap, {
      userId: safeUserId,
      roleId: toSafeScalar(role.roleId || role.id),
      isPrimary: normalizeFlag(role.isPrimary ?? (index === 0), index === 0 ? 1 : 0),
      assignedById: toSafeScalar(assignedById),
      assignedAt: new Date(),
    }));
  }
  return ids;
}

export async function listUserRoles(userId) {
  return query(
    `
    SELECT
      UR.ID AS "id",
      UR.USER_ID AS "userId",
      UR.ROLE_ID AS "roleId",
      R.NAME AS "roleName",
      UR.IS_PRIMARY AS "isPrimary",
      UR.ASSIGNED_AT AS "assignedAt"
    FROM ${TABLES.userRoles} UR
    JOIN ${TABLES.roles} R ON R.ID = UR.ROLE_ID
    WHERE UR.USER_ID = :userId
    ORDER BY UR.IS_PRIMARY DESC, R.NAME ASC
    `,
    { userId: toSafeScalar(userId) },
  );
}

export async function listUserScreenOverrides(userId) {
  return query(
    `
    SELECT
      ID AS "id",
      USER_ID AS "userId",
      SCREEN_CODE AS "screenCode",
      CAN_VIEW AS "canView",
      CAN_CREATE AS "canCreate",
      CAN_UPDATE AS "canUpdate",
      CAN_DELETE AS "canDelete",
      CAN_APPROVE AS "canApprove",
      OVERRIDE_REASON AS "overrideReason"
    FROM ${TABLES.userScreenOverrides}
    WHERE USER_ID = :userId
    ORDER BY SCREEN_CODE
    `,
    { userId: toSafeScalar(userId) },
  );
}

export async function updateUserScreenOverrides(userId, overrides = []) {
  const safeUserId = toSafeScalar(userId);
  await executeCommit(`DELETE FROM ${TABLES.userScreenOverrides} WHERE USER_ID = :userId`, { userId: safeUserId });

  const rows = Array.isArray(overrides)
    ? overrides
    : Object.entries(overrides || {}).map(([screenCode, value]) => ({ screenCode, ...(value || {}) }));

  const ids = [];
  for (const row of rows.filter((item) => item?.screenCode)) {
    ids.push(await insertRow(TABLES.userScreenOverrides, screenOverrideFieldMap, {
      userId: safeUserId,
      screenCode: row.screenCode,
      canView: normalizeFlag(row.canView ?? row.view),
      canCreate: normalizeFlag(row.canCreate ?? row.create),
      canUpdate: normalizeFlag(row.canUpdate ?? row.update ?? row.edit),
      canDelete: normalizeFlag(row.canDelete ?? row.delete),
      canApprove: normalizeFlag(row.canApprove ?? row.approve ?? row.export),
      overrideReason: row.overrideReason || row.reason || null,
    }));
  }
  return ids;
}

export async function listUserFeatureOverrides(userId) {
  return query(
    `
    SELECT
      ID AS "id",
      USER_ID AS "userId",
      FEATURE_CODE AS "featureCode",
      IS_ALLOWED AS "isAllowed",
      IS_ALLOWED AS "isEnabled",
      OVERRIDE_REASON AS "overrideReason"
    FROM ${TABLES.userFeatureOverrides}
    WHERE USER_ID = :userId
    ORDER BY FEATURE_CODE
    `,
    { userId: toSafeScalar(userId) },
  );
}

export async function updateUserFeatureOverrides(userId, overrides = []) {
  const safeUserId = toSafeScalar(userId);
  await executeCommit(`DELETE FROM ${TABLES.userFeatureOverrides} WHERE USER_ID = :userId`, { userId: safeUserId });

  const rows = Array.isArray(overrides)
    ? overrides
    : Object.entries(overrides || {}).map(([featureCode, value]) => (
      typeof value === 'object' && value !== null ? { featureCode, ...value } : { featureCode, isAllowed: value }
    ));

  const ids = [];
  for (const row of rows.filter((item) => item?.featureCode)) {
    ids.push(await insertRow(TABLES.userFeatureOverrides, featureOverrideFieldMap, {
      userId: safeUserId,
      featureCode: row.featureCode,
      isAllowed: normalizeFlag(row.isAllowed ?? row.isEnabled ?? row.enabled ?? row.value, 0),
      overrideReason: row.overrideReason || row.reason || null,
    }));
  }
  return ids;
}

export async function listUserScope(userId) {
  return query(
    `
    SELECT
      ID AS "id",
      USER_ID AS "userId",
      SCOPE_TYPE AS "scopeType",
      SCOPE_CODE AS "scopeCode",
      SCOPE_NAME AS "scopeName",
      IS_ALLOWED AS "isAllowed"
    FROM ${TABLES.userScope}
    WHERE USER_ID = :userId
    ORDER BY SCOPE_TYPE, SCOPE_CODE
    `,
    { userId: toSafeScalar(userId) },
  );
}

function scopeObjectToRows(scope) {
  if (Array.isArray(scope)) return scope;
  const rows = [];
  for (const [scopeType, values] of Object.entries(scope || {})) {
    const type = String(scopeType).replace(/s$/, '').toUpperCase();
    for (const value of Array.isArray(values) ? values : []) {
      if (typeof value === 'object' && value !== null) {
        rows.push({
          scopeType: value.scopeType || type,
          scopeCode: value.scopeCode || value.code || value.id,
          scopeName: value.scopeName || value.name || value.label || value.code || value.id,
          isAllowed: value.isAllowed ?? value.allowed ?? true,
        });
      } else {
        rows.push({ scopeType: type, scopeCode: value, scopeName: value, isAllowed: true });
      }
    }
  }
  return rows;
}

export async function updateUserScope(userId, scope = []) {
  const safeUserId = toSafeScalar(userId);
  await executeCommit(`DELETE FROM ${TABLES.userScope} WHERE USER_ID = :userId`, { userId: safeUserId });

  const ids = [];
  for (const row of scopeObjectToRows(scope).filter((item) => item?.scopeCode)) {
    ids.push(await insertRow(TABLES.userScope, userScopeFieldMap, {
      userId: safeUserId,
      scopeType: toSafeScalar(row.scopeType || 'CUSTOM'),
      scopeCode: toSafeScalar(row.scopeCode),
      scopeName: toSafeScalar(row.scopeName || row.scopeCode),
      isAllowed: normalizeFlag(row.isAllowed ?? row.allowed, 1),
    }));
  }
  return ids;
}

export { listUserActivity };

export default {
  listUsers,
  getUserById,
  getUserByEmpId,
  createUser,
  updateUser,
  deleteUser,
  updatePermissions,
  listRoles,
  getRoleById,
  createRole,
  updateRole,
  deleteRole,
  listScreens,
  listFeatures,
  listRoleScreenPermissions,
  replaceRoleScreenPermissions,
  listRoleFeaturePermissions,
  replaceRoleFeaturePermissions,
  saveRoleAccess,
  assignUserRole,
  replaceUserRoles,
  listUserRoles,
  listUserScreenOverrides,
  updateUserScreenOverrides,
  listUserFeatureOverrides,
  updateUserFeatureOverrides,
  listUserScope,
  updateUserScope,
  listUserActivity,
};
