import {
  TABLES,
  query,
  queryOne,
  pagedQuery,
  addEq,
  addLike,
  insertRow,
  updateRow,
  parseJson,
  toNumber,
} from './base.model.js';
import { executeCommit } from '../config/oracle.js';

const boxFieldMap = {
  barcode: 'BARCODE',
  woId: 'WO_ID',
  machineId: 'MACHINE_ID',
  packedById: 'PACKED_BY_ID',
  quantity: 'QUANTITY',
  weight: 'WEIGHT',
  status: 'STATUS',
  qcStatus: 'QC_STATUS',
  qcNotes: 'QC_NOTES',
  qcChecks: 'QC_CHECKS_JSON',
  palletId: 'PALLET_ID',
  packedAt: 'PACKED_AT',
  labelPrinted: 'LABEL_PRINTED',
};

const palletFieldMap = {
  palletNumber: 'PALLET_NUMBER',
  woId: 'WO_ID',
  createdById: 'CREATED_BY_ID',
  boxCount: 'BOX_COUNT',
  totalQty: 'TOTAL_QTY',
  totalWeight: 'TOTAL_WEIGHT',
  status: 'STATUS',
  labelPrinted: 'LABEL_PRINTED',
};

function normalizeBox(row) {
  if (!row) return null;
  return {
    ...row,
    labelPrinted: Number(row.labelPrinted || 0) === 1,
    qcChecks: parseJson(row.qcChecks, {}),
  };
}

const BOX_APPROVED_QC = new Set(['appr', 'approved', 'pass', 'passed']);

export async function getLatestBoxPrint({ woId, machineId = null }) {
  const machineClause = machineId ? 'AND B.MACHINE_ID = :machineId' : '';
  return queryOne(
    `
    SELECT H.PRINTED_AT AS "printedAt"
    FROM ${TABLES.labelPrintHistory} H
    JOIN ${TABLES.boxes} B ON B.ID = H.REF_ID
    WHERE H.LABEL_TYPE = 'box'
      AND H.REF_TABLE = :refTable
      AND B.WO_ID = :woId
      ${machineClause}
    ORDER BY H.PRINTED_AT DESC
    FETCH FIRST 1 ROWS ONLY
    `,
    { refTable: TABLES.boxes, woId, ...(machineId ? { machineId } : {}) },
  );
}

export async function nextBoxBarcode(date = new Date()) {
  const dd = String(date.getDate()).padStart(2, '0');
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const yy = String(date.getFullYear()).slice(-2);
  const prefix = `P${dd}${mm}${yy}-`;

  const row = await queryOne(
    `
    SELECT NVL(MAX(TO_NUMBER(REGEXP_SUBSTR(BARCODE, '[0-9]+$'))), 0) + 1 AS "nextNo"
    FROM ${TABLES.boxes}
    WHERE BARCODE LIKE :prefixLike
      AND NVL(IS_DELETED,0) = 0
    `,
    { prefixLike: `${prefix}%` },
  );

  return `${prefix}${String(Number(row?.nextNo || 1)).padStart(4, '0')}`;
}

export async function listBoxes(filters = {}) {
  const where = ['NVL(B.IS_DELETED,0) = 0'];
  const binds = {};
  const woFilter = filters.woNumber || filters.workOrderNumber || filters.woId;
  const machineFilter = filters.machineCode || filters.machineId;
  addEq(where, binds, 'B.WO_ID', 'woId', woFilter);
  addEq(where, binds, 'B.MACHINE_ID', 'machineId', machineFilter);
  addEq(where, binds, 'B.STATUS', 'status', filters.status);
  addEq(where, binds, 'B.QC_STATUS', 'qcStatus', filters.qcStatus);
  addEq(where, binds, 'B.PALLET_ID', 'palletId', filters.palletId);
  addLike(where, binds, ['B.BARCODE', 'WO.WO_NUMBER', 'M.CODE'], 'search', filters.search);

  const result = await pagedQuery({
    select: `
      B.ID AS "id", B.BARCODE AS "barcode", B.WO_ID AS "woId", WO.WO_NUMBER AS "woNumber",
      ROW_NUMBER() OVER (PARTITION BY B.WO_ID ORDER BY B.CREATED_AT ASC, B.ID ASC) AS "boxNumber",
      WO.PRODUCT AS "product", WO.PRODUCT_CODE AS "productCode",
      B.MACHINE_ID AS "machineId", M.CODE AS "machineCode", M.NAME AS "machineName",
      B.PACKED_BY_ID AS "packedById", U.FULL_NAME AS "packedByName",
      B.QUANTITY AS "quantity", B.WEIGHT AS "weight", B.STATUS AS "status", B.QC_STATUS AS "qcStatus",
      B.QC_NOTES AS "qcNotes", B.QC_CHECKS_JSON AS "qcChecks", B.PALLET_ID AS "palletId",
      P.PALLET_NUMBER AS "palletNumber", B.PACKED_AT AS "packedAt", B.LABEL_PRINTED AS "labelPrinted",
      B.CREATED_AT AS "createdAt", B.UPDATED_AT AS "updatedAt"
    `,
    from: `${TABLES.boxes} B`,
    joins: `
      LEFT JOIN ${TABLES.workOrders} WO ON WO.WO_NUMBER = B.WO_ID
      LEFT JOIN ${TABLES.machines} M ON M.CODE = B.MACHINE_ID
      LEFT JOIN ${TABLES.users} U ON U.ID = B.PACKED_BY_ID
      LEFT JOIN ${TABLES.pallets} P ON P.ID = B.PALLET_ID
    `,
    where,
    binds,
    orderBy: 'B.CREATED_AT DESC',
    page: filters.page,
    limit: filters.limit,
  });
  return { ...result, rows: result.rows.map(normalizeBox) };
}

export async function getBoxById(id) {
  const row = await queryOne(
    `
    SELECT
      B.ID AS "id", B.BARCODE AS "barcode", B.WO_ID AS "woId", WO.WO_NUMBER AS "woNumber",
      ROW_NUMBER() OVER (PARTITION BY B.WO_ID ORDER BY B.CREATED_AT ASC, B.ID ASC) AS "boxNumber",
      WO.PRODUCT AS "product", WO.PRODUCT_CODE AS "productCode",
      B.MACHINE_ID AS "machineId", M.CODE AS "machineCode", B.PACKED_BY_ID AS "packedById",
      B.QUANTITY AS "quantity", B.WEIGHT AS "weight", B.STATUS AS "status", B.QC_STATUS AS "qcStatus",
      B.QC_NOTES AS "qcNotes", B.QC_CHECKS_JSON AS "qcChecks", B.PALLET_ID AS "palletId",
      B.PACKED_AT AS "packedAt", B.LABEL_PRINTED AS "labelPrinted", B.CREATED_AT AS "createdAt", B.UPDATED_AT AS "updatedAt"
    FROM ${TABLES.boxes} B
    LEFT JOIN ${TABLES.workOrders} WO ON WO.WO_NUMBER = B.WO_ID
    LEFT JOIN ${TABLES.machines} M ON M.CODE = B.MACHINE_ID
    WHERE B.ID = :id AND NVL(B.IS_DELETED,0) = 0
    FETCH FIRST 1 ROWS ONLY
    `,
    { id },
  );
  return normalizeBox(row);
}


async function assertBoxWithinPlannedQuantity(woId, quantity = 1) {
  if (!woId) return;
  const wo = await queryOne(
    `
    SELECT WO_NUMBER AS "woNumber", PLANNED_QTY AS "plannedQty", PRODUCED_QTY AS "producedQty"
    FROM ${TABLES.workOrders}
    WHERE (WO_NUMBER = :woId OR ID = :woId)
      AND NVL(IS_DELETED,0) = 0
    FETCH FIRST 1 ROWS ONLY
    `,
    { woId },
  );
  if (!wo) return;
  const planned = Number(wo.plannedQty || 0);
  if (!planned) return;
  const produced = Number(wo.producedQty || 0);
  const nextQty = Number(quantity || 1);
  if (produced + nextQty > planned) {
    throw new Error(`Planned quantity exceeded for work order ${wo.woNumber}. Planned ${planned}, already produced ${produced}.`);
  }
}

export async function createBox(data, user = null) {
  await assertBoxWithinPlannedQuantity(data.woId, data.quantity);
  return insertRow(TABLES.boxes, boxFieldMap, {
    ...data,
    status: data.status || 'open',
    qcStatus: data.qcStatus || 'pending',
    packedById: data.packedById || user?.id,
    packedAt: data.packedAt || new Date(),
    labelPrinted: data.labelPrinted ?? 0,
  }, user);
}

export async function updateBox(id, data, user = null) {
  return updateRow(TABLES.boxes, boxFieldMap, id, data, user);
}

export async function listPallets(filters = {}) {
  const where = ['NVL(P.IS_DELETED,0) = 0'];
  const binds = {};
  const woFilter = filters.woNumber || filters.workOrderNumber || filters.woId;
  addEq(where, binds, 'P.WO_ID', 'woId', woFilter);
  addEq(where, binds, 'P.STATUS', 'status', filters.status);
  addLike(where, binds, ['P.PALLET_NUMBER', 'WO.WO_NUMBER'], 'search', filters.search);

  return pagedQuery({
    select: `
      P.ID AS "id", P.PALLET_NUMBER AS "palletNumber", P.WO_ID AS "woId", WO.WO_NUMBER AS "woNumber",
      P.CREATED_BY_ID AS "createdById", U.FULL_NAME AS "createdByName",
      P.BOX_COUNT AS "boxCount", P.TOTAL_QTY AS "totalQty", P.TOTAL_WEIGHT AS "totalWeight",
      P.STATUS AS "status", P.LABEL_PRINTED AS "labelPrinted", P.CREATED_AT AS "createdAt", P.UPDATED_AT AS "updatedAt"
    `,
    from: `${TABLES.pallets} P`,
    joins: `
      LEFT JOIN ${TABLES.workOrders} WO ON WO.WO_NUMBER = P.WO_ID
      LEFT JOIN ${TABLES.users} U ON U.ID = P.CREATED_BY_ID
    `,
    where,
    binds,
    orderBy: 'P.CREATED_AT DESC',
    page: filters.page,
    limit: filters.limit,
  });
}

export async function getPalletById(id) {
  return queryOne(
    `
    SELECT
      P.ID AS "id", P.PALLET_NUMBER AS "palletNumber", P.WO_ID AS "woId", WO.WO_NUMBER AS "woNumber",
      P.CREATED_BY_ID AS "createdById", P.BOX_COUNT AS "boxCount", P.TOTAL_QTY AS "totalQty",
      P.TOTAL_WEIGHT AS "totalWeight", P.STATUS AS "status", P.LABEL_PRINTED AS "labelPrinted",
      P.CREATED_AT AS "createdAt", P.UPDATED_AT AS "updatedAt"
    FROM ${TABLES.pallets} P
    LEFT JOIN ${TABLES.workOrders} WO ON WO.WO_NUMBER = P.WO_ID
    WHERE P.ID = :id AND NVL(P.IS_DELETED,0) = 0
    FETCH FIRST 1 ROWS ONLY
    `,
    { id },
  );
}

export async function createPallet(data, user = null) {
  return insertRow(TABLES.pallets, palletFieldMap, {
    ...data,
    createdById: data.createdById || user?.id,
    boxCount: data.boxCount || 0,
    totalQty: data.totalQty || 0,
    totalWeight: data.totalWeight || 0,
    status: data.status || 'building',
    labelPrinted: data.labelPrinted ?? 0,
  }, user);
}

export async function addBoxToPallet({ palletId, boxId, slotNo = null, addedById = null }, user = null) {
  const pallet = await getPalletById(palletId);
  if (!pallet) throw new Error('Pallet not found');
  if (String(pallet.status || '').toLowerCase() === 'complete') throw new Error('Cannot add boxes to a completed pallet');

  const box = await getBoxById(boxId);
  if (!box) throw new Error('Box not found');

  if (box.palletId) throw new Error('Box is already assigned to a pallet');
  if (['palletized', 'shipped'].includes(String(box.status || '').toLowerCase())) {
    throw new Error('Box is already palletized or shipped');
  }
  if (!BOX_APPROVED_QC.has(String(box.qcStatus || '').toLowerCase())) {
    throw new Error('Only QC approved boxes can be added to a pallet');
  }

  const countRow = await queryOne(
    `
    SELECT COUNT(1) AS "count"
    FROM ${TABLES.palletBoxSlots}
    WHERE PALLET_ID = :palletId
      AND STATUS = 'active'
    `,
    { palletId },
  );
  if (Number(countRow?.count || 0) >= 50) throw new Error('Maximum 50 boxes allowed per pallet');

  if (slotNo) {
    const slotRow = await queryOne(
      `
      SELECT ID AS "id"
      FROM ${TABLES.palletBoxSlots}
      WHERE PALLET_ID = :palletId
        AND SLOT_NO = :slotNo
        AND STATUS = 'active'
      FETCH FIRST 1 ROWS ONLY
      `,
      { palletId, slotNo },
    );
    if (slotRow) throw new Error(`Pallet slot ${slotNo} is already occupied`);
  }

  await updateRow(TABLES.boxes, boxFieldMap, boxId, { palletId, status: 'palletized' }, user);

  await insertRow(TABLES.palletBoxSlots, {
    palletId: 'PALLET_ID',
    boxId: 'BOX_ID',
    slotNo: 'SLOT_NO',
    addedById: 'ADDED_BY_ID',
    addedAt: 'ADDED_AT',
    status: 'STATUS',
  }, {
    palletId,
    boxId,
    slotNo,
    addedById: addedById || user?.id,
    addedAt: new Date(),
    status: 'active',
  }, user);

  await executeCommit(
    `
    UPDATE ${TABLES.pallets}
    SET BOX_COUNT = NVL(BOX_COUNT,0) + 1,
        TOTAL_QTY = NVL(TOTAL_QTY,0) + :qty,
        TOTAL_WEIGHT = NVL(TOTAL_WEIGHT,0) + :weight,
        UPDATED_AT = SYSTIMESTAMP
    WHERE ID = :palletId
    `,
    { palletId, qty: toNumber(box.quantity, 0), weight: toNumber(box.weight, 0) },
  );

  await executeCommit(
    `
    UPDATE ${TABLES.stockRecords} SR
    SET SR.PALLET_ID = :palletId,
        SR.PALLET_CODE = (SELECT P.PALLET_NUMBER FROM ${TABLES.pallets} P WHERE P.ID = :palletId),
        SR.STATUS = 'in_stock',
        SR.UPDATED_AT = SYSTIMESTAMP
    WHERE SR.WO_ID = :woId
      AND SR.BOX_NO = :boxNo
      AND NVL(SR.IS_DELETED,0) = 0
    `,
    { palletId, woId: box.woId, boxNo: box.barcode },
  );

  return getPalletById(palletId);
}

export async function removeBoxFromPallet({ palletId, boxId, removedById = null }, user = null) {
  const pallet = await getPalletById(palletId);
  if (!pallet) throw new Error('Pallet not found');
  if (String(pallet.status || '').toLowerCase() === 'complete') {
    throw new Error('Cannot remove boxes from a completed pallet');
  }

  const box = await getBoxById(boxId);
  if (!box) throw new Error('Box not found');

  const slot = await queryOne(
    `
    SELECT ID AS "id"
    FROM ${TABLES.palletBoxSlots}
    WHERE PALLET_ID = :palletId
      AND BOX_ID = :boxId
      AND STATUS = 'active'
    FETCH FIRST 1 ROWS ONLY
    `,
    { palletId, boxId },
  );

  if (!slot) throw new Error('Box is not assigned to this pallet');

  await executeCommit(
    `
    UPDATE ${TABLES.palletBoxSlots}
    SET STATUS = 'removed',
        REMOVED_BY_ID = :removedById,
        REMOVED_AT = SYSTIMESTAMP,
        UPDATED_BY = :updatedBy,
        UPDATED_AT = SYSTIMESTAMP
    WHERE ID = :slotId
    `,
    {
      slotId: slot.id,
      removedById: removedById || user?.id || null,
      updatedBy: user?.username || user?.empId || user?.id || 'system',
    },
  );

  await updateRow(TABLES.boxes, boxFieldMap, boxId, { palletId: null, status: 'open' }, user);

  await executeCommit(
    `
    UPDATE ${TABLES.pallets}
    SET BOX_COUNT = GREATEST(NVL(BOX_COUNT,0) - 1, 0),
        TOTAL_QTY = GREATEST(NVL(TOTAL_QTY,0) - :qty, 0),
        TOTAL_WEIGHT = GREATEST(NVL(TOTAL_WEIGHT,0) - :weight, 0),
        UPDATED_AT = SYSTIMESTAMP
    WHERE ID = :palletId
    `,
    { palletId, qty: toNumber(box.quantity, 0), weight: toNumber(box.weight, 0) },
  );

  await executeCommit(
    `
    UPDATE ${TABLES.stockRecords}
    SET PALLET_ID = NULL,
        PALLET_CODE = NULL,
        UPDATED_AT = SYSTIMESTAMP
    WHERE PALLET_ID = :palletId
      AND WO_ID = :woId
      AND BOX_NO = :boxNo
      AND NVL(IS_DELETED,0) = 0
    `,
    { palletId, woId: box.woId, boxNo: box.barcode },
  );

  return getPalletById(palletId);
}

export async function listPalletBoxes(palletId) {
  return query(
    `
    SELECT
      PBS.ID AS "id", PBS.PALLET_ID AS "palletId", PBS.BOX_ID AS "boxId", B.BARCODE AS "barcode",
      PBS.SLOT_NO AS "slotNo", PBS.STATUS AS "status", PBS.ADDED_AT AS "addedAt",
      B.QUANTITY AS "quantity", B.WEIGHT AS "weight", B.QC_STATUS AS "qcStatus"
    FROM ${TABLES.palletBoxSlots} PBS
    JOIN ${TABLES.boxes} B ON B.ID = PBS.BOX_ID
    WHERE PBS.PALLET_ID = :palletId AND PBS.STATUS = 'active'
    ORDER BY PBS.SLOT_NO NULLS LAST, PBS.ADDED_AT ASC
    `,
    { palletId },
  );
}

export async function finalizePallet(id, user = null) {
  await updateRow(TABLES.pallets, palletFieldMap, id, { status: 'complete' }, user);
  return getPalletById(id);
}

export async function createLabelPrintJob(data, user = null) {
  return insertRow(TABLES.labelPrintJobs, {
    templateId: 'TEMPLATE_ID',
    labelType: 'LABEL_TYPE',
    refTable: 'REF_TABLE',
    refId: 'REF_ID',
    printerName: 'PRINTER_NAME',
    printQty: 'PRINT_QTY',
    status: 'STATUS',
    errorMessage: 'ERROR_MESSAGE',
    requestedById: 'REQUESTED_BY_ID',
    requestedAt: 'REQUESTED_AT',
    printedAt: 'PRINTED_AT',
  }, {
    ...data,
    status: data.status || 'queued',
    requestedById: data.requestedById || user?.id,
    requestedAt: data.requestedAt || new Date(),
  }, user);
}

export async function markBoxLabelPrinted({ boxId, templateId = null, printerName = null, payload = null }, user = null) {
  const box = await getBoxById(boxId);
  if (!box) throw new Error('Box not found');

  const jobId = await createLabelPrintJob({
    templateId,
    labelType: 'box',
    refTable: TABLES.boxes,
    refId: boxId,
    printerName,
    printQty: 1,
    status: 'printed',
    printedAt: new Date(),
  }, user);

  await insertRow(TABLES.labelPrintHistory, {
    printJobId: 'PRINT_JOB_ID',
    labelType: 'LABEL_TYPE',
    refTable: 'REF_TABLE',
    refId: 'REF_ID',
    templateId: 'TEMPLATE_ID',
    printerName: 'PRINTER_NAME',
    printedById: 'PRINTED_BY_ID',
    printedAt: 'PRINTED_AT',
  }, {
    printJobId: jobId,
    labelType: 'box',
    refTable: TABLES.boxes,
    refId: boxId,
    templateId,
    printerName,
    printedById: user?.id,
    printedAt: new Date(),
  }, user);

  await updateRow(TABLES.boxes, boxFieldMap, boxId, { labelPrinted: 1 }, user);
  return { ...(await getBoxById(boxId)), printJobId: jobId };
}

export async function markPalletLabelPrinted({ palletId, templateId = null, printerName = null, payload = null }, user = null) {
  const jobId = await createLabelPrintJob({
    templateId,
    labelType: 'pallet',
    refTable: TABLES.pallets,
    refId: palletId,
    printerName,
    printQty: 1,
    status: 'printed',
    printedAt: new Date(),
  }, user);

  await insertRow(TABLES.labelPrintHistory, {
    printJobId: 'PRINT_JOB_ID',
    labelType: 'LABEL_TYPE',
    refTable: 'REF_TABLE',
    refId: 'REF_ID',
    templateId: 'TEMPLATE_ID',
    printerName: 'PRINTER_NAME',
    printedById: 'PRINTED_BY_ID',
    printedAt: 'PRINTED_AT',
  }, {
    printJobId: jobId,
    labelType: 'pallet',
    refTable: TABLES.pallets,
    refId: palletId,
    templateId,
    printerName,
    printedById: user?.id,
    printedAt: new Date(),
  }, user);

  await updateRow(TABLES.pallets, palletFieldMap, palletId, { labelPrinted: 1 }, user);
  return getPalletById(palletId);
}



export async function bulkAddBoxesToPallet({ palletId, boxes = [] }, user = null) {
  const safeBoxes = Array.isArray(boxes) ? boxes : [];
  const added = [];
  for (let index = 0; index < safeBoxes.length; index += 1) {
    const item = safeBoxes[index];
    const boxId = item?.boxId || item?.id || item;
    if (!boxId) continue;
    const pallet = await addBoxToPallet({
      palletId,
      boxId,
      slotNo: item?.slotNo || item?.slot || index + 1,
      addedById: user?.id,
    }, user);
    added.push({ boxId, pallet });
  }
  return { pallet: await getPalletById(palletId), addedCount: added.length, added };
}

export async function clearPalletBoxes(palletId, user = null) {
  const boxes = await listPalletBoxes(palletId);
  for (const box of boxes) {
    await removeBoxFromPallet({ palletId, boxId: box.boxId, removedById: user?.id }, user);
  }
  return { pallet: await getPalletById(palletId), removedCount: boxes.length };
}

export async function getAvailableBoxes(filters = {}) {
  return listBoxes({
    ...filters,
    qcStatus: filters.qcStatus || 'appr',
    status: filters.status || 'open',
    limit: filters.limit || 1000,
  });
}

export async function listPalletHistory(palletId, filters = {}) {
  const where = ['PBS.PALLET_ID = :palletId'];
  const binds = { palletId };
  addEq(where, binds, 'PBS.STATUS', 'status', filters.status);
  return query(
    `
    SELECT
      PBS.ID AS "id", PBS.PALLET_ID AS "palletId", P.PALLET_NUMBER AS "palletNumber",
      PBS.BOX_ID AS "boxId", B.BARCODE AS "barcode", PBS.SLOT_NO AS "slotNo",
      PBS.STATUS AS "status", PBS.ADDED_BY_ID AS "addedById", AU.FULL_NAME AS "addedByName",
      PBS.ADDED_AT AS "addedAt", PBS.REMOVED_BY_ID AS "removedById", RU.FULL_NAME AS "removedByName",
      PBS.REMOVED_AT AS "removedAt", PBS.CREATED_AT AS "createdAt", PBS.UPDATED_AT AS "updatedAt"
    FROM ${TABLES.palletBoxSlots} PBS
    LEFT JOIN ${TABLES.pallets} P ON P.ID = PBS.PALLET_ID
    LEFT JOIN ${TABLES.boxes} B ON B.ID = PBS.BOX_ID
    LEFT JOIN ${TABLES.users} AU ON AU.ID = PBS.ADDED_BY_ID
    LEFT JOIN ${TABLES.users} RU ON RU.ID = PBS.REMOVED_BY_ID
    WHERE ${where.join(' AND ')}
    ORDER BY PBS.CREATED_AT DESC, PBS.ADDED_AT DESC NULLS LAST
    `,
    binds,
  );
}

export async function listLabelPrintHistory(filters = {}) {
  const where = ['1=1'];
  const binds = {};
  addEq(where, binds, 'H.LABEL_TYPE', 'labelType', filters.labelType);
  addEq(where, binds, 'H.REF_ID', 'refId', filters.refId);
  return pagedQuery({
    select: `
      H.ID AS "id", H.PRINT_JOB_ID AS "printJobId", H.LABEL_TYPE AS "labelType",
      H.REF_TABLE AS "refTable", H.REF_ID AS "refId", H.TEMPLATE_ID AS "templateId",
      T.TEMPLATE_CODE AS "templateCode", T.TEMPLATE_NAME AS "templateName",
      H.PRINTER_NAME AS "printerName", H.PRINTED_BY_ID AS "printedById",
      U.FULL_NAME AS "printedByName", H.PRINTED_AT AS "printedAt",
      H.CREATED_AT AS "createdAt"
    `,
    from: `${TABLES.labelPrintHistory} H`,
    joins: `
      LEFT JOIN ${TABLES.labelTemplates} T ON T.ID = H.TEMPLATE_ID
      LEFT JOIN ${TABLES.users} U ON U.ID = H.PRINTED_BY_ID
    `,
    where,
    binds,
    orderBy: 'H.PRINTED_AT DESC NULLS LAST, H.CREATED_AT DESC',
    page: filters.page,
    limit: filters.limit || 100,
  });
}

export async function getLabelPrintHistoryById(id) {
  return queryOne(
    `
    SELECT
      H.ID AS "id", H.PRINT_JOB_ID AS "printJobId", H.LABEL_TYPE AS "labelType",
      H.REF_TABLE AS "refTable", H.REF_ID AS "refId", H.TEMPLATE_ID AS "templateId",
      H.PRINTER_NAME AS "printerName", H.PRINTED_BY_ID AS "printedById",
      H.PRINTED_AT AS "printedAt", H.CREATED_AT AS "createdAt"
    FROM ${TABLES.labelPrintHistory} H
    WHERE H.ID = :id
    FETCH FIRST 1 ROWS ONLY
    `,
    { id },
  );
}

export default {
  listBoxes,
  getBoxById,
  createBox,
  updateBox,
  getLatestBoxPrint,
  nextBoxBarcode,
  listPallets,
  getPalletById,
  createPallet,
  addBoxToPallet,
  removeBoxFromPallet,
  listPalletBoxes,
  finalizePallet,
  createLabelPrintJob,
  markBoxLabelPrinted,
  markPalletLabelPrinted,
  bulkAddBoxesToPallet,
  clearPalletBoxes,
  getAvailableBoxes,
  listPalletHistory,
  listLabelPrintHistory,
  getLabelPrintHistoryById,
};
