import { executeRows, executeOne, executeCommit } from '../config/oracle.js';
import { SETUP_TABLES, newUuid, asJson, jsonString } from './setupAccess.model.js';

const userSelect = `
  U.ID AS "id",
  U.EMP_ID AS "empId",
  U.USERNAME AS "username",
  U.PASSWORD_HASH AS "passwordHash",
  U.FULL_NAME AS "fullName",
  U.EMAIL AS "email",
  U.PHONE AS "phone",
  U.ROLE AS "role",
  U.ROLE_ID AS "roleId",
  PR.ROLE_ID AS "primaryRoleId",
  PR.NAME AS "roleName",
  U.PLANT AS "plant",
  U.DEPARTMENT AS "department",
  U.SHIFT AS "shift",
  U.LANGUAGE AS "language",
  U.THEME AS "theme",
  U.LAST_LOGIN_AT AS "lastLoginAt",
  U.MUST_CHANGE_PASSWORD AS "mustChangePassword",
  U.SCREEN_PERMISSIONS AS "screenPermissions",
  U.IS_ACTIVE AS "isActive",
  U.CREATED_AT AS "createdAt",
  U.UPDATED_AT AS "updatedAt"
`;

const roleJoin = `
  LEFT JOIN ${SETUP_TABLES.userRoles} UR ON UR.USER_ID = U.ID AND NVL(UR.IS_PRIMARY,0) = 1
  LEFT JOIN ${SETUP_TABLES.roles} PR ON PR.ROLE_ID = UR.ROLE_ID AND NVL(PR.IS_DELETED,0)=0
`;

function normalizeUser(row) {
  if (!row) return null;
  const user = { ...row };
  user.mustChangePassword = Number(user.mustChangePassword || 0) === 1;
  user.isActive = Number(user.isActive ?? 1) === 1;
  user.screenPermissions = asJson(user.screenPermissions, {});
  user.role = user.role || user.roleName || 'user';
  user.roleId = user.roleId || user.primaryRoleId || null;
  return user;
}

export async function countUsers() {
  const row = await executeOne(`SELECT COUNT(1) AS "count" FROM ${SETUP_TABLES.users} WHERE NVL(IS_DELETED,0)=0`);
  return Number(row?.count || 0);
}

export async function findUserByLogin(loginId) {
  const row = await executeOne(
    `
    SELECT ${userSelect}
    FROM ${SETUP_TABLES.users} U
    ${roleJoin}
    WHERE NVL(U.IS_DELETED,0)=0
      AND NVL(U.IS_ACTIVE,1)=1
      AND (
        LOWER(U.EMP_ID)=LOWER(:loginId)
        OR LOWER(U.USERNAME)=LOWER(:loginId)
        OR LOWER(NVL(U.EMAIL,''))=LOWER(:loginId)
      )
    FETCH FIRST 1 ROWS ONLY
    `,
    { loginId },
  );
  return normalizeUser(row);
}

export async function findUserById(id, { includePassword = false } = {}) {
  const row = await executeOne(
    `
    SELECT ${userSelect}
    FROM ${SETUP_TABLES.users} U
    ${roleJoin}
    WHERE U.ID=:id AND NVL(U.IS_DELETED,0)=0
    FETCH FIRST 1 ROWS ONLY
    `,
    { id },
  );
  const user = normalizeUser(row);
  if (user && !includePassword) delete user.passwordHash;
  return user;
}

export async function updateLastLogin(userId) {
  const result = await executeCommit(
    `UPDATE ${SETUP_TABLES.users} SET LAST_LOGIN_AT=SYSTIMESTAMP, UPDATED_AT=SYSTIMESTAMP WHERE ID=:userId`,
    { userId },
  );
  return result.rowsAffected || 0;
}

export async function updatePassword(userId, passwordHash, user = null) {
  const result = await executeCommit(
    `UPDATE ${SETUP_TABLES.users} SET PASSWORD_HASH=:passwordHash, MUST_CHANGE_PASSWORD=0, UPDATED_BY=:updatedBy, UPDATED_AT=SYSTIMESTAMP WHERE ID=:userId`,
    { userId, passwordHash, updatedBy: user?.username || user?.empId || user?.id || 'system' },
  );
  return result.rowsAffected || 0;
}

export async function createDefaultAdmin({ empId, username = 'admin', passwordHash, fullName, role = 'System Admin', plant = 'Zamil Plastics' }) {
  const roleRow = await executeOne(
    `SELECT ID AS "id", ROLE_ID AS "role_id", NAME AS "name" FROM ${SETUP_TABLES.roles} WHERE (LOWER(NAME)=LOWER(:role) OR LOWER(CODE)='system_admin') AND NVL(IS_DELETED,0)=0 FETCH FIRST 1 ROWS ONLY`,
    { role },
  );

  const id = newUuid();
  await executeCommit(
    `
    INSERT INTO ${SETUP_TABLES.users}
    (ID, EMP_ID, USERNAME, PASSWORD_HASH, FULL_NAME, EMAIL, ROLE, ROLE_ID, PLANT,
     LANGUAGE, THEME, MUST_CHANGE_PASSWORD, SCREEN_PERMISSIONS, CREATED_BY, UPDATED_BY,
     IS_ACTIVE, IS_DELETED, CREATED_AT, UPDATED_AT)
    VALUES
    (:id, :empId, :username, :passwordHash, :fullName, NULL, :roleName, :roleUuid, :plant,
     'en', 'black', 0, :screenPermissions, 'system', 'system', 1, 0, SYSTIMESTAMP, SYSTIMESTAMP)
    `,
    {
      id,
      empId,
      username,
      passwordHash,
      fullName,
      roleName: roleRow?.name || role,
      roleUuid: roleRow?.id || null,
      plant,
      screenPermissions: jsonString({ all: true }, {}),
    },
  );

  if (roleRow?.role_id) {
    const nextIdRow = await executeOne(`SELECT NVL(MAX(ID),0)+1 AS "id" FROM ${SETUP_TABLES.userRoles}`);
    await executeCommit(
      `INSERT INTO ${SETUP_TABLES.userRoles} (ID, USER_ID, ROLE_ID, IS_PRIMARY, CREATED_AT) VALUES (:id, :userId, :roleId, 1, SYSTIMESTAMP)`,
      { id: Number(nextIdRow?.id || 1), userId: id, roleId: roleRow.role_id },
    );
  }

  return id;
}

export function sanitizeUser(user) {
  if (!user) return null;
  const { passwordHash, ...safe } = user;
  return safe;
}

export default {
  countUsers,
  findUserByLogin,
  findUserById,
  updateLastLogin,
  updatePassword,
  createDefaultAdmin,
  sanitizeUser,
};
