// Zamil MES Oracle ADW model layer
// ------------------------------------------------------------
// Sequelize has been removed from the model layer.
// Controllers must import module models directly, for example:
//   import * as productionModel from '../models/production.model.js';
//   import * as setupModel from '../models/setup.model.js';
//
// All table names use the MES_ prefix and all queries use node-oracledb.
export * as machineIpMapModel from './machineIpMap.model.js';
export * as baseModel from './base.model.js';
export * as authModel from './auth.model.js';
export * as usersModel from './users.model.js';
export * as auditModel from './audit.model.js';
export * as setupModel from './setup.model.js';
export * as productionModel from './production.model.js';
export * as qcModel from './qc.model.js';
export * as packerModel from './packer.model.js';
export * as wasteModel from './waste.model.js';
export * as downtimeModel from './downtime.model.js';
export * as stockModel from './stock.model.js';
export * as lineclearanceModel from './lineclearance.model.js';
export * as referenceModel from './reference.model.js';

export function getModels() {
  throw new Error(
    'Sequelize getModels() has been removed. Update controllers to import the required Oracle ADW model file directly from src/models/*.model.js.',
  );
}

export default {
  getModels,
};
