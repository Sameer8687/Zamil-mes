import { TABLES, query, addEq } from './base.model.js';

export async function getDefectTypes(filters = {}) {
  const where = ['NVL(IS_DELETED,0) = 0', 'NVL(IS_ACTIVE,1) = 1'];
  const binds = {};
  addEq(where, binds, 'CATEGORY', 'category', filters.category);
  return query(
    `SELECT ID AS "id", DEFECT_CODE AS "code", DEFECT_NAME AS "name", CATEGORY AS "category", SEVERITY AS "severity"
     FROM ${TABLES.defectTypes}
     WHERE ${where.join(' AND ')}
     ORDER BY CATEGORY, DEFECT_NAME`,
    binds,
  );
}

export async function getWasteTypes() {
  return query(
    `SELECT DISTINCT WASTE_TYPE AS "value", WASTE_TYPE AS "label" FROM ${TABLES.wasteReasonCodes} WHERE NVL(IS_ACTIVE,1)=1 AND WASTE_TYPE IS NOT NULL ORDER BY WASTE_TYPE`,
  );
}

export async function getWasteCategories() {
  return query(
    `SELECT DISTINCT CATEGORY AS "value", CATEGORY AS "label" FROM ${TABLES.wasteReasonCodes} WHERE NVL(IS_ACTIVE,1)=1 AND CATEGORY IS NOT NULL ORDER BY CATEGORY`,
  );
}

export async function getDisposalMethods() {
  return query(
    `SELECT DISTINCT DISPOSAL_METHOD AS "value", DISPOSAL_METHOD AS "label" FROM ${TABLES.wasteReasonCodes} WHERE NVL(IS_ACTIVE,1)=1 AND DISPOSAL_METHOD IS NOT NULL ORDER BY DISPOSAL_METHOD`,
  );
}

export async function getDowntimeCategories() {
  return query(
    `SELECT DISTINCT CATEGORY AS "value", CATEGORY AS "label" FROM ${TABLES.downtimeReasonCodes} WHERE NVL(IS_ACTIVE,1)=1 AND CATEGORY IS NOT NULL ORDER BY CATEGORY`,
  );
}

export async function getQCChecklist(filters = {}) {
  const where = ['NVL(IS_DELETED,0)=0', 'NVL(IS_ACTIVE,1)=1'];
  const binds = {};
  addEq(where, binds, 'CHECK_TYPE', 'checkType', filters.checkType);
  addEq(where, binds, 'CHECK_GROUP', 'checkGroup', filters.checkGroup);
  return query(
    `SELECT ID AS "id", CHECK_CODE AS "code", CHECK_NAME AS "name", CHECK_GROUP AS "group", CHECK_TYPE AS "checkType", SORT_ORDER AS "sortOrder", IS_REQUIRED AS "isRequired"
     FROM ${TABLES.qcChecklists}
     WHERE ${where.join(' AND ')}
     ORDER BY CHECK_GROUP, SORT_ORDER, CHECK_NAME`,
    binds,
  );
}

export async function getLCChecklist(filters = {}) {
  const where = ['NVL(IS_DELETED,0)=0', 'NVL(IS_ACTIVE,1)=1'];
  const binds = {};
  addEq(where, binds, 'CHECK_GROUP', 'checkGroup', filters.checkGroup);
  return query(
    `SELECT ID AS "id", CHECK_CODE AS "code", CHECK_NAME AS "name", CHECK_GROUP AS "group", SORT_ORDER AS "sortOrder", IS_REQUIRED AS "isRequired"
     FROM ${TABLES.lcChecklists}
     WHERE ${where.join(' AND ')}
     ORDER BY CHECK_GROUP, SORT_ORDER, CHECK_NAME`,
    binds,
  );
}

export async function getScreens() {
  return query(
    `SELECT ID AS "id", SCREEN_CODE AS "screenCode", SCREEN_NAME AS "screenName", MODULE_CODE AS "moduleCode", ROUTE_PATH AS "routePath", SORT_ORDER AS "sortOrder"
     FROM ${TABLES.screens}
     WHERE NVL(IS_ACTIVE,1)=1
     ORDER BY MODULE_CODE, SORT_ORDER`,
  );
}

export async function getFeatures() {
  return query(
    `SELECT ID AS "id", FEATURE_CODE AS "featureCode", FEATURE_NAME AS "featureName", SCREEN_CODE AS "screenCode", MODULE_CODE AS "moduleCode", DESCRIPTION AS "description"
     FROM ${TABLES.features}
     WHERE NVL(IS_ACTIVE,1)=1
     ORDER BY MODULE_CODE, SCREEN_CODE, FEATURE_CODE`,
  );
}

export default {
  getDefectTypes,
  getWasteTypes,
  getWasteCategories,
  getDisposalMethods,
  getDowntimeCategories,
  getQCChecklist,
  getLCChecklist,
  getScreens,
  getFeatures,
};
