import {
  TABLES,
  query,
  queryOne,
  pagedQuery,
  addEq,
  addDateFrom,
  addDateTo,
  insertRow,
  updateRow,
  softDeleteRow,
  parseJson,
} from './base.model.js';
import { executeCommit } from '../config/oracle.js';

const qcResultFieldMap = {
  woId: 'WO_ID',
  machineId: 'MACHINE_ID',
  inspectorId: 'INSPECTOR_ID',
  shift: 'SHIFT',
  checkType: 'CHECK_TYPE',
  sampleSize: 'SAMPLE_SIZE',
  passCount: 'PASS_COUNT',
  failCount: 'FAIL_COUNT',
  overallResult: 'OVERALL_RESULT',
  dimensions: 'DIMENSIONS_JSON',
  visualChecks: 'VISUAL_CHECKS_JSON',
  measurements: 'MEASUREMENTS_JSON',
  defects: 'DEFECTS_JSON',
  notes: 'NOTES',
};

const boxQcFieldMap = {
  boxId: 'BOX_ID',
  woId: 'WO_ID',
  machineId: 'MACHINE_ID',
  inspectorId: 'INSPECTOR_ID',
  result: 'RESULT',
  checks: 'CHECKS_JSON',
  defects: 'DEFECTS_JSON',
  notes: 'NOTES',
  inspectedAt: 'INSPECTED_AT',
};

function normalizeQc(row) {
  if (!row) return null;
  return {
    ...row,
    dimensions: parseJson(row.dimensions, {}),
    visualChecks: parseJson(row.visualChecks, {}),
    measurements: parseJson(row.measurements, {}),
    defects: parseJson(row.defects, []),
  };
}

function normalizeBoxQc(row) {
  if (!row) return null;
  return {
    ...row,
    checks: parseJson(row.checks, {}),
    defects: parseJson(row.defects, []),
  };
}

const cleanKey = (value) => {
  if (value === undefined || value === null) return null;
  const text = String(value).trim();
  return text || null;
};

async function resolveWorkOrderNumber(value) {
  const lookup = cleanKey(value);
  if (!lookup) return null;

  const row = await queryOne(
    `
    SELECT WO_NUMBER AS "woNumber"
    FROM ${TABLES.workOrders}
    WHERE NVL(IS_DELETED,0) = 0
      AND (
        UPPER(TRIM(ID)) = UPPER(TRIM(:lookup))
        OR UPPER(TRIM(WO_NUMBER)) = UPPER(TRIM(:lookup))
        OR UPPER(TRIM(WORK_ORDER_ID)) = UPPER(TRIM(:lookup))
      )
    FETCH FIRST 1 ROWS ONLY
    `,
    { lookup },
  );

  return row?.woNumber || lookup;
}

async function resolveMachineCode(value) {
  const lookup = cleanKey(value);
  if (!lookup) return null;

  const row = await queryOne(
    `
    SELECT CODE AS "code"
    FROM ${TABLES.machines}
    WHERE NVL(IS_DELETED,0) = 0
      AND (
        UPPER(TRIM(ID)) = UPPER(TRIM(:lookup))
        OR UPPER(TRIM(CODE)) = UPPER(TRIM(:lookup))
        OR UPPER(TRIM(MES_CODE)) = UPPER(TRIM(:lookup))
      )
    FETCH FIRST 1 ROWS ONLY
    `,
    { lookup },
  );

  return row?.code || lookup;
}

export async function listQCResults(filters = {}) {
  const where = ['NVL(QR.IS_DELETED,0) = 0'];
  const binds = {};
  addEq(where, binds, 'QR.WO_ID', 'woId', filters.woNumber || filters.workOrderNumber || filters.woId);
  addEq(where, binds, 'QR.MACHINE_ID', 'machineId', filters.machineCode || filters.machineId);
  addEq(where, binds, 'QR.INSPECTOR_ID', 'inspectorId', filters.inspectorId);
  addEq(where, binds, 'QR.CHECK_TYPE', 'checkType', filters.checkType);
  addEq(where, binds, 'QR.OVERALL_RESULT', 'overallResult', filters.overallResult || filters.result);
  addDateFrom(where, binds, 'QR.CREATED_AT', 'fromDate', filters.fromDate);
  addDateTo(where, binds, 'QR.CREATED_AT', 'toDate', filters.toDate);

  const result = await pagedQuery({
    select: `
      QR.ID AS "id", QR.WO_ID AS "woId", WO.WO_NUMBER AS "woNumber",
      QR.MACHINE_ID AS "machineId", M.CODE AS "machineCode", M.NAME AS "machineName",
      QR.INSPECTOR_ID AS "inspectorId", U.FULL_NAME AS "inspectorName",
      QR.SHIFT AS "shift", QR.CHECK_TYPE AS "checkType", QR.SAMPLE_SIZE AS "sampleSize",
      QR.PASS_COUNT AS "passCount", QR.FAIL_COUNT AS "failCount", QR.OVERALL_RESULT AS "overallResult",
      QR.DIMENSIONS_JSON AS "dimensions", QR.VISUAL_CHECKS_JSON AS "visualChecks",
      QR.MEASUREMENTS_JSON AS "measurements", QR.DEFECTS_JSON AS "defects",
      QR.NOTES AS "notes", QR.CREATED_AT AS "createdAt", QR.UPDATED_AT AS "updatedAt"
    `,
    from: `${TABLES.qcResults} QR`,
    joins: `
      LEFT JOIN ${TABLES.workOrders} WO ON WO.WO_NUMBER = QR.WO_ID
      LEFT JOIN ${TABLES.machines} M ON M.CODE = QR.MACHINE_ID
      LEFT JOIN ${TABLES.users} U ON U.ID = QR.INSPECTOR_ID
    `,
    where,
    binds,
    orderBy: 'QR.CREATED_AT DESC',
    page: filters.page,
    limit: filters.limit,
  });
  return { ...result, rows: result.rows.map(normalizeQc) };
}

export async function getQCResultById(id) {
  const row = await queryOne(
    `
    SELECT
      QR.ID AS "id", QR.WO_ID AS "woId", WO.WO_NUMBER AS "woNumber",
      QR.MACHINE_ID AS "machineId", M.CODE AS "machineCode", M.NAME AS "machineName",
      QR.INSPECTOR_ID AS "inspectorId", U.FULL_NAME AS "inspectorName",
      QR.SHIFT AS "shift", QR.CHECK_TYPE AS "checkType", QR.SAMPLE_SIZE AS "sampleSize",
      QR.PASS_COUNT AS "passCount", QR.FAIL_COUNT AS "failCount", QR.OVERALL_RESULT AS "overallResult",
      QR.DIMENSIONS_JSON AS "dimensions", QR.VISUAL_CHECKS_JSON AS "visualChecks",
      QR.MEASUREMENTS_JSON AS "measurements", QR.DEFECTS_JSON AS "defects",
      QR.NOTES AS "notes", QR.CREATED_AT AS "createdAt", QR.UPDATED_AT AS "updatedAt"
    FROM ${TABLES.qcResults} QR
    LEFT JOIN ${TABLES.workOrders} WO ON WO.WO_NUMBER = QR.WO_ID
    LEFT JOIN ${TABLES.machines} M ON M.CODE = QR.MACHINE_ID
    LEFT JOIN ${TABLES.users} U ON U.ID = QR.INSPECTOR_ID
    WHERE QR.ID = :id AND NVL(QR.IS_DELETED,0) = 0
    FETCH FIRST 1 ROWS ONLY
    `,
    { id },
  );
  return normalizeQc(row);
}

export async function createQCResult(data, user = null) {
  const woNumber = await resolveWorkOrderNumber(data.woId || data.woNumber || data.workOrderNumber);
  const machineCode = await resolveMachineCode(data.machineId || data.machineCode);

  return insertRow(TABLES.qcResults, qcResultFieldMap, {
    ...data,
    woId: woNumber || data.woId,
    machineId: machineCode || data.machineId,
  }, user);
}

export async function updateQCResult(id, data, user = null) {
  return updateRow(TABLES.qcResults, qcResultFieldMap, id, data, user);
}

export async function getQCSummary(filters = {}) {
  const where = ['NVL(IS_DELETED,0) = 0'];
  const binds = {};
  addDateFrom(where, binds, 'CREATED_AT', 'fromDate', filters.fromDate);
  addDateTo(where, binds, 'CREATED_AT', 'toDate', filters.toDate);
  return queryOne(
    `
    SELECT
      COUNT(1) AS "total",
      SUM(CASE WHEN OVERALL_RESULT = 'pass' THEN 1 ELSE 0 END) AS "pass",
      SUM(CASE WHEN OVERALL_RESULT = 'fail' THEN 1 ELSE 0 END) AS "fail",
      SUM(CASE WHEN OVERALL_RESULT = 'conditional' THEN 1 ELSE 0 END) AS "conditional",
      SUM(NVL(SAMPLE_SIZE,0)) AS "sampleSize",
      SUM(NVL(PASS_COUNT,0)) AS "passCount",
      SUM(NVL(FAIL_COUNT,0)) AS "failCount"
    FROM ${TABLES.qcResults}
    WHERE ${where.join(' AND ')}
    `,
    binds,
  );
}

export async function listBoxQCResults(filters = {}) {
  const where = ['NVL(BQR.IS_DELETED,0) = 0'];
  const binds = {};
  addEq(where, binds, 'BQR.BOX_ID', 'boxId', filters.boxId);
  addEq(where, binds, 'BQR.WO_ID', 'woId', filters.woNumber || filters.workOrderNumber || filters.woId);
  addEq(where, binds, 'BQR.MACHINE_ID', 'machineId', filters.machineCode || filters.machineId);
  addEq(where, binds, 'BQR.RESULT', 'result', filters.result);

  const result = await pagedQuery({
    select: `
      BQR.ID AS "id", BQR.BOX_ID AS "boxId", B.BARCODE AS "barcode",
      BQR.WO_ID AS "woId", WO.WO_NUMBER AS "woNumber",
      BQR.MACHINE_ID AS "machineId", M.CODE AS "machineCode",
      BQR.INSPECTOR_ID AS "inspectorId", U.FULL_NAME AS "inspectorName",
      BQR.RESULT AS "result", BQR.CHECKS_JSON AS "checks", BQR.DEFECTS_JSON AS "defects",
      BQR.NOTES AS "notes", BQR.INSPECTED_AT AS "inspectedAt",
      BQR.CREATED_AT AS "createdAt", BQR.UPDATED_AT AS "updatedAt"
    `,
    from: `${TABLES.boxQcResults} BQR`,
    joins: `
      LEFT JOIN ${TABLES.boxes} B ON B.ID = BQR.BOX_ID
      LEFT JOIN ${TABLES.workOrders} WO ON WO.WO_NUMBER = BQR.WO_ID
      LEFT JOIN ${TABLES.machines} M ON M.CODE = BQR.MACHINE_ID
      LEFT JOIN ${TABLES.users} U ON U.ID = BQR.INSPECTOR_ID
    `,
    where,
    binds,
    orderBy: 'BQR.INSPECTED_AT DESC NULLS LAST, BQR.CREATED_AT DESC',
    page: filters.page,
    limit: filters.limit,
  });
  return { ...result, rows: result.rows.map(normalizeBoxQc) };
}

export async function createBoxQCResult(data, user = null) {
  const woNumber = await resolveWorkOrderNumber(data.woId || data.woNumber || data.workOrderNumber);
  const machineCode = await resolveMachineCode(data.machineId || data.machineCode);

  const id = await insertRow(TABLES.boxQcResults, boxQcFieldMap, {
    ...data,
    woId: woNumber || data.woId,
    machineId: machineCode || data.machineId,
    inspectedAt: data.inspectedAt || new Date(),
  }, user);

  if (data.boxId) {
    await updateRow(TABLES.boxes, {
      qcStatus: 'QC_STATUS',
      qcNotes: 'QC_NOTES',
      qcChecks: 'QC_CHECKS_JSON',
    }, data.boxId, {
      qcStatus: data.result,
      qcNotes: data.notes,
      qcChecks: data.checks,
    }, user);
  }

  return id;
}



export async function getBoxQCResultById(id) {
  const row = await queryOne(
    `
    SELECT
      BQR.ID AS "id", BQR.BOX_ID AS "boxId", B.BARCODE AS "barcode",
      BQR.WO_ID AS "woId", BQR.MACHINE_ID AS "machineId",
      BQR.INSPECTOR_ID AS "inspectorId", BQR.RESULT AS "result",
      BQR.CHECKS_JSON AS "checks", BQR.DEFECTS_JSON AS "defects",
      BQR.NOTES AS "notes", BQR.INSPECTED_AT AS "inspectedAt",
      BQR.CREATED_AT AS "createdAt", BQR.UPDATED_AT AS "updatedAt"
    FROM ${TABLES.boxQcResults} BQR
    LEFT JOIN ${TABLES.boxes} B ON B.ID = BQR.BOX_ID
    WHERE BQR.ID = :id AND NVL(BQR.IS_DELETED,0) = 0
    FETCH FIRST 1 ROWS ONLY
    `,
    { id },
  );
  return normalizeBoxQc(row);
}

export async function updateBoxQCResult(id, data, user = null) {
  const affected = await updateRow(TABLES.boxQcResults, boxQcFieldMap, id, data, user);
  const row = await getBoxQCResultById(id);
  if (affected && row?.boxId && data.result) {
    await updateBoxQualityStatus({
      boxId: row.boxId,
      result: data.result,
      notes: data.notes ?? row.notes,
      checks: data.checks ?? row.checks,
      defects: data.defects ?? row.defects,
      inspectorId: data.inspectorId || user?.id,
    }, user);
  }
  return affected;
}

export async function deleteBoxQCResult(id, user = null) {
  return softDeleteRow(TABLES.boxQcResults, id, user);
}

export function normalizeBoxResultStatus(value) {
  const status = String(value || '').trim().toLowerCase();
  if (['appr', 'approved', 'approve', 'pass', 'passed', 'ok'].includes(status)) return 'appr';
  if (['rejt', 'rejected', 'reject', 'fail', 'failed'].includes(status)) return 'rejt';
  if (['hold', 'onhold', 'on hold', 'pending', 'pend'].includes(status)) return status === 'hold' || status === 'onhold' || status === 'on hold' ? 'hold' : 'pend';
  return status || 'pend';
}

export async function updateBoxQualityStatus({ boxId, result, notes = null, checks = null, defects = null, inspectorId = null }, user = null) {
  const status = normalizeBoxResultStatus(result);
  const box = await queryOne(
    `
    SELECT ID AS "id", WO_ID AS "woId", MACHINE_ID AS "machineId", BARCODE AS "barcode"
    FROM ${TABLES.boxes}
    WHERE ID = :boxId AND NVL(IS_DELETED,0) = 0
    FETCH FIRST 1 ROWS ONLY
    `,
    { boxId },
  );
  if (!box) return null;

  await executeCommit(
    `
    UPDATE ${TABLES.boxes}
    SET QC_STATUS = :status,
        QC_NOTES = :notes,
        QC_CHECKS_JSON = :checks,
        UPDATED_BY = :updatedBy,
        UPDATED_AT = SYSTIMESTAMP
    WHERE ID = :boxId AND NVL(IS_DELETED,0) = 0
    `,
    {
      boxId,
      status,
      notes,
      checks: checks === undefined || checks === null ? null : JSON.stringify(checks),
      updatedBy: user?.username || user?.empId || user?.id || 'system',
    },
  );

  await executeCommit(
    `
    UPDATE ${TABLES.stockRecords}
    SET QC_STATUS = :status,
        STATUS = CASE WHEN :status = 'rejt' THEN 'rejected' WHEN :status = 'hold' THEN 'hold' ELSE STATUS END,
        UPDATED_BY = :updatedBy,
        UPDATED_AT = SYSTIMESTAMP
    WHERE NVL(IS_DELETED,0) = 0
      AND (BOX_NO = :barcode OR WO_ID = :woId)
    `,
    {
      status,
      barcode: box.barcode,
      woId: box.woId,
      updatedBy: user?.username || user?.empId || user?.id || 'system',
    },
  );

  await createBoxQCResult({
    boxId,
    woId: box.woId,
    machineId: box.machineId,
    inspectorId: inspectorId || user?.id,
    result: status,
    checks: checks || {},
    defects: defects || [],
    notes,
  }, user);

  return queryOne(
    `
    SELECT ID AS "id", BARCODE AS "barcode", WO_ID AS "woId", MACHINE_ID AS "machineId",
           QC_STATUS AS "qcStatus", QC_NOTES AS "qcNotes", QC_CHECKS_JSON AS "qcChecks",
           STATUS AS "status", UPDATED_AT AS "updatedAt"
    FROM ${TABLES.boxes}
    WHERE ID = :boxId
    `,
    { boxId },
  );
}

export async function getWorkOrderBoxQCSummary(woId) {
  const woNumber = await resolveWorkOrderNumber(woId);
  return queryOne(
    `
    SELECT
      COUNT(1) AS "total",
      SUM(CASE WHEN QC_STATUS = 'appr' THEN 1 ELSE 0 END) AS "approved",
      SUM(CASE WHEN QC_STATUS = 'rejt' THEN 1 ELSE 0 END) AS "rejected",
      SUM(CASE WHEN QC_STATUS = 'hold' THEN 1 ELSE 0 END) AS "hold",
      SUM(CASE WHEN QC_STATUS IS NULL OR QC_STATUS IN ('pend','pending') THEN 1 ELSE 0 END) AS "pending"
    FROM ${TABLES.boxes}
    WHERE WO_ID = :woId AND NVL(IS_DELETED,0) = 0
    `,
    { woId: woNumber },
  );
}

export async function listDefectTypes(filters = {}) {
  const where = ['NVL(IS_DELETED,0) = 0', 'NVL(IS_ACTIVE,1) = 1'];
  const binds = {};
  addEq(where, binds, 'CATEGORY', 'category', filters.category);
  addEq(where, binds, 'SEVERITY', 'severity', filters.severity);
  return query(
    `
    SELECT ID AS "id", DEFECT_CODE AS "code", DEFECT_NAME AS "name", CATEGORY AS "category", SEVERITY AS "severity"
    FROM ${TABLES.defectTypes}
    WHERE ${where.join(' AND ')}
    ORDER BY CATEGORY, DEFECT_NAME
    `,
    binds,
  );
}

export async function listQCChecklist(filters = {}) {
  const where = ['NVL(IS_DELETED,0) = 0', 'NVL(IS_ACTIVE,1) = 1'];
  const binds = {};
  addEq(where, binds, 'CHECK_TYPE', 'checkType', filters.checkType);
  addEq(where, binds, 'CHECK_GROUP', 'checkGroup', filters.checkGroup);
  return query(
    `
    SELECT
      ID AS "id", CHECK_CODE AS "code", CHECK_NAME AS "name", CHECK_GROUP AS "group",
      CHECK_TYPE AS "checkType", SORT_ORDER AS "sortOrder", IS_REQUIRED AS "isRequired"
    FROM ${TABLES.qcChecklists}
    WHERE ${where.join(' AND ')}
    ORDER BY CHECK_GROUP, SORT_ORDER, CHECK_NAME
    `,
    binds,
  );
}

export default {
  listQCResults,
  getQCResultById,
  createQCResult,
  updateQCResult,
  getQCSummary,
  listBoxQCResults,
  createBoxQCResult,
  getBoxQCResultById,
  updateBoxQCResult,
  deleteBoxQCResult,
  updateBoxQualityStatus,
  getWorkOrderBoxQCSummary,
  listDefectTypes,
  listQCChecklist,
};
