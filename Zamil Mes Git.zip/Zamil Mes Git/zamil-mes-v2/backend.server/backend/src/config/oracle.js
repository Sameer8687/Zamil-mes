import env from './env.js';
import oracledb from 'oracledb';
import logger from '../utils/logger.js';
import path from 'path';
import fs from 'fs';

// Set up wallet directory before initializing oracledb
if (env.ORACLE_WALLET_DIR) {
  // Convert to absolute path and set TNS_ADMIN
  const walletDir = path.resolve(env.ORACLE_WALLET_DIR);
  process.env.TNS_ADMIN = walletDir;
  logger.info(`TNS_ADMIN set to: ${walletDir}`);
}

oracledb.outFormat = oracledb.OUT_FORMAT_OBJECT;
oracledb.autoCommit = false;
oracledb.fetchAsString = [oracledb.CLOB];

let pool = null;
let initPromise = null;

const resolveConnectString = (connectString, walletDir) => {
  if (!walletDir || String(connectString).includes('(')) {
    return connectString;
  }

  const tnsPath = path.join(walletDir, 'tnsnames.ora');
  const tns = fs.readFileSync(tnsPath, 'utf8');
  const aliasPattern = new RegExp(`^\\s*${connectString}\\s*=\\s*(.+?)(?=\\r?\\n\\s*\\w+\\s*=|\\s*$)`, 'ims');
  const match = tns.match(aliasPattern);
  if (!match) {
    return connectString;
  }

  let descriptor = match[1].trim();
  descriptor = descriptor
    .replace(/\(retry_count\s*=\s*\d+\)/ig, '(retry_count=0)')
    .replace(/\(retry_delay\s*=\s*\d+\)/ig, '(retry_delay=0)');

  if (!/\(connect_timeout\s*=/i.test(descriptor)) {
    descriptor = descriptor.replace(/^\(description\s*=/i, `(description=(connect_timeout=${env.ORACLE_CONNECT_TIMEOUT})`);
  }
  if (!/\(transport_connect_timeout\s*=/i.test(descriptor)) {
    descriptor = descriptor.replace(/^\(description\s*=/i, `(description=(transport_connect_timeout=${env.ORACLE_CONNECT_TIMEOUT})`);
  }

  return descriptor;
};

const buildPoolConfig = () => {
  if (!env.ORACLE_USER || !env.ORACLE_PASSWORD || !env.ORACLE_CONNECT_STRING) {
    throw new Error(
      'Oracle ADW configuration missing. Set ORACLE_USER, ORACLE_PASSWORD, and ORACLE_CONNECT_STRING in backend/.env.'
    );
  }

  const walletDir = env.ORACLE_WALLET_DIR ? path.resolve(env.ORACLE_WALLET_DIR) : '';

  const config = {
    user: env.ORACLE_USER,
    password: env.ORACLE_PASSWORD,
    connectString: resolveConnectString(env.ORACLE_CONNECT_STRING, walletDir),
    walletPassword: env.ORACLE_WALLET_PASSWORD || undefined,

    poolMin: env.ORACLE_POOL_MIN,
    poolMax: env.ORACLE_POOL_MAX,
    poolIncrement: env.ORACLE_POOL_INCREMENT,
    poolTimeout: env.ORACLE_POOL_TIMEOUT,
    queueTimeout: env.ORACLE_QUEUE_TIMEOUT,
    connectTimeout: env.ORACLE_CONNECT_TIMEOUT,
    poolPingTimeout: env.ORACLE_POOL_PING_TIMEOUT,

    stmtCacheSize: 50
  };

  if (env.ORACLE_WALLET_DIR) {
    if (!fs.existsSync(walletDir)) {
      throw new Error(`Oracle wallet directory not found: ${walletDir}`);
    }
    if (!fs.existsSync(path.join(walletDir, 'tnsnames.ora'))) {
      throw new Error(`Oracle wallet tnsnames.ora not found in: ${walletDir}`);
    }
    if (!fs.existsSync(path.join(walletDir, 'ewallet.pem')) && !fs.existsSync(path.join(walletDir, 'cwallet.sso'))) {
      throw new Error(`Oracle wallet credentials not found in: ${walletDir}`);
    }

    config.configDir = walletDir;
    config.walletLocation = walletDir;
  }

  return config;
};

export async function initOraclePool() {
  if (pool) return pool;
  if (initPromise) return initPromise;

  if (env.DB_CLIENT !== 'oracle') {
    throw new Error(`Unsupported DB_CLIENT "${env.DB_CLIENT}". This backend is configured for Oracle ADW only.`);
  }

  initPromise = oracledb.createPool(buildPoolConfig())
    .then((createdPool) => {
      pool = createdPool;
      logger.info(`Oracle ADW pool created: ${env.ORACLE_CONNECT_STRING}`);
      return pool;
    })
    .catch((error) => {
      initPromise = null;
      const message = explainOracleError(error);
      logger.error(`Oracle ADW pool creation failed: ${message}`);
      throw error;
    });

  return initPromise;
}

export function explainOracleError(error) {
  const message = error?.message || String(error);
  if (/bad decrypt|NJS-505|wallet credentials/i.test(message)) {
    return `${message}. If this wallet was downloaded with a password, set ORACLE_WALLET_PASSWORD in backend/.env.`;
  }
  return message;
}

export async function getConnection() {
  if (!pool) {
    await initOraclePool();
  }
  return pool.getConnection();
}

export async function closeOraclePool() {
  if (!pool) return;

  await pool.close(10);
  pool = null;
  logger.info('Oracle ADW pool closed');
}

export async function execute(sql, binds = {}, options = {}) {
  let connection;

  try {
    connection = await getConnection();

    return await connection.execute(sql, binds, {
      outFormat: oracledb.OUT_FORMAT_OBJECT,
      autoCommit: false,
      ...options,
    });
  } finally {
    if (connection) {
      await connection.close();
    }
  }
}

export async function executeOne(sql, binds = {}, options = {}) {
  const result = await execute(sql, binds, options);
  return result.rows?.[0] || null;
}

export async function executeRows(sql, binds = {}, options = {}) {
  const result = await execute(sql, binds, options);
  return result.rows || [];
}

export async function executeDml(sql, binds = {}, options = {}) {
  let connection;

  try {
    connection = await getConnection();

    const result = await connection.execute(sql, binds, {
      outFormat: oracledb.OUT_FORMAT_OBJECT,
      autoCommit: false,
      ...options,
    });

    await connection.commit();
    return result;
  } catch (error) {
    if (connection) {
      await connection.rollback();
    }
    throw error;
  } finally {
    if (connection) {
      await connection.close();
    }
  }
}

export async function executeMany(sql, rows = [], options = {}) {
  if (!rows.length) {
    return { rowsAffected: 0 };
  }

  let connection;

  try {
    connection = await getConnection();

    const result = await connection.executeMany(sql, rows, {
      autoCommit: false,
      ...options,
    });

    await connection.commit();
    return result;
  } catch (error) {
    if (connection) {
      await connection.rollback();
    }
    throw error;
  } finally {
    if (connection) {
      await connection.close();
    }
  }
}

export const executeCommit = async (sql, binds = {}, options = {}) => {
  const connection = await getConnection();

  try {
    await connection.execute(`ALTER SESSION DISABLE PARALLEL DML`);
    await connection.execute(`ALTER SESSION DISABLE PARALLEL QUERY`);
    await connection.execute(`ALTER SESSION DISABLE PARALLEL DDL`);

    const result = await connection.execute(sql, binds, {
      autoCommit: false,
      ...options,
    });

    await connection.commit();
    return result;
  } catch (err) {
    try {
      await connection.rollback();
    } catch (_) {
      // ignore rollback error
    }

    throw err;
  } finally {
    try {
      await connection.close();
    } catch (_) {
      // ignore close error
    }
  }
};

export default {
  initOraclePool,
  getConnection,
  closeOraclePool,
  execute,
  executeOne,
  executeRows,
  executeDml,
  executeMany,
  executeCommit,
  explainOracleError,
};
