import 'dotenv/config';

const toNumber = (value, fallback) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
};

const cleanPath = (value = '') => value.trim().replace(/^['"]|['"]$/g, '').replace(/\\/g, '/');

const env = {
  NODE_ENV: process.env.NODE_ENV || 'development',
  PORT: toNumber(process.env.PORT, 5000),

  FRONTEND_URL: process.env.FRONTEND_URL || 'http://localhost:5173',
  API_PREFIX: process.env.API_PREFIX || '/api/v1',
  LOG_LEVEL: process.env.LOG_LEVEL || 'info',

  JWT_SECRET: process.env.JWT_SECRET || 'zamil-mes-secret-change-in-production',
  JWT_EXPIRES_IN: process.env.JWT_EXPIRES_IN || '8h',
  JWT_REFRESH_SECRET: process.env.JWT_REFRESH_SECRET || 'zamil-mes-refresh-secret-change-in-production',
  JWT_REFRESH_EXPIRES_IN: process.env.JWT_REFRESH_EXPIRES_IN || '7d',

  DB_CLIENT: (process.env.DB_CLIENT || process.env.DB_DIALECT || 'oracle').toLowerCase(),

  ORACLE_USER: process.env.ORACLE_USER || '',
  ORACLE_PASSWORD: process.env.ORACLE_PASSWORD || '',
  ORACLE_WALLET_PASSWORD: process.env.ORACLE_WALLET_PASSWORD || '',
  ORACLE_CONNECT_STRING: process.env.ORACLE_CONNECT_STRING || '',
  ORACLE_WALLET_DIR: cleanPath(process.env.ORACLE_WALLET_DIR || ''),
  ORACLE_SCHEMA: (process.env.ORACLE_SCHEMA || '').trim().toUpperCase(),

  ORACLE_POOL_MIN: toNumber(process.env.ORACLE_POOL_MIN, 0),
  ORACLE_POOL_MAX: toNumber(process.env.ORACLE_POOL_MAX, 3),
  ORACLE_POOL_INCREMENT: toNumber(process.env.ORACLE_POOL_INCREMENT, 1),
  ORACLE_POOL_TIMEOUT: toNumber(process.env.ORACLE_POOL_TIMEOUT, 60),
  ORACLE_QUEUE_TIMEOUT: toNumber(process.env.ORACLE_QUEUE_TIMEOUT, 120000),
  ORACLE_CONNECT_TIMEOUT: toNumber(process.env.ORACLE_CONNECT_TIMEOUT, 10),
  ORACLE_POOL_PING_TIMEOUT: toNumber(process.env.ORACLE_POOL_PING_TIMEOUT, 5000),

  APP_INSTALLED: process.env.APP_INSTALLED === 'true',
  INSTALL_SECRET: process.env.INSTALL_SECRET || 'zamil-install-2024',
};

if (env.ORACLE_WALLET_DIR && !process.env.TNS_ADMIN) {
  process.env.TNS_ADMIN = env.ORACLE_WALLET_DIR;
}

export default env;
