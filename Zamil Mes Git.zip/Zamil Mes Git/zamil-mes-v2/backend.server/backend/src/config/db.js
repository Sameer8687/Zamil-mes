/**
 * Sequelize has been removed from the Zamil MES backend.
 *
 * The application now uses Oracle ADW directly through node-oracledb:
 *   - Connection: src/config/oracle.js
 *   - Models:     src/models/*.model.js
 *   - Tables:     MES_* tables in Oracle ADW
 *
 * This file is kept only to give a clear error if any legacy code still imports it.
 */

const removed = () => {
  throw new Error(
    'Legacy Sequelize database layer is removed. Use src/config/oracle.js and module model files under src/models/*.model.js.'
  );
};

export const initDatabase = removed;
export const sequelize = null;
export default removed;
