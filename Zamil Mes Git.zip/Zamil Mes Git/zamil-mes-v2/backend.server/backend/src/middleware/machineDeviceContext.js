import { getIpDetailsFromRequest } from '../utils/ipDetails.js';
import { runRequestContext } from '../utils/requestContext.js';
import { findActiveMachineDeviceByIp } from '../models/machineIpMap.model.js';
import logger from '../utils/logger.js';

const buildMachineDeviceInfo = ({
  ipDetails,
  machine = null,
  lookupError = null,
}) => {
  const selectedIp = ipDetails?.selectedIp || {};

  const requesterIp = selectedIp.ip || null;
  const privateIp = ipDetails?.privateIp || (selectedIp.isPrivate ? requesterIp : null);
  const publicIp = ipDetails?.publicIp || (selectedIp.isPublic ? requesterIp : null);

  return {
    requesterIp,
    requesterIpVersion: selectedIp.version || null,
    requesterIpScope: selectedIp.scope || null,
    requesterIpSource: selectedIp.source || null,

    privateIp,
    publicIp,

    machineIpBound: Boolean(machine),
    isMachineBound: Boolean(machine),
    lookupError,

    matchedOn: machine?.matchedOn || null,

    machineId: machine?.id || null,
    id: machine?.id || null,
    code: machine?.code || null,
    name: machine?.name || null,
    machineType: machine?.machineType || null,
    plant: machine?.plant || null,
    department: machine?.department || null,
    area: machine?.area || null,
    locator: machine?.locator || null,
    oem: machine?.oem || null,
    model: machine?.model || null,
    serialNo: machine?.serialNo || null,
    tonnage: machine?.tonnage || null,
    cycleTime: machine?.cycleTime || null,
    cavities: machine?.cavities || null,
    ipAddress: machine?.ipAddress || null,
    plcType: machine?.plcType || null,
    commProtocol: machine?.commProtocol || null,
    mesCode: machine?.mesCode || null,
    pmFreq: machine?.pmFreq || null,
    lastPmDate: machine?.lastPmDate || null,
    status: machine?.status || null,
    specsJson: machine?.specsJson || null,
    createdBy: machine?.createdBy || null,
    updatedBy: machine?.updatedBy || null,
    isActive: machine?.isActive ?? null,
    isDeleted: machine?.isDeleted ?? null,
    createdAt: machine?.createdAt || null,
    updatedAt: machine?.updatedAt || null,
    resourceId: machine?.resourceId || null,
    resourceClassCode: machine?.resourceClassCode || null,
    organizationId: machine?.organizationId || null,
    uomCode: machine?.uomCode || null,
    costedFlag: machine?.costedFlag || null,
    inactiveDate: machine?.inactiveDate || null,
    workDefinitionId: machine?.workDefinitionId || null,
    autoEquipmentFlag: machine?.autoEquipmentFlag || null,

    machine,
  };
};

export const attachMachineDeviceContext = async (req, res, next) => {
  let ipDetails = null;

  try {
    ipDetails = getIpDetailsFromRequest(req);

    const selectedIp = ipDetails.selectedIp || {};

    const requesterIp = selectedIp.ip || null;
    const privateIp = ipDetails.privateIp || (selectedIp.isPrivate ? requesterIp : null);
    const publicIp = ipDetails.publicIp || (selectedIp.isPublic ? requesterIp : null);

    const machine = await findActiveMachineDeviceByIp({
      requesterIp,
      privateIp,
      publicIp,
    });

    const machineDeviceInfo = buildMachineDeviceInfo({
      ipDetails,
      machine,
    });

    req.ipDetails = ipDetails;
    req.machineDeviceInfo = machineDeviceInfo;
    req.machineIpBound = machineDeviceInfo.machineIpBound;

    res.locals.ipDetails = ipDetails;
    res.locals.machineDeviceInfo = machineDeviceInfo;

    return runRequestContext(
      {
        ipDetails,
        machineDeviceInfo,
      },
      () => next(),
    );
  } catch (error) {
    logger.warn(`Machine device context lookup failed: ${error.message}`);

    const fallbackIpDetails = ipDetails || getIpDetailsFromRequest(req);

    const machineDeviceInfo = buildMachineDeviceInfo({
      ipDetails: fallbackIpDetails,
      lookupError: error.message,
    });

    req.ipDetails = fallbackIpDetails;
    req.machineDeviceInfo = machineDeviceInfo;
    req.machineIpBound = machineDeviceInfo.machineIpBound;

    res.locals.ipDetails = fallbackIpDetails;
    res.locals.machineDeviceInfo = machineDeviceInfo;

    return runRequestContext(
      {
        ipDetails: fallbackIpDetails,
        machineDeviceInfo,
      },
      () => next(),
    );
  }
};

export default attachMachineDeviceContext;