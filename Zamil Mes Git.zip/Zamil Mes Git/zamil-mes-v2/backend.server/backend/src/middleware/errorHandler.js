import logger from '../utils/logger.js';

export const errorHandler = (err, _req, res, _next) => {
  logger.error('Unhandled error:', err);
  const status = err.status || err.statusCode || 500;
  res.status(status).json({ success: false, message: err.message || 'Internal server error' });
};

export const notFoundHandler = (_req, res) => {
  res.status(404).json({ success: false, message: 'Route not found' });
};
