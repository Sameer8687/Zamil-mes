import { createAuditLog } from '../models/audit.model.js';

const SENSITIVE_KEYS = new Set(['password', 'passwordHash', 'token', 'refreshToken', 'authorization', 'secret']);

const maskSensitive = (value) => {
  if (!value || typeof value !== 'object') return value;
  if (Array.isArray(value)) return value.map(maskSensitive);
  const copy = {};
  for (const [key, item] of Object.entries(value)) {
    copy[key] = SENSITIVE_KEYS.has(String(key).toLowerCase()) ? '[MASKED]' : maskSensitive(item);
  }
  return copy;
};

const resolveRecordId = (req, resolver) => {
  if (typeof resolver === 'function') return resolver(req);
  if (typeof resolver === 'string') return req.params?.[resolver] || req.body?.[resolver] || null;
  return req.params?.id || req.params?.boxId || req.params?.woId || req.params?.palletId || req.body?.id || req.body?.woId || null;
};

export const auditAction = (module, action, recordIdResolver = null) => (req, res, next) => {
  res.on('finish', () => {
    if (res.statusCode >= 400) return;

    createAuditLog({
      userId: req.user?.id || null,
      action,
      module,
      recordId: resolveRecordId(req, recordIdResolver),
      oldData: null,
      newData: {
        method: req.method,
        path: req.originalUrl,
        params: req.params || {},
        query: req.query || {},
        body: maskSensitive(req.body || {}),
      },
      ipAddress: req.ip || req.headers?.['x-forwarded-for'] || null,
      userAgent: req.headers?.['user-agent'] || null,
    }).catch(() => {
      // Audit logging must never block the business action.
    });
  });

  next();
};

export default auditAction;
