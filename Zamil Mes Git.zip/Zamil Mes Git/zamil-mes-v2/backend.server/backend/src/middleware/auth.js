import jwt from 'jsonwebtoken';
import env from '../config/env.js';

const normalizeRole = (role) => {
  const r = String(role || '').trim().toLowerCase().replace(/\s+/g, '_');
  if (['system_admin', 'admin', 'administrator'].includes(r)) return 'admin';
  if (['process_technician', 'technician', 'tech'].includes(r)) return 'tech';
  if (['qc_inspector', 'quality_inspector'].includes(r)) return 'qc';
  return r;
};

export const authenticate = (req, res, next) => {
  const header = req.headers.authorization;

  if (!header?.startsWith('Bearer ')) {
    return res.status(401).json({ success: false, message: 'Authentication required' });
  }

  try {
    const payload = jwt.verify(header.slice(7), env.JWT_SECRET);
    req.user = { ...payload, role: normalizeRole(payload.role || payload.roleName) };
    return next();
  } catch (_error) {
    return res.status(401).json({ success: false, message: 'Invalid or expired token' });
  }
};

export const authorize = (...roles) => (req, res, next) => {
  if (!req.user) return res.status(401).json({ success: false, message: 'Not authenticated' });

  const allowedRoles = roles.map(normalizeRole);
  const userRole = normalizeRole(req.user.role);

  if (userRole === 'admin' || allowedRoles.includes(userRole)) return next();

  return res.status(403).json({ success: false, message: `Required role: ${roles.join(' or ')}` });
};

export default { authenticate, authorize };
