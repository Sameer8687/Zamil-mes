import { Router } from 'express';
import * as access from '../controllers/accessController.js';

const router = Router();

router.get('/bootstrap', access.bootstrap);

router.get('/users/:userId', access.getUserAccess);
router.put('/users/:userId', access.saveUserAccess);
router.put('/users/:userId/security', access.saveUserSecurity);
router.post('/users/:userId/force-logout', access.forceLogoutUser);

router.post('/users/:userId/roles', access.addUserRole);
router.delete('/users/:userId/roles/:roleId', access.removeUserRole);
router.put('/users/:userId/roles/:roleId/primary', access.setPrimaryUserRole);

router.get('/roles/:roleId/permissions', access.getRolePermissions);
router.post('/roles/:roleId/permissions', access.createRolePermissions);
router.put('/roles/:roleId/permissions', access.updateRolePermissions);
router.delete('/roles/:roleId/permissions', access.deleteRolePermissions);

router.get('/screens', access.getScreens);
router.post('/screens', access.createScreen);
router.put('/screens/:id', access.updateScreen);
router.delete('/screens/:id', access.deleteScreen);

router.get('/features', access.getFeatures);
router.post('/features', access.createFeature);
router.put('/features/:id', access.updateFeature);
router.delete('/features/:id', access.deleteFeature);

export default router;
