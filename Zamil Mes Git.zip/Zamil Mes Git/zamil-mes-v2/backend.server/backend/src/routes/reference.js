import { Router } from 'express';

import * as ref from '../controllers/referenceController.js';

const router = Router();

// Reference data is read-only. No auth required for dropdown/checklist loading.
router.get('/defect-types', ref.getDefectTypes);
router.get('/waste-types', ref.getWasteTypes);
router.get('/waste-categories', ref.getWasteCategories);
router.get('/disposal-methods', ref.getDisposalMethods);
router.get('/downtime-categories', ref.getDowntimeCategories);
router.get('/lc-checklist', ref.getLCChecklist);
router.get('/qc-checklist', ref.getQCChecklist);
router.get('/screens', ref.getScreens);
router.get('/features', ref.getFeatures);

export default router;
