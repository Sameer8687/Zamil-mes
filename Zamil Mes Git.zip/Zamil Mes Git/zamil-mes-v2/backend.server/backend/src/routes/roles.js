import { Router } from 'express';
import * as roles from '../controllers/rolesController.js';

const router = Router();

router.get('/', roles.getRoles);
router.get('/:id', roles.getRole);
router.post('/', roles.createRole);
router.put('/:id', roles.updateRole);
router.delete('/:id', roles.deleteRole);
router.patch('/:id/toggle-status', roles.toggleRoleStatus);
router.put('/:id/permissions', roles.updateRolePermissions);

export default router;
