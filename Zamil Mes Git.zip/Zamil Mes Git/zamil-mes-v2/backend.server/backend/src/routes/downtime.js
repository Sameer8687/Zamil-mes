import { Router } from 'express';

import * as dt from '../controllers/downtimeController.js';
import { authenticate, authorize } from '../middleware/auth.js';
import { auditAction } from '../middleware/audit.js';

const router = Router();

router.use(authenticate);

router.get('/summary', dt.getDowntimeSummary);
router.get('/recent', dt.getRecentDowntimeRecords);
router.get('/report/export', dt.exportDowntimeReport);
router.get('/machine-product-lookup', dt.getMachineProductLookup);
router.get('/reason-codes', dt.getDowntimeReasonCodes);
router.get('/', dt.getDowntimeRecords);
router.post('/', authorize('admin', 'tech', 'operator'), auditAction('DOWNTIME', 'CREATE'), dt.createDowntimeRecord);
router.get('/:id', dt.getDowntimeRecord);
router.put('/:id', authorize('admin', 'tech', 'operator'), auditAction('DOWNTIME', 'UPDATE'), dt.updateDowntimeRecord);
router.delete('/:id', authorize('admin', 'tech'), auditAction('DOWNTIME', 'DELETE'), dt.deleteDowntimeRecord);
router.post('/:id/resolve', authorize('admin', 'tech', 'operator'), auditAction('DOWNTIME', 'RESOLVE'), dt.resolveDowntimeRecord);
router.post('/:id/reopen', authorize('admin', 'tech'), auditAction('DOWNTIME', 'REOPEN'), dt.reopenDowntimeRecord);

export default router;
