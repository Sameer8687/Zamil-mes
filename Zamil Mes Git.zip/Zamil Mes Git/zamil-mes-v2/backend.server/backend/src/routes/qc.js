import { Router } from 'express';
import { body } from 'express-validator';

import * as qc from '../controllers/qcController.js';
import { authenticate, authorize } from '../middleware/auth.js';
import validate from '../middleware/validate.js';
import { auditAction } from '../middleware/audit.js';

const router = Router();

router.use(authenticate);

router.get('/summary', qc.getQCSummary);
router.get('/defect-types', qc.getDefectTypes);
router.get('/checklist', qc.getQCChecklist);

// Box-level QC required by the HTML QC detail screen.
router.get('/box-results', qc.getBoxQCResults);
router.post('/box-results', authorize('admin', 'qc', 'tech'), auditAction('BOX_QC', 'CREATE'), qc.createBoxQCResult);
router.put('/box-results/:id', authorize('admin', 'qc', 'tech'), auditAction('BOX_QC', 'UPDATE'), qc.updateBoxQCResult);
router.delete('/box-results/:id', authorize('admin', 'qc', 'tech'), auditAction('BOX_QC', 'DELETE'), qc.deleteBoxQCResult);
router.get('/boxes', qc.getQCBoxes);
router.get('/boxes/:boxId/history', qc.getBoxHistory);
router.post('/boxes/:boxId/approve', authorize('admin', 'qc', 'tech'), auditAction('BOX_QC', 'APPROVE', 'boxId'), qc.approveBox);
router.post('/boxes/:boxId/reject', authorize('admin', 'qc', 'tech'), auditAction('BOX_QC', 'REJECT', 'boxId'), qc.rejectBox);
router.post('/boxes/:boxId/hold', authorize('admin', 'qc', 'tech'), auditAction('BOX_QC', 'HOLD', 'boxId'), qc.holdBox);
router.get('/work-orders/:woId/summary', qc.getWorkOrderQCSummary);

router.get('/', qc.getQCResults);
router.get('/:id', qc.getQCResult);
router.post(
  '/',
  authorize('admin', 'qc', 'tech'),
  body('overallResult').optional().isIn(['pass', 'fail', 'conditional']),
  validate,
  auditAction('QC_RESULT', 'CREATE'),
  qc.createQCResult
);
router.put('/:id', authorize('admin', 'qc', 'tech'), auditAction('QC_RESULT', 'UPDATE'), qc.updateQCResult);

export default router;
