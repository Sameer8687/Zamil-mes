import { Router } from 'express';
import { body } from 'express-validator';

import * as packer from '../controllers/packerController.js';
import { authenticate, authorize } from '../middleware/auth.js';
import validate from '../middleware/validate.js';
import { auditAction } from '../middleware/audit.js';

const router = Router();

router.use(authenticate);

router.get('/boxes', packer.getBoxes);
router.post('/boxes', authorize('admin', 'packer', 'operator', 'tech'), auditAction('BOX', 'CREATE'), packer.createBox);
router.put('/boxes/:id', authorize('admin', 'packer', 'operator', 'tech', 'qc'), auditAction('BOX', 'UPDATE'), packer.updateBox);
router.post('/boxes/:id/print', authorize('admin', 'packer', 'operator', 'tech'), auditAction('LABEL_PRINT', 'BOX_PRINT'), packer.printBoxLabel);
router.post('/labels/print', authorize('admin', 'packer', 'operator', 'tech'), auditAction('LABEL_PRINT', 'BOX_PRINT'), packer.printLabel);
router.get('/label-history', packer.getLabelHistory);
router.get('/label-history/:id', packer.getLabelHistoryById);
router.get('/available-boxes', packer.getAvailableBoxes);

router.get('/pallets', packer.getPallets);
router.post(
  '/pallets',
  authorize('admin', 'packer', 'tech'),
  body('woId').optional().trim(),
  validate,
  auditAction('PALLET', 'CREATE'),
  packer.createPallet
);
router.get('/pallets/:id', packer.getPallet);
router.get('/pallets/:id/boxes', packer.getPalletBoxes);
router.post('/pallets/:id/boxes', authorize('admin', 'packer', 'tech'), auditAction('PALLET', 'ADD_BOX'), packer.addBoxToPallet);
router.post('/pallets/:id/boxes/bulk-add', authorize('admin', 'packer', 'tech'), auditAction('PALLET', 'BULK_ADD_BOXES'), packer.bulkAddBoxesToPallet);
router.post('/pallets/:id/auto-arrange', authorize('admin', 'packer', 'tech'), auditAction('PALLET', 'AUTO_ARRANGE'), packer.autoArrangePallet);
router.post('/pallets/:id/clear', authorize('admin', 'packer', 'tech'), auditAction('PALLET', 'CLEAR'), packer.clearPallet);
router.post('/pallets/:id/confirm', authorize('admin', 'packer', 'tech'), auditAction('PALLET', 'CONFIRM'), packer.confirmPallet);
router.get('/pallets/:id/history', packer.getPalletHistory);
router.delete('/pallets/:id/boxes/:boxId', authorize('admin', 'packer', 'tech'), auditAction('PALLET', 'REMOVE_BOX', 'boxId'), packer.removeBoxFromPallet);
router.put('/pallets/:id/finalize', authorize('admin', 'packer', 'tech'), auditAction('PALLET', 'FINALIZE'), packer.finalizePallet);
router.post('/pallets/:id/finalize', authorize('admin', 'packer', 'tech'), auditAction('PALLET', 'FINALIZE'), packer.finalizePallet);
router.post('/pallets/:id/print', authorize('admin', 'packer', 'tech'), auditAction('LABEL_PRINT', 'PALLET_PRINT'), packer.printPalletLabel);

export default router;
