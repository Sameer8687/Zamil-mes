import { Router } from 'express';
import { body } from 'express-validator';

import * as prod from '../controllers/productionController.js';
import { authenticate, authorize } from '../middleware/auth.js';
import validate from '../middleware/validate.js';
import { auditAction } from '../middleware/audit.js';

const router = Router();

router.use(authenticate);

router.get('/dashboard', prod.getDashboard);
router.get('/tech-dashboard', prod.getTechDashboard);
router.get('/export', prod.exportWorkOrders);
router.get('/machines/lov', prod.getMachinesLov);
router.get('/machines', prod.getMachines);
router.put('/machines/:id/status', authorize('admin', 'tech'), auditAction('MACHINE', 'STATUS_UPDATE'), prod.updateMachineStatus);

// Process technician / operator APIs required by HTML functionality.
router.get('/operator/active-work-order', prod.getActiveWorkOrder);
router.get('/active-work-order', prod.getActiveWorkOrder);

router.get('/work-orders/export', prod.exportWorkOrders);
router.post('/work-orders/reorder', authorize('admin', 'tech'), auditAction('WORK_ORDER', 'REORDER'), prod.reorderWorkOrders);
router.get('/work-orders/lov', prod.getWorkOrdersLov);
router.get('/work-orders', prod.getWorkOrders);
router.get('/work-orders/:id', prod.getWorkOrder);

router.post(
  '/work-orders',
  authorize('admin', 'tech'),
  body().custom((value, { req }) => Boolean(req.body.woNumber || req.body.wo || req.body.workOrderNumber || req.body.id)).withMessage('Work order number is required'),
  body().custom((value, { req }) => Boolean(req.body.product || req.body.productName || req.body.sub)).withMessage('Product is required'),
  validate,
  auditAction('WORK_ORDER', 'CREATE'),
  prod.createWorkOrder
);

router.put('/work-orders/:id', authorize('admin', 'tech'), auditAction('WORK_ORDER', 'UPDATE'), prod.updateWorkOrder);
router.delete('/work-orders/:id', authorize('admin'), auditAction('WORK_ORDER', 'DELETE'), prod.deleteWorkOrder);

router.post('/work-orders/:id/assign', authorize('admin', 'tech'), auditAction('WORK_ORDER', 'ASSIGN'), prod.assignWorkOrder);
router.get('/work-orders/:id/events', prod.getWorkOrderEvents);
router.get('/work-orders/:id/assignment-history', prod.getWorkOrderAssignmentHistory);
router.put('/work-orders/:id/schedule', authorize('admin', 'tech'), auditAction('WORK_ORDER', 'SCHEDULE_UPDATE'), prod.updateWorkOrderSchedule);
router.put('/work-orders/:id/priority-rank', authorize('admin', 'tech'), auditAction('WORK_ORDER', 'PRIORITY_UPDATE'), prod.updateWorkOrderPriorityRank);
router.post('/work-orders/:id/start', authorize('admin', 'tech', 'operator'), auditAction('WORK_ORDER', 'START'), prod.startWorkOrder);

router.post('/work-orders/:id/release', authorize('admin', 'tech', 'operator'), auditAction('WORK_ORDER', 'RELEASE'), prod.releaseWorkOrder);

router.post('/work-orders/:id/hold', authorize('admin', 'tech', 'operator'), auditAction('WORK_ORDER', 'HOLD'), prod.holdWorkOrder);
router.post('/work-orders/:id/resume', authorize('admin', 'tech', 'operator'), auditAction('WORK_ORDER', 'RESUME'), prod.resumeWorkOrder);
router.post('/work-orders/:id/complete', authorize('admin', 'tech'), auditAction('WORK_ORDER', 'COMPLETE'), prod.completeWorkOrder);
router.post('/work-orders/:id/terminate', authorize('admin', 'tech'), auditAction('WORK_ORDER', 'TERMINATE'), prod.terminateWorkOrder);

router.get('/work-orders/:id/components', prod.getComponents);
router.post('/work-orders/:id/components', authorize('admin', 'tech'), auditAction('WORK_ORDER_COMPONENT', 'CREATE'), prod.createComponent);

router.get('/logs', prod.getLogs);
router.post('/logs', authorize('admin', 'tech', 'operator'), auditAction('PRODUCTION_LOG', 'CREATE'), prod.createLog);

export default router;
