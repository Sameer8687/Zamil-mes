import { Router } from 'express';

import * as waste from '../controllers/wasteController.js';
import { authenticate, authorize } from '../middleware/auth.js';
import { auditAction } from '../middleware/audit.js';

const router = Router();

router.use(authenticate);

router.get('/summary', waste.getWasteSummary);
router.get('/work-orders', waste.getWasteWorkOrders);
router.get('/work-orders/:woId/components', waste.getWasteComponents);
router.get('/lots', waste.getWasteLots);
router.get('/destination-options', waste.getDestinationOptions);
router.get('/export', waste.exportWasteTransactions);
router.get('/reason-codes', waste.getWasteReasonCodes);

// Detailed waste transaction APIs required by the HTML waste recording screen.
router.get('/transactions', waste.getWasteTransactions);
router.post('/transactions', authorize('admin', 'tech', 'operator', 'qc'), auditAction('WASTE_TRANSACTION', 'CREATE'), waste.createWasteTransaction);
router.put('/transactions/:id', authorize('admin', 'tech', 'operator', 'qc'), auditAction('WASTE_TRANSACTION', 'UPDATE'), waste.updateWasteTransaction);
router.delete('/transactions/:id', authorize('admin', 'tech'), auditAction('WASTE_TRANSACTION', 'DELETE'), waste.deleteWasteTransaction);
router.post('/transactions/:id/reverse', authorize('admin', 'tech', 'operator', 'qc'), auditAction('WASTE_TRANSACTION', 'REVERSE'), waste.reverseWasteTransaction);
router.post('/transactions/:id/approve', authorize('admin', 'tech', 'qc'), auditAction('WASTE_TRANSACTION', 'APPROVE'), waste.approveWasteTransaction);

router.get('/', waste.getWasteRecords);
router.post('/', authorize('admin', 'tech', 'operator', 'qc'), auditAction('WASTE_RECORD', 'CREATE'), waste.createWasteRecord);
router.put('/:id', authorize('admin', 'tech', 'operator', 'qc'), auditAction('WASTE_RECORD', 'UPDATE'), waste.updateWasteRecord);
router.delete('/:id', authorize('admin', 'tech'), auditAction('WASTE_RECORD', 'DELETE'), waste.deleteWasteRecord);

export default router;
