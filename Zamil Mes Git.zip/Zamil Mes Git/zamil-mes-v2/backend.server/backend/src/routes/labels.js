import { Router } from 'express';

import * as labels from '../controllers/labelsController.js';
import { authenticate, authorize } from '../middleware/auth.js';
import { auditAction } from '../middleware/audit.js';

const router = Router();

router.use(authenticate);

router.get('/templates/default', labels.getDefaultTemplate);
router.get('/templates', labels.getTemplates);
router.get('/templates/:id', labels.getTemplate);
router.post('/templates', authorize('admin', 'tech'), auditAction('LABEL_TEMPLATE', 'CREATE'), labels.createTemplate);
router.put('/templates/:id', authorize('admin', 'tech'), auditAction('LABEL_TEMPLATE', 'UPDATE'), labels.updateTemplate);
router.delete('/templates/:id', authorize('admin'), auditAction('LABEL_TEMPLATE', 'DELETE'), labels.deleteTemplate);

router.get('/print-jobs', labels.getPrintJobs);
router.get('/print-history', labels.getPrintHistory);
router.get('/print-history/:id', labels.getPrintHistoryById);
router.post('/print-history/:id/reprint', authorize('admin', 'packer', 'operator', 'tech'), auditAction('LABEL_PRINT', 'REPRINT', 'id'), labels.reprintLabel);
router.post('/reprint', authorize('admin', 'packer', 'operator', 'tech'), auditAction('LABEL_PRINT', 'REPRINT'), labels.reprintLabel);

export default router;
