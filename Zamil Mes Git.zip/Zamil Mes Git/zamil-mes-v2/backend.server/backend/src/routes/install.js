import { Router } from 'express';

import * as install from '../controllers/installController.js';

const router = Router();

// ADW schema must be created using SQL Developer scripts.
// These endpoints now only validate connection, seed master data, and finalize install state.
router.get('/status', install.checkInstall);
router.post('/test-connection', install.testConnection);
router.post('/create-schema', install.createSchema);
router.post('/seed-data', install.seedData);
router.post('/finalize', install.finalizeInstall);

export default router;
