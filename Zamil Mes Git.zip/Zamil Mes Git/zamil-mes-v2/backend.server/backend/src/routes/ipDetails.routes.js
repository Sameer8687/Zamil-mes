import express from "express";
import { getIpDetails } from "../controllers/ipDetails.controller.js";

const router = express.Router();

router.get("/ip-details", getIpDetails);

export default router;