import { Router } from 'express';

import * as lc from '../controllers/lineclearanceController.js';
import { authenticate, authorize } from '../middleware/auth.js';
import { auditAction } from '../middleware/audit.js';

const router = Router();

router.use(authenticate);

router.get('/checklist', lc.getLCChecklist);
router.get('/product-lookup', lc.getProductLookup);
router.get('/report/export', lc.exportLineClearanceReport);
router.get('/', lc.getLineClearances);
router.get('/:id', lc.getLineClearance);
router.post('/', authorize('admin', 'tech', 'qc'), auditAction('LINE_CLEARANCE', 'CREATE'), lc.createLineClearance);
router.put('/:id', authorize('admin', 'tech', 'qc'), auditAction('LINE_CLEARANCE', 'UPDATE'), lc.updateLineClearance);
router.post('/:id/submit', authorize('admin', 'tech', 'qc'), auditAction('LINE_CLEARANCE', 'SUBMIT'), lc.submitLineClearance);
router.post('/:id/approve', authorize('admin', 'qc', 'tech'), auditAction('LINE_CLEARANCE', 'APPROVE'), lc.approveLineClearance);
router.post('/:id/reject', authorize('admin', 'qc', 'tech'), auditAction('LINE_CLEARANCE', 'REJECT'), lc.rejectLineClearance);
router.get('/:id/print', lc.printLineClearance);

export default router;
