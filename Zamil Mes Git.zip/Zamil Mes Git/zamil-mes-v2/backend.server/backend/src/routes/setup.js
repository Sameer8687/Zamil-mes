import { Router } from 'express';
import * as setup from '../controllers/setupController.js';
import { authenticate } from '../middleware/auth.js';
import { auditAction } from '../middleware/audit.js';

const router = Router();

// Public APIs needed before login. Login page uses machine list for machine selection.
router.get('/machines', setup.getMachines);

router.use(authenticate);

router.get('/items/by-segment/:segment1', setup.getFusionItemBySegment);

router.get('/organizations/lov', setup.getOrganizationsLov);
router.get('/organizations-lov', setup.getOrganizationsLov);

// Colleague Setup frontend expects these endpoints to be reachable with the same URL and response shape.
router.get('/machines/stats', setup.getMachineStats);
router.get('/machines/export', setup.exportMachines);
router.post('/machines/import', auditAction('SETUP_MACHINE', 'IMPORT'), setup.importMachines);
router.get('/machines/area-options', setup.getMachineAreaOptions);
router.get('/machines/auto-locator', setup.getAutoLocator);
router.post('/machines', auditAction('SETUP_MACHINE', 'CREATE'), setup.createMachine);
router.put('/machines/:id', auditAction('SETUP_MACHINE', 'UPDATE'), setup.updateMachine);
router.delete('/machines/:id', auditAction('SETUP_MACHINE', 'DELETE'), setup.deleteMachine);

router.get('/locations/stats', setup.getLocationStats);
router.get('/locations/export', setup.exportLocations);
router.post('/locations/import', auditAction('SETUP_LOCATION', 'IMPORT'), setup.importLocations);
router.post('/locations/seed', auditAction('SETUP_LOCATION', 'SEED'), setup.seedLocations);
router.get('/locations/barcodes', setup.getLocationBarcodes);
router.post('/locations/print-barcodes', auditAction('SETUP_LOCATION', 'PRINT_BARCODES'), setup.printLocationBarcodes);
router.get('/locations', setup.getLocations);
router.post('/locations', auditAction('SETUP_LOCATION', 'CREATE'), setup.createLocation);
router.put('/locations/:id', auditAction('SETUP_LOCATION', 'UPDATE'), setup.updateLocation);
router.delete('/locations/:id', auditAction('SETUP_LOCATION', 'DELETE'), setup.deleteLocation);

router.get('/shifts', setup.getShifts);
router.post('/shifts', auditAction('SETUP_SHIFT', 'CREATE'), setup.createShift);
router.put('/shifts/:id', auditAction('SETUP_SHIFT', 'UPDATE'), setup.updateShift);
router.delete('/shifts/:id', auditAction('SETUP_SHIFT', 'DELETE'), setup.deleteShift);

router.get('/configs', setup.getConfigs);
router.post('/configs', auditAction('SETUP_CONFIG', 'UPSERT'), setup.upsertConfig);

router.get('/box-qty-report/export', setup.exportBoxQtyReport);
router.get('/box-qty-report', setup.getBoxQtyReport);
router.get('/box-qty-records', setup.getBoxQtyReport);
router.get('/box-qty-records/:id', setup.getBoxQtyRecord);
router.get('/box-qty/item-lookup', setup.getBoxQtyItemLookup);
router.post('/box-qty/import', auditAction('BOX_QTY', 'IMPORT'), setup.importBoxQtyRecords);
router.post('/box-qty-records', auditAction('BOX_QTY', 'CREATE'), setup.createBoxQtyRecord);
router.put('/box-qty-records/:id', auditAction('BOX_QTY', 'UPDATE'), setup.updateBoxQtyRecord);
router.delete('/box-qty-records/:id', auditAction('BOX_QTY', 'DELETE'), setup.deleteBoxQtyRecord);

export default router;
