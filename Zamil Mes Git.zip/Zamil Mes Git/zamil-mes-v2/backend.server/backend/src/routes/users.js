import { Router } from 'express';
import * as users from '../controllers/usersController.js';

const router = Router();

router.get('/roles', users.getRoles);

// Employee master APIs from MES_EMPLOYEES.
// Keep these before '/:id', otherwise Express will treat 'employees' as user id.
router.get('/employees', users.getEmployees);
router.get('/employees/:employeeNumber', users.getEmployeeByEmployeeNumber);

router.get('/', users.getUsers);
router.get('/:id', users.getUser);
router.get('/:id/activity', users.getActivityLog);

router.post('/', users.createUser);
router.put('/:id', users.updateUser);
router.delete('/:id', users.deleteUser);
router.put('/:id/permissions', users.updatePermissions);

export default router;
