import { Router } from 'express';

import * as stock from '../controllers/stockController.js';
import { authenticate, authorize } from '../middleware/auth.js';
import { auditAction } from '../middleware/audit.js';

const router = Router();

router.use(authenticate);

router.get('/summary', stock.getStockSummary);
router.get('/export', stock.exportStock);

// Item master and inventory lot APIs needed for produced stock / locator flow.
router.get('/items', stock.getItemMaster);
router.post('/items', authorize('admin', 'tech'), auditAction('ITEM_MASTER', 'CREATE'), stock.createItemMaster);
router.put('/items/:id', authorize('admin', 'tech'), auditAction('ITEM_MASTER', 'UPDATE'), stock.updateItemMaster);
router.delete('/items/:id', authorize('admin', 'tech'), auditAction('ITEM_MASTER', 'DELETE'), stock.deleteItemMaster);
router.get('/lots', stock.getInventoryLots);
router.post('/lots', authorize('admin', 'tech'), auditAction('INVENTORY_LOT', 'CREATE'), stock.createInventoryLot);
router.put('/lots/:id', authorize('admin', 'tech'), auditAction('INVENTORY_LOT', 'UPDATE'), stock.updateInventoryLot);
router.delete('/lots/:id', authorize('admin', 'tech'), auditAction('INVENTORY_LOT', 'DELETE'), stock.deleteInventoryLot);

router.get('/by-box/:boxNo', stock.getStockByBox);
router.get('/by-pallet/:palletCode', stock.getStockByPallet);

router.get('/', stock.getStockRecords);
router.get('/:id', stock.getStockRecord);
router.post('/', authorize('admin', 'tech', 'operator', 'packer'), auditAction('STOCK', 'CREATE'), stock.createStockRecord);
router.put('/:id', authorize('admin', 'tech', 'operator', 'packer'), auditAction('STOCK', 'UPDATE'), stock.updateStockRecord);
router.post('/:id/reserve', authorize('admin', 'tech', 'packer'), auditAction('STOCK', 'RESERVE'), stock.reserveStock);
router.post('/:id/unreserve', authorize('admin', 'tech', 'packer'), auditAction('STOCK', 'UNRESERVE'), stock.unreserveStock);
router.post('/:id/dispatch', authorize('admin', 'tech', 'packer'), auditAction('STOCK', 'DISPATCH'), stock.dispatchStock);
router.post('/:id/hold', authorize('admin', 'tech', 'packer', 'qc'), auditAction('STOCK', 'HOLD'), stock.holdStock);

export default router;
