import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import bcrypt from 'bcryptjs';

import env from './config/env.js';
import { initOraclePool, closeOraclePool, executeOne, explainOracleError } from './config/oracle.js';
import logger from './utils/logger.js';
import requestLogger from './middleware/logger.js';
import { errorHandler, notFoundHandler } from './middleware/errorHandler.js';
import { attachMachineDeviceContext } from './middleware/machineDeviceContext.js';
import * as authModel from './models/auth.model.js';
// Routes - keep current MVC route structure
import authRoutes from './routes/auth.js';
import usersRoutes from './routes/users.js';
import rolesRoutes from './routes/roles.js';
import accessRoutes from './routes/access.js';
import productionRoutes from './routes/production.js';
import qcRoutes from './routes/qc.js';
import wasteRoutes from './routes/waste.js';
import downtimeRoutes from './routes/downtime.js';
import packerRoutes from './routes/packer.js';
import lineclearanceRoutes from './routes/lineclearance.js';
import stockRoutes from './routes/stock.js';
import setupRoutes from './routes/setup.js';
import installRoutes from './routes/install.js';
import referenceRoutes from './routes/reference.js';
import labelsRoutes from './routes/labels.js';
import ipDetailsRoutes from "./routes/ipDetails.routes.js";


const app = express();

const trustProxyValue = (() => {
  const value = process.env.TRUST_PROXY || "false";

  if (value === "true") return true;
  if (value === "false") return false;

  const numericValue = Number(value);

  if (!Number.isNaN(numericValue) && numericValue > 0) {
    return numericValue;
  }

  return false;
})();

app.set("trust proxy", trustProxyValue);


const prefix = env.API_PREFIX || '/api/v1';

app.use(helmet({ crossOriginEmbedderPolicy: false }));



const isDev = env.NODE_ENV !== 'production';
const allowedOrigins = new Set([
  env.FRONTEND_URL,
  'http://localhost:3000',
  'http://127.0.0.1:3000',
  'http://localhost:5173',
  'http://127.0.0.1:5173',
  'http://localhost:4173',
  'http://127.0.0.1:4173',
  'http://localhost:8805',
  'http://127.0.0.1:8805',
]);

const corsOptions = {
  origin: isDev
    ? true
    : (origin, callback) => {
      if (!origin || allowedOrigins.has(origin)) {
        callback(null, true);
      } else {
        callback(new Error(`CORS origin denied: ${origin}`));
      }
    },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: [
    'Content-Type',
    'Authorization',
    'X-Client-Public-IP',
    'X-Client-Public-IPv4',
    'X-Client-Public-IPv6',
    'X-Requested-With',
  ],
  optionsSuccessStatus: 204,
};

app.use(cors(corsOptions));
app.options('*', cors(corsOptions));

app.use(compression());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(requestLogger);

const healthPayload = () => ({
  status: 'ok',
  service: 'Zamil MES API',
  version: '3.0.0',
  database: 'Oracle ADW',
  timestamp: new Date().toISOString(),
});

app.get('/health', (_req, res) => res.json(healthPayload()));
app.get(`${prefix}/health`, (_req, res) => res.json(healthPayload()));

app.get(`${prefix}/health/db`, async (_req, res) => {
  try {
    const row = await executeOne(`
      SELECT
        USER AS "currentUser",
        SYSDATE AS "dbDate"
      FROM DUAL
    `);

    return res.json({
      success: true,
      message: 'Oracle ADW connected',
      data: row,
    });
  } catch (error) {
    const message = explainOracleError(error);
    logger.error(`Oracle ADW health check failed: ${message}`);
    return res.status(500).json({
      success: false,
      message: 'Oracle ADW connection failed',
      error: message,
    });
  }
});
app.use(prefix, attachMachineDeviceContext);
// Existing API paths stay same for frontend compatibility.
app.use(`${prefix}/auth`, authRoutes);
app.use(`${prefix}/users`, usersRoutes);
app.use(`${prefix}/roles`, rolesRoutes);
app.use(`${prefix}/access`, accessRoutes);
app.use(`${prefix}/production`, productionRoutes);
app.use(`${prefix}/qc`, qcRoutes);
app.use(`${prefix}/waste`, wasteRoutes);
app.use(`${prefix}/downtime`, downtimeRoutes);
app.use(`${prefix}/packer`, packerRoutes);
app.use(`${prefix}/labels`, labelsRoutes);
app.use(`${prefix}/line-clearance`, lineclearanceRoutes);
app.use(`${prefix}/stock`, stockRoutes);
app.use(`${prefix}/setup`, setupRoutes);
app.use(`${prefix}/install`, installRoutes);
app.use(`${prefix}/reference`, referenceRoutes);
app.use(prefix, ipDetailsRoutes);

app.use(notFoundHandler);
app.use(errorHandler);

const ensureDefaultAdmin = async () => {
  try {
    const userCount = await authModel.countUsers();

    if (userCount === 0) {
      const hash = await bcrypt.hash('Admin@1234', 12);

      await authModel.createDefaultAdmin({
        empId: 'EMP-0001',
        username: 'admin',
        passwordHash: hash,
        fullName: 'System Administrator',
        role: 'admin',
        plant: 'Zamil Plastics',
      });

      logger.info('Default admin created — EMP-0001 / Admin@1234');
    }
  } catch (error) {
    // This can happen before USERS table is created. It should not stop server startup.
    logger.warn(`Default admin check skipped: ${error.message}`);
  }
};

const checkDatabase = async () => {
  await initOraclePool();

  const dbTest = await executeOne(`
    SELECT
      USER AS "currentUser",
      SYS_CONTEXT('USERENV', 'SERVICE_NAME') AS "serviceName",
      SYSDATE AS "dbDate"
    FROM DUAL
  `);

  logger.info(`Oracle ADW connected as ${dbTest.currentUser} using service ${dbTest.serviceName}`);
  await ensureDefaultAdmin();
};

const shutdown = async (signal) => {
  try {
    logger.info(`${signal} received. Closing Oracle pool...`);
    await closeOraclePool();
    process.exit(0);
  } catch (error) {
    logger.error('Shutdown failed:', error);
    process.exit(1);
  }
};

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

const start = async () => {
  app.listen(env.PORT || 5000, () => {
    logger.info(`Zamil MES API - port ${env.PORT || 5000} [${env.NODE_ENV}]`);
    console.log(`Zamil MES API - port ${env.PORT || 5000} [${env.NODE_ENV}]`);
    logger.info(`API Prefix: ${prefix}`);
  });

  // Keep HTTP reachable even if ADW is down. DB-backed routes and /health/db
  // will report the concrete Oracle error when connection fails.
  checkDatabase().catch((error) => {
    logger.error(`Oracle ADW startup check failed: ${explainOracleError(error)}`);
  });
  return;

  try {
    await initOraclePool();

    const dbTest = await executeOne(`
      SELECT 
        USER AS "currentUser",
        SYS_CONTEXT('USERENV', 'SERVICE_NAME') AS "serviceName",
        SYSDATE AS "dbDate"
      FROM DUAL
    `);

    logger.info(`Oracle ADW connected as ${dbTest.currentUser} using service ${dbTest.serviceName}`);

    // No Sequelize sync. Oracle ADW schema must be created using SQL Developer scripts.
    await ensureDefaultAdmin();

    app.listen(env.PORT || 5000, () => {
      logger.info(`Zamil MES API — port ${env.PORT || 5000} [${env.NODE_ENV}]`);
      console.log(`Zamil MES API — port ${env.PORT || 5000} [${env.NODE_ENV}]`);
      logger.info(`API Prefix: ${prefix}`);
    });
  } catch (error) {
    logger.error('Startup failed:', error);
    process.exit(1);
  }
};

start();

export default app;
