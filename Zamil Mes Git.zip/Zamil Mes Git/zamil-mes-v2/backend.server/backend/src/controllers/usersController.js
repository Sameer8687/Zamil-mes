import bcrypt from 'bcryptjs';
import { success, created, notFound, badRequest, error, paginated } from '../utils/response.js';
import { executeRows, executeOne, executeCommit } from '../config/oracle.js';
import {
  SETUP_TABLES,
  newUuid,
  nextNumber,
  toFlag,
  toBool,
  asJson,
  jsonString,
  fetchRoleByAny,
  listActiveRoles,
  withTransaction,
  rebuildUserPermissions,
} from '../models/setupAccess.model.js';

const mapUser = (row = {}) => ({
  id: row.id,
  empId: row.empId,
  username: row.username,
  fullName: row.fullName,
  name: row.fullName,
  email: row.email,
  phone: row.phone,
  role: row.role,
  role_id: row.primaryRoleId ?? row.role_id,
  roleId: row.roleId,
  roleName: row.roleName || row.role,
  plant: row.plant,
  department: row.department,
  dept: row.department,
  jobTitle: row.jobTitle,
  title: row.jobTitle,
  shift: row.shift,
  language: row.language,
  theme: row.theme,
  lastLoginAt: row.lastLoginAt,
  mustChangePassword: toBool(row.mustChangePassword, false),
  screenPermissions: asJson(row.screenPermissions, {}),
  isActive: toBool(row.isActive, true),
  isDeleted: toBool(row.isDeleted, false),
  createdAt: row.createdAt,
  updatedAt: row.updatedAt,
});

const userSelect = `
  U.ID AS "id",
  U.EMP_ID AS "empId",
  U.USERNAME AS "username",
  U.FULL_NAME AS "fullName",
  U.EMAIL AS "email",
  U.PHONE AS "phone",
  U.ROLE AS "role",
  U.ROLE_ID AS "roleId",
  PR.ROLE_ID AS "primaryRoleId",
  PR.NAME AS "roleName",
  U.PLANT AS "plant",
  U.DEPARTMENT AS "department",
  E.JOB_TITLE AS "jobTitle",
  U.SHIFT AS "shift",
  U.LANGUAGE AS "language",
  U.THEME AS "theme",
  U.LAST_LOGIN_AT AS "lastLoginAt",
  U.MUST_CHANGE_PASSWORD AS "mustChangePassword",
  U.SCREEN_PERMISSIONS AS "screenPermissions",
  U.IS_ACTIVE AS "isActive",
  U.IS_DELETED AS "isDeleted",
  U.CREATED_AT AS "createdAt",
  U.UPDATED_AT AS "updatedAt"
`;

const roleJoin = `
  LEFT JOIN ${SETUP_TABLES.userRoles} UR
    ON UR.USER_ID = U.ID
   AND NVL(UR.IS_PRIMARY,0) = 1

  LEFT JOIN ${SETUP_TABLES.roles} PR
    ON PR.ROLE_ID = UR.ROLE_ID
   AND NVL(PR.IS_DELETED,0)=0
`;

const employeeJoin = `
  LEFT JOIN ${SETUP_TABLES.employees || 'MES_EMPLOYEES'} E
    ON LOWER(E.EMPLOYEE_NUMBER) = LOWER(U.EMP_ID)
   AND NVL(E.IS_DELETED,0)=0
`;

const employeeSelect = `
  E.ID AS "id",
  E.EMPLOYEE_NUMBER AS "employeeNumber",
  E.FULL_NAME AS "fullName",
  E.LAST_NAME AS "lastName",
  E.FIRST_NAME AS "firstName",
  E.EMAIL_ADDRESS AS "emailAddress",
  E.PERSON_TYPE AS "personType",
  E.ORIGINAL_DATE_OF_HIRE AS "originalDateOfHire",
  E.PERIOD_START_DATE AS "periodStartDate",
  E.ACTUAL_TERMINATION_DATE AS "actualTerminationDate",
  E.NATIONALITY_IDENTIFIER AS "nationalityIdentifier",
  E.DATE_OF_BIRTH AS "dateOfBirth",
  E.MARITAL_STATUS AS "maritalStatus",
  E.NATIONALITY AS "nationality",
  E.GENDER AS "gender",
  E.EFFECTIVE_START_DATE_EMP AS "effectiveStartDateEmp",
  E.EFFECTIVE_END_DATE_EMP AS "effectiveEndDateEmp",
  E.EFFECTIVE_START_DATE_ASG AS "effectiveStartDateAsg",
  E.EFFECTIVE_END_DATE_ASG AS "effectiveEndDateAsg",
  E.ORGANIZATION_DEPT AS "organizationDept",
  E.JOB_TITLE AS "jobTitle",
  E.POSITION AS "position",
  E.WORKER_CATEGORY AS "workerCategory",
  E.COST_CENTER AS "costCenter",
  E.CREATED_AT AS "createdAt",
  E.UPDATED_AT AS "updatedAt",
  E.IS_ACTIVE AS "isActive",
  E.IS_DELETED AS "isDeleted"
`;

const mapEmployee = (row = {}) => ({
  id: row.id,

  employeeNumber: row.employeeNumber,
  empId: row.employeeNumber,

  fullName: row.fullName,
  name: row.fullName,

  lastName: row.lastName,
  firstName: row.firstName,

  emailAddress: row.emailAddress,
  email: row.emailAddress,

  personType: row.personType,
  originalDateOfHire: row.originalDateOfHire,
  periodStartDate: row.periodStartDate,
  actualTerminationDate: row.actualTerminationDate,

  nationalityIdentifier: row.nationalityIdentifier,
  dateOfBirth: row.dateOfBirth,
  maritalStatus: row.maritalStatus,
  nationality: row.nationality,
  gender: row.gender,

  effectiveStartDateEmp: row.effectiveStartDateEmp,
  effectiveEndDateEmp: row.effectiveEndDateEmp,
  effectiveStartDateAsg: row.effectiveStartDateAsg,
  effectiveEndDateAsg: row.effectiveEndDateAsg,

  organizationDept: row.organizationDept,
  department: row.organizationDept,
  dept: row.organizationDept,

  jobTitle: row.jobTitle,
  position: row.position,
  workerCategory: row.workerCategory,
  costCenter: row.costCenter,

  username: row.employeeNumber,

  isActive: toBool(row.isActive, true),
  isDeleted: toBool(row.isDeleted, false),
  createdAt: row.createdAt,
  updatedAt: row.updatedAt,
});

export const getEmployees = async (req, res) => {
  try {
    const {
      page = 1,
      limit = 50,
      search,
      employeeNumber,
      fullName,
      email,
      department,
      jobTitle,
      position,
      personType,
      gender,
      active,
      includeDeleted = 'false',
    } = req.query;

    const where = [];
    const binds = {};

    if (String(includeDeleted).toLowerCase() !== 'true') {
      where.push('NVL(E.IS_DELETED,0)=0');
    }

    if (active !== undefined && active !== '') {
      if (
        active === true ||
        active === 'true' ||
        active === '1' ||
        String(active).toLowerCase() === 'yes'
      ) {
        where.push('NVL(E.IS_ACTIVE,1)=1');
      }

      if (
        active === false ||
        active === 'false' ||
        active === '0' ||
        String(active).toLowerCase() === 'no'
      ) {
        where.push('NVL(E.IS_ACTIVE,1)=0');
      }
    }

    if (employeeNumber) {
      where.push('LOWER(E.EMPLOYEE_NUMBER) LIKE LOWER(:employeeNumber)');
      binds.employeeNumber = `%${String(employeeNumber).trim()}%`;
    }

    if (fullName) {
      where.push('LOWER(E.FULL_NAME) LIKE LOWER(:fullName)');
      binds.fullName = `%${String(fullName).trim()}%`;
    }

    if (email) {
      where.push('LOWER(NVL(E.EMAIL_ADDRESS, \'\')) LIKE LOWER(:email)');
      binds.email = `%${String(email).trim()}%`;
    }

    if (department) {
      where.push('LOWER(NVL(E.ORGANIZATION_DEPT, \'\')) LIKE LOWER(:department)');
      binds.department = `%${String(department).trim()}%`;
    }

    if (jobTitle) {
      where.push('LOWER(NVL(E.JOB_TITLE, \'\')) LIKE LOWER(:jobTitle)');
      binds.jobTitle = `%${String(jobTitle).trim()}%`;
    }

    if (position) {
      where.push('LOWER(NVL(E.POSITION, \'\')) LIKE LOWER(:position)');
      binds.position = `%${String(position).trim()}%`;
    }

    if (personType) {
      where.push('LOWER(NVL(E.PERSON_TYPE, \'\')) = LOWER(:personType)');
      binds.personType = String(personType).trim();
    }

    if (gender) {
      where.push('LOWER(NVL(E.GENDER, \'\')) = LOWER(:gender)');
      binds.gender = String(gender).trim();
    }

    if (search) {
      where.push(`
        (
          LOWER(E.EMPLOYEE_NUMBER) LIKE LOWER(:search)
          OR LOWER(NVL(E.FULL_NAME, '')) LIKE LOWER(:search)
          OR LOWER(NVL(E.FIRST_NAME, '')) LIKE LOWER(:search)
          OR LOWER(NVL(E.LAST_NAME, '')) LIKE LOWER(:search)
          OR LOWER(NVL(E.EMAIL_ADDRESS, '')) LIKE LOWER(:search)
          OR LOWER(NVL(E.ORGANIZATION_DEPT, '')) LIKE LOWER(:search)
          OR LOWER(NVL(E.JOB_TITLE, '')) LIKE LOWER(:search)
          OR LOWER(NVL(E.POSITION, '')) LIKE LOWER(:search)
          OR LOWER(NVL(E.COST_CENTER, '')) LIKE LOWER(:search)
        )
      `);

      binds.search = `%${String(search).trim()}%`;
    }

    const safePage = Math.max(Number(page) || 1, 1);
    const safeLimit = Math.min(Math.max(Number(limit) || 50, 1), 500);
    const offset = (safePage - 1) * safeLimit;

    const whereSql = where.length ? where.join(' AND ') : '1=1';

    const countRow = await executeOne(
      `
      SELECT COUNT(1) AS "count"
      FROM ${SETUP_TABLES.employees} E
      WHERE ${whereSql}
      `,
      binds,
    );

    const rows = await executeRows(
      `
      SELECT ${employeeSelect}
      FROM ${SETUP_TABLES.employees} E
      WHERE ${whereSql}
      ORDER BY E.EMPLOYEE_NUMBER ASC
      OFFSET :offset ROWS FETCH NEXT :limit ROWS ONLY
      `,
      {
        ...binds,
        offset,
        limit: safeLimit,
      },
    );

    return paginated(
      res,
      {
        rows: rows.map(mapEmployee),
        count: Number(countRow?.count || 0),
      },
      safePage,
      safeLimit
    );
  } catch (err) {
    return error(res, err.message);
  }
};

export const getEmployeeByEmployeeNumber = async (req, res) => {
  try {
    const employeeNumber = String(req.params.employeeNumber || '').trim();

    if (!employeeNumber) {
      return badRequest(res, 'Employee number is required');
    }

    const row = await executeOne(
      `
      SELECT ${employeeSelect}
      FROM ${SETUP_TABLES.employees} E
      WHERE LOWER(E.EMPLOYEE_NUMBER) = LOWER(:employeeNumber)
        AND NVL(E.IS_DELETED,0)=0
      FETCH FIRST 1 ROWS ONLY
      `,
      {
        employeeNumber,
      },
    );

    if (!row) {
      return notFound(res, 'Employee not found');
    }

    return success(res, mapEmployee(row), 'Employee details loaded');
  } catch (err) {
    return error(res, err.message);
  }
};

export const getUsers = async (req, res) => {
  try {
    const { page = 1, limit = 50, search, role } = req.query;
    const where = ['NVL(U.IS_DELETED,0)=0'];
    const binds = {};
    if (role) { where.push('LOWER(U.ROLE)=LOWER(:role)'); binds.role = role; }
    if (search) {
      where.push('(LOWER(U.FULL_NAME) LIKE LOWER(:search) OR LOWER(U.EMP_ID) LIKE LOWER(:search) OR LOWER(NVL(U.EMAIL,\'\')) LIKE LOWER(:search) OR LOWER(NVL(U.USERNAME,\'\')) LIKE LOWER(:search))');
      binds.search = `%${search}%`;
    }
    const safePage = Math.max(Number(page) || 1, 1);
    const safeLimit = Math.max(Number(limit) || 50, 1);
    const offset = (safePage - 1) * safeLimit;
    const whereSql = where.join(' AND ');

    const countRow = await executeOne(`SELECT COUNT(1) AS "count" FROM ${SETUP_TABLES.users} U WHERE ${whereSql}`, binds);
    const rows = await executeRows(
      `
      SELECT ${userSelect}
    FROM ${SETUP_TABLES.users} U
    ${roleJoin}
    ${employeeJoin}
    WHERE ${whereSql}
      ORDER BY U.FULL_NAME ASC
      OFFSET :offset ROWS FETCH NEXT :limit ROWS ONLY
      `,
      { ...binds, offset, limit: safeLimit },
    );
    return paginated(res, { rows: rows.map(mapUser), count: Number(countRow?.count || 0) }, safePage, safeLimit);
  } catch (err) { return error(res, err.message); }
};

export const getUser = async (req, res) => {
  try {
    const row = await executeOne(
      `
    SELECT ${userSelect}
    FROM ${SETUP_TABLES.users} U
    ${roleJoin}
    ${employeeJoin}
    WHERE U.ID=:id
      AND NVL(U.IS_DELETED,0)=0
    FETCH FIRST 1 ROWS ONLY
    `,
      { id: req.params.id },
    );
    if (!row) return notFound(res, 'User not found');
    return success(res, mapUser(row));
  } catch (err) { return error(res, err.message); }
};

export const createUser = async (req, res) => {
  try {
    const { password, role_id, ...rest } = req.body;

    if (!rest.empId || !rest.fullName) {
      return badRequest(res, 'Employee ID and Full Name required');
    }

    if (!role_id) {
      return badRequest(res, 'Role is required');
    }

    const role = await fetchRoleByAny(role_id);

    if (!role) {
      return badRequest(res, 'Invalid role selected');
    }

    const hash = await bcrypt.hash(password || 'User@123', 12);
    const userId = newUuid();
    const actor = req.user?.username || 'system';

    await withTransaction(async (connection) => {
      await connection.execute(
        `
        INSERT INTO ${SETUP_TABLES.users}
        (
          ID,
          EMP_ID,
          USERNAME,
          PASSWORD_HASH,
          FULL_NAME,
          EMAIL,
          PHONE,
          ROLE,
          ROLE_ID,
          PLANT,
          DEPARTMENT,
          SHIFT,
          LANGUAGE,
          THEME,
          MUST_CHANGE_PASSWORD,
          SCREEN_PERMISSIONS,
          CREATED_BY,
          UPDATED_BY,
          IS_ACTIVE,
          IS_DELETED,
          CREATED_AT,
          UPDATED_AT
        )
        VALUES
        (
          :id,
          :empId,
          :username,
          :passwordHash,
          :fullName,
          :email,
          :phone,
          :role,
          :roleId,
          :plant,
          :department,
          :shift,
          :language,
          :theme,
          0,
          :screenPermissions,
          :createdBy,
          :updatedBy,
          1,
          0,
          SYSTIMESTAMP,
          SYSTIMESTAMP
        )
        `,
        {
          id: userId,
          empId: rest.empId,
          username: rest.username || rest.empId,
          passwordHash: hash,
          fullName: rest.fullName,
          email: rest.email || null,
          phone: rest.phone || null,
          role: role.name,
          roleId: role.id,
          plant: rest.plant || 'FPP',
          department: rest.department || rest.dept || null,
          shift: rest.shift || 'ANY',
          language: rest.language || 'en',
          theme: rest.theme || 'black',
          screenPermissions: jsonString(rest.screenPermissions || {}, {}),
          createdBy: actor,
          updatedBy: actor,
        }
      );

      await connection.execute(
        `
        INSERT INTO ${SETUP_TABLES.userRoles}
        (
          ID,
          USER_ID,
          ROLE_ID,
          IS_PRIMARY,
          CREATED_AT
        )
        VALUES
        (
          :id,
          :userId,
          :roleId,
          1,
          SYSTIMESTAMP
        )
        `,
        {
          id: await nextNumber(SETUP_TABLES.userRoles, 'ID', connection),
          userId,
          roleId: role.role_id,
        }
      );

      await rebuildUserPermissions(connection, userId);
    });

    return created(
      res,
      {
        id: userId,
        empId: rest.empId,
        username: rest.username || rest.empId,
        fullName: rest.fullName,
        email: rest.email || null,
        role: role.name,
        role_id: role.role_id,
        roleName: role.name,
        plant: rest.plant || 'FPP',
        dept: rest.department || rest.dept || null,
        isActive: true,
      },
      'User created'
    );
  } catch (err) {
    return error(res, err.message);
  }
};

export const updateUser = async (req, res) => {
  try {
    const current = await executeOne(`SELECT ID AS "id" FROM ${SETUP_TABLES.users} WHERE ID=:id AND NVL(IS_DELETED,0)=0`, { id: req.params.id });
    if (!current) return notFound(res, 'User not found');

    let passwordSql = '';
    const binds = {
      id: req.params.id,
      empId: req.body.empId || req.body.emp_id || null,
      username: req.body.username || null,
      fullName: req.body.fullName || req.body.name || null,
      email: req.body.email || null,
      phone: req.body.phone || null,
      plant: req.body.plant || null,
      department: req.body.department || req.body.dept || null,
      shift: req.body.shift || 'ANY',
      isActive: toFlag(req.body.isActive, 1),
      userName: req.user?.username || 'system',
    };
    if (req.body.password) {
      passwordSql = ', PASSWORD_HASH=:passwordHash';
      binds.passwordHash = await bcrypt.hash(req.body.password, 12);
    }

    await executeCommit(
      `
      UPDATE ${SETUP_TABLES.users}
      SET EMP_ID=NVL(:empId, EMP_ID), USERNAME=NVL(:username, USERNAME), FULL_NAME=NVL(:fullName, FULL_NAME),
          EMAIL=:email, PHONE=:phone, PLANT=:plant, DEPARTMENT=:department, SHIFT=:shift,
          IS_ACTIVE=:isActive, UPDATED_BY=:userName, UPDATED_AT=SYSTIMESTAMP ${passwordSql}
      WHERE ID=:id AND NVL(IS_DELETED,0)=0
      `,
      binds,
    );
    return success(res, null, 'User updated');
  } catch (err) { return error(res, err.message); }
};

export const deleteUser = async (req, res) => {
  try {
    const result = await executeCommit(`UPDATE ${SETUP_TABLES.users} SET IS_DELETED=1, IS_ACTIVE=0, UPDATED_AT=SYSTIMESTAMP WHERE ID=:id AND NVL(IS_DELETED,0)=0`, { id: req.params.id });
    if (!result.rowsAffected) return notFound(res, 'User not found');
    return success(res, null, 'User deleted');
  } catch (err) { return error(res, err.message); }
};

export const updatePermissions = async (req, res) => {
  try {
    const result = await executeCommit(
      `UPDATE ${SETUP_TABLES.users} SET SCREEN_PERMISSIONS=:permissions, UPDATED_AT=SYSTIMESTAMP WHERE ID=:id AND NVL(IS_DELETED,0)=0`,
      { id: req.params.id, permissions: jsonString(req.body.permissions || {}, {}) },
    );
    if (!result.rowsAffected) return notFound(res, 'User not found');
    return success(res, null, 'Permissions updated');
  } catch (err) { return error(res, err.message); }
};

export const getRoles = async (_req, res) => {
  try {
    const roles = await listActiveRoles();
    return success(res, roles);
  } catch (err) { return error(res, err.message); }
};

export const getActivityLog = async (req, res) => {
  try {
    const rows = await executeRows(
      `SELECT ID AS "id", USER_ID AS "userId", ACTION AS "action", MODULE AS "module", RECORD_ID AS "recordId", OLD_DATA_JSON AS "oldData", NEW_DATA_JSON AS "newData", IP_ADDRESS AS "ipAddress", USER_AGENT AS "userAgent", CREATED_AT AS "createdAt" FROM ${SETUP_TABLES.auditLogs} WHERE USER_ID=:id OR RECORD_ID=:id ORDER BY CREATED_AT DESC FETCH FIRST 50 ROWS ONLY`,
      { id: req.params.id },
    );
    return success(res, rows);
  } catch (err) { return error(res, err.message); }
};

export default {
  getUsers,
  getUser,

  getEmployees,
  getEmployeeByEmployeeNumber,

  createUser,
  updateUser,
  deleteUser,
  updatePermissions,
  getRoles,
  getActivityLog,
};
