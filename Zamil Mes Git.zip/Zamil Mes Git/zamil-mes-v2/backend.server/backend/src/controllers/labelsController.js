import { success, created, notFound, error, badRequest, paginated } from '../utils/response.js';
import * as labelsModel from '../models/labels.model.js';
import * as packerModel from '../models/packer.model.js';

const normalizeType = (type) => String(type || 'box').trim().toLowerCase();

export const getTemplates = async (req, res) => {
  try {
    const result = await labelsModel.listLabelTemplates(req.query);
    return paginated(res, result, req.query.page || 1, req.query.limit || 100);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getDefaultTemplate = async (req, res) => {
  try {
    const type = normalizeType(req.query.type || req.query.templateType);
    const row = await labelsModel.getDefaultLabelTemplate(type);
    if (!row) return notFound(res, `Default ${type} label template not found`);
    return success(res, row);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getTemplate = async (req, res) => {
  try {
    const row = await labelsModel.getLabelTemplateById(req.params.id);
    if (!row) return notFound(res, 'Label template not found');
    return success(res, row);
  } catch (err) {
    return error(res, err.message);
  }
};

export const createTemplate = async (req, res) => {
  try {
    if (!req.body.templateCode && !req.body.code) return badRequest(res, 'templateCode is required');
    if (!req.body.templateName && !req.body.name) return badRequest(res, 'templateName is required');
    const row = await labelsModel.createLabelTemplate(req.body, req.user);
    return created(res, row, 'Label template created');
  } catch (err) {
    return error(res, err.message);
  }
};

export const updateTemplate = async (req, res) => {
  try {
    const row = await labelsModel.updateLabelTemplate(req.params.id, req.body, req.user);
    if (!row) return notFound(res, 'Label template not found');
    return success(res, row, 'Label template updated');
  } catch (err) {
    return error(res, err.message);
  }
};

export const deleteTemplate = async (req, res) => {
  try {
    const affected = await labelsModel.deleteLabelTemplate(req.params.id, req.user);
    if (!affected) return notFound(res, 'Label template not found');
    return success(res, null, 'Label template deleted');
  } catch (err) {
    return error(res, err.message);
  }
};

export const getPrintJobs = async (req, res) => {
  try {
    const result = await labelsModel.listLabelPrintJobs(req.query);
    return paginated(res, result, req.query.page || 1, req.query.limit || 100);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getPrintHistory = async (req, res) => {
  try {
    const result = await packerModel.listLabelPrintHistory(req.query);
    return paginated(res, result, req.query.page || 1, req.query.limit || 100);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getPrintHistoryById = async (req, res) => {
  try {
    const row = await packerModel.getLabelPrintHistoryById(req.params.id);
    if (!row) return notFound(res, 'Label print history not found');
    return success(res, row);
  } catch (err) {
    return error(res, err.message);
  }
};

export const reprintLabel = async (req, res) => {
  try {
    let labelType = normalizeType(req.body.labelType || req.query.labelType);
    let refId = req.body.refId || req.query.refId;
    let templateId = req.body.templateId || null;
    let sourceHistory = null;

    if (req.body.historyId || req.params.id) {
      sourceHistory = await packerModel.getLabelPrintHistoryById(req.body.historyId || req.params.id);
      if (!sourceHistory) return notFound(res, 'Label print history not found');
      labelType = normalizeType(sourceHistory.labelType);
      refId = sourceHistory.refId;
      templateId = templateId || sourceHistory.templateId || null;
    }

    if (!refId) return badRequest(res, 'refId or historyId is required');

    if (!templateId) {
      const defaultTemplate = await labelsModel.getDefaultLabelTemplate(labelType);
      templateId = defaultTemplate?.id || null;
    }

    const commonPayload = {
      templateId,
      printerName: req.body.printerName || null,
      payload: {
        reprint: true,
        sourceHistory,
        requestedPayload: req.body || {},
        printedFrom: 'MES',
      },
    };

    if (labelType === 'box') {
      const printed = await packerModel.markBoxLabelPrinted({ boxId: refId, ...commonPayload }, req.user);
      return success(res, printed, 'Box label reprinted');
    }

    if (labelType === 'pallet') {
      const printed = await packerModel.markPalletLabelPrinted({ palletId: refId, ...commonPayload }, req.user);
      return success(res, printed, 'Pallet label reprinted');
    }

    return badRequest(res, 'Unsupported labelType. Use box or pallet.');
  } catch (err) {
    if (err.message === 'Box not found') return notFound(res, 'Box not found');
    return error(res, err.message);
  }
};

export default {
  getTemplates,
  getDefaultTemplate,
  getTemplate,
  createTemplate,
  updateTemplate,
  deleteTemplate,
  getPrintJobs,
  getPrintHistory,
  getPrintHistoryById,
  reprintLabel,
};
