import crypto from "node:crypto";
import { getIpDetailsFromRequest } from "../utils/ipDetails.js";

export const getIpDetails = async (req, res) => {
    const requestId = crypto.randomUUID();

    try {
        const details = req.ipDetails || getIpDetailsFromRequest(req);

        if (!details.selectedIp.ip) {
            return res.status(400).json({
                success: false,
                message: "Unable to detect requester IP address",
                data: {
                    requestId,
                    privateIp: null,
                    publicIp: null,
                    details,
                },
            });
        }

        res.setHeader("Cache-Control", "no-store");

        return res.json({
            success: true,
            message: "IP details detected successfully",
            data: {
                requestId,
                detectedAt: new Date().toISOString(),

                requesterIp: details.selectedIp.ip,
                requesterIpVersion: details.selectedIp.version,
                requesterIpScope: details.selectedIp.scope,
                requesterIpSource: details.selectedIp.source,

                privateIp: details.privateIp,
                publicIp: details.publicIp,

                selectedIp: details.selectedIp,

                trustProxy: details.trustProxy,

                candidates: details.candidates,

                proxy: details.proxy,

                clientProvidedPublicIp: details.clientProvidedPublicIp,

                request: details.request,
                machineDeviceInfo: req.machineDeviceInfo || null,

                note: details.publicIp
                    ? "Public IP detected or received from client header."
                    : "Public IP is not available from backend for intranet request unless client sends it or request comes through public network.",
            },
        });
    } catch (err) {
        console.error("IP details API failed:", err);

        return res.status(500).json({
            success: false,
            message: "Failed to detect IP details",
            error: err.message,
            data: {
                requestId,
            },
        });
    }
};