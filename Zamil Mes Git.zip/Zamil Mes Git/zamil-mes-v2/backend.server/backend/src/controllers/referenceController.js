import { success, error } from '../utils/response.js';
import * as referenceModel from '../models/reference.model.js';

const toLabelValue = (row, valueKey = 'code', labelKey = 'name') => ({
  ...row,
  id: row.id || row[valueKey],
  value: row.value || row[valueKey] || row.code || row.name || row.label,
  label: row.label || row[labelKey] || row.name || row.value || row.code,
});

const groupLCChecklist = (rows = []) => {
  const grouped = rows.reduce((acc, item) => {
    const group = item.group || 'general';
    if (!acc[group]) acc[group] = [];
    acc[group].push(item);
    return acc;
  }, {});

  return {
    hygiene: grouped.hygiene || [],
    operations: grouped.operations || grouped.operation || [],
    mold: grouped.mold || [],
    all: rows,
    ...grouped,
  };
};

export const getDefectTypes = async (req, res) => {
  try {
    const rows = await referenceModel.getDefectTypes(req.query);
    return success(res, rows.map((r) => toLabelValue(r, 'code', 'name')));
  } catch (err) {
    return error(res, err.message);
  }
};

export const getWasteTypes = async (_req, res) => {
  try {
    const rows = await referenceModel.getWasteTypes();
    return success(res, rows);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getWasteCategories = async (_req, res) => {
  try {
    const rows = await referenceModel.getWasteCategories();
    return success(res, rows);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getDisposalMethods = async (_req, res) => {
  try {
    const rows = await referenceModel.getDisposalMethods();
    return success(res, rows);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getDowntimeCategories = async (_req, res) => {
  try {
    const rows = await referenceModel.getDowntimeCategories();
    return success(res, rows);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getLCChecklist = async (req, res) => {
  try {
    const rows = await referenceModel.getLCChecklist(req.query);
    return success(res, groupLCChecklist(rows));
  } catch (err) {
    return error(res, err.message);
  }
};

export const getQCChecklist = async (req, res) => {
  try {
    const rows = await referenceModel.getQCChecklist(req.query);
    return success(res, rows.map((r) => ({
      id: r.code || r.id,
      label: r.name,
      description: r.description || r.name,
      ...r,
    })));
  } catch (err) {
    return error(res, err.message);
  }
};

export const getScreens = async (_req, res) => {
  try {
    const rows = await referenceModel.getScreens();
    return success(res, rows);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getFeatures = async (_req, res) => {
  try {
    const rows = await referenceModel.getFeatures();
    return success(res, rows);
  } catch (err) {
    return error(res, err.message);
  }
};

export default {
  getDefectTypes,
  getWasteTypes,
  getWasteCategories,
  getDisposalMethods,
  getDowntimeCategories,
  getLCChecklist,
  getQCChecklist,
  getScreens,
  getFeatures,
};
