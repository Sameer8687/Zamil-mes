import { success, created, notFound, badRequest, error } from '../utils/response.js';
import { executeRows, executeOne, executeCommit } from '../config/oracle.js';
import {
  SETUP_TABLES,
  newUuid,
  toFlag,
  toBool,
  toNumber,
  asJson,
  jsonString,
  cleanObject,
} from '../models/setupAccess.model.js';

const ITEM_MASTER_TABLE = 'MES_ITEM_MASTER';

const STATUS_TO_DISPLAY = { running: 'Running', idle: 'Idle', maintenance: 'Maintenance', breakdown: 'Fault' };
const STATUS_TO_DB = { Running: 'running', Idle: 'idle', Maintenance: 'maintenance', Fault: 'breakdown' };

const normalizeDate = (value) => {
  if (!value) return null;
  if (value instanceof Date) return value;
  return String(value).slice(0, 10);
};

const specsFromMachine = (row = {}) => asJson(row.specs, {});

const mapMachine = (m = {}) => {
  const specs = specsFromMachine(m);
  const rawStatus = String(m.status || 'idle').toLowerCase();
  return {
    id: m.id,
    machineId: m.code,
    code: m.code,
    name: m.name,
    type: m.type || m.machineType,
    machineType: m.type || m.machineType,
    plant: m.plant,
    dept: m.dept || m.department,
    department: m.dept || m.department,
    area: m.area,
    locator: m.locator,
    oem: m.oem,
    model: m.model,
    serial: m.serial || m.serialNo,
    serialNo: m.serial || m.serialNo,
    tonnage: m.tonnage,
    cycleTime: m.cycleTime,
    cavities: m.cavities,
    ip: m.ip || m.ipAddress,
    ipAddress: m.ip || m.ipAddress,
    plcType: m.plcType,
    commProtocol: m.commProtocol,
    mesCode: m.mesCode,
    pmFreq: m.pmFreq,
    lastPmDate: m.lastPmDate,
    status: STATUS_TO_DISPLAY[rawStatus] || m.status || 'Idle',
    pps: specs.pps,
    clampForce: specs.clampForce,
    shotWeight: specs.shotWeight,
    port: specs.port,
    tagRun: specs.tagRun,
    tagProd: specs.tagProd,
    tagReject: specs.tagReject,
    tagAlarm: specs.tagAlarm,
    tagMode: specs.tagMode,
    nextPmDate: specs.nextPmDate,
    notes: specs.notes,
    specs,
    isActive: toBool(m.isActive, true),
    isDeleted: toBool(m.isDeleted, false),
    createdAt: m.createdAt,
    updatedAt: m.updatedAt,
  };
};

const normalizeMachinePayload = (body = {}) => {
  const specs = cleanObject({
    pps: body.pps,
    clampForce: body.clampForce,
    shotWeight: body.shotWeight,
    port: body.port,
    tagRun: body.tagRun,
    tagProd: body.tagProd,
    tagReject: body.tagReject,
    tagAlarm: body.tagAlarm,
    tagMode: body.tagMode,
    nextPmDate: body.nextPmDate,
    notes: body.notes,
  });

  return cleanObject({
    code: String(body.machineId || body.code || '').trim(),
    name: String(body.name || '').trim(),
    type: body.type || body.machineType,
    plant: body.plant,
    dept: body.dept || body.department,
    area: body.area,
    locator: body.locator,
    oem: body.oem,
    model: body.model,
    serial: body.serial || body.serialNo,
    tonnage: body.tonnage,
    cycleTime: toNumber(body.cycleTime),
    cavities: toNumber(body.cavities),
    ip: body.ip || body.ipAddress,
    plcType: body.plcType,
    commProtocol: body.commProtocol,
    mesCode: body.mesCode,
    pmFreq: body.pmFreq,
    lastPmDate: normalizeDate(body.lastPmDate),
    status: STATUS_TO_DB[body.status] || String(body.status || 'idle').toLowerCase(),
    specs: jsonString(specs),
    isActive: toFlag(body.isActive, 1),
  });
};

const machineBindDefaults = {
  code: null, name: null, type: null, plant: null, dept: null, area: null, locator: null,
  oem: null, model: null, serial: null, tonnage: null, cycleTime: null, cavities: null,
  ip: null, plcType: null, commProtocol: null, mesCode: null, pmFreq: null, status: 'idle',
  specs: '{}', isActive: 1, lastPmDate: null,
};
const completeMachineBinds = (p = {}) => ({ ...machineBindDefaults, ...p, lastPmDateValue: p.lastPmDate || null });

export const getOrganizationsLov = async (_req, res) => {
  try {
    const rows = await executeRows(
      `
      WITH org_sources AS (
        SELECT ORGANIZATION_ID AS organization_id, MAX(PLANT) AS plant, 1 AS priority
        FROM ${SETUP_TABLES.machines}
        WHERE ORGANIZATION_ID IS NOT NULL AND NVL(IS_DELETED,0)=0
        GROUP BY ORGANIZATION_ID
        UNION ALL
        SELECT ORGANIZATION_ID AS organization_id, MAX(PLANT) AS plant, 2 AS priority
        FROM MES_WORK_ORDERS
        WHERE ORGANIZATION_ID IS NOT NULL AND NVL(IS_DELETED,0)=0
        GROUP BY ORGANIZATION_ID
      ), org_rollup AS (
        SELECT
          organization_id,
          MAX(plant) KEEP (DENSE_RANK FIRST ORDER BY priority) AS plant
        FROM org_sources
        GROUP BY organization_id
      )
      SELECT
        organization_id AS "organizationId",
        organization_id AS "inventoryOrganizationId",
        CASE
          WHEN organization_id = '300000003595383' THEN 'FPP'
          WHEN organization_id = '300000003595398' THEN 'IPP'
          ELSE NVL(NULLIF(TRIM(plant), ''), organization_id)
        END AS "organizationCode",
        CASE
          WHEN organization_id = '300000003595383' THEN 'FPP BU'
          WHEN organization_id = '300000003595398' THEN 'IPP BU'
          ELSE NVL(NULLIF(TRIM(plant), ''), organization_id)
        END AS "organizationName",
        plant AS "plant",
        'inventory' AS "source"
      FROM org_rollup
      UNION ALL
      SELECT
        TO_CHAR(ID) AS "organizationId",
        TO_CHAR(ID) AS "inventoryOrganizationId",
        CODE AS "organizationCode",
        NAME AS "organizationName",
        NAME AS "plant",
        'org_unit' AS "source"
      FROM ${SETUP_TABLES.orgUnits}
      WHERE NVL(IS_ACTIVE,1)=1
        AND NOT EXISTS (SELECT 1 FROM org_rollup)
      ORDER BY "organizationCode"
      `,
      {},
    );

    return success(res, rows);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getMachines = async (req, res) => {
  try {
    const { search, code, machineId, mesCode, plant, status, department, dept, area } = req.query;
    const where = ['NVL(IS_DELETED,0)=0'];
    const binds = {};
    if (code || machineId) { where.push('LOWER(CODE)=LOWER(:code)'); binds.code = code || machineId; }
    if (mesCode) { where.push('LOWER(MES_CODE)=LOWER(:mesCode)'); binds.mesCode = mesCode; }
    if (plant) { where.push('LOWER(PLANT)=LOWER(:plant)'); binds.plant = plant; }
    if (status) { where.push('LOWER(STATUS)=LOWER(:status)'); binds.status = STATUS_TO_DB[status] || String(status).toLowerCase(); }
    if (department || dept) { where.push('LOWER(DEPARTMENT)=LOWER(:department)'); binds.department = department || dept; }
    if (area) { where.push('LOWER(AREA)=LOWER(:area)'); binds.area = area; }
    if (search) {
      where.push('(LOWER(CODE) LIKE LOWER(:search) OR LOWER(NAME) LIKE LOWER(:search) OR LOWER(NVL(MES_CODE,\'\')) LIKE LOWER(:search) OR LOWER(NVL(LOCATOR,\'\')) LIKE LOWER(:search))');
      binds.search = `%${search}%`;
    }

    const rows = await executeRows(
      `
      SELECT ID AS "id", CODE AS "code", NAME AS "name", MACHINE_TYPE AS "type",
             PLANT AS "plant", DEPARTMENT AS "dept", AREA AS "area", LOCATOR AS "locator",
             OEM AS "oem", MODEL AS "model", SERIAL_NO AS "serial", TONNAGE AS "tonnage",
             CYCLE_TIME AS "cycleTime", CAVITIES AS "cavities", IP_ADDRESS AS "ip",
             PLC_TYPE AS "plcType", COMM_PROTOCOL AS "commProtocol", MES_CODE AS "mesCode",
             PM_FREQ AS "pmFreq", LAST_PM_DATE AS "lastPmDate", STATUS AS "status",
             SPECS_JSON AS "specs", IS_ACTIVE AS "isActive", IS_DELETED AS "isDeleted",
             CREATED_AT AS "createdAt", UPDATED_AT AS "updatedAt"
      FROM ${SETUP_TABLES.machines}
      WHERE ${where.join(' AND ')}
      ORDER BY CODE ASC
      `,
      binds,
    );

    return success(res, rows.map(mapMachine));
  } catch (err) { return error(res, err.message); }
};

export const createMachine = async (req, res) => {
  try {
    const p = normalizeMachinePayload(req.body);

    if (!p.code || !p.name) {
      return badRequest(res, 'Machine code and name are required');
    }

    const id = newUuid();
    const actor = req.user?.username || 'system';

    const binds = {
      b_id: id,
      b_code: p.code || null,
      b_name: p.name || null,
      b_machine_type: p.type || null,
      b_plant: p.plant || null,
      b_department: p.dept || null,
      b_area: p.area || null,
      b_locator: p.locator || null,
      b_oem: p.oem || null,
      b_model: p.model || null,
      b_serial_no: p.serial || null,
      b_tonnage: p.tonnage || null,
      b_cycle_time: p.cycleTime ?? null,
      b_cavities: p.cavities ?? null,
      b_ip_address: p.ip || null,
      b_plc_type: p.plcType || null,
      b_comm_protocol: p.commProtocol || null,
      b_mes_code: p.mesCode || null,
      b_pm_freq: p.pmFreq || null,
      b_last_pm_date: p.lastPmDate || null,
      b_status: p.status || 'idle',
      b_specs_json: p.specs || '{}',
      b_created_by: actor,
      b_updated_by: actor,
      b_is_active: p.isActive ?? 1,
    };

    await executeCommit(
      `
      INSERT INTO ${SETUP_TABLES.machines}
      (
        ID,
        CODE,
        NAME,
        MACHINE_TYPE,
        PLANT,
        DEPARTMENT,
        AREA,
        LOCATOR,
        OEM,
        MODEL,
        SERIAL_NO,
        TONNAGE,
        CYCLE_TIME,
        CAVITIES,
        IP_ADDRESS,
        PLC_TYPE,
        COMM_PROTOCOL,
        MES_CODE,
        PM_FREQ,
        LAST_PM_DATE,
        STATUS,
        SPECS_JSON,
        CREATED_BY,
        UPDATED_BY,
        IS_ACTIVE,
        IS_DELETED,
        CREATED_AT,
        UPDATED_AT
      )
      VALUES
      (
        :b_id,
        :b_code,
        :b_name,
        :b_machine_type,
        :b_plant,
        :b_department,
        :b_area,
        :b_locator,
        :b_oem,
        :b_model,
        :b_serial_no,
        :b_tonnage,
        :b_cycle_time,
        :b_cavities,
        :b_ip_address,
        :b_plc_type,
        :b_comm_protocol,
        :b_mes_code,
        :b_pm_freq,
        TO_DATE(:b_last_pm_date, 'YYYY-MM-DD'),
        :b_status,
        :b_specs_json,
        :b_created_by,
        :b_updated_by,
        :b_is_active,
        0,
        SYSTIMESTAMP,
        SYSTIMESTAMP
      )
      `,
      binds
    );

    const row = await executeOne(
      `
      SELECT
        ID AS "id",
        CODE AS "code",
        NAME AS "name",
        MACHINE_TYPE AS "type",
        PLANT AS "plant",
        DEPARTMENT AS "dept",
        AREA AS "area",
        LOCATOR AS "locator",
        OEM AS "oem",
        MODEL AS "model",
        SERIAL_NO AS "serial",
        TONNAGE AS "tonnage",
        CYCLE_TIME AS "cycleTime",
        CAVITIES AS "cavities",
        IP_ADDRESS AS "ip",
        PLC_TYPE AS "plcType",
        COMM_PROTOCOL AS "commProtocol",
        MES_CODE AS "mesCode",
        PM_FREQ AS "pmFreq",
        LAST_PM_DATE AS "lastPmDate",
        STATUS AS "status",
        SPECS_JSON AS "specs",
        IS_ACTIVE AS "isActive",
        IS_DELETED AS "isDeleted",
        CREATED_AT AS "createdAt",
        UPDATED_AT AS "updatedAt"
      FROM ${SETUP_TABLES.machines}
      WHERE ID = :b_id
      `,
      {
        b_id: id,
      }
    );

    return created(res, mapMachine(row), 'Machine created');
  } catch (err) {
    return error(res, err.message);
  }
};

export const updateMachine = async (req, res) => {
  try {
    const p = normalizeMachinePayload(req.body);
    const actor = req.user?.username || 'system';

    const binds = {
      b_id: req.params.id,
      b_code: p.code || null,
      b_name: p.name || null,
      b_machine_type: p.type || null,
      b_plant: p.plant || null,
      b_department: p.dept || null,
      b_area: p.area || null,
      b_locator: p.locator || null,
      b_oem: p.oem || null,
      b_model: p.model || null,
      b_serial_no: p.serial || null,
      b_tonnage: p.tonnage || null,
      b_cycle_time: p.cycleTime ?? null,
      b_cavities: p.cavities ?? null,
      b_ip_address: p.ip || null,
      b_plc_type: p.plcType || null,
      b_comm_protocol: p.commProtocol || null,
      b_mes_code: p.mesCode || null,
      b_pm_freq: p.pmFreq || null,
      b_last_pm_date: p.lastPmDate || null,
      b_status: p.status || 'idle',
      b_specs_json: p.specs || '{}',
      b_updated_by: actor,
      b_is_active: p.isActive ?? 1,
    };

    const result = await executeCommit(
      `
      UPDATE ${SETUP_TABLES.machines}
      SET
        CODE = :b_code,
        NAME = :b_name,
        MACHINE_TYPE = :b_machine_type,
        PLANT = :b_plant,
        DEPARTMENT = :b_department,
        AREA = :b_area,
        LOCATOR = :b_locator,
        OEM = :b_oem,
        MODEL = :b_model,
        SERIAL_NO = :b_serial_no,
        TONNAGE = :b_tonnage,
        CYCLE_TIME = :b_cycle_time,
        CAVITIES = :b_cavities,
        IP_ADDRESS = :b_ip_address,
        PLC_TYPE = :b_plc_type,
        COMM_PROTOCOL = :b_comm_protocol,
        MES_CODE = :b_mes_code,
        PM_FREQ = :b_pm_freq,
        LAST_PM_DATE = TO_DATE(:b_last_pm_date, 'YYYY-MM-DD'),
        STATUS = :b_status,
        SPECS_JSON = :b_specs_json,
        UPDATED_BY = :b_updated_by,
        IS_ACTIVE = :b_is_active,
        UPDATED_AT = SYSTIMESTAMP
      WHERE ID = :b_id
        AND NVL(IS_DELETED, 0) = 0
      `,
      binds
    );

    if (!result.rowsAffected) {
      return notFound(res, 'Machine not found');
    }

    const row = await executeOne(
      `
      SELECT
        ID AS "id",
        CODE AS "code",
        NAME AS "name",
        MACHINE_TYPE AS "type",
        PLANT AS "plant",
        DEPARTMENT AS "dept",
        AREA AS "area",
        LOCATOR AS "locator",
        OEM AS "oem",
        MODEL AS "model",
        SERIAL_NO AS "serial",
        TONNAGE AS "tonnage",
        CYCLE_TIME AS "cycleTime",
        CAVITIES AS "cavities",
        IP_ADDRESS AS "ip",
        PLC_TYPE AS "plcType",
        COMM_PROTOCOL AS "commProtocol",
        MES_CODE AS "mesCode",
        PM_FREQ AS "pmFreq",
        LAST_PM_DATE AS "lastPmDate",
        STATUS AS "status",
        SPECS_JSON AS "specs",
        IS_ACTIVE AS "isActive",
        IS_DELETED AS "isDeleted",
        CREATED_AT AS "createdAt",
        UPDATED_AT AS "updatedAt"
      FROM ${SETUP_TABLES.machines}
      WHERE ID = :b_id
      `,
      {
        b_id: req.params.id,
      }
    );

    return success(res, mapMachine(row), 'Machine updated');
  } catch (err) {
    return error(res, err.message);
  }
};

export const deleteMachine = async (req, res) => {
  try {
    const result = await executeCommit(
      `UPDATE ${SETUP_TABLES.machines} SET IS_DELETED=1, IS_ACTIVE=0, UPDATED_AT=SYSTIMESTAMP WHERE ID=:id AND NVL(IS_DELETED,0)=0`,
      { id: req.params.id },
    );
    if (!result.rowsAffected) return notFound(res, 'Machine not found');
    return success(res, null, 'Machine deleted');
  } catch (err) { return error(res, err.message); }
};

const LOC_ZONE_VALUES = ['PRD', 'SIL', 'STG', 'ASM', 'QA', 'RJT', 'HLD'];
const LOC_DIV_VALUES = ['FPP', 'IPP', 'ZPC'];

const normalizeDiv = (value) => {
  const v = String(value || '').trim().toUpperCase().replace(' BU', '');
  return LOC_DIV_VALUES.includes(v) ? v : 'FPP';
};

const normalizeZone = (value) => {
  const v = String(value || '').trim().toUpperCase();
  if (['PRODUCTION', 'PROD', 'MACHINE'].includes(v)) return 'PRD';
  if (v === 'SILO') return 'SIL';
  if (['WAREHOUSE', 'WH', 'STAGING'].includes(v)) return 'STG';
  if (v === 'ASSEMBLY') return 'ASM';
  if (['QUALITY', 'QC'].includes(v)) return 'QA';
  if (['SCRAP', 'REJECT', 'REJECTED'].includes(v)) return 'RJT';
  if (['HOLD', 'BLOCKED'].includes(v)) return 'HLD';
  return LOC_ZONE_VALUES.includes(v) ? v : 'PRD';
};

const cleanCodePart = (value) => String(value || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '');

const buildLocatorCode = ({ zone, area, section, level }) => {
  const code = `${normalizeZone(zone)}${cleanCodePart(area)}${cleanCodePart(section)}${cleanCodePart(level || 'L1')}`;
  return code || `PRDLOC${Date.now()}`;
};

const parseAuthUsers = (value) => {
  if (Array.isArray(value)) return value;
  if (!value) return [];
  if (typeof value === 'string') {
    try {
      const parsed = JSON.parse(value);
      if (Array.isArray(parsed)) return parsed;
      if (typeof parsed === 'string') return parsed.split(/[,\n]/).map((v) => v.trim()).filter(Boolean);
    } catch (_err) {
      return value.split(/[,\n]/).map((v) => v.trim()).filter(Boolean);
    }
  }
  return [];
};

const stringifyAuthUsers = (value) => JSON.stringify(parseAuthUsers(value));

const mapLocation = (row = {}) => {
  const division = normalizeDiv(row.division || row.plant || row.div);
  const zone = normalizeZone(row.type || row.zone || row.locationZone || row.plant);
  const area = row.area || row.name || '';
  const section = row.section || '';
  const level = row.level || 'L1';
  const locator = String(row.locator || row.code || buildLocatorCode({ zone, area, section, level })).toUpperCase();
  const barcode = String(row.barcode || `LOC-${locator}`).toUpperCase();

  return {
    id: row.id,
    code: locator,
    name: row.name || area,
    type: zone,
    plant: division,
    zone,
    div: division,
    division,
    area,
    section,
    level,
    locator,
    barcode,
    locType: row.locType || 'FLOOR',
    status: row.status || (toBool(row.isActive, true) ? 'Active' : 'Inactive'),
    minUnits: Number(row.minUnits || 0),
    maxUnits: Number(row.maxUnits || 0),
    maxLPN: Number(row.maxLPN || 9),
    usedLPN: Number(row.usedLPN || 0),
    uom: row.uom || 'BOX',
    multiSKU: row.multiSKU || 'Yes',
    partialPick: row.partialPick || 'Yes',
    specificSKU: row.specificSKU || '',
    maxWeight: Number(row.maxWeight || 2000),
    owner: row.owner || '',
    authUsers: parseAuthUsers(row.authUsers),
    access: row.accessRestriction || 'AuthList',
    accessRestriction: row.accessRestriction || 'AuthList',
    notes: row.notes || '',
    createdBy: row.createdBy,
    updatedBy: row.updatedBy,
    isActive: toBool(row.isActive, true),
    isDeleted: toBool(row.isDeleted, false),
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
  };
};

const buildLocationPayload = (body = {}, user) => {
  const division = normalizeDiv(body.division || body.div || body.org || body.plant);
  const zone = normalizeZone(body.zone || body.locationZone || body.type || body.locPlant || body.plantZone);
  const area = String(body.area || body.name || '').trim().toUpperCase();
  const section = String(body.section || '').trim().toUpperCase();
  const level = String(body.level || 'L1').trim().toUpperCase();
  const locator = String(body.locator || body.code || buildLocatorCode({ zone, area, section, level })).trim().toUpperCase();
  const barcode = String(body.barcode || `LOC-${locator}`).trim().toUpperCase();
  const maxLPN = Number(body.maxLPN || body.maxLpn) || 9;
  const usedLPN = Math.min(maxLPN, Number(body.usedLPN) || 0);
  const status = body.status || (body.isActive === false ? 'Inactive' : 'Active');

  return {
    code: locator,
    name: area || locator,
    type: zone,
    plant: division,
    division,
    area,
    section,
    level,
    locator,
    barcode,
    locType: body.locType || body.locationType || 'FLOOR',
    status,
    minUnits: Number(body.minUnits) || 0,
    maxUnits: Number(body.maxUnits) || maxLPN * 500,
    maxLPN,
    usedLPN,
    uom: body.uom || 'BOX',
    multiSKU: body.multiSKU || body.allowMultiSku || 'Yes',
    partialPick: body.partialPick || body.partialPickAllowed || 'Yes',
    specificSKU: body.specificSKU || body.specificSkuRestriction || null,
    maxWeight: Number(body.maxWeight || body.maxWeightKg) || 2000,
    owner: body.owner || body.primaryOwner || null,
    authUsers: stringifyAuthUsers(body.authUsers || body.authorizedUsers),
    accessRestriction: body.accessRestriction || body.access || 'AuthList',
    notes: body.notes || null,
    isActive: status !== 'Inactive' && body.isActive !== false ? 1 : 0,
    updatedBy: user?.username || 'system',
  };
};

const locationSelect = `
  SELECT
    ID AS "id",
    CODE AS "code",
    NAME AS "name",
    LOCATION_TYPE AS "type",
    PLANT AS "plant",
    DIVISION AS "division",
    AREA AS "area",
    SECTION AS "section",
    LOCATION_LEVEL AS "level",
    LOCATOR AS "locator",
    BARCODE AS "barcode",
    LOC_TYPE AS "locType",
    STATUS AS "status",
    MIN_UNITS AS "minUnits",
    MAX_UNITS AS "maxUnits",
    MAX_LPN AS "maxLPN",
    USED_LPN AS "usedLPN",
    UOM AS "uom",
    MULTI_SKU AS "multiSKU",
    PARTIAL_PICK AS "partialPick",
    SPECIFIC_SKU AS "specificSKU",
    MAX_WEIGHT AS "maxWeight",
    OWNER AS "owner",
    AUTH_USERS_JSON AS "authUsers",
    ACCESS_RESTRICTION AS "accessRestriction",
    NOTES AS "notes",
    CREATED_BY AS "createdBy",
    UPDATED_BY AS "updatedBy",
    IS_ACTIVE AS "isActive",
    IS_DELETED AS "isDeleted",
    CREATED_AT AS "createdAt",
    UPDATED_AT AS "updatedAt"
  FROM ${SETUP_TABLES.locations}
`;

const locationDefaultBinds = {
  code: null,
  name: null,
  type: null,
  plant: null,
  division: null,
  area: null,
  section: null,
  level: null,
  locator: null,
  barcode: null,
  locType: null,
  status: null,
  minUnits: 0,
  maxUnits: 0,
  maxLPN: 9,
  usedLPN: 0,
  uom: 'BOX',
  multiSKU: 'Yes',
  partialPick: 'Yes',
  specificSKU: null,
  maxWeight: 2000,
  owner: null,
  authUsers: '[]',
  accessRestriction: 'AuthList',
  notes: null,
  isActive: 1,
  updatedBy: 'system',
};

const completeLocationBinds = (payload = {}) => ({ ...locationDefaultBinds, ...payload });

export const getLocations = async (req, res) => {
  try {
    const { div, division, plant, zone, type, status, search } = req.query;
    const where = ['NVL(IS_DELETED,0)=0'];
    const binds = {};
    const divFilter = div || division;
    const zoneFilter = zone || type;

    if (divFilter || plant) { where.push('LOWER(DIVISION)=LOWER(:division)'); binds.division = normalizeDiv(divFilter || plant); }
    if (zoneFilter) { where.push('LOWER(LOCATION_TYPE)=LOWER(:zone)'); binds.zone = normalizeZone(zoneFilter); }
    if (status) { where.push('LOWER(STATUS)=LOWER(:status)'); binds.status = status; }
    if (search) {
      where.push(`(
        LOWER(CODE) LIKE LOWER(:search)
        OR LOWER(NVL(LOCATOR,'')) LIKE LOWER(:search)
        OR LOWER(NVL(BARCODE,'')) LIKE LOWER(:search)
        OR LOWER(NAME) LIKE LOWER(:search)
        OR LOWER(NVL(AREA,'')) LIKE LOWER(:search)
        OR LOWER(NVL(OWNER,'')) LIKE LOWER(:search)
      )`);
      binds.search = `%${search}%`;
    }

    const rows = await executeRows(
      `${locationSelect} WHERE ${where.join(' AND ')} ORDER BY CODE ASC`,
      binds,
    );
    return success(res, rows.map(mapLocation));
  } catch (err) { return error(res, err.message); }
};

export const createLocation = async (req, res) => {
  try {
    const payload = buildLocationPayload(req.body, req.user);

    if (!payload.area) {
      return badRequest(res, 'Area is required');
    }

    const id = newUuid();
    const actor = req.user?.username || 'system';

    const binds = {
      b_id: id,
      b_code: payload.code || null,
      b_name: payload.name || null,
      b_location_type: payload.type || null,
      b_plant: payload.plant || null,
      b_created_by: actor,
      b_updated_by: payload.updatedBy || actor,
      b_is_active: payload.isActive ?? 1,

      b_division: payload.division || null,
      b_area: payload.area || null,
      b_section: payload.section || null,
      b_location_level: payload.level || null,
      b_locator: payload.locator || null,
      b_barcode: payload.barcode || null,
      b_loc_type: payload.locType || null,
      b_status: payload.status || 'Active',

      b_min_units: payload.minUnits ?? 0,
      b_max_units: payload.maxUnits ?? 0,
      b_max_lpn: payload.maxLPN ?? 9,
      b_used_lpn: payload.usedLPN ?? 0,
      b_uom: payload.uom || 'BOX',
      b_multi_sku: payload.multiSKU || 'Yes',
      b_partial_pick: payload.partialPick || 'Yes',
      b_specific_sku: payload.specificSKU || null,
      b_max_weight: payload.maxWeight ?? 2000,

      b_owner: payload.owner || actor,
      b_auth_users: payload.authUsers || '[]',
      b_access_restriction: payload.accessRestriction || 'AuthList',
      b_notes: payload.notes || null,
    };

    await executeCommit(
      `
      INSERT INTO ${SETUP_TABLES.locations}
      (
        ID,
        CODE,
        NAME,
        LOCATION_TYPE,
        PLANT,
        CREATED_BY,
        UPDATED_BY,
        IS_ACTIVE,
        IS_DELETED,
        CREATED_AT,
        UPDATED_AT,
        DIVISION,
        AREA,
        SECTION,
        LOCATION_LEVEL,
        LOCATOR,
        BARCODE,
        LOC_TYPE,
        STATUS,
        MIN_UNITS,
        MAX_UNITS,
        MAX_LPN,
        USED_LPN,
        UOM,
        MULTI_SKU,
        PARTIAL_PICK,
        SPECIFIC_SKU,
        MAX_WEIGHT,
        OWNER,
        AUTH_USERS_JSON,
        ACCESS_RESTRICTION,
        NOTES
      )
      VALUES
      (
        :b_id,
        :b_code,
        :b_name,
        :b_location_type,
        :b_plant,
        :b_created_by,
        :b_updated_by,
        :b_is_active,
        0,
        SYSTIMESTAMP,
        SYSTIMESTAMP,
        :b_division,
        :b_area,
        :b_section,
        :b_location_level,
        :b_locator,
        :b_barcode,
        :b_loc_type,
        :b_status,
        :b_min_units,
        :b_max_units,
        :b_max_lpn,
        :b_used_lpn,
        :b_uom,
        :b_multi_sku,
        :b_partial_pick,
        :b_specific_sku,
        :b_max_weight,
        :b_owner,
        :b_auth_users,
        :b_access_restriction,
        :b_notes
      )
      `,
      binds
    );

    const row = await executeOne(
      `${locationSelect} WHERE ID = :b_id`,
      {
        b_id: id,
      }
    );

    return created(res, mapLocation(row), 'Location created');
  } catch (err) {
    return error(res, err.message);
  }
};

export const updateLocation = async (req, res) => {
  try {
    const payload = buildLocationPayload(req.body, req.user);

    if (!payload.area) {
      return badRequest(res, 'Area is required');
    }

    const actor = req.user?.username || 'system';

    const binds = {
      b_id: req.params.id,
      b_code: payload.code || null,
      b_name: payload.name || null,
      b_location_type: payload.type || null,
      b_plant: payload.plant || null,
      b_updated_by: payload.updatedBy || actor,
      b_is_active: payload.isActive ?? 1,
      b_division: payload.division || null,
      b_area: payload.area || null,
      b_section: payload.section || null,
      b_location_level: payload.level || null,
      b_locator: payload.locator || null,
      b_barcode: payload.barcode || null,
      b_loc_type: payload.locType || null,
      b_status: payload.status || 'Active',
      b_min_units: payload.minUnits ?? 0,
      b_max_units: payload.maxUnits ?? 0,
      b_max_lpn: payload.maxLPN ?? 9,
      b_used_lpn: payload.usedLPN ?? 0,
      b_uom: payload.uom || 'BOX',
      b_multi_sku: payload.multiSKU || 'Yes',
      b_partial_pick: payload.partialPick || 'Yes',
      b_specific_sku: payload.specificSKU || null,
      b_max_weight: payload.maxWeight ?? 2000,
      b_owner: payload.owner || actor,
      b_auth_users: payload.authUsers || '[]',
      b_access_restriction: payload.accessRestriction || 'AuthList',
      b_notes: payload.notes || null,
    };

    const result = await executeCommit(
      `
      UPDATE ${SETUP_TABLES.locations}
      SET
        CODE = :b_code,
        NAME = :b_name,
        LOCATION_TYPE = :b_location_type,
        PLANT = :b_plant,
        UPDATED_BY = :b_updated_by,
        IS_ACTIVE = :b_is_active,
        UPDATED_AT = SYSTIMESTAMP,
        DIVISION = :b_division,
        AREA = :b_area,
        SECTION = :b_section,
        LOCATION_LEVEL = :b_location_level,
        LOCATOR = :b_locator,
        BARCODE = :b_barcode,
        LOC_TYPE = :b_loc_type,
        STATUS = :b_status,
        MIN_UNITS = :b_min_units,
        MAX_UNITS = :b_max_units,
        MAX_LPN = :b_max_lpn,
        USED_LPN = :b_used_lpn,
        UOM = :b_uom,
        MULTI_SKU = :b_multi_sku,
        PARTIAL_PICK = :b_partial_pick,
        SPECIFIC_SKU = :b_specific_sku,
        MAX_WEIGHT = :b_max_weight,
        OWNER = :b_owner,
        AUTH_USERS_JSON = :b_auth_users,
        ACCESS_RESTRICTION = :b_access_restriction,
        NOTES = :b_notes
      WHERE ID = :b_id
        AND NVL(IS_DELETED, 0) = 0
      `,
      binds
    );

    if (!result.rowsAffected) {
      return notFound(res, 'Location not found');
    }

    const row = await executeOne(
      `${locationSelect} WHERE ID = :b_id`,
      {
        b_id: req.params.id,
      }
    );

    return success(res, mapLocation(row), 'Location updated');
  } catch (err) {
    return error(res, err.message);
  }
};

export const deleteLocation = async (req, res) => {
  try {
    const result = await executeCommit(
      `UPDATE ${SETUP_TABLES.locations} SET IS_DELETED=1, IS_ACTIVE=0, UPDATED_BY=:userName, UPDATED_AT=SYSTIMESTAMP WHERE ID=:id AND NVL(IS_DELETED,0)=0`,
      { id: req.params.id, userName: req.user?.username || 'system' },
    );
    if (!result.rowsAffected) return notFound(res, 'Location not found');
    return success(res, null, 'Location deleted');
  } catch (err) { return error(res, err.message); }
};

export const getShifts = async (_req, res) => {
  try {
    const rows = await executeRows(
      `SELECT ID AS "id", NAME AS "name", START_TIME AS "startTime", END_TIME AS "endTime", PLANT AS "plant", IS_ACTIVE AS "isActive", IS_DELETED AS "isDeleted", CREATED_AT AS "createdAt", UPDATED_AT AS "updatedAt" FROM ${SETUP_TABLES.shifts} WHERE NVL(IS_DELETED,0)=0 ORDER BY PLANT, START_TIME, NAME`,
    );
    return success(res, rows.map((r) => ({ ...r, isActive: toBool(r.isActive, true) })));
  } catch (err) { return error(res, err.message); }
};

export const createShift = async (req, res) => {
  try {
    const id = newUuid();
    const p = { name: req.body.name, startTime: req.body.startTime, endTime: req.body.endTime, plant: req.body.plant || 'FPP', isActive: toFlag(req.body.isActive, 1) };
    if (!p.name) return badRequest(res, 'Shift name is required');
    const actor = req.user?.username || 'system';

    await executeCommit(
      `
    INSERT INTO ${SETUP_TABLES.shifts}
    (
      ID,
      NAME,
      START_TIME,
      END_TIME,
      PLANT,
      CREATED_BY,
      UPDATED_BY,
      IS_ACTIVE,
      IS_DELETED,
      CREATED_AT,
      UPDATED_AT
    )
    VALUES
    (
      :id,
      :name,
      :startTime,
      :endTime,
      :plant,
      :createdBy,
      :updatedBy,
      :isActive,
      0,
      SYSTIMESTAMP,
      SYSTIMESTAMP
    )
    `,
      {
        ...p,
        id,
        createdBy: actor,
        updatedBy: actor,
      }
    );
    return created(res, { id, ...p }, 'Shift created');
  } catch (err) { return error(res, err.message); }
};

export const updateShift = async (req, res) => {
  try {
    const p = { name: req.body.name, startTime: req.body.startTime, endTime: req.body.endTime, plant: req.body.plant || 'FPP', isActive: toFlag(req.body.isActive, 1) };
    const result = await executeCommit(`UPDATE ${SETUP_TABLES.shifts} SET NAME=:name, START_TIME=:startTime, END_TIME=:endTime, PLANT=:plant, IS_ACTIVE=:isActive, UPDATED_BY=:userName, UPDATED_AT=SYSTIMESTAMP WHERE ID=:id AND NVL(IS_DELETED,0)=0`, { ...p, id: req.params.id, userName: req.user?.username || 'system' });
    if (!result.rowsAffected) return notFound(res, 'Shift not found');
    return success(res, { id: req.params.id, ...p }, 'Shift updated');
  } catch (err) { return error(res, err.message); }
};

export const deleteShift = async (req, res) => {
  try {
    const result = await executeCommit(`UPDATE ${SETUP_TABLES.shifts} SET IS_DELETED=1, IS_ACTIVE=0, UPDATED_AT=SYSTIMESTAMP WHERE ID=:id AND NVL(IS_DELETED,0)=0`, { id: req.params.id });
    if (!result.rowsAffected) return notFound(res, 'Shift not found');
    return success(res, null, 'Shift deleted');
  } catch (err) { return error(res, err.message); }
};

export const getConfigs = async (req, res) => {
  try {
    const where = ['NVL(IS_DELETED,0)=0'];
    const binds = {};
    if (req.query.key) { where.push('CONFIG_KEY=:key'); binds.key = req.query.key; }
    const rows = await executeRows(`SELECT ID AS "id", CONFIG_KEY AS "key", CONFIG_VALUE AS "value", CATEGORY AS "category", DESCRIPTION AS "description", IS_ACTIVE AS "isActive", CREATED_AT AS "createdAt", UPDATED_AT AS "updatedAt" FROM ${SETUP_TABLES.systemConfigs} WHERE ${where.join(' AND ')} ORDER BY CATEGORY, CONFIG_KEY`, binds);
    return success(res, rows);
  } catch (err) { return error(res, err.message); }
};

export const upsertConfig = async (req, res) => {
  try {
    const key = req.body.key || req.body.configKey;
    const value = req.body.value ?? req.body.configValue;
    if (!key) return badRequest(res, 'Config key is required');
    const existing = await executeOne(`SELECT ID AS "id" FROM ${SETUP_TABLES.systemConfigs} WHERE CONFIG_KEY=:key AND NVL(IS_DELETED,0)=0 FETCH FIRST 1 ROWS ONLY`, { key });
    if (existing) {
      await executeCommit(`UPDATE ${SETUP_TABLES.systemConfigs} SET CONFIG_VALUE=:value, CATEGORY=:category, DESCRIPTION=:description, UPDATED_BY=:userName, UPDATED_AT=SYSTIMESTAMP WHERE ID=:id`, { id: existing.id, value, category: req.body.category || 'general', description: req.body.description || null, userName: req.user?.username || 'system' });
    } else {
      const actor = req.user?.username || 'system';

      await executeCommit(
        `
  INSERT INTO ${SETUP_TABLES.systemConfigs}
  (
    ID,
    CONFIG_KEY,
    CONFIG_VALUE,
    CATEGORY,
    DESCRIPTION,
    CREATED_BY,
    UPDATED_BY,
    IS_ACTIVE,
    IS_DELETED,
    CREATED_AT,
    UPDATED_AT
  )
  VALUES
  (
    :id,
    :key,
    :value,
    :category,
    :description,
    :createdBy,
    :updatedBy,
    1,
    0,
    SYSTIMESTAMP,
    SYSTIMESTAMP
  )
  `,
        {
          id: newUuid(),
          key,
          value,
          category: req.body.category || 'general',
          description: req.body.description || null,
          createdBy: actor,
          updatedBy: actor,
        }
      );
    }
    return success(res, req.body, 'Config saved');
  } catch (err) { return error(res, err.message); }
};

export const getBoxQtyReport = async (req, res) => {
  try {
    const { org, code, productCode, search } = req.query;
    const where = ['NVL(IS_DELETED,0)=0'];
    const binds = {};
    if (org) { where.push('ORG=:org'); binds.org = org; }
    if (code || productCode) { where.push('PRODUCT_CODE=:code'); binds.code = code || productCode; }
    if (search) { where.push('(LOWER(PRODUCT_CODE) LIKE LOWER(:search) OR LOWER(PRODUCT_DESC) LIKE LOWER(:search))'); binds.search = `%${search}%`; }
    const rows = await executeRows(
      `SELECT ID AS "id", ORG AS "org", PRODUCT_CODE AS "productCode", PRODUCT_DESC AS "productDesc", QTY_PER_BOX AS "qtyPerBox", EFFECTIVE_DATE AS "effectiveDate", IS_ACTIVE AS "isActive", CREATED_AT AS "createdAt", UPDATED_AT AS "updatedAt" FROM ${SETUP_TABLES.boxQtyRecords} WHERE ${where.join(' AND ')} ORDER BY ORG, PRODUCT_CODE, EFFECTIVE_DATE DESC`,
      binds,
    );
    return success(res, rows.map((r) => ({ id: r.id, org: r.org, code: r.productCode, productCode: r.productCode, desc: r.productDesc, productDesc: r.productDesc, qty: r.qtyPerBox, qtyPerBox: r.qtyPerBox, effectiveDate: r.effectiveDate, isActive: toBool(r.isActive, true), createdAt: r.createdAt, updatedAt: r.updatedAt })));
  } catch (err) { return error(res, err.message); }
};

const csvValue = (value) => {
  if (value === undefined || value === null) return '';
  const text = String(value).replace(/"/g, '""');
  return /[",\n]/.test(text) ? `"${text}"` : text;
};

export const exportBoxQtyReport = async (req, res) => {
  try {
    const { org, code, productCode, search } = req.query;
    const where = ['NVL(IS_DELETED,0)=0'];
    const binds = {};

    if (org) { where.push('ORG=:org'); binds.org = org; }
    if (code || productCode) { where.push('PRODUCT_CODE=:code'); binds.code = code || productCode; }
    if (search) {
      where.push('(LOWER(PRODUCT_CODE) LIKE LOWER(:search) OR LOWER(PRODUCT_DESC) LIKE LOWER(:search))');
      binds.search = `%${search}%`;
    }

    const rows = await executeRows(
      `SELECT ORG AS "org", PRODUCT_CODE AS "productCode", PRODUCT_DESC AS "productDesc", QTY_PER_BOX AS "qtyPerBox", EFFECTIVE_DATE AS "effectiveDate", IS_ACTIVE AS "isActive" FROM ${SETUP_TABLES.boxQtyRecords} WHERE ${where.join(' AND ')} ORDER BY ORG, PRODUCT_CODE, EFFECTIVE_DATE DESC`,
      binds,
    );

    const headers = ['Org', 'Product Code', 'Product Description', 'Qty Per Box', 'Effective Date', 'Status'];
    const body = rows.map((row) => [
      row.org,
      row.productCode,
      row.productDesc,
      row.qtyPerBox,
      row.effectiveDate,
      toBool(row.isActive, true) ? 'Active' : 'Inactive',
    ]);

    const csv = [headers, ...body].map((row) => row.map(csvValue).join(',')).join('\n');

    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="box-qty-report-${new Date().toISOString().slice(0, 10)}.csv"`);
    return res.status(200).send(csv);
  } catch (err) {
    return error(res, err.message);
  }
};

export const createBoxQtyRecord = async (req, res) => {
  try {
    const { org, items = [], date, effectiveDate } = req.body;

    if (!org) {
      return badRequest(res, 'org is required');
    }

    const rows = Array.isArray(items) && items.length ? items : [req.body];
    const saved = [];
    const actor = req.user?.username || 'system';

    for (const item of rows) {
      const code = item.code || item.productCode;

      if (!code) {
        continue;
      }

      const id = newUuid();
      const productDesc = item.desc || item.productDesc || '';
      const qty = toNumber(item.qty ?? item.qtyPerBox, 0);
      const effDate = normalizeDate(item.effectiveDate || item.date || effectiveDate || date);

      await executeCommit(
        `
        INSERT INTO ${SETUP_TABLES.boxQtyRecords}
        (
          ID,
          ORG,
          PRODUCT_CODE,
          PRODUCT_DESC,
          QTY_PER_BOX,
          EFFECTIVE_DATE,
          CREATED_BY,
          UPDATED_BY,
          IS_ACTIVE,
          IS_DELETED,
          CREATED_AT,
          UPDATED_AT
        )
        VALUES
        (
          :b_id,
          :b_org,
          :b_product_code,
          :b_product_desc,
          :b_qty_per_box,
          NVL(TO_DATE(:b_effective_date, 'YYYY-MM-DD'), TRUNC(SYSDATE)),
          :b_created_by,
          :b_updated_by,
          1,
          0,
          SYSTIMESTAMP,
          SYSTIMESTAMP
        )
        `,
        {
          b_id: id,
          b_org: org,
          b_product_code: code,
          b_product_desc: productDesc,
          b_qty_per_box: qty,
          b_effective_date: effDate,
          b_created_by: actor,
          b_updated_by: actor,
        }
      );

      saved.push({
        id,
        org,
        code,
        productCode: code,
        desc: productDesc,
        productDesc,
        qty,
        qtyPerBox: qty,
        effectiveDate: effDate,
      });
    }

    return created(res, saved, `${saved.length} box quantity record(s) saved`);
  } catch (err) {
    return error(res, err.message);
  }
};

export const updateBoxQtyRecord = async (req, res) => {
  try {
    const actor = req.user?.username || 'system';

    const p = {
      b_id: req.params.id,
      b_org: req.body.org || null,
      b_product_code: req.body.code || req.body.productCode || null,
      b_product_desc: req.body.desc || req.body.productDesc || null,
      b_qty_per_box: toNumber(req.body.qty ?? req.body.qtyPerBox, 0),
      b_effective_date: normalizeDate(req.body.effectiveDate || req.body.date),
      b_updated_by: actor,
    };

    const result = await executeCommit(
      `
      UPDATE ${SETUP_TABLES.boxQtyRecords}
      SET
        ORG = :b_org,
        PRODUCT_CODE = :b_product_code,
        PRODUCT_DESC = :b_product_desc,
        QTY_PER_BOX = :b_qty_per_box,
        EFFECTIVE_DATE = NVL(TO_DATE(:b_effective_date, 'YYYY-MM-DD'), EFFECTIVE_DATE),
        UPDATED_BY = :b_updated_by,
        UPDATED_AT = SYSTIMESTAMP
      WHERE ID = :b_id
        AND NVL(IS_DELETED, 0) = 0
      `,
      p
    );

    if (!result.rowsAffected) {
      return notFound(res, 'Box quantity record not found');
    }

    return success(
      res,
      {
        id: req.params.id,
        org: p.b_org,
        code: p.b_product_code,
        productCode: p.b_product_code,
        desc: p.b_product_desc,
        productDesc: p.b_product_desc,
        qty: p.b_qty_per_box,
        qtyPerBox: p.b_qty_per_box,
        effectiveDate: p.b_effective_date,
      },
      'Box quantity record updated'
    );
  } catch (err) {
    return error(res, err.message);
  }
};

export const deleteBoxQtyRecord = async (req, res) => {
  try {
    const result = await executeCommit(`UPDATE ${SETUP_TABLES.boxQtyRecords} SET IS_DELETED=1, IS_ACTIVE=0, UPDATED_AT=SYSTIMESTAMP WHERE ID=:id AND NVL(IS_DELETED,0)=0`, { id: req.params.id });
    if (!result.rowsAffected) return notFound(res, 'Box quantity record not found');
    return success(res, null, 'Box quantity record deleted');
  } catch (err) { return error(res, err.message); }
};


export const getMachineStats = async (_req, res) => {
  try {
    const rows = await executeRows(
      `
      SELECT LOWER(NVL(STATUS,'idle')) AS "status", COUNT(*) AS "count"
      FROM ${SETUP_TABLES.machines}
      WHERE NVL(IS_DELETED,0)=0
      GROUP BY LOWER(NVL(STATUS,'idle'))
      `,
    );
    const stats = { total: 0, running: 0, idle: 0, maintenance: 0, breakdown: 0, active: 0 };
    rows.forEach((row) => {
      const key = String(row.status || 'idle').toLowerCase();
      const count = Number(row.count || 0);
      stats.total += count;
      stats[key] = count;
    });
    const activeRow = await executeOne(
      `SELECT COUNT(*) AS "count" FROM ${SETUP_TABLES.machines} WHERE NVL(IS_DELETED,0)=0 AND NVL(IS_ACTIVE,1)=1`,
    );
    stats.active = Number(activeRow?.count || 0);
    return success(res, stats);
  } catch (err) { return error(res, err.message); }
};

export const exportMachines = async (req, res) => {
  try {
    const { search, plant, status, department, area } = req.query;
    const where = ['NVL(IS_DELETED,0)=0'];
    const binds = {};
    if (plant) { where.push('LOWER(PLANT)=LOWER(:plant)'); binds.plant = plant; }
    if (status) { where.push('LOWER(STATUS)=LOWER(:status)'); binds.status = STATUS_TO_DB[status] || String(status).toLowerCase(); }
    if (department) { where.push('LOWER(DEPARTMENT)=LOWER(:department)'); binds.department = department; }
    if (area) { where.push('LOWER(AREA)=LOWER(:area)'); binds.area = area; }
    if (search) {
      where.push('(LOWER(CODE) LIKE LOWER(:search) OR LOWER(NAME) LIKE LOWER(:search) OR LOWER(NVL(MES_CODE,\'\')) LIKE LOWER(:search))');
      binds.search = `%${search}%`;
    }
    const rows = await executeRows(
      `SELECT CODE AS "code", NAME AS "name", MACHINE_TYPE AS "machineType", PLANT AS "plant", DEPARTMENT AS "department", AREA AS "area", LOCATOR AS "locator", OEM AS "oem", MODEL AS "model", SERIAL_NO AS "serialNo", TONNAGE AS "tonnage", CYCLE_TIME AS "cycleTime", CAVITIES AS "cavities", STATUS AS "status" FROM ${SETUP_TABLES.machines} WHERE ${where.join(' AND ')} ORDER BY CODE`,
      binds,
    );
    const headers = ['Code', 'Name', 'Type', 'Plant', 'Department', 'Area', 'Locator', 'OEM', 'Model', 'Serial No', 'Tonnage', 'Cycle Time', 'Cavities', 'Status'];
    const body = rows.map((r) => [r.code, r.name, r.machineType, r.plant, r.department, r.area, r.locator, r.oem, r.model, r.serialNo, r.tonnage, r.cycleTime, r.cavities, r.status]);
    const csv = [headers, ...body].map((row) => row.map(csvValue).join(',')).join('\n');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="machines-${new Date().toISOString().slice(0, 10)}.csv"`);
    return res.status(200).send(csv);
  } catch (err) { return error(res, err.message); }
};

export const importMachines = async (req, res) => {
  try {
    const rows = req.body?.machines || req.body?.rows || [];
    if (!Array.isArray(rows) || rows.length === 0) return badRequest(res, 'machines array is required');
    const saved = [];
    const actor = req.user?.username || 'system';
    for (const item of rows) {
      const p = normalizeMachinePayload(item);
      if (!p.code || !p.name) continue;
      const existing = await executeOne(`SELECT ID AS "id" FROM ${SETUP_TABLES.machines} WHERE LOWER(CODE)=LOWER(:code) AND NVL(IS_DELETED,0)=0 FETCH FIRST 1 ROWS ONLY`, { code: p.code });
      if (existing?.id) {
        await executeCommit(
          `UPDATE ${SETUP_TABLES.machines} SET NAME=:name, MACHINE_TYPE=:type, PLANT=:plant, DEPARTMENT=:dept, AREA=:area, LOCATOR=:locator, STATUS=:status, UPDATED_BY=:actor, UPDATED_AT=SYSTIMESTAMP WHERE ID=:id`,
          { id: existing.id, name: p.name, type: p.type || null, plant: p.plant || null, dept: p.dept || null, area: p.area || null, locator: p.locator || null, status: p.status || 'idle', actor },
        );
        saved.push({ id: existing.id, code: p.code, action: 'updated' });
      } else {
        const id = newUuid();
        await executeCommit(
          `INSERT INTO ${SETUP_TABLES.machines} (ID,CODE,NAME,MACHINE_TYPE,PLANT,DEPARTMENT,AREA,LOCATOR,STATUS,SPECS_JSON,CREATED_BY,UPDATED_BY,IS_ACTIVE,IS_DELETED,CREATED_AT,UPDATED_AT) VALUES (:id,:code,:name,:type,:plant,:dept,:area,:locator,:status,:specs,:actor,:actor,1,0,SYSTIMESTAMP,SYSTIMESTAMP)`,
          { id, code: p.code, name: p.name, type: p.type || null, plant: p.plant || null, dept: p.dept || null, area: p.area || null, locator: p.locator || null, status: p.status || 'idle', specs: p.specs || '{}', actor },
        );
        saved.push({ id, code: p.code, action: 'created' });
      }
    }
    return success(res, saved, `${saved.length} machine row(s) imported`);
  } catch (err) { return error(res, err.message); }
};

export const getMachineAreaOptions = async (_req, res) => {
  try {
    const rows = await executeRows(`SELECT DISTINCT AREA AS "area" FROM ${SETUP_TABLES.machines} WHERE NVL(IS_DELETED,0)=0 AND AREA IS NOT NULL ORDER BY AREA`);
    return success(res, rows.map((r) => r.area));
  } catch (err) { return error(res, err.message); }
};

export const getAutoLocator = async (req, res) => {
  try {
    const area = String(req.query.area || 'AREA').trim().toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8) || 'AREA';
    const plant = String(req.query.plant || 'FPP').trim().toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 4) || 'FPP';
    const row = await executeOne(`SELECT COUNT(*) + 1 AS "seq" FROM ${SETUP_TABLES.machines} WHERE NVL(IS_DELETED,0)=0 AND LOWER(NVL(AREA,''))=LOWER(:area)`, { area });
    const locator = `${plant}-${area}-${String(row?.seq || 1).padStart(3, '0')}`;
    return success(res, { locator });
  } catch (err) { return error(res, err.message); }
};

export const getLocationStats = async (_req, res) => {
  try {
    const rows = await executeRows(`SELECT STATUS AS "status", COUNT(*) AS "count" FROM ${SETUP_TABLES.locations} WHERE NVL(IS_DELETED,0)=0 GROUP BY STATUS`);
    const stats = { total: 0, active: 0, inactive: 0 };
    rows.forEach((r) => {
      const key = String(r.status || 'active').toLowerCase();
      const count = Number(r.count || 0);
      stats.total += count;
      if (key.includes('inactive')) stats.inactive += count;
      else stats.active += count;
    });
    return success(res, stats);
  } catch (err) { return error(res, err.message); }
};

export const exportLocations = async (req, res) => {
  try {
    const { div, division, plant, zone, type, status, search } = req.query;
    const where = ['NVL(IS_DELETED,0)=0'];
    const binds = {};
    const divFilter = div || division;
    const zoneFilter = zone || type;
    if (divFilter || plant) { where.push('LOWER(DIVISION)=LOWER(:division)'); binds.division = normalizeDiv(divFilter || plant); }
    if (zoneFilter) { where.push('LOWER(LOCATION_TYPE)=LOWER(:zone)'); binds.zone = normalizeZone(zoneFilter); }
    if (status) { where.push('LOWER(STATUS)=LOWER(:status)'); binds.status = status; }
    if (search) { where.push('(LOWER(CODE) LIKE LOWER(:search) OR LOWER(NVL(LOCATOR,\'\')) LIKE LOWER(:search) OR LOWER(NVL(BARCODE,\'\')) LIKE LOWER(:search) OR LOWER(NAME) LIKE LOWER(:search))'); binds.search = `%${search}%`; }
    const rows = await executeRows(`${locationSelect} WHERE ${where.join(' AND ')} ORDER BY CODE ASC`, binds);
    const data = rows.map(mapLocation);
    const headers = ['Division', 'Zone', 'Area', 'Section', 'Level', 'Locator', 'Barcode', 'Status', 'Max LPN', 'Used LPN', 'Owner'];
    const body = data.map((l) => [l.division, l.zone, l.area, l.section, l.level, l.locator, l.barcode, l.status, l.maxLPN, l.usedLPN, l.owner]);
    const csv = [headers, ...body].map((row) => row.map(csvValue).join(',')).join('\n');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="locations-${new Date().toISOString().slice(0, 10)}.csv"`);
    return res.status(200).send(csv);
  } catch (err) { return error(res, err.message); }
};

export const importLocations = async (req, res) => {
  try {
    const rows = req.body?.locations || req.body?.rows || [];
    if (!Array.isArray(rows) || rows.length === 0) return badRequest(res, 'locations array is required');
    const saved = [];
    const actor = req.user?.username || 'system';
    for (const row of rows) {
      const payload = buildLocationPayload(row, req.user);
      if (!payload.area) continue;
      const existing = await executeOne(`SELECT ID AS "id" FROM ${SETUP_TABLES.locations} WHERE LOWER(LOCATOR)=LOWER(:locator) AND NVL(IS_DELETED,0)=0 FETCH FIRST 1 ROWS ONLY`, { locator: payload.locator });
      if (existing?.id) {
        await executeCommit(`UPDATE ${SETUP_TABLES.locations} SET NAME=:name, AREA=:area, SECTION=:section, LOCATION_LEVEL=:level, BARCODE=:barcode, STATUS=:status, UPDATED_BY=:actor, UPDATED_AT=SYSTIMESTAMP WHERE ID=:id`, { id: existing.id, name: payload.name, area: payload.area, section: payload.section, level: payload.level, barcode: payload.barcode, status: payload.status, actor });
        saved.push({ id: existing.id, locator: payload.locator, action: 'updated' });
      } else {
        const id = newUuid();
        await executeCommit(`INSERT INTO ${SETUP_TABLES.locations} (ID,CODE,NAME,LOCATION_TYPE,PLANT,CREATED_BY,UPDATED_BY,IS_ACTIVE,IS_DELETED,CREATED_AT,UPDATED_AT,DIVISION,AREA,SECTION,LOCATION_LEVEL,LOCATOR,BARCODE,LOC_TYPE,STATUS,MIN_UNITS,MAX_UNITS,MAX_LPN,USED_LPN,UOM,MULTI_SKU,PARTIAL_PICK,SPECIFIC_SKU,MAX_WEIGHT,OWNER,AUTH_USERS_JSON,ACCESS_RESTRICTION,NOTES) VALUES (:id,:code,:name,:type,:plant,:actor,:actor,:isActive,0,SYSTIMESTAMP,SYSTIMESTAMP,:division,:area,:section,:level,:locator,:barcode,:locType,:status,:minUnits,:maxUnits,:maxLPN,:usedLPN,:uom,:multiSKU,:partialPick,:specificSKU,:maxWeight,:owner,:authUsers,:accessRestriction,:notes)`, { id, actor, ...completeLocationBinds(payload) });
        saved.push({ id, locator: payload.locator, action: 'created' });
      }
    }
    return success(res, saved, `${saved.length} location row(s) imported`);
  } catch (err) { return error(res, err.message); }
};

export const seedLocations = async (req, res) => {
  try {
    const seeds = req.body?.locations || [
      { division: 'FPP', zone: 'PRD', area: 'MAIN', section: 'A', level: 'L1' },
      { division: 'FPP', zone: 'QA', area: 'QC', section: 'A', level: 'L1' },
      { division: 'FPP', zone: 'RJT', area: 'REJECT', section: 'A', level: 'L1' },
    ];
    req.body = { locations: seeds };
    return importLocations(req, res);
  } catch (err) { return error(res, err.message); }
};

export const getLocationBarcodes = async (req, res) => {
  try {
    const rows = await executeRows(`${locationSelect} WHERE NVL(IS_DELETED,0)=0 ORDER BY CODE ASC FETCH FIRST 500 ROWS ONLY`);
    return success(res, rows.map(mapLocation).map((l) => ({ id: l.id, locator: l.locator, barcode: l.barcode, name: l.name, area: l.area, zone: l.zone, division: l.division })));
  } catch (err) { return error(res, err.message); }
};

export const printLocationBarcodes = async (req, res) => {
  try {
    const ids = Array.isArray(req.body?.ids) ? req.body.ids : [];
    const where = ['NVL(IS_DELETED,0)=0'];
    const binds = {};
    if (ids.length) {
      where.push(`ID IN (${ids.map((_, i) => `:id${i}`).join(',')})`);
      ids.forEach((id, i) => { binds[`id${i}`] = id; });
    }
    const rows = await executeRows(`${locationSelect} WHERE ${where.join(' AND ')} ORDER BY CODE ASC`, binds);
    return success(res, { count: rows.length, locations: rows.map(mapLocation) }, 'Location barcode payload ready');
  } catch (err) { return error(res, err.message); }
};

export const getBoxQtyRecord = async (req, res) => {
  try {
    const row = await executeOne(`SELECT ID AS "id", ORG AS "org", PRODUCT_CODE AS "productCode", PRODUCT_DESC AS "productDesc", QTY_PER_BOX AS "qtyPerBox", EFFECTIVE_DATE AS "effectiveDate", IS_ACTIVE AS "isActive", CREATED_AT AS "createdAt", UPDATED_AT AS "updatedAt" FROM ${SETUP_TABLES.boxQtyRecords} WHERE ID=:id AND NVL(IS_DELETED,0)=0`, { id: req.params.id });
    if (!row) return notFound(res, 'Box quantity record not found');
    return success(res, { id: row.id, org: row.org, code: row.productCode, productCode: row.productCode, desc: row.productDesc, productDesc: row.productDesc, qty: row.qtyPerBox, qtyPerBox: row.qtyPerBox, effectiveDate: row.effectiveDate, isActive: toBool(row.isActive, true), createdAt: row.createdAt, updatedAt: row.updatedAt });
  } catch (err) { return error(res, err.message); }
};


export const getFusionItemBySegment = async (req, res) => {
  try {
    const segment1 = String(
      req.params.segment1 || req.query.segment1 || req.query.productCode || ''
    ).trim();

    if (!segment1) {
      return badRequest(res, 'segment1 is required');
    }

    const row = await executeOne(
      `
      SELECT
        INVENTORY_ITEM_ID AS "inventoryItemId",
        DESCRIPTION AS "description",
        SEGMENT1 AS "segment1"
      FROM XX_DIGI_ITEM_MASTER
      WHERE SEGMENT1 = :segment1
      FETCH NEXT 1 ROW ONLY
      `,
      { segment1 }
    );

    if (!row) {
      return notFound(res, 'Item not found');
    }

    return success(res, row);
  } catch (err) {
    return error(res, err.message);
  }
};


export const getBoxQtyItemLookup = async (req, res) => {
  try {
    const search = req.query.search || req.query.q;
    const where = ['NVL(IS_DELETED,0)=0'];
    const binds = {};
    if (search) { where.push('(LOWER(ITEM_CODE) LIKE LOWER(:search) OR LOWER(ITEM_DESCRIPTION) LIKE LOWER(:search))'); binds.search = `%${search}%`; }
    const rows = await executeRows(`SELECT ORG AS "org", ITEM_CODE AS "itemCode", ITEM_DESCRIPTION AS "itemDescription", UOM AS "uom", STATUS AS "status" FROM ${ITEM_MASTER_TABLE} WHERE ${where.join(' AND ')} ORDER BY ITEM_CODE FETCH FIRST 100 ROWS ONLY`, binds);
    return success(res, rows);
  } catch (err) { return error(res, err.message); }
};

export const importBoxQtyRecords = async (req, res) => {
  try {
    const rows = req.body?.records || req.body?.rows || req.body?.items || [];
    if (!Array.isArray(rows) || rows.length === 0) return badRequest(res, 'records array is required');
    req.body = { org: req.body.org || rows[0]?.org, items: rows };
    return createBoxQtyRecord(req, res);
  } catch (err) { return error(res, err.message); }
};

export default {
  getOrganizationsLov,
  getMachines, createMachine, updateMachine, deleteMachine,
  getMachineStats, exportMachines, importMachines, getMachineAreaOptions, getAutoLocator,
  getLocations, createLocation, updateLocation, deleteLocation,
  getLocationStats, exportLocations, importLocations, seedLocations, getLocationBarcodes, printLocationBarcodes,
  getShifts, createShift, updateShift, deleteShift,
  getConfigs, upsertConfig,
  getBoxQtyReport, exportBoxQtyReport, createBoxQtyRecord, getBoxQtyRecord, updateBoxQtyRecord, deleteBoxQtyRecord, getFusionItemBySegment, getBoxQtyItemLookup, importBoxQtyRecords,
};
