import bcrypt from 'bcryptjs';

import env from '../config/env.js';
import { initOraclePool, executeOne } from '../config/oracle.js';
import { success, error, badRequest } from '../utils/response.js';
import logger from '../utils/logger.js';
import * as authModel from '../models/auth.model.js';
import * as setupModel from '../models/setup.model.js';
import * as productionModel from '../models/production.model.js';

export const testConnection = async (_req, res) => {
  try {
    await initOraclePool();
    const row = await executeOne(`
      SELECT USER AS "currentUser", SYSDATE AS "dbDate" FROM DUAL
    `);
    return success(res, row, 'Oracle ADW connection successful');
  } catch (err) {
    return badRequest(res, `Oracle ADW connection failed: ${err.message}`);
  }
};

export const createSchema = async (_req, res) => {
  return success(res, {
    mode: 'manual_sql_developer',
    scripts: [
      '02_create_mes_current_schema.sql',
      '03_create_mes_html_gap_schema.sql',
      '04_indexes_constraints.sql',
      '05_seed_master_data.sql',
      '06_verify_schema.sql',
    ],
  }, 'Schema creation is managed by Oracle SQL Developer scripts. Sequelize sync is disabled.');
};

const createDemoUserIfMissing = async ({ empId, username, fullName, role, passwordHash }) => {
  const existing = await authModel.findUserByLogin(empId);
  if (existing) return existing.id;

  return authModel.createDefaultAdmin({
    empId,
    username,
    passwordHash,
    fullName,
    role,
    plant: 'Zamil Plastics',
  });
};

export const seedData = async (req, res) => {
  try {
    const { adminName, adminEmpId, adminPassword, seedDemoData } = req.body;
    const hash = await bcrypt.hash(adminPassword || 'Admin@1234', 12);

    let admin = await authModel.findUserByLogin(adminEmpId || 'EMP-0001');
    let adminId = admin?.id;

    if (!admin) {
      adminId = await authModel.createDefaultAdmin({
        empId: adminEmpId || 'EMP-0001',
        username: 'admin',
        passwordHash: hash,
        fullName: adminName || 'System Administrator',
        role: 'admin',
        plant: 'Zamil Plastics',
      });
    }

    const seeded = { adminId, users: 0, machines: 0, locations: 0, shifts: 0, workOrders: 0, configs: 0 };

    if (seedDemoData) {
      const demoHash = await bcrypt.hash('Demo@1234', 12);
      const demoUsers = [
        { empId: 'EMP-2479', username: 'syed.hussaini', fullName: 'Syed Hussaini', role: 'tech' },
        { empId: 'EMP-5012', username: 'ahmed.hassan', fullName: 'Ahmed Hassan', role: 'operator' },
        { empId: 'EMP-1001', username: 'mustafa.maqrodh', fullName: 'Mustafa Al Maqrodh', role: 'qc' },
        { empId: 'EMP-3301', username: 'ahmed.rashidi', fullName: 'Ahmed Al Rashidi', role: 'packer' },
        { empId: 'EMP-2122', username: 'amro.faisal', fullName: 'Amro Faisal', role: 'tech' },
      ];

      for (const u of demoUsers) {
        const existing = await authModel.findUserByLogin(u.empId);
        if (!existing) {
          await createDemoUserIfMissing({ ...u, passwordHash: demoHash });
          seeded.users += 1;
        }
      }

      const machines = [
        { code: 'ZFP001', name: 'Zamil Film Press 001', machineType: 'Film Press', status: 'running' },
        { code: 'ZFP002', name: 'Zamil Film Press 002', machineType: 'Film Press', status: 'idle' },
        { code: 'ZBL010', name: 'Zamil Blow Liner 010', machineType: 'Blow Liner', status: 'running' },
        { code: 'ZPK005', name: 'Zamil Packer 005', machineType: 'Packer', status: 'running' },
        { code: 'INJ-077', name: 'Injection Mold 077', machineType: 'Injection', status: 'maintenance' },
        { code: 'INJ-083', name: 'Injection Mold 083', machineType: 'Injection', status: 'running' },
        { code: 'INJ-103', name: 'Injection Mold 103', machineType: 'Injection', status: 'idle' },
        { code: 'INJ-106', name: 'Injection Mold 106', machineType: 'Injection', status: 'running' },
      ];
      for (const m of machines) {
        await setupModel.createMachine({ ...m, plant: 'Zamil Plastics' }, { username: 'install' });
        seeded.machines += 1;
      }

      const locations = [
        { code: 'WH-A', name: 'Warehouse A', locationType: 'warehouse' },
        { code: 'WH-B', name: 'Warehouse B', locationType: 'warehouse' },
        { code: 'STAGING', name: 'Staging Area', locationType: 'staging' },
        { code: 'DISPATCH', name: 'Dispatch Bay', locationType: 'dispatch' },
      ];
      for (const l of locations) {
        await setupModel.createLocation({ ...l, plant: 'Zamil Plastics' }, { username: 'install' });
        seeded.locations += 1;
      }

      const shifts = [
        { name: 'Morning', startTime: '06:00', endTime: '14:00' },
        { name: 'Afternoon', startTime: '14:00', endTime: '22:00' },
        { name: 'Night', startTime: '22:00', endTime: '06:00' },
      ];
      for (const s of shifts) {
        await setupModel.createShift({ ...s, plant: 'Zamil Plastics' }, { username: 'install' });
        seeded.shifts += 1;
      }

      const workOrders = [
        { woNumber: 'FPP-WO-414', product: 'HDPE Film 200µm', productCode: 'FPP-200', customer: 'Zamil Steel', plannedQty: 15000, producedQty: 11200, status: 'active' },
        { woNumber: 'FPP-WO-494', product: 'LDPE Liner Bag 100µm', productCode: 'FPP-100', customer: 'Saudi Aramco', plannedQty: 8000, producedQty: 3400, status: 'active' },
        { woNumber: 'FPP-WO-477', product: 'PP Woven Sack 50kg', productCode: 'FPP-WS50', customer: 'SABIC', plannedQty: 5000, producedQty: 5000, status: 'completed' },
        { woNumber: 'IPP-WO-221', product: 'PP Crate 60L Blue', productCode: 'IPP-C60B', customer: 'Al-Marai', plannedQty: 2000, producedQty: 1650, status: 'active' },
        { woNumber: 'IPP-WO-198', product: 'HDPE Jerry Can 20L', productCode: 'IPP-JC20', customer: 'Saudi Exports', plannedQty: 3000, producedQty: 2900, status: 'active' },
      ];
      for (const wo of workOrders) {
        await productionModel.createWorkOrder({ ...wo, plant: 'Zamil Plastics', scheduledDate: new Date() }, { username: 'install' });
        seeded.workOrders += 1;
      }

      const configs = [
        { key: 'default_box_qty', value: '50', category: 'packing', description: 'Default pieces per box' },
        { key: 'app_name', value: 'Zamil MES System', category: 'general' },
        { key: 'plant_name', value: 'Zamil Plastics Factory', category: 'general' },
      ];
      for (const cfg of configs) {
        await setupModel.upsertConfig(cfg, { username: 'install' });
        seeded.configs += 1;
      }
    }

    return success(res, seeded, 'Data seeded successfully');
  } catch (err) {
    logger.error('Seed error:', err);
    return error(res, `Seed error: ${err.message}`);
  }
};

export const finalizeInstall = async (_req, res) => {
  try {
    logger.info('Installation finalized');
    return success(res, { installed: true }, 'Installation complete. Please restart the server.');
  } catch (err) {
    return error(res, err.message);
  }
};

export const checkInstall = async (_req, res) => {
  return success(res, {
    installed: env.APP_INSTALLED,
    dbClient: env.DB_CLIENT || 'oracle',
    database: 'Oracle ADW',
    schemaMode: 'SQL Developer scripts',
  });
};

export default {
  testConnection,
  createSchema,
  seedData,
  finalizeInstall,
  checkInstall,
};
