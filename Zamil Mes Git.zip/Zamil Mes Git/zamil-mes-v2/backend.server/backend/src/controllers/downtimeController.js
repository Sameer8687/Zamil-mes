import { success, created, notFound, error, paginated } from '../utils/response.js';
import * as downtimeModel from '../models/downtime.model.js';

const calculateDurationMinutes = (startTime, endTime) => {
  if (!startTime || !endTime) return undefined;
  const start = new Date(startTime);
  const end = new Date(endTime);
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) return undefined;
  return Math.max(Math.round((end - start) / 60000), 0);
};

const mapDowntime = (r) => ({
  id: r.id,
  resId: `DT-${String(r.id || '').slice(-6).toUpperCase()}`,
  org: r.org,
  machineId: r.machineId,
  machine: r.machine || r.machineCode || r.machineName,
  machineCode: r.machineCode,
  date: r.downtimeDate,
  downtimeDate: r.downtimeDate,
  product: r.product,
  desc: r.description,
  description: r.description,
  shift: r.shift,
  dtType: r.dtType,
  category: r.category,
  process: r.process,
  reason: r.reason,
  hrs: r.hours,
  hours: r.hours,
  min: r.minute,
  minute: r.minute,
  durationMinutes: r.durationMinutes,
  status: r.status,
  startTime: r.startTime,
  endTime: r.endTime,
  subcategory: r.subcategory,
  actionTaken: r.actionTaken,
  createdAt: r.createdAt,
  updatedAt: r.updatedAt,
});

export const getDowntimeRecords = async (req, res) => {
  try {
    const { page = 1, limit = 50 } = req.query;
    const filters = {
      ...req.query,
      machineId: req.query.machineId,
      search: req.query.search || req.query.machine,
    };
    const result = await downtimeModel.listDowntimeRecords(filters);
    return paginated(res, { ...result, rows: result.rows.map(mapDowntime) }, page, limit);
  } catch (err) {
    return error(res, err.message);
  }
};

export const createDowntimeRecord = async (req, res) => {
  try {
    const { date, desc, hrs, min, ...rest } = req.body;
    const payload = {
      ...rest,
      downtimeDate: rest.downtimeDate || date,
      description: rest.description || desc,
      hours: rest.hours ?? hrs,
      minute: rest.minute ?? min,
      durationMinutes: rest.durationMinutes ?? ((Number(rest.hours ?? hrs) || 0) * 60 + (Number(rest.minute ?? min) || 0)),
      reportedById: rest.reportedById || req.user?.id,
      status: rest.status || 'open',
    };

    const id = await downtimeModel.createDowntimeRecord(payload, req.user);
    const record = await downtimeModel.getDowntimeRecordById(id);
    return created(res, mapDowntime(record), 'Downtime recorded');
  } catch (err) {
    return error(res, err.message);
  }
};

export const updateDowntimeRecord = async (req, res) => {
  try {
    const current = await downtimeModel.getDowntimeRecordById(req.params.id);
    if (!current) return notFound(res, 'Downtime record not found');

    const payload = { ...req.body };
    if (payload.status === 'resolved') {
      payload.resolvedById = req.user?.id;
      payload.endTime = payload.endTime || current.endTime || new Date();
      payload.durationMinutes = payload.durationMinutes ?? calculateDurationMinutes(payload.startTime || current.startTime, payload.endTime);
    }

    const affected = await downtimeModel.updateDowntimeRecord(req.params.id, payload, req.user);
    if (!affected) return notFound(res, 'Downtime record not found');

    const record = await downtimeModel.getDowntimeRecordById(req.params.id);
    return success(res, mapDowntime(record), 'Downtime record updated');
  } catch (err) {
    return error(res, err.message);
  }
};



export const getDowntimeRecord = async (req, res) => {
  try {
    const record = await downtimeModel.getDowntimeRecordById(req.params.id);
    if (!record) return notFound(res, 'Downtime record not found');
    return success(res, mapDowntime(record));
  } catch (err) {
    return error(res, err.message);
  }
};

export const deleteDowntimeRecord = async (req, res) => {
  try {
    const affected = await downtimeModel.deleteDowntimeRecord(req.params.id, req.user);
    if (!affected) return notFound(res, 'Downtime record not found');
    return success(res, null, 'Downtime record deleted');
  } catch (err) {
    return error(res, err.message);
  }
};

export const getRecentDowntimeRecords = async (req, res) => {
  try {
    const result = await downtimeModel.listDowntimeRecords({ ...req.query, page: 1, limit: req.query.limit || 10 });
    return success(res, result.rows.map(mapDowntime));
  } catch (err) {
    return error(res, err.message);
  }
};

export const resolveDowntimeRecord = async (req, res) => {
  try {
    const current = await downtimeModel.getDowntimeRecordById(req.params.id);
    if (!current) return notFound(res, 'Downtime record not found');
    const payload = {
      ...req.body,
      durationMinutes: req.body.durationMinutes ?? calculateDurationMinutes(req.body.startTime || current.startTime, req.body.endTime || current.endTime || new Date()),
    };
    const affected = await downtimeModel.resolveDowntimeRecord(req.params.id, payload, req.user);
    if (!affected) return notFound(res, 'Downtime record not found');
    const record = await downtimeModel.getDowntimeRecordById(req.params.id);
    return success(res, mapDowntime(record), 'Downtime resolved');
  } catch (err) {
    return error(res, err.message);
  }
};

export const reopenDowntimeRecord = async (req, res) => {
  try {
    const affected = await downtimeModel.reopenDowntimeRecord(req.params.id, req.body || {}, req.user);
    if (!affected) return notFound(res, 'Downtime record not found');
    const record = await downtimeModel.getDowntimeRecordById(req.params.id);
    return success(res, mapDowntime(record), 'Downtime reopened');
  } catch (err) {
    return error(res, err.message);
  }
};

export const getMachineProductLookup = async (req, res) => {
  try {
    const rows = await downtimeModel.machineProductLookup(req.query);
    return success(res, rows);
  } catch (err) {
    return error(res, err.message);
  }
};

const csvValue = (value) => {
  if (value === undefined || value === null) return '';
  const text = String(value).replace(/"/g, '""');
  return /[",\n]/.test(text) ? `"${text}"` : text;
};

export const exportDowntimeReport = async (req, res) => {
  try {
    const result = await downtimeModel.listDowntimeRecords({ ...req.query, page: 1, limit: req.query.limit || 5000 });
    const headers = ['Date', 'Machine', 'WO Number', 'Product', 'DT Type', 'Category', 'Reason', 'Hours', 'Minutes', 'Duration Minutes', 'Status', 'Action Taken'];
    const rows = result.rows.map((r) => [r.downtimeDate, r.machine || r.machineCode, r.woNumber, r.product, r.dtType, r.category, r.reason, r.hours, r.minute, r.durationMinutes, r.status, r.actionTaken]);
    const csv = [headers, ...rows].map((row) => row.map(csvValue).join(',')).join('\n');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="downtime-report-${new Date().toISOString().slice(0, 10)}.csv"`);
    return res.status(200).send(csv);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getDowntimeSummary = async (req, res) => {
  try {
    const summary = await downtimeModel.getDowntimeSummary(req.query);
    return success(res, summary);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getDowntimeReasonCodes = async (req, res) => {
  try {
    const rows = await downtimeModel.listDowntimeReasonCodes(req.query);
    return success(res, rows);
  } catch (err) {
    return error(res, err.message);
  }
};

export default {
  getDowntimeRecords,
  createDowntimeRecord,
  updateDowntimeRecord,
  getDowntimeRecord,
  deleteDowntimeRecord,
  getRecentDowntimeRecords,
  resolveDowntimeRecord,
  reopenDowntimeRecord,
  getMachineProductLookup,
  exportDowntimeReport,
  getDowntimeSummary,
  getDowntimeReasonCodes,
};
