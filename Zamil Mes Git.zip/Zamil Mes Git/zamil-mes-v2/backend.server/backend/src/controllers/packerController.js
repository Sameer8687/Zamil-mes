import { success, created, notFound, error, badRequest, paginated } from '../utils/response.js';
import * as packerModel from '../models/packer.model.js';
import * as productionModel from '../models/production.model.js';
import * as stockModel from '../models/stock.model.js';
import * as labelsModel from '../models/labels.model.js';
import { executeCommit } from '../config/oracle.js';
import * as woQtyFusionTxnModel from '../models/woQtyFusionTransaction.model.js';
import * as fusionService from '../services/fusion.service.js';

const QC_TO_FRONTEND = {
  pending: 'pend',
  pass: 'appr',
  passed: 'appr',
  approved: 'appr',
  fail: 'rejt',
  failed: 'rejt',
  rejected: 'rejt',
};
const cleanText = (value) => {
  if (value === undefined || value === null) return '';
  return String(value).trim();
};

const getRequestQuantity = (req, wo) => {
  const rawQty =
    req.body.quantity ??
    req.body.transactionQty ??
    req.body.qty ??
    wo?.boxQty ??
    wo?.boxQtyRecorded ??
    1;

  const qty = Number(rawQty);

  if (!Number.isFinite(qty) || qty <= 0) {
    return null;
  }

  return qty;
};

const getTransactionDate = (req) => {
  const value = req.body.transactionDate || req.body.printedAt || null;

  if (!value) return new Date();

  const date = new Date(value);

  if (!Number.isFinite(date.getTime())) {
    return null;
  }

  return date;
};

const getUserName = (user = null) => {
  return (
    cleanText(user?.username) ||
    cleanText(user?.empId) ||
    cleanText(user?.email) ||
    cleanText(user?.id) ||
    'system'
  );
};

const getErrorPayload = (err) => {
  return err?.fusionData || {
    message: err?.message || 'Unknown error',
    code: err?.code || 'UNKNOWN_ERROR',
  };
};

const sendFusionQtyError = (res, err, transaction = null) => {
  const statusCode = err?.statusCode || 502;

  return res.status(statusCode).json({
    success: false,
    message: `Box qty not recorded. ${err?.message || 'Fusion quantity posting failed'}`,
    code: err?.code || 'FUSION_QTY_POST_FAILED',
    fusionHttpStatus: err?.fusionHttpStatus || null,
    fusionUrl: err?.fusionUrl || null,
    fusionData: err?.fusionData || null,
    transaction,
  });
};

const normalizeQcStatus = (status, fallback = 'pend') => {
  if (!status) return fallback;
  const value = String(status).trim().toLowerCase();
  return QC_TO_FRONTEND[value] || value;
};

const mapBox = (box, index = 0) => {
  const boxNumber = Number(box?.boxNumber || index + 1);
  return {
    ...box,
    boxNumber: Number.isFinite(boxNumber) ? boxNumber : index + 1,
    product: box.product || box.productName || null,
    qcStatus: normalizeQcStatus(box.qcStatus),
  };
};


const resolveTemplateId = async (labelType, requestedTemplateId = null) => {
  if (requestedTemplateId) return requestedTemplateId;
  const template = await labelsModel.getDefaultLabelTemplate(labelType);
  return template?.id || null;
};

const BOX_PRINT_COOLDOWN_MS = 60 * 1000;

const isCooldownActive = (printedAt) => {
  if (!printedAt) return false;
  const ts = new Date(printedAt).getTime();
  return Number.isFinite(ts) && (Date.now() - ts) < BOX_PRINT_COOLDOWN_MS;
};

export const getBoxes = async (req, res) => {
  try {
    const result = await packerModel.listBoxes({ ...req.query, limit: req.query.limit || 500 });
    return success(res, result.rows.map(mapBox));
  } catch (err) {
    return error(res, err.message);
  }
};

export const createBox = async (req, res) => {
  try {
    const requestedWoId = req.body.woId || req.body.woNumber || req.body.workOrderNumber;
    const wo = requestedWoId ? await productionModel.getWorkOrderById(requestedWoId) : null;

    const boxWoId = wo?.woNumber || requestedWoId || null;
    const machineId = await productionModel.resolveMachineCode(
      req.body.machineId || req.body.machineCode || wo?.machineId || null
    );

    const existingBoxes = boxWoId ? await packerModel.listBoxes({
      woId: boxWoId,
      machineId,
      limit: 2000,
    }) : { rows: [] };

    const nextBoxNo = existingBoxes.rows.length + 1;
    const barcode = req.body.barcode || req.body.labelSeq || `BOX-${wo?.woNumber || 'WO'}-${String(nextBoxNo).padStart(4, '0')}`;
    const quantity = Number(req.body.quantity || wo?.boxQty || 1);

    const id = await packerModel.createBox({
      ...req.body,
      woId: boxWoId,
      machineId,
      barcode,
      packedById: req.body.packedById || req.user?.id,
      status: req.body.status || 'open',
      qcStatus: normalizeQcStatus(req.body.qcStatus),
      quantity,
      labelPrinted: req.body.labelPrinted ?? 1,
    }, req.user);

    const box = await packerModel.getBoxById(id);
    if (wo?.id && quantity > 0) {
      await executeCommit(
        `
        UPDATE MES_WORK_ORDERS
        SET PRODUCED_QTY = LEAST(NVL(PLANNED_QTY,0), NVL(PRODUCED_QTY,0) + :quantity),
            UPDATED_AT = SYSTIMESTAMP
        WHERE ID = :woId
        `,
        { quantity, woId: wo.id },
      );

      await stockModel.createStockRecord({
        woId: boxWoId,
        org: wo.plant || 'Zamil',
        plant: wo.plant || 'Zamil Plastics',
        machine: box?.machineCode || machineId || wo.machineCode || null,
        productCode: wo.productCode || null,
        productName: wo.product || null,
        woNum: wo.woNumber,
        boxNo: barcode,
        locatorCode: req.body.locatorCode || wo.locatorCode || wo.locator || null,
        quantity,
        qcStatus: normalizeQcStatus(req.body.qcStatus),
        status: 'in_stock',
        receivedAt: new Date(),
      }, req.user);
    }

    return created(res, mapBox(box), 'Box created');
  } catch (err) {
    return error(res, err.message);
  }
};

export const updateBox = async (req, res) => {
  try {
    const payload = { ...req.body };
    if (payload.qcStatus !== undefined) payload.qcStatus = normalizeQcStatus(payload.qcStatus);

    const affected = await packerModel.updateBox(req.params.id, payload, req.user);
    if (!affected) return notFound(res, 'Box not found');

    const box = await packerModel.getBoxById(req.params.id);
    return success(res, mapBox(box), 'Box updated');
  } catch (err) {
    return error(res, err.message);
  }
};

export const getPallets = async (req, res) => {
  try {
    const result = await packerModel.listPallets({ ...req.query, limit: req.query.limit || 500 });

    const pallets = [];
    for (const pallet of result.rows) {
      const boxes = await packerModel.listPalletBoxes(pallet.id);
      pallets.push({
        ...pallet,
        labelPrinted: Number(pallet.labelPrinted || 0) === 1,
        boxes,
      });
    }

    return success(res, pallets);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getPallet = async (req, res) => {
  try {
    const pallet = await packerModel.getPalletById(req.params.id);
    if (!pallet) return notFound(res, 'Pallet not found');

    const boxes = await packerModel.listPalletBoxes(req.params.id);
    return success(res, { ...pallet, boxes });
  } catch (err) {
    return error(res, err.message);
  }
};

export const createPallet = async (req, res) => {
  try {
    const requestedWoId = req.body.woId || req.body.woNumber || req.body.workOrderNumber;
    const wo = requestedWoId ? await productionModel.getWorkOrderById(requestedWoId) : null;
    const palletNumber = req.body.palletNumber || `PLT-${Date.now()}`;

    const id = await packerModel.createPallet({
      ...req.body,
      woId: wo?.woNumber || requestedWoId || req.body.woId,
      palletNumber,
      createdById: req.body.createdById || req.user?.id,
    }, req.user);

    const pallet = await packerModel.getPalletById(id);
    return created(res, pallet, 'Pallet created');
  } catch (err) {
    return error(res, err.message);
  }
};

export const addBoxToPallet = async (req, res) => {
  try {
    const palletId = req.params.id;
    const { boxId, slotNo } = req.body;
    if (!palletId || !boxId) return badRequest(res, 'palletId and boxId are required');

    const pallet = await packerModel.addBoxToPallet({
      palletId,
      boxId,
      slotNo,
      addedById: req.user?.id,
    }, req.user);

    return success(res, pallet, 'Box added to pallet');
  } catch (err) {
    if (err.message === 'Box not found') return notFound(res, 'Box not found');
    return error(res, err.message);
  }
};

export const removeBoxFromPallet = async (req, res) => {
  try {
    const palletId = req.params.id;
    const boxId = req.params.boxId;

    if (!palletId || !boxId) {
      return badRequest(res, 'palletId and boxId are required');
    }

    const pallet = await packerModel.removeBoxFromPallet({
      palletId,
      boxId,
      removedById: req.user?.id,
    }, req.user);

    if (!pallet) return notFound(res, 'Pallet not found');

    const boxes = await packerModel.listPalletBoxes(palletId);
    return success(res, { ...pallet, boxes }, 'Box removed from pallet');
  } catch (err) {
    if (err.message === 'Pallet not found') return notFound(res, 'Pallet not found');
    if (err.message === 'Box not found') return notFound(res, 'Box not found');
    if (err.message === 'Box is not assigned to this pallet') return notFound(res, 'Box is not assigned to this pallet');
    if (err.message === 'Cannot remove boxes from a completed pallet') return badRequest(res, err.message);
    return error(res, err.message);
  }
};

export const getPalletBoxes = async (req, res) => {
  try {
    const boxes = await packerModel.listPalletBoxes(req.params.id);
    return success(res, boxes);
  } catch (err) {
    return error(res, err.message);
  }
};



export const bulkAddBoxesToPallet = async (req, res) => {
  try {
    const boxes = req.body.boxes || req.body.items || [];
    if (!Array.isArray(boxes) || !boxes.length) return badRequest(res, 'boxes array is required');
    const result = await packerModel.bulkAddBoxesToPallet({ palletId: req.params.id, boxes }, req.user);
    const palletBoxes = await packerModel.listPalletBoxes(req.params.id);
    return success(res, { ...result.pallet, boxes: palletBoxes, addedCount: result.addedCount }, 'Boxes added to pallet');
  } catch (err) {
    return error(res, err.message);
  }
};

export const autoArrangePallet = async (req, res) => {
  try {
    const pallet = await packerModel.getPalletById(req.params.id);
    if (!pallet) return notFound(res, 'Pallet not found');
    const available = await packerModel.getAvailableBoxes({
      woId: req.body.woId || req.query.woId || pallet.woId,
      machineId: req.body.machineId || req.query.machineId,
      limit: req.body.limit || req.query.limit || 50,
    });
    const boxes = (available.rows || []).slice(0, 50).map((box, index) => ({ boxId: box.id, slotNo: index + 1 }));
    const result = boxes.length ? await packerModel.bulkAddBoxesToPallet({ palletId: req.params.id, boxes }, req.user) : { addedCount: 0 };
    const palletBoxes = await packerModel.listPalletBoxes(req.params.id);
    return success(res, { ...(await packerModel.getPalletById(req.params.id)), boxes: palletBoxes, addedCount: result.addedCount || 0 }, 'Pallet auto-arranged');
  } catch (err) {
    return error(res, err.message);
  }
};

export const clearPallet = async (req, res) => {
  try {
    const result = await packerModel.clearPalletBoxes(req.params.id, req.user);
    return success(res, { ...result.pallet, boxes: [], removedCount: result.removedCount }, 'Pallet cleared');
  } catch (err) {
    return error(res, err.message);
  }
};

export const confirmPallet = async (req, res) => {
  try {
    const pallet = await packerModel.finalizePallet(req.params.id, req.user);
    if (!pallet) return notFound(res, 'Pallet not found');
    const boxes = await packerModel.listPalletBoxes(req.params.id);
    return success(res, { ...pallet, boxes }, 'Pallet confirmed');
  } catch (err) {
    return error(res, err.message);
  }
};

export const getPalletHistory = async (req, res) => {
  try {
    const rows = await packerModel.listPalletHistory(req.params.id, req.query);
    return success(res, rows);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getAvailableBoxes = async (req, res) => {
  try {
    const result = await packerModel.getAvailableBoxes(req.query);
    return paginated(res, result, req.query.page || 1, req.query.limit || 1000);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getLabelHistory = async (req, res) => {
  try {
    const result = await packerModel.listLabelPrintHistory(req.query);
    return paginated(res, result, req.query.page || 1, req.query.limit || 100);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getLabelHistoryById = async (req, res) => {
  try {
    const row = await packerModel.getLabelPrintHistoryById(req.params.id);
    if (!row) return notFound(res, 'Label print history not found');
    return success(res, row);
  } catch (err) {
    return error(res, err.message);
  }
};

export const finalizePallet = async (req, res) => {
  try {
    const pallet = await packerModel.finalizePallet(req.params.id, req.user);
    if (!pallet) return notFound(res, 'Pallet not found');
    return success(res, pallet, 'Pallet finalized');
  } catch (err) {
    return error(res, err.message);
  }
};

export const printBoxLabel = async (req, res) => {
  try {
    const box = await packerModel.getBoxById(req.params.id);
    if (!box) return notFound(res, 'Box not found');

    const updated = await packerModel.markBoxLabelPrinted({
      boxId: req.params.id,
      templateId: await resolveTemplateId('box', req.body.templateId),
      printerName: req.body.printerName || null,
      payload: {
        box,
        printedFrom: 'MES',
        requestedPayload: req.body || {},
      },
    }, req.user);

    return success(res, mapBox(updated), 'Box label printed');
  } catch (err) {
    return error(res, err.message);
  }
};

export const printLabel = async (req, res) => {
  let fusionTxn = null;

  try {
    const requestedWoId = req.body.woId || req.body.woNumber || req.body.workOrderNumber;

    if (!requestedWoId) {
      return badRequest(res, 'woId is required');
    }

    const wo = await productionModel.getWorkOrderById(requestedWoId);

    if (!wo) {
      return notFound(res, 'Work order not found');
    }

    if (String(wo.status || '').toLowerCase() !== 'active') {
      return badRequest(res, 'Operator can print labels only for a running work order');
    }

    const boxWoId = wo.woNumber;

    if (!boxWoId) {
      return error(res, 'Work order number is missing for this work order');
    }

    const quantity = getRequestQuantity(req, wo);

    if (!quantity) {
      return badRequest(res, 'Valid quantity is required');
    }

    const plannedQty = Number(wo.plannedQty || 0);
    const producedQty = Number(wo.producedQty || 0);

    if (plannedQty > 0 && producedQty + quantity > plannedQty) {
      return badRequest(
        res,
        `Planned quantity exceeded. Planned ${plannedQty}, already produced ${producedQty}, requested ${quantity}`
      );
    }

    const transactionDate = getTransactionDate(req);

    if (!transactionDate) {
      return badRequest(res, 'Invalid transactionDate');
    }

    const machineId = await productionModel.resolveMachineCode(
      req.body.machineId || req.body.machineCode || wo.machineId || null
    );

    if (!machineId) {
      return badRequest(res, 'Machine code is required');
    }

    const lastPrint = await packerModel.getLatestBoxPrint({
      woId: boxWoId,
      machineId,
    });

    if (isCooldownActive(lastPrint?.printedAt)) {
      const remaining = Math.ceil(
        (BOX_PRINT_COOLDOWN_MS - (Date.now() - new Date(lastPrint.printedAt).getTime())) / 1000
      );

      return badRequest(
        res,
        `Please wait ${remaining} seconds before printing the next box label`
      );
    }

    const existingBoxes = await packerModel.listBoxes({
      woId: boxWoId,
      machineId,
      limit: 2000,
    });

    const nextBoxNo = existingBoxes.rows.length + 1;

    const barcode =
      req.body.barcode ||
      req.body.labelSeq ||
      await packerModel.nextBoxBarcode();

    const qcStatus = normalizeQcStatus(req.body.qcStatus);

    /*
      IMPORTANT:
      Create pending Fusion transaction first.
      Do not create MES_BOXES yet.
      MES_BOXES will be created only after Fusion quantity posting succeeds.
    */
    fusionTxn = await woQtyFusionTxnModel.createWoQtyFusionTransaction(
      {
        woNumber: boxWoId,
        organizationId: wo.organizationId || null,
        productCode: wo.productCode || null,
        machineCode: machineId,
        boxId: null,
        boxBarcode: barcode,
        transactionQty: quantity,
        transactionUomCode: req.body.transactionUomCode || req.body.uomCode || null,
        transactionDate,
        sourceSystemCode: 'ZAMIL_MES',
        sourceSystemType: 'EXTERNAL',
        transactionSource: 'MES_LABEL_PRINT',
        remarks: 'Pending Fusion quantity posting from label print',
      },
      req.user
    );

    let fusionPostResult;

    try {
      fusionPostResult = await fusionService.postLabelPrintQtyToFusion({
        workOrderNumber: boxWoId,
        quantity,
        boxBarcode: barcode,
        transactionDate,
        operationSequenceNumber:
          req.body.operationSequenceNumber ||
          req.body.woOperationSequenceNumber ||
          wo.operationSequenceNumber ||
          wo.operationSequenceId ||
          null,
      });

      fusionTxn = await woQtyFusionTxnModel.markWoQtyFusionTransactionSuccess(
        fusionTxn.id,
        {
          organizationId: fusionPostResult.organizationId,
          productCode: fusionPostResult.productCode || wo.productCode || null,
          machineCode: machineId,
          boxBarcode: barcode,
          transactionUomCode: fusionPostResult.transactionUomCode,
          fusionHttpStatus: fusionPostResult.httpStatus,
          fusionTransactionId: fusionPostResult.fusionTransactionId,
          fusionRequestId: fusionPostResult.fusionRequestId,
          fusionRequestPayload: fusionPostResult.payload,
          fusionResponsePayload: fusionPostResult.response,
          isLastTransaction: fusionPostResult.completeOperationFlag ? 1 : 0,
          workOrderCompletedFlag: fusionPostResult.completeOperationFlag ? 1 : 0,
          remarks: fusionPostResult.completeOperationFlag
            ? 'Fusion quantity posted and operation completed'
            : 'Fusion quantity posted successfully',
        },
        req.user
      );
    } catch (fusionErr) {
      fusionTxn = await woQtyFusionTxnModel.markWoQtyFusionTransactionFailed(
        fusionTxn.id,
        {
          organizationId: wo.organizationId || null,
          productCode: wo.productCode || null,
          machineCode: machineId,
          boxBarcode: barcode,
          transactionUomCode: req.body.transactionUomCode || req.body.uomCode || null,
          fusionHttpStatus: fusionErr?.fusionHttpStatus || null,
          fusionErrorCode: fusionErr?.code || 'FUSION_QTY_POST_FAILED',
          fusionErrorMessage: fusionErr?.message || 'Fusion quantity posting failed',
          fusionRequestPayload: fusionErr?.fusionRequestPayload || null,
          fusionResponsePayload: getErrorPayload(fusionErr),
          remarks: 'Box qty not recorded because Fusion posting failed',
        },
        req.user
      );

      return sendFusionQtyError(res, fusionErr, fusionTxn);
    }

    /*
      Fusion success confirmed.
      Now create local MES_BOXES, stock, label print job/history.
    */
    const boxId = await packerModel.createBox(
      {
        ...req.body,
        woId: boxWoId,
        machineId,
        barcode,
        packedById: req.body.packedById || req.user?.id,
        status: req.body.status || 'open',
        qcStatus,
        quantity,
        labelPrinted: 0,
      },
      req.user
    );

    const box = await packerModel.getBoxById(boxId);

    fusionTxn = await woQtyFusionTxnModel.attachBoxToWoQtyFusionTransaction(
      fusionTxn.id,
      {
        boxId,
        boxBarcode: barcode,
      },
      req.user
    );

    if (wo?.id && quantity > 0) {
      await executeCommit(
        `
        UPDATE MES_WORK_ORDERS
        SET
          PRODUCED_QTY = LEAST(NVL(PLANNED_QTY, 0), NVL(PRODUCED_QTY, 0) + :quantity),
          STATUS =
            CASE
              WHEN :completedFlag = 1 THEN 'Completed'
              ELSE STATUS
            END,
          COMPLETED_DATE =
            CASE
              WHEN :completedFlag = 1 THEN TO_CHAR(SYSTIMESTAMP, 'YYYY-MM-DD"T"HH24:MI:SS')
              ELSE COMPLETED_DATE
            END,
          UPDATED_BY = :updatedBy,
          UPDATED_AT = SYSTIMESTAMP
        WHERE ID = :woId
        `,
        {
          quantity,
          completedFlag: fusionPostResult.completeOperationFlag ? 1 : 0,
          updatedBy: getUserName(req.user),
          woId: wo.id,
        },
      );

      await stockModel.createStockRecord(
        {
          woId: boxWoId,
          org: wo.plant || 'Zamil',
          plant: wo.plant || 'Zamil Plastics',
          machine: box?.machineCode || machineId || wo.machineCode || null,
          productCode: wo.productCode || fusionPostResult.productCode || null,
          productName: wo.product || null,
          woNum: wo.woNumber,
          boxNo: barcode,
          locatorCode: req.body.locatorCode || wo.locatorCode || wo.locator || null,
          quantity,
          qcStatus,
          status: 'in_stock',
          receivedAt: new Date(),
        },
        req.user
      );
    }

    const printedBox = await packerModel.markBoxLabelPrinted(
      {
        boxId,
        templateId: await resolveTemplateId('box', req.body.templateId),
        printerName: req.body.printerName || null,
        payload: {
          box: {
            ...box,
            boxNumber: nextBoxNo,
            barcode,
          },
          wo,
          fusion: {
            transactionId: fusionTxn.id,
            fusionTransactionId: fusionPostResult.fusionTransactionId,
            completeOperationFlag: fusionPostResult.completeOperationFlag,
            readyQty: fusionPostResult.readyQty,
            requestPayload: fusionPostResult.payload,
            responsePayload: fusionPostResult.response,
          },
          labelSeq: barcode,
          printedFrom: 'MES',
          requestedPayload: req.body || {},
        },
      },
      req.user
    );

    return created(
      res,
      {
        ...mapBox({
          ...printedBox,
          boxNumber: nextBoxNo,
        }),
        fusionPosting: {
          transactionId: fusionTxn.id,
          posted: true,
          status: 'SUCCESS',
          fusionTransactionId: fusionPostResult.fusionTransactionId,
          fusionRequestId: fusionPostResult.fusionRequestId,
          completeOperationFlag: fusionPostResult.completeOperationFlag,
          workOrderCompleted: fusionPostResult.completeOperationFlag,
          readyQty: fusionPostResult.readyQty,
          transactionQty: quantity,
        },
      },
      fusionPostResult.completeOperationFlag
        ? 'Box label printed, quantity posted to Fusion, and work order completed'
        : 'Box label printed and quantity posted to Fusion'
    );
  } catch (err) {
    return error(res, err.message);
  }
};

export const printPalletLabel = async (req, res) => {
  try {
    const pallet = await packerModel.getPalletById(req.params.id);
    if (!pallet) return notFound(res, 'Pallet not found');

    const boxes = await packerModel.listPalletBoxes(req.params.id);
    const updated = await packerModel.markPalletLabelPrinted({
      palletId: req.params.id,
      templateId: await resolveTemplateId('pallet', req.body.templateId),
      printerName: req.body.printerName || null,
      payload: {
        pallet,
        boxes,
        printedFrom: 'MES',
        requestedPayload: req.body || {},
      },
    }, req.user);

    return success(res, { ...updated, boxes }, 'Pallet label printed');
  } catch (err) {
    return error(res, err.message);
  }
};

export default {
  getBoxes,
  createBox,
  updateBox,
  getPallets,
  getPallet,
  createPallet,
  addBoxToPallet,
  removeBoxFromPallet,
  getPalletBoxes,
  bulkAddBoxesToPallet,
  autoArrangePallet,
  clearPallet,
  confirmPallet,
  getPalletHistory,
  getAvailableBoxes,
  getLabelHistory,
  getLabelHistoryById,
  finalizePallet,
  printBoxLabel,
  printLabel,
  printPalletLabel,
};
