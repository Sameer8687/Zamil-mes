import { success, created, notFound, error, paginated } from '../utils/response.js';
import * as lcModel from '../models/lineclearance.model.js';

const titleStatus = (status) => status ? String(status).charAt(0).toUpperCase() + String(status).slice(1) : 'Draft';

const mapLC = (r) => ({
  id: r.id,
  woId: r.woId,
  woNumber: r.woNumber,
  machineId: r.machineId,
  machineCode: r.machineCode,
  plant: r.plant,
  machine: r.machine || r.machineName || r.machineCode,
  jobOrder: r.jobOrder,
  date: r.submissionDate || (r.createdAt ? new Date(r.createdAt).toISOString().slice(0, 10) : null),
  submissionDate: r.submissionDate,
  productCode: r.productCode,
  productName: r.productName,
  shift: r.submissionShift || r.shift,
  submissionShift: r.submissionShift,
  type: r.clearanceType,
  clearanceType: r.clearanceType,
  checked: `${r.checkedCount || 0}/${r.checkedTotal || 0}`,
  checkedCount: r.checkedCount || 0,
  checkedTotal: r.checkedTotal || 0,
  tech: r.techName,
  techName: r.techName,
  qi: r.qiName,
  qiName: r.qiName,
  requestNo: r.requestNo,
  reqNo: r.requestNo,
  status: titleStatus(r.status),
  rawStatus: r.status,
  checklistData: r.checklistData,
  hygieneChecks: r.hygieneChecks,
  operationChecks: r.operationChecks,
  moldChecks: r.moldChecks,
  note: r.note,
  comment: r.note,
  controlNbr: r.controlNbr,
  submittedAt: r.submittedAt,
  approvedAt: r.approvedAt,
  rejectionReason: r.rejectionReason,
  createdAt: r.createdAt,
  updatedAt: r.updatedAt,
});

export const getLineClearances = async (req, res) => {
  try {
    const { page = 1, limit = 50 } = req.query;
    const result = await lcModel.listLineClearances({
      ...req.query,
      status: req.query.status ? String(req.query.status).toLowerCase() : undefined,
    });
    return paginated(res, { ...result, rows: result.rows.map(mapLC) }, page, limit);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getLineClearance = async (req, res) => {
  try {
    const lc = await lcModel.getLineClearanceById(req.params.id);
    if (!lc) return notFound(res, 'Line clearance not found');
    return success(res, mapLC(lc));
  } catch (err) {
    return error(res, err.message);
  }
};

export const createLineClearance = async (req, res) => {
  try {
    const { checks, totalItems, completedItems, status: frontStatus, reqNo, comment, ...rest } = req.body;
    const payload = {
      ...rest,
      requestNo: reqNo || rest.requestNo,
      note: comment || rest.note,
      checklistData: checks || rest.checklistData || {},
      checkedCount: completedItems ?? rest.checkedCount ?? 0,
      checkedTotal: totalItems ?? rest.checkedTotal ?? 0,
      status: String(frontStatus || rest.status || 'draft').toLowerCase(),
      conductedById: rest.conductedById || req.user?.id,
    };

    const id = await lcModel.createLineClearance(payload, req.user);
    const lc = await lcModel.getLineClearanceById(id);
    return created(res, mapLC(lc), 'Line clearance created');
  } catch (err) {
    return error(res, err.message);
  }
};

export const updateLineClearance = async (req, res) => {
  try {
    const { checks, totalItems, completedItems, status: frontStatus, reqNo, comment, ...rest } = req.body;
    const payload = { ...rest };

    if (checks !== undefined) payload.checklistData = checks;
    if (completedItems !== undefined) payload.checkedCount = completedItems;
    if (totalItems !== undefined) payload.checkedTotal = totalItems;
    if (reqNo !== undefined) payload.requestNo = reqNo;
    if (comment !== undefined) payload.note = comment;
    if (frontStatus) {
      payload.status = String(frontStatus).toLowerCase();
      if (payload.status === 'submitted') payload.submittedAt = new Date();
    }

    const affected = await lcModel.updateLineClearance(req.params.id, payload, req.user);
    if (!affected) return notFound(res, 'Line clearance not found');

    const lc = await lcModel.getLineClearanceById(req.params.id);
    return success(res, mapLC(lc), 'Line clearance updated');
  } catch (err) {
    return error(res, err.message);
  }
};

export const approveLineClearance = async (req, res) => {
  try {
    const { action, reason } = req.body;
    const approved = action === 'approve' || action === 'approved' || req.body.approved === true;
    const affected = await lcModel.approveLineClearance(req.params.id, {
      approved,
      rejectionReason: reason || req.body.rejectionReason || null,
    }, req.user);

    if (!affected) return notFound(res, 'Line clearance not found');
    const lc = await lcModel.getLineClearanceById(req.params.id);
    return success(res, mapLC(lc), `Line clearance ${approved ? 'approved' : 'rejected'}`);
  } catch (err) {
    return error(res, err.message);
  }
};



export const submitLineClearance = async (req, res) => {
  try {
    const affected = await lcModel.submitLineClearance(req.params.id, req.user);
    if (!affected) return notFound(res, 'Line clearance not found');
    const lc = await lcModel.getLineClearanceById(req.params.id);
    return success(res, mapLC(lc), 'Line clearance submitted');
  } catch (err) {
    return error(res, err.message);
  }
};

export const rejectLineClearance = async (req, res) => {
  try {
    const affected = await lcModel.rejectLineClearance(req.params.id, req.body.reason || req.body.rejectionReason || null, req.user);
    if (!affected) return notFound(res, 'Line clearance not found');
    const lc = await lcModel.getLineClearanceById(req.params.id);
    return success(res, mapLC(lc), 'Line clearance rejected');
  } catch (err) {
    return error(res, err.message);
  }
};

export const getProductLookup = async (req, res) => {
  try {
    const rows = await lcModel.productLookup(req.query);
    return success(res, rows);
  } catch (err) {
    return error(res, err.message);
  }
};

const csvValue = (value) => {
  if (value === undefined || value === null) return '';
  const text = String(value).replace(/"/g, '""');
  return /[",\n]/.test(text) ? `"${text}"` : text;
};

export const exportLineClearanceReport = async (req, res) => {
  try {
    const result = await lcModel.listLineClearances({ ...req.query, page: 1, limit: req.query.limit || 5000 });
    const headers = ['Request No', 'WO Number', 'Machine', 'Product Code', 'Product Name', 'Shift', 'Type', 'Status', 'Checked', 'Submitted At', 'Approved At'];
    const rows = result.rows.map((r) => [r.requestNo, r.woNumber, r.machine || r.machineCode, r.productCode, r.productName, r.submissionShift || r.shift, r.clearanceType, r.status, `${r.checkedCount || 0}/${r.checkedTotal || 0}`, r.submittedAt, r.approvedAt]);
    const csv = [headers, ...rows].map((row) => row.map(csvValue).join(',')).join('\n');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="line-clearance-${new Date().toISOString().slice(0, 10)}.csv"`);
    return res.status(200).send(csv);
  } catch (err) {
    return error(res, err.message);
  }
};

export const printLineClearance = async (req, res) => {
  try {
    const lc = await lcModel.getLineClearanceById(req.params.id);
    if (!lc) return notFound(res, 'Line clearance not found');
    return success(res, mapLC(lc), 'Line clearance print data');
  } catch (err) {
    return error(res, err.message);
  }
};

export const getLCChecklist = async (req, res) => {
  try {
    const rows = await lcModel.listLCChecklist(req.query);
    return success(res, rows);
  } catch (err) {
    return error(res, err.message);
  }
};

export default {
  getLineClearances,
  getLineClearance,
  createLineClearance,
  updateLineClearance,
  approveLineClearance,
  submitLineClearance,
  rejectLineClearance,
  getProductLookup,
  exportLineClearanceReport,
  printLineClearance,
  getLCChecklist,
};
