import { success, created, notFound, error, paginated, badRequest } from '../utils/response.js';
import * as qcModel from '../models/qc.model.js';

export const getQCResults = async (req, res) => {
  try {
    const { page = 1, limit = 50 } = req.query;
    const result = await qcModel.listQCResults(req.query);
    return paginated(res, result, page, limit);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getQCResult = async (req, res) => {
  try {
    const qc = await qcModel.getQCResultById(req.params.id);
    if (!qc) return notFound(res, 'QC record not found');
    return success(res, qc);
  } catch (err) {
    return error(res, err.message);
  }
};

export const createQCResult = async (req, res) => {
  try {
    const id = await qcModel.createQCResult({
      ...req.body,
      inspectorId: req.body.inspectorId || req.user?.id,
      overallResult: req.body.overallResult || req.body.result,
    }, req.user);

    const qc = await qcModel.getQCResultById(id);
    return created(res, qc, 'QC result recorded');
  } catch (err) {
    return error(res, err.message);
  }
};

export const updateQCResult = async (req, res) => {
  try {
    const affected = await qcModel.updateQCResult(req.params.id, {
      ...req.body,
      overallResult: req.body.overallResult || req.body.result,
    }, req.user);
    if (!affected) return notFound(res, 'QC record not found');

    const qc = await qcModel.getQCResultById(req.params.id);
    return success(res, qc, 'QC result updated');
  } catch (err) {
    return error(res, err.message);
  }
};

export const getQCSummary = async (req, res) => {
  try {
    const summary = await qcModel.getQCSummary(req.query);
    return success(res, summary);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getBoxQCResults = async (req, res) => {
  try {
    const { page = 1, limit = 50 } = req.query;
    const result = await qcModel.listBoxQCResults(req.query);
    return paginated(res, result, page, limit);
  } catch (err) {
    return error(res, err.message);
  }
};

export const createBoxQCResult = async (req, res) => {
  try {
    if (!req.body.boxId) return badRequest(res, 'boxId is required');

    const id = await qcModel.createBoxQCResult({
      ...req.body,
      inspectorId: req.body.inspectorId || req.user?.id,
      result: req.body.result || req.body.qcStatus || 'pending',
    }, req.user);

    return created(res, { id }, 'Box QC result recorded');
  } catch (err) {
    return error(res, err.message);
  }
};



export const updateBoxQCResult = async (req, res) => {
  try {
    const affected = await qcModel.updateBoxQCResult(req.params.id, {
      ...req.body,
      result: req.body.result || req.body.qcStatus,
      inspectorId: req.body.inspectorId || req.user?.id,
    }, req.user);
    if (!affected) return notFound(res, 'Box QC result not found');
    const row = await qcModel.getBoxQCResultById(req.params.id);
    return success(res, row, 'Box QC result updated');
  } catch (err) {
    return error(res, err.message);
  }
};

export const deleteBoxQCResult = async (req, res) => {
  try {
    const affected = await qcModel.deleteBoxQCResult(req.params.id, req.user);
    if (!affected) return notFound(res, 'Box QC result not found');
    return success(res, null, 'Box QC result deleted');
  } catch (err) {
    return error(res, err.message);
  }
};

export const getQCBoxes = async (req, res) => {
  try {
    const { default: packerModel } = await import('../models/packer.model.js');
    const result = await packerModel.listBoxes({ ...req.query, limit: req.query.limit || 500 });
    return paginated(res, result, req.query.page || 1, req.query.limit || 500);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getBoxHistory = async (req, res) => {
  try {
    const result = await qcModel.listBoxQCResults({ boxId: req.params.boxId, limit: req.query.limit || 200 });
    return success(res, result.rows || []);
  } catch (err) {
    return error(res, err.message);
  }
};

const setBoxDecision = async (req, res, status, message) => {
  try {
    const box = await qcModel.updateBoxQualityStatus({
      boxId: req.params.boxId,
      result: status,
      notes: req.body.notes || req.body.qcNotes || null,
      checks: req.body.checks || req.body.qcChecks || {},
      defects: req.body.defects || [],
      inspectorId: req.body.inspectorId || req.user?.id,
    }, req.user);
    if (!box) return notFound(res, 'Box not found');
    return success(res, box, message);
  } catch (err) {
    return error(res, err.message);
  }
};

export const approveBox = (req, res) => setBoxDecision(req, res, 'appr', 'Box approved');
export const rejectBox = (req, res) => setBoxDecision(req, res, 'rejt', 'Box rejected');
export const holdBox = (req, res) => setBoxDecision(req, res, 'hold', 'Box put on hold');

export const getWorkOrderQCSummary = async (req, res) => {
  try {
    const summary = await qcModel.getWorkOrderBoxQCSummary(req.params.woId);
    return success(res, summary || { total: 0, approved: 0, rejected: 0, hold: 0, pending: 0 });
  } catch (err) {
    return error(res, err.message);
  }
};

export const getDefectTypes = async (req, res) => {
  try {
    const rows = await qcModel.listDefectTypes(req.query);
    return success(res, rows);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getQCChecklist = async (req, res) => {
  try {
    const rows = await qcModel.listQCChecklist(req.query);
    return success(res, rows);
  } catch (err) {
    return error(res, err.message);
  }
};

export default {
  getQCResults,
  getQCResult,
  createQCResult,
  updateQCResult,
  getQCSummary,
  getBoxQCResults,
  createBoxQCResult,
  updateBoxQCResult,
  deleteBoxQCResult,
  getQCBoxes,
  getBoxHistory,
  approveBox,
  rejectBox,
  holdBox,
  getWorkOrderQCSummary,
  getDefectTypes,
  getQCChecklist,
};
