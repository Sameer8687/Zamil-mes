import { success, created, notFound, error, paginated, badRequest } from '../utils/response.js';
import * as productionModel from '../models/production.model.js';
import * as fusionService from '../services/fusion.service.js';

const sendFailure = (res, statusCode, message, data = null) => {
  return res.status(statusCode).json({
    success: false,
    message,
    ...(data ? { data } : {}),
  });
};

const safeFusionErrorData = (err) => {
  const fusionData = err?.fusionData || null;

  return {
    code: err?.code || 'FUSION_API_ERROR',
    fusionHttpStatus: err?.fusionHttpStatus || null,
    fusionMessage:
      fusionData?.title ||
      fusionData?.detail ||
      fusionData?.message ||
      fusionData?.Message ||
      null,
    fusionErrorCode:
      fusionData?.errorCode ||
      fusionData?.ErrorCode ||
      null,
  };
};

const buildFusionStatusSummary = (fusionItem = {}) => ({
  organizationId: fusionItem.OrganizationId,
  organizationCode: fusionItem.OrganizationCode,
  workOrderId: fusionItem.WorkOrderId,
  workOrderNumber: fusionItem.WorkOrderNumber,
  statusName: fusionItem.WorkOrderStatusName,
  statusCode: fusionItem.WorkOrderStatusCode,
  systemStatusCode: fusionItem.WorkOrderSystemStatusCode,
  releasedDate: fusionItem.ReleasedDate,
  lastUpdateDate: fusionItem.LastUpdateDate,
});


const normalizePriority = (value) => {
  if (value === undefined || value === null || value === '') return value;
  const v = String(value).trim().toLowerCase();
  if (['1', '1 - high', 'high'].includes(v)) return 'high';
  if (['2', '2 - normal', 'normal', 'medium'].includes(v)) return 'normal';
  if (['3', '3 - low', 'low'].includes(v)) return 'low';
  if (['urgent', 'critical'].includes(v)) return 'urgent';
  return v;
};

const normalizeStatus = (value) => {
  if (value === undefined || value === null || value === '') return value;
  const v = String(value).trim().toLowerCase().replace(/[_-]+/g, ' ');
  if (['running', 'run', 'in progress', 'started'].includes(v)) return 'active';
  if (['not started', 'new', 'open', 'scheduled'].includes(v)) return 'pending';
  if (['on hold', 'hold', 'pause'].includes(v)) return 'paused';
  if (['terminated', 'canceled', 'cancel', 'void'].includes(v)) return 'cancelled';
  if (['complete', 'done', 'closed'].includes(v)) return 'completed';
  return v;
};

const toIsoDateString = (value) => {
  if (value === undefined) return undefined;
  if (value === null || value === '') return null;

  if (value instanceof Date) {
    return value.toISOString().replace('Z', '+00:00');
  }

  const raw = String(value).trim();

  // Already correct format: 2025-12-22T08:50:00.000+00:00
  if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}\+00:00$/.test(raw)) {
    return raw;
  }

  // ISO with Z: 2025-12-22T08:50:00.000Z
  if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(raw)) {
    return raw.replace('Z', '+00:00');
  }

  // input type="date": 2025-12-22
  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) {
    return `${raw}T00:00:00.000+00:00`;
  }

  // input type="datetime-local": 2025-12-22T08:50
  if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(raw)) {
    return `${raw}:00.000+00:00`;
  }

  // ISO without milliseconds: 2025-12-22T08:50:00
  if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}$/.test(raw)) {
    return `${raw}.000+00:00`;
  }

  const parsedDate = new Date(raw);

  if (Number.isNaN(parsedDate.getTime())) {
    throw new Error(`Invalid date format: ${value}`);
  }

  return parsedDate.toISOString().replace('Z', '+00:00');
};

const removeUndefined = (obj) =>
  Object.fromEntries(
    Object.entries(obj).filter(([, value]) => value !== undefined)
  );

const normalizeWorkOrderPayload = (body = {}, user = null) => {
  const payload = {
    ...body,

    woNumber: body.woNumber || body.workOrderNumber || body.wo || body.id,

    product:
      body.product ||
      body.productName ||
      body.sub ||
      body.itemName ||
      body.itemDescription,

    productCode: body.productCode || body.code || body.itemCode,

    plannedQty:
      body.plannedQty ??
      body.qty ??
      body.quantity ??
      body.totalQty ??
      body.orderQty,

    boxQty:
      body.boxQty ??
      body.qtyPerBox ??
      body.quantityPerBox,

    targetQty:
      body.targetQty ??
      body.plannedQty ??
      body.qty ??
      body.quantity,

    machineId: body.machineId || body.machine || body.machineCode,

    priority:
      body.priority !== undefined
        ? normalizePriority(body.priority)
        : undefined,

    status:
      body.status !== undefined || body.woStatus !== undefined
        ? normalizeStatus(body.status || body.woStatus)
        : undefined,

    scheduledDate: toIsoDateString(
      body.scheduledDate ||
      body.scheduleDate ||
      body.startDate
    ),

    completedDate: toIsoDateString(
      body.completedDate ||
      body.completionDate
    ),

    startedAt: toIsoDateString(
      body.startedAt ||
      body.startTime
    ),

    pausedAt: toIsoDateString(
      body.pausedAt ||
      body.pauseTime
    ),

    scheduledEndDate: toIsoDateString(
      body.scheduledEndDate ||
      body.scheduledEnd ||
      body.scheduleEnd ||
      body.endDate
    ),

    locatorCode:
      body.locatorCode ||
      body.locator ||
      body.stockLocator ||
      body.locationCode,

    executionSequence:
      body.executionSequence ??
      body.sequence ??
      body.sortOrder ??
      body.lineSequence,

    plant: body.plant || user?.plant || 'Zamil Plastics',
  };

  return removeUndefined(payload);
};

export const getWorkOrdersLov = async (req, res) => {
  try {
    const organizationId =
      req.query.organizationId ||
      req.query.organization_id ||
      req.query.organisationId ||
      req.query.organisation_id ||
      req.query.orgId ||
      req.query.org_id ||
      null;

    const machineId =
      req.query.machineId ||
      req.query.machine_id ||
      req.query.machine ||
      null;

    const workOrders = await productionModel.listWorkOrdersLov({
      organizationId,
      machineId,
    });

    return success(res, workOrders);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getWorkOrders = async (req, res) => {

  try {
    const isMachineIpBound = req?.machineDeviceInfo?.machineIpBound || false;
    const machineCode = req?.machineDeviceInfo?.code || '';
    const organizationId = req?.machineDeviceInfo?.organizationId || '';

    const { page = 1, limit = 20 } = req.query;
    const result = await productionModel.listWorkOrders(req.query, isMachineIpBound, machineCode, organizationId);
    return paginated(res, result, page, limit);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getWorkOrder = async (req, res) => {
  try {
    const wo = await productionModel.getWorkOrderById(req.params.id);
    if (!wo) return notFound(res, 'Work order not found');

    const components = await productionModel.listWorkOrderComponents(req.params.id);
    return success(res, { ...wo, components });
  } catch (err) {
    return error(res, err.message);
  }
};

export const createWorkOrder = async (req, res) => {
  try {
    const payload = normalizeWorkOrderPayload(req.body, req.user);
    payload.status = payload.status || 'pending';
    if (!payload.woNumber || !payload.product) return badRequest(res, 'Work order number and product are required');

    const id = await productionModel.createWorkOrder(payload, req.user);
    const wo = await productionModel.getWorkOrderById(id);
    return created(res, wo, 'Work order created');
  } catch (err) {
    return error(res, err.message);
  }
};

export const updateWorkOrder = async (req, res) => {
  try {
    const payload = normalizeWorkOrderPayload(req.body, req.user);
    const affected = await productionModel.updateWorkOrder(req.params.id, payload, req.user);
    if (!affected) return notFound(res, 'Work order not found');

    const wo = await productionModel.getWorkOrderById(req.params.id);
    return success(res, wo, 'Work order updated');
  } catch (err) {
    return error(res, err.message);
  }
};

export const deleteWorkOrder = async (req, res) => {
  try {
    const affected = await productionModel.deleteWorkOrder(req.params.id, req.user);
    if (!affected) return notFound(res, 'Work order not found');
    return success(res, null, 'Work order deleted');
  } catch (err) {
    return error(res, err.message);
  }
};

export const assignWorkOrder = async (req, res) => {
  try {
    const woId = req.params.id || req.body.woId;
    const { machineId, priorityRank } = req.body;
    const notes = req.body.notes || req.body.reason || req.body.machineChangeReason || null;
    if (!woId || !machineId) return badRequest(res, 'woId and machineId are required');

    const assignmentId = await productionModel.assignWorkOrderToMachine({
      woId,
      machineId,
      priorityRank,
      assignedById: req.user?.id,
      notes,
    }, req.user);

    if (!assignmentId) return notFound(res, 'Work order not found');

    const wo = await productionModel.getWorkOrderById(woId);
    return success(res, { ...wo, assignmentId }, 'Work order assigned to machine');
  } catch (err) {
    return error(res, err.message);
  }
};

const setWorkOrderStatus = async (req, res, status, message) => {
  try {



    const wo = await productionModel.changeWorkOrderStatus({
      id: req.params.id,
      status,
      userId: req.user?.id,
      reason: req.body?.reason || req.body?.notes || null,
      qty: req.body?.qty || req.body?.quantity || null,
    }, req.user);

    if (!wo) return notFound(res, 'Work order not found');
    return success(res, wo, message);
  } catch (err) {
    if (String(err.message || '').includes('Machine already has running work order')) {
      return badRequest(res, err.message);
    }
    return error(res, err.message);
  }
};

const releaseWorkOrderFromFusion = async (req, res, status, message) => {
  try {

    // Check work order exists and is in a Unreleased state before attempting release

    // Call Fusion API to release the work order in the ERP system. If that call fails, we should not update our local status.

    // If the release is successful in the ERP system, then update the local status to Released.

    // Code to update local status to Released:
    const wo = await productionModel.changeWorkOrderStatus({
      id: req.params.id,
      status,
      userId: req.user?.id,
      reason: req.body?.reason || req.body?.notes || null,
      qty: req.body?.qty || req.body?.quantity || null,
    }, req.user);

    if (!wo) return notFound(res, 'Work order not found');
    return success(res, wo, message);
  } catch (err) {
    if (String(err.message || '').includes('Machine already has running work order')) {
      return badRequest(res, err.message);
    }
    return error(res, err.message);
  }
};

export const startWorkOrder = (req, res) => setWorkOrderStatus(req, res, 'active', 'Production started');
export const holdWorkOrder = (req, res) => setWorkOrderStatus(req, res, 'paused', 'Production paused');
export const resumeWorkOrder = (req, res) => setWorkOrderStatus(req, res, 'active', 'Production resumed');
export const completeWorkOrder = (req, res) => setWorkOrderStatus(req, res, 'completed', 'Production completed');
export const terminateWorkOrder = (req, res) => setWorkOrderStatus(req, res, 'cancelled', 'Production terminated');


export const releaseWorkOrder = async (req, res) => {
  try {
    const lookup = String(req.params.id || '').trim();

    if (!lookup) {
      return badRequest(res, 'Work order ID or work order number is required');
    }

    const localWo = await productionModel.getWorkOrderForFusionRelease(lookup);

    if (!localWo) {
      return notFound(
        res,
        'Work order not found. Only INJ- and ZFP work orders are allowed for release.'
      );
    }

    if (!localWo.woNumber) {
      return badRequest(res, 'MES work order number is missing');
    }

    if (!productionModel.isLocalUnreleasedStatus(localWo.status)) {
      return sendFailure(
        res,
        400,
        `Only Unreleased work orders can be released. Current MES status is ${localWo.status || 'blank'}.`,
        {
          action: 'RELEASE_BLOCKED_LOCAL_NOT_UNRELEASED',
          local: {
            id: localWo.id,
            woNumber: localWo.woNumber,
            workOrderId: localWo.workOrderId,
            machineId: localWo.machineId,
            status: localWo.status,
          },
        }
      );
    }

    const fusionGetResult = await fusionService.getFusionWorkOrderByNumber(localWo.woNumber);
    const fusionItem = fusionGetResult.item;

    const fusionStatus = buildFusionStatusSummary(fusionItem);

    if (
      localWo.workOrderId &&
      fusionItem.WorkOrderId &&
      String(localWo.workOrderId) !== String(fusionItem.WorkOrderId)
    ) {
      return sendFailure(
        res,
        409,
        'MES WORK_ORDER_ID does not match Fusion WorkOrderId for this WorkOrderNumber.',
        {
          action: 'RELEASE_BLOCKED_WORK_ORDER_ID_MISMATCH',
          local: {
            id: localWo.id,
            woNumber: localWo.woNumber,
            workOrderId: localWo.workOrderId,
            status: localWo.status,
          },
          fusion: fusionStatus,
        }
      );
    }

    if (!fusionService.isFusionUnreleased(fusionItem)) {
      const localMatchesFusion = productionModel.localStatusMatchesFusion(
        localWo.status,
        fusionItem
      );

      let localSyncApplied = false;

      if (!localMatchesFusion && productionModel.isLocalUnreleasedStatus(localWo.status)) {
        const affected = await productionModel.updateLocalWorkOrderStatusFromFusion({
          id: localWo.id,
          fusionItem,
          onlyWhenLocalUnreleased: true,
          user: req.user,
        });

        localSyncApplied = affected > 0;
      }

      const updatedWo = await productionModel.getWorkOrderById(localWo.id);

      return success(
        res,
        {
          action: localSyncApplied
            ? 'LOCAL_STATUS_SYNCED_FROM_FUSION_NO_RELEASE_PATCH'
            : 'NO_RELEASE_PATCH_FUSION_NOT_UNRELEASED',
          releasePatchCalled: false,
          localStatusBefore: localWo.status,
          localStatusAfter: updatedWo?.status || localWo.status,
          localSyncApplied,
          workOrder: updatedWo || localWo,
          fusion: fusionStatus,
        },
        `Fusion work order is ${fusionStatus.statusName || fusionStatus.systemStatusCode || 'not Unreleased'}, so release PATCH was not called.`
      );
    }

    const fusionWorkOrderId = fusionItem.WorkOrderId;

    if (!fusionWorkOrderId) {
      return sendFailure(
        res,
        502,
        'Fusion work order is Unreleased but WorkOrderId is missing in Fusion response.',
        {
          action: 'RELEASE_BLOCKED_FUSION_WORK_ORDER_ID_MISSING',
          local: {
            id: localWo.id,
            woNumber: localWo.woNumber,
            status: localWo.status,
          },
          fusion: fusionStatus,
        }
      );
    }

    const fusionPatchResult = await fusionService.releaseFusionWorkOrderById(fusionWorkOrderId);
    const releasedFusionItem = fusionPatchResult.item;

    const affected = await productionModel.updateLocalWorkOrderStatusFromFusion({
      id: localWo.id,
      fusionItem: releasedFusionItem,
      onlyWhenLocalUnreleased: true,
      user: req.user,
    });

    if (!affected) {
      return sendFailure(
        res,
        409,
        'Fusion released the work order, but MES local update was not applied because local status changed from Unreleased.',
        {
          action: 'FUSION_RELEASED_LOCAL_UPDATE_BLOCKED',
          local: {
            id: localWo.id,
            woNumber: localWo.woNumber,
            previousStatus: localWo.status,
          },
          fusion: buildFusionStatusSummary(releasedFusionItem),
        }
      );
    }

    const updatedWo = await productionModel.getWorkOrderById(localWo.id);

    return success(
      res,
      {
        action: 'FUSION_RELEASED_AND_LOCAL_UPDATED',
        releasePatchCalled: true,
        workOrder: updatedWo,
        fusion: {
          httpStatus: fusionPatchResult.httpStatus,
          ...buildFusionStatusSummary(releasedFusionItem),
        },
      },
      'Work order released successfully'
    );
  } catch (err) {
    if (err?.isFusionApiError) {
      return sendFailure(
        res,
        err.statusCode || 502,
        err.message || 'Fusion API failed',
        {
          action: 'FUSION_API_ERROR',
          ...safeFusionErrorData(err),
        }
      );
    }

    return error(res, err.message);
  }
};

export const getActiveWorkOrder = async (req, res) => {
  try {
    const machineIdRaw = req.query.machineId || req.params.machineId;

    if (!machineIdRaw) {
      return badRequest(res, 'machineId is required');
    }

    // Supports values like:
    // "machine_uuid"
    // "ZFP001"
    // "ZFP001 – INJECTION"
    // "ZFP001 - INJECTION"
    const machineId = String(machineIdRaw)
      .split(/\s+[–-]\s+/)[0]
      .trim();

    const strictActive =
      req.query.strict === 'true' ||
      req.originalUrl.includes('/operator/active-work-order');

    const wo = await productionModel.getActiveWorkOrderByMachine(machineId, {
      strictActive,
    });

    if (!wo) {
      return notFound(res, 'No active work order found for this machine');
    }

    const components = await productionModel.listWorkOrderComponents(wo.id);

    return success(res, { ...wo, components });
  } catch (err) {
    return error(res, err.message);
  }
};

export const getLogs = async (req, res) => {
  try {
    const { page = 1, limit = 20 } = req.query;
    const result = await productionModel.listProductionLogs(req.query);
    return paginated(res, result, page, limit);
  } catch (err) {
    return error(res, err.message);
  }
};

export const createLog = async (req, res) => {
  try {
    const id = await productionModel.createProductionLog({
      ...req.body,
      operatorId: req.body.operatorId || req.user?.id,
      qtyProduced: req.body.qtyProduced ?? req.body.quantity ?? req.body.qty,
    }, req.user);
    return created(res, { id }, 'Production log created');
  } catch (err) {
    return error(res, err.message);
  }
};

export const getMachinesLov = async (req, res) => {
  try {
    const organizationId =
      req.query.organizationId ||
      req.query.organization_id ||
      req.query.organisationId ||
      req.query.organisation_id ||
      req.query.orgId ||
      req.query.org_id ||
      null;

    const machines = await productionModel.listMachinesLov(organizationId);

    return success(res, machines);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getMachines = async (req, res) => {
  try {
    const machines = await productionModel.listProductionMachines(req.query);
    return success(res, machines);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getDashboard = async (_req, res) => {
  try {
    const summary = await productionModel.getDashboardSummary();
    return success(res, {
      workOrders: {
        total: summary.totalWorkOrders || 0,
        active: summary.activeWorkOrders || 0,
        pending: summary.pendingWorkOrders || 0,
        completed: summary.completedWorkOrders || 0,
      },
      production: {
        plannedQty: summary.plannedQty || 0,
        producedQty: summary.producedQty || 0,
      },
      machines: {
        total: summary.totalMachines || 0,
        running: summary.runningMachines || 0,
        idle: summary.idleMachines || 0,
        down: summary.downMachines || 0,
      },
    });
  } catch (err) {
    return error(res, err.message);
  }
};

export const getTechDashboard = async (req, res) => {
  try {
    const machineId = req.query.machineId || req.query.machineCode || req.query.machine || null;
    const plant = req.query.plant || null;

    const [summary, machines, activeResult, pendingResult, pausedResult] = await Promise.all([
      productionModel.getDashboardSummary(),
      productionModel.listProductionMachines({
        plant,
        machineId,
        machineCode: machineId,
      }),
      productionModel.listWorkOrders({
        plant,
        machineId,
        status: 'active',
        page: 1,
        limit: req.query.limit || 500,
      }),
      productionModel.listWorkOrders({
        plant,
        machineId,
        status: 'pending',
        page: 1,
        limit: req.query.limit || 500,
      }),
      productionModel.listWorkOrders({
        plant,
        machineId,
        status: 'paused',
        page: 1,
        limit: req.query.limit || 500,
      }),
    ]);

    return success(res, {
      summary: {
        workOrders: {
          total: summary.totalWorkOrders || 0,
          active: summary.activeWorkOrders || 0,
          pending: summary.pendingWorkOrders || 0,
          completed: summary.completedWorkOrders || 0,
        },
        production: {
          plannedQty: summary.plannedQty || 0,
          producedQty: summary.producedQty || 0,
        },
        machines: {
          total: summary.totalMachines || 0,
          running: summary.runningMachines || 0,
          idle: summary.idleMachines || 0,
          down: summary.downMachines || 0,
        },
      },
      machines,
      activeWorkOrders: activeResult.rows || [],
      pendingWorkOrders: pendingResult.rows || [],
      pausedWorkOrders: pausedResult.rows || [],
      queue: [
        ...(activeResult.rows || []),
        ...(pausedResult.rows || []),
        ...(pendingResult.rows || []),
      ],
    });
  } catch (err) {
    return error(res, err.message);
  }
};



export const getWorkOrderEvents = async (req, res) => {
  try {
    const rows = await productionModel.listWorkOrderEvents(req.params.id);
    return success(res, rows);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getWorkOrderAssignmentHistory = async (req, res) => {
  try {
    const rows = await productionModel.listWorkOrderAssignmentHistory(req.params.id);
    return success(res, rows);
  } catch (err) {
    return error(res, err.message);
  }
};

export const updateWorkOrderSchedule = async (req, res) => {
  try {
    const affected = await productionModel.updateWorkOrderSchedule(req.params.id, req.body || {}, req.user);
    if (!affected) return notFound(res, 'Work order not found');
    const wo = await productionModel.getWorkOrderById(req.params.id);
    return success(res, wo, 'Work order schedule updated');
  } catch (err) {
    return error(res, err.message);
  }
};

export const updateWorkOrderPriorityRank = async (req, res) => {
  try {
    const rank = req.body.priorityRank ?? req.body.executionSequence ?? req.body.sequence;
    if (rank === undefined || rank === null || rank === '') return badRequest(res, 'priorityRank is required');
    const affected = await productionModel.updateWorkOrderPriorityRank(req.params.id, Number(rank), req.user);
    if (!affected) return notFound(res, 'Work order not found');
    const wo = await productionModel.getWorkOrderById(req.params.id);
    return success(res, wo, 'Work order priority rank updated');
  } catch (err) {
    return error(res, err.message);
  }
};

export const updateMachineStatus = async (req, res) => {
  try {
    const status = req.body.status || req.body.machineStatus;
    if (!status) return badRequest(res, 'status is required');
    const affected = await productionModel.updateMachineStatus(req.params.id, status, req.user);
    if (!affected) return notFound(res, 'Machine not found');
    return success(res, { id: req.params.id, status }, 'Machine status updated');
  } catch (err) {
    return error(res, err.message);
  }
};

export const getComponents = async (req, res) => {
  try {
    const components = await productionModel.listWorkOrderComponents(req.params.id || req.query.woId);
    return success(res, components);
  } catch (err) {
    return error(res, err.message);
  }
};

export const createComponent = async (req, res) => {
  try {
    const woId = req.params.id || req.body.woId;
    if (!woId) return badRequest(res, 'woId is required');

    const id = await productionModel.createWorkOrderComponent({ ...req.body, woId }, req.user);
    return created(res, { id }, 'Work order component created');
  } catch (err) {
    return error(res, err.message);
  }
};


export const reorderWorkOrders = async (req, res) => {
  try {
    const items = Array.isArray(req.body) ? req.body : (req.body.items || req.body.workOrders || []);
    if (!Array.isArray(items) || !items.length) return badRequest(res, 'items array is required');

    const updatedCount = await productionModel.reorderWorkOrders(items, req.user);
    return success(res, { updatedCount }, 'Execution sequence updated');
  } catch (err) {
    return error(res, err.message);
  }
};

const csvValue = (value) => {
  if (value === undefined || value === null) return '';
  const text = String(value).replace(/"/g, '""');
  return /[",\n]/.test(text) ? `"${text}"` : text;
};

export const exportWorkOrders = async (req, res) => {
  try {
    const result = await productionModel.listWorkOrders({ ...req.query, page: 1, limit: req.query.limit || 5000 });
    const headers = [
      'WO Number', 'Product Code', 'Product', 'Customer', 'Plant', 'Machine Code', 'Machine Name',
      'Status', 'Priority', 'Planned Qty', 'Produced Qty', 'Box Qty', 'Total Boxes',
      'Scheduled Start', 'Scheduled End', 'Locator', 'Execution Sequence',
    ];
    const rows = result.rows.map((wo) => [
      wo.woNumber, wo.productCode, wo.product, wo.customer, wo.plant, wo.machineCode, wo.machineName,
      wo.status, wo.priority, wo.plannedQty, wo.producedQty, wo.boxQty, wo.totalBoxes,
      wo.scheduledDate, wo.scheduledEndDate, wo.locatorCode || wo.locator, wo.executionSequence,
    ]);
    const csv = [headers, ...rows].map((row) => row.map(csvValue).join(',')).join('\n');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="production-schedule-${new Date().toISOString().slice(0, 10)}.csv"`);
    return res.status(200).send(csv);
  } catch (err) {
    return error(res, err.message);
  }
};

export default {
  getDashboard,
  getTechDashboard,
  getWorkOrders,
  getWorkOrder,
  createWorkOrder,
  updateWorkOrder,
  deleteWorkOrder,
  assignWorkOrder,
  getWorkOrderEvents,
  getWorkOrderAssignmentHistory,
  updateWorkOrderSchedule,
  updateWorkOrderPriorityRank,
  updateMachineStatus,
  startWorkOrder,
  holdWorkOrder,
  resumeWorkOrder,
  completeWorkOrder,
  terminateWorkOrder,
  getActiveWorkOrder,
  reorderWorkOrders,
  exportWorkOrders,
  getLogs,
  createLog,
  getWorkOrdersLov,
  getMachinesLov,
  getMachines,
  getComponents,
  createComponent,
  releaseWorkOrder,
};
