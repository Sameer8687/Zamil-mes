import { success, notFound, badRequest, error } from '../utils/response.js';
import { executeRows, executeOne, executeCommit } from '../config/oracle.js';
import {
  SETUP_TABLES,
  nextNumber,
  toFlag,
  toBool,
  withTransaction,
  mapScreenPerms,
  mapFeaturePerms,
  getScreenIdByCode,
  getFeatureIdByCode,
  normalizeSecurity,
  saveSecuritySettings,
  rebuildUserPermissions,
  audit,
  fetchRoleByAny,
  listActiveRoles,
} from '../models/setupAccess.model.js';

const buildTree = (rows, parentId = null) => rows
  .filter((row) => String(row.parent_id ?? '') === String(parentId ?? ''))
  .map((row) => ({
    id: row.code,
    dbId: row.id,
    name: row.name,
    icon: row.icon,
    unitType: row.unit_type,
    children: buildTree(rows, row.id),
  }));

const getScreenRows = () => executeRows(
  `
  SELECT ID AS "dbId", CODE AS "id", CODE AS "code", LABEL AS "label",
         MODULE AS "mod", MODULE AS "module", ICON AS "icon", SORT_ORDER AS "sort_order"
  FROM ${SETUP_TABLES.appScreens}
  WHERE NVL(IS_ACTIVE,1)=1
  ORDER BY SORT_ORDER, ID
  `,
);

const getFeatureRows = () => executeRows(
  `
  SELECT ID AS "dbId", CODE AS "id", CODE AS "code", LABEL AS "label",
         CATEGORY AS "cat", CATEGORY AS "category", DESCRIPTION AS "desc",
         DESCRIPTION AS "description", SORT_ORDER AS "sort_order"
  FROM ${SETUP_TABLES.appFeatures}
  WHERE NVL(IS_ACTIVE,1)=1
  ORDER BY SORT_ORDER, ID
  `,
);

const rolePermissionObjects = async (roleId) => {
  const screenRows = await executeRows(
    `
    SELECT s.CODE AS "code", NVL(rsp.CAN_VIEW,0) AS "can_view", NVL(rsp.CAN_CREATE,0) AS "can_create",
           NVL(rsp.CAN_EDIT,0) AS "can_edit", NVL(rsp.CAN_DELETE,0) AS "can_delete", NVL(rsp.CAN_EXPORT,0) AS "can_export"
    FROM ${SETUP_TABLES.appScreens} s
    LEFT JOIN ${SETUP_TABLES.roleScreenPermissions} rsp
      ON rsp.SCREEN_ID = s.ID AND rsp.ROLE_ID = :roleId
    WHERE NVL(s.IS_ACTIVE,1)=1
    ORDER BY s.SORT_ORDER, s.ID
    `,
    { roleId },
  );
  const featureRows = await executeRows(
    `
    SELECT f.CODE AS "code", NVL(rfp.IS_ENABLED,0) AS "is_enabled"
    FROM ${SETUP_TABLES.appFeatures} f
    LEFT JOIN ${SETUP_TABLES.roleFeaturePermissions} rfp
      ON rfp.FEATURE_ID = f.ID AND rfp.ROLE_ID = :roleId
    WHERE NVL(f.IS_ACTIVE,1)=1
    ORDER BY f.SORT_ORDER, f.ID
    `,
    { roleId },
  );
  return { screens: mapScreenPerms(screenRows), features: mapFeaturePerms(featureRows), screenRows, featureRows };
};

export const bootstrap = async (_req, res) => {
  try {
    const screens = await getScreenRows();
    const features = await getFeatureRows();
    const roles = await listActiveRoles();

    for (const role of roles) {
      const perms = await rolePermissionObjects(role.role_id);
      role.screens = perms.screens;
      role.features = perms.features;
    }

    const orgRows = await executeRows(
      `
      SELECT ID AS "id", CODE AS "code", NAME AS "name", UNIT_TYPE AS "unit_type",
             PARENT_ID AS "parent_id", ICON AS "icon", SORT_ORDER AS "sort_order"
      FROM ${SETUP_TABLES.orgUnits}
      WHERE NVL(IS_ACTIVE,1)=1
      ORDER BY SORT_ORDER, ID
      `,
    );

    return success(res, {
      screens: screens.map((s) => ({ id: s.id, label: s.label, mod: s.mod, icon: s.icon })),
      features: features.map((f) => ({ id: f.id, label: f.label, cat: f.cat, desc: f.desc })),
      roles,
      orgTree: buildTree(orgRows),
    }, 'Access master data loaded');
  } catch (err) { return error(res, err.message); }
};

export const getUserAccess = async (req, res) => {
  try {
    const { userId } = req.params;
    const user = await executeOne(
      `SELECT ID AS "id", ROLE AS "role", SCREEN_PERMISSIONS AS "screenPermissions" FROM ${SETUP_TABLES.users} WHERE ID=:userId AND NVL(IS_DELETED,0)=0 FETCH FIRST 1 ROWS ONLY`,
      { userId },
    );
    if (!user) return notFound(res, 'User not found');

    const roleRows = await executeRows(
      `
      SELECT r.ROLE_ID AS "role_id", r.ID AS "id", r.CODE AS "code", r.NAME AS "name",
             r.ICON AS "icon", r.COLOR AS "color", ur.IS_PRIMARY AS "is_primary"
      FROM ${SETUP_TABLES.userRoles} ur
      JOIN ${SETUP_TABLES.roles} r ON r.ROLE_ID = ur.ROLE_ID
      WHERE ur.USER_ID = :userId AND NVL(r.IS_DELETED,0)=0
      ORDER BY ur.IS_PRIMARY DESC, r.NAME
      `,
      { userId },
    );

    const screenRows = await executeRows(
      `
      SELECT s.CODE AS "code", usp.CAN_VIEW AS "can_view", usp.CAN_CREATE AS "can_create",
             usp.CAN_EDIT AS "can_edit", usp.CAN_DELETE AS "can_delete", usp.CAN_EXPORT AS "can_export"
      FROM ${SETUP_TABLES.userScreenPermissions} usp
      JOIN ${SETUP_TABLES.appScreens} s ON s.ID = usp.SCREEN_ID
      WHERE usp.USER_ID = :userId
      ORDER BY s.SORT_ORDER, s.ID
      `,
      { userId },
    );

    const featureRows = await executeRows(
      `
      SELECT f.CODE AS "code", ufp.IS_ENABLED AS "is_enabled"
      FROM ${SETUP_TABLES.userFeaturePermissions} ufp
      JOIN ${SETUP_TABLES.appFeatures} f ON f.ID = ufp.FEATURE_ID
      WHERE ufp.USER_ID = :userId
      ORDER BY f.SORT_ORDER, f.ID
      `,
      { userId },
    );

    const scopeRows = await executeRows(
      `
      SELECT o.CODE AS "code"
      FROM ${SETUP_TABLES.userScope} us
      JOIN ${SETUP_TABLES.orgUnits} o ON o.ID = us.ORG_UNIT_ID
      WHERE us.USER_ID = :userId
      `,
      { userId },
    );

    const security = await executeOne(
      `
      SELECT FORCE_PASSWORD_RESET AS "pwReset", PASSWORD_STRENGTH AS "pwStr",
             LOCKOUT_AFTER AS "lockout", SESSION_TIMEOUT_MINUTES AS "timeout",
             ALLOWED_LOGIN_HOURS AS "hours", ALLOWED_DEVICE AS "device",
             AUDIT_ENABLED AS "audit", EMAIL_NOTIFY AS "emailNotify",
             TWO_FA_ENABLED AS "twoFA", IP_RESTRICT_ENABLED AS "ipRestrict"
      FROM ${SETUP_TABLES.userSecuritySettings}
      WHERE USER_ID = :userId
      FETCH FIRST 1 ROWS ONLY
      `,
      { userId },
    );

    const normalizedSecurity = security ? {
      ...security,
      lockout: String(security.lockout || '5'),
      timeout: String(security.timeout || '240'),
      audit: toBool(security.audit, true),
      emailNotify: toBool(security.emailNotify, true),
      twoFA: toBool(security.twoFA),
      ipRestrict: toBool(security.ipRestrict),
    } : null;

    return success(res, {
      roles: roleRows.map((r) => ({ ...r, role_id: Number(r.role_id), is_primary: Number(r.is_primary || 0) })),
      screens: mapScreenPerms(screenRows),
      features: mapFeaturePerms(featureRows),
      scope: scopeRows.map((r) => r.code),
      security: normalizedSecurity,
    }, 'User access loaded');
  } catch (err) { return error(res, err.message); }
};

export const saveUserAccess = async (req, res) => {
  try {
    const { userId } = req.params;
    const { screens = {}, features = {}, scope = [], security = {} } = req.body;

    const saved = await withTransaction(async (connection) => {
      const userResult = await connection.execute(
        `SELECT ID AS "id" FROM ${SETUP_TABLES.users} WHERE ID=:userId AND NVL(IS_DELETED,0)=0 FETCH FIRST 1 ROWS ONLY`,
        { userId },
      );
      if (!userResult.rows?.length) throw Object.assign(new Error('User not found'), { statusCode: 404 });

      await connection.execute(`DELETE FROM ${SETUP_TABLES.userScreenPermissions} WHERE USER_ID=:userId`, { userId });
      for (const [screenCode, perms] of Object.entries(screens)) {
        const screenId = await getScreenIdByCode(screenCode, connection);
        if (!screenId) continue;
        await connection.execute(
          `
          INSERT INTO ${SETUP_TABLES.userScreenPermissions}
          (ID, USER_ID, SCREEN_ID, CAN_VIEW, CAN_CREATE, CAN_EDIT, CAN_DELETE, CAN_EXPORT, CREATED_AT, UPDATED_AT)
          VALUES (:id, :userId, :screenId, :canView, :canCreate, :canEdit, :canDelete, :canExport, SYSTIMESTAMP, SYSTIMESTAMP)
          `,
          {
            id: await nextNumber(SETUP_TABLES.userScreenPermissions, 'ID', connection),
            userId,
            screenId,
            canView: perms.view ? 1 : 0,
            canCreate: perms.create ? 1 : 0,
            canEdit: perms.edit ? 1 : 0,
            canDelete: perms.delete ? 1 : 0,
            canExport: perms.export ? 1 : 0,
          },
        );
      }

      await connection.execute(`DELETE FROM ${SETUP_TABLES.userFeaturePermissions} WHERE USER_ID=:userId`, { userId });
      for (const [featureCode, enabled] of Object.entries(features)) {
        const featureId = await getFeatureIdByCode(featureCode, connection);
        if (!featureId) continue;
        await connection.execute(
          `INSERT INTO ${SETUP_TABLES.userFeaturePermissions} (ID, USER_ID, FEATURE_ID, IS_ENABLED, CREATED_AT, UPDATED_AT) VALUES (:id, :userId, :featureId, :isEnabled, SYSTIMESTAMP, SYSTIMESTAMP)`,
          { id: await nextNumber(SETUP_TABLES.userFeaturePermissions, 'ID', connection), userId, featureId, isEnabled: enabled ? 1 : 0 },
        );
      }

      await connection.execute(`DELETE FROM ${SETUP_TABLES.userScope} WHERE USER_ID=:userId`, { userId });
      for (const code of scope) {
        const orgResult = await connection.execute(`SELECT ID AS "id" FROM ${SETUP_TABLES.orgUnits} WHERE CODE=:code FETCH FIRST 1 ROWS ONLY`, { code });
        const orgUnitId = orgResult.rows?.[0]?.id;
        if (!orgUnitId) continue;
        await connection.execute(
          `INSERT INTO ${SETUP_TABLES.userScope} (ID, USER_ID, ORG_UNIT_ID, CREATED_AT) VALUES (:id, :userId, :orgUnitId, SYSTIMESTAMP)`,
          { id: await nextNumber(SETUP_TABLES.userScope, 'ID', connection), userId, orgUnitId },
        );
      }

      const savedSecurity = await saveSecuritySettings(connection, userId, security);

      await connection.execute(
        `UPDATE ${SETUP_TABLES.users} SET SCREEN_PERMISSIONS=:screenPermissions, UPDATED_BY=:userName, UPDATED_AT=SYSTIMESTAMP WHERE ID=:userId`,
        { userId, screenPermissions: JSON.stringify({ scope, security: savedSecurity }), userName: req.user?.empId || req.user?.username || req.user?.id || 'system' },
      );

      await audit('USER_ACCESS', 'UPDATE', userId, req, null, { screens, features, scope, security: savedSecurity }, connection);
      return { screens, features, scope, security: savedSecurity };
    });

    return success(res, saved, 'User access saved');
  } catch (err) {
    if (err.statusCode === 404) return notFound(res, err.message);
    return error(res, err.message);
  }
};

export const getRolePermissions = async (req, res) => {
  try {
    const role = await fetchRoleByAny(req.params.roleId);
    if (!role) return notFound(res, 'Role not found');
    const perms = await rolePermissionObjects(role.role_id);
    return success(res, perms, 'Role permissions loaded');
  } catch (err) { return error(res, err.message); }
};

export const createRolePermissions = async (req, res) => updateRolePermissions(req, res);

export const updateRolePermissions = async (req, res) => {
  try {
    const role = await fetchRoleByAny(req.params.roleId);
    if (!role) return notFound(res, 'Role not found');
    const { screens = {}, features = {} } = req.body;

    await withTransaction(async (connection) => {
      await connection.execute(`DELETE FROM ${SETUP_TABLES.roleScreenPermissions} WHERE ROLE_ID=:roleId`, { roleId: role.role_id });
      for (const [screenCode, perms] of Object.entries(screens)) {
        const screenId = await getScreenIdByCode(screenCode, connection);
        if (!screenId) continue;
        await connection.execute(
          `INSERT INTO ${SETUP_TABLES.roleScreenPermissions} (ID, ROLE_ID, SCREEN_ID, CAN_VIEW, CAN_CREATE, CAN_EDIT, CAN_DELETE, CAN_EXPORT, CREATED_AT, UPDATED_AT) VALUES (:id, :roleId, :screenId, :canView, :canCreate, :canEdit, :canDelete, :canExport, SYSTIMESTAMP, SYSTIMESTAMP)`,
          { id: await nextNumber(SETUP_TABLES.roleScreenPermissions, 'ID', connection), roleId: role.role_id, screenId, canView: perms.view ? 1 : 0, canCreate: perms.create ? 1 : 0, canEdit: perms.edit ? 1 : 0, canDelete: perms.delete ? 1 : 0, canExport: perms.export ? 1 : 0 },
        );
      }

      await connection.execute(`DELETE FROM ${SETUP_TABLES.roleFeaturePermissions} WHERE ROLE_ID=:roleId`, { roleId: role.role_id });
      for (const [featureCode, enabled] of Object.entries(features)) {
        const featureId = await getFeatureIdByCode(featureCode, connection);
        if (!featureId) continue;
        await connection.execute(
          `INSERT INTO ${SETUP_TABLES.roleFeaturePermissions} (ID, ROLE_ID, FEATURE_ID, IS_ENABLED, CREATED_AT, UPDATED_AT) VALUES (:id, :roleId, :featureId, :isEnabled, SYSTIMESTAMP, SYSTIMESTAMP)`,
          { id: await nextNumber(SETUP_TABLES.roleFeaturePermissions, 'ID', connection), roleId: role.role_id, featureId, isEnabled: enabled ? 1 : 0 },
        );
      }
    });

    return success(res, { roleId: role.role_id, screens, features }, 'Role permissions saved');
  } catch (err) { return error(res, err.message); }
};

export const deleteRolePermissions = async (req, res) => {
  try {
    const role = await fetchRoleByAny(req.params.roleId);
    if (!role) return notFound(res, 'Role not found');
    await withTransaction(async (connection) => {
      await connection.execute(`DELETE FROM ${SETUP_TABLES.roleScreenPermissions} WHERE ROLE_ID=:roleId`, { roleId: role.role_id });
      await connection.execute(`DELETE FROM ${SETUP_TABLES.roleFeaturePermissions} WHERE ROLE_ID=:roleId`, { roleId: role.role_id });
    });
    return success(res, { roleId: role.role_id }, 'Role permissions deleted');
  } catch (err) { return error(res, err.message); }
};

export const getScreens = async (_req, res) => {
  try { return success(res, await getScreenRows(), 'Screens loaded'); }
  catch (err) { return error(res, err.message); }
};

export const createScreen = async (req, res) => {
  try {
    const { code, label, module, mod, icon = null, sort_order = 0, sortOrder = 0 } = req.body;
    if (!code || !label) return badRequest(res, 'Screen code and label are required');
    await executeCommit(
      `INSERT INTO ${SETUP_TABLES.appScreens} (ID, CODE, LABEL, MODULE, ICON, SORT_ORDER, IS_ACTIVE, CREATED_AT, UPDATED_AT) VALUES (:id, :code, :label, :moduleName, :icon, :sortOrder, 1, SYSTIMESTAMP, SYSTIMESTAMP)`,
      { id: await nextNumber(SETUP_TABLES.appScreens), code, label, moduleName: module || mod || 'Setup', icon, sortOrder: sort_order || sortOrder || 0 },
    );
    return success(res, req.body, 'Screen created');
  } catch (err) { return error(res, err.message); }
};

export const updateScreen = async (req, res) => {
  try {
    const { code, label, module, mod, icon = null, sort_order = 0, sortOrder = 0 } = req.body;
    await executeCommit(
      `UPDATE ${SETUP_TABLES.appScreens} SET CODE=:code, LABEL=:label, MODULE=:moduleName, ICON=:icon, SORT_ORDER=:sortOrder, UPDATED_AT=SYSTIMESTAMP WHERE ID=:id`,
      { id: req.params.id, code, label, moduleName: module || mod || 'Setup', icon, sortOrder: sort_order || sortOrder || 0 },
    );
    return success(res, req.body, 'Screen updated');
  } catch (err) { return error(res, err.message); }
};

export const deleteScreen = async (req, res) => {
  try {
    await executeCommit(`UPDATE ${SETUP_TABLES.appScreens} SET IS_ACTIVE=0, UPDATED_AT=SYSTIMESTAMP WHERE ID=:id`, { id: req.params.id });
    return success(res, { id: req.params.id }, 'Screen deleted');
  } catch (err) { return error(res, err.message); }
};

export const getFeatures = async (_req, res) => {
  try { return success(res, await getFeatureRows(), 'Features loaded'); }
  catch (err) { return error(res, err.message); }
};

export const createFeature = async (req, res) => {
  try {
    const { code, label, category, cat, description = null, desc = null, sort_order = 0, sortOrder = 0 } = req.body;
    if (!code || !label) return badRequest(res, 'Feature code and label are required');
    await executeCommit(
      `INSERT INTO ${SETUP_TABLES.appFeatures} (ID, CODE, LABEL, CATEGORY, DESCRIPTION, SORT_ORDER, IS_ACTIVE, CREATED_AT, UPDATED_AT) VALUES (:id, :code, :label, :category, :description, :sortOrder, 1, SYSTIMESTAMP, SYSTIMESTAMP)`,
      { id: await nextNumber(SETUP_TABLES.appFeatures), code, label, category: category || cat || 'Setup', description: description || desc, sortOrder: sort_order || sortOrder || 0 },
    );
    return success(res, req.body, 'Feature created');
  } catch (err) { return error(res, err.message); }
};

export const updateFeature = async (req, res) => {
  try {
    const { code, label, category, cat, description = null, desc = null, sort_order = 0, sortOrder = 0 } = req.body;
    await executeCommit(
      `UPDATE ${SETUP_TABLES.appFeatures} SET CODE=:code, LABEL=:label, CATEGORY=:category, DESCRIPTION=:description, SORT_ORDER=:sortOrder, UPDATED_AT=SYSTIMESTAMP WHERE ID=:id`,
      { id: req.params.id, code, label, category: category || cat || 'Setup', description: description || desc, sortOrder: sort_order || sortOrder || 0 },
    );
    return success(res, req.body, 'Feature updated');
  } catch (err) { return error(res, err.message); }
};

export const deleteFeature = async (req, res) => {
  try {
    await executeCommit(`UPDATE ${SETUP_TABLES.appFeatures} SET IS_ACTIVE=0, UPDATED_AT=SYSTIMESTAMP WHERE ID=:id`, { id: req.params.id });
    return success(res, { id: req.params.id }, 'Feature deleted');
  } catch (err) { return error(res, err.message); }
};

export const addUserRole = async (req, res) => {
  try {
    const { userId } = req.params;
    const roleId = Number(req.body.role_id || req.body.roleId);
    if (!roleId) return badRequest(res, 'role_id is required');

    await withTransaction(async (connection) => {
      const user = await connection.execute(`SELECT ID AS "id" FROM ${SETUP_TABLES.users} WHERE ID=:userId AND NVL(IS_DELETED,0)=0 FETCH FIRST 1 ROWS ONLY`, { userId });
      if (!user.rows?.length) throw Object.assign(new Error('User not found'), { statusCode: 404 });
      const role = await connection.execute(`SELECT ROLE_ID AS "role_id", NAME AS "name" FROM ${SETUP_TABLES.roles} WHERE ROLE_ID=:roleId AND NVL(IS_ACTIVE,1)=1 AND NVL(IS_DELETED,0)=0 FETCH FIRST 1 ROWS ONLY`, { roleId });
      if (!role.rows?.length) throw Object.assign(new Error('Role not found'), { statusCode: 404 });

      if (req.body.is_primary) {
        await connection.execute(`UPDATE ${SETUP_TABLES.userRoles} SET IS_PRIMARY=0 WHERE USER_ID=:userId`, { userId });
      }
      await connection.execute(`DELETE FROM ${SETUP_TABLES.userRoles} WHERE USER_ID=:userId AND ROLE_ID=:roleId`, { userId, roleId });
      await connection.execute(
        `INSERT INTO ${SETUP_TABLES.userRoles} (ID, USER_ID, ROLE_ID, IS_PRIMARY, CREATED_AT) VALUES (:id, :userId, :roleId, :isPrimary, SYSTIMESTAMP)`,
        { id: await nextNumber(SETUP_TABLES.userRoles, 'ID', connection), userId, roleId, isPrimary: req.body.is_primary ? 1 : 0 },
      );

      const primary = await connection.execute(`SELECT COUNT(1) AS "count" FROM ${SETUP_TABLES.userRoles} WHERE USER_ID=:userId AND IS_PRIMARY=1`, { userId });
      if (Number(primary.rows?.[0]?.count || 0) === 0) {
        await connection.execute(`UPDATE ${SETUP_TABLES.userRoles} SET IS_PRIMARY=1 WHERE USER_ID=:userId AND ROLE_ID=(SELECT MIN(ROLE_ID) FROM ${SETUP_TABLES.userRoles} WHERE USER_ID=:userId)`, { userId });
      }
      await rebuildUserPermissions(connection, userId);
    });
    return success(res, { userId, role_id: roleId }, 'Role assigned to user');
  } catch (err) {
    if (err.statusCode === 404) return notFound(res, err.message);
    return error(res, err.message);
  }
};

export const removeUserRole = async (req, res) => {
  try {
    const { userId, roleId } = req.params;
    await withTransaction(async (connection) => {
      await connection.execute(`DELETE FROM ${SETUP_TABLES.userRoles} WHERE USER_ID=:userId AND ROLE_ID=:roleId`, { userId, roleId: Number(roleId) });
      const primary = await connection.execute(`SELECT COUNT(1) AS "count" FROM ${SETUP_TABLES.userRoles} WHERE USER_ID=:userId AND IS_PRIMARY=1`, { userId });
      if (Number(primary.rows?.[0]?.count || 0) === 0) {
        await connection.execute(`UPDATE ${SETUP_TABLES.userRoles} SET IS_PRIMARY=1 WHERE USER_ID=:userId AND ROLE_ID=(SELECT MIN(ROLE_ID) FROM ${SETUP_TABLES.userRoles} WHERE USER_ID=:userId)`, { userId });
      }
      await rebuildUserPermissions(connection, userId);
    });
    return success(res, { userId, roleId }, 'Role removed from user');
  } catch (err) { return error(res, err.message); }
};

export const setPrimaryUserRole = async (req, res) => {
  try {
    const { userId, roleId } = req.params;
    const existing = await executeOne(`SELECT ID AS "id" FROM ${SETUP_TABLES.userRoles} WHERE USER_ID=:userId AND ROLE_ID=:roleId FETCH FIRST 1 ROWS ONLY`, { userId, roleId: Number(roleId) });
    if (!existing) return notFound(res, 'User role not found');
    await withTransaction(async (connection) => {
      await connection.execute(`UPDATE ${SETUP_TABLES.userRoles} SET IS_PRIMARY=0 WHERE USER_ID=:userId`, { userId });
      await connection.execute(`UPDATE ${SETUP_TABLES.userRoles} SET IS_PRIMARY=1 WHERE USER_ID=:userId AND ROLE_ID=:roleId`, { userId, roleId: Number(roleId) });
    });
    return success(res, { userId, roleId }, 'Primary role updated');
  } catch (err) { return error(res, err.message); }
};

export const saveUserSecurity = async (req, res) => {
  try {
    const { userId } = req.params;
    const saved = await withTransaction(async (connection) => {
      const user = await connection.execute(`SELECT ID AS "id" FROM ${SETUP_TABLES.users} WHERE ID=:userId AND NVL(IS_DELETED,0)=0 FETCH FIRST 1 ROWS ONLY`, { userId });
      if (!user.rows?.length) throw Object.assign(new Error('User not found'), { statusCode: 404 });
      const s = await saveSecuritySettings(connection, userId, req.body);
      await audit('USER_SECURITY', 'UPDATE', userId, req, null, s, connection);
      return s;
    });
    return success(res, saved, 'Security settings saved');
  } catch (err) {
    if (err.statusCode === 404) return notFound(res, err.message);
    return error(res, err.message);
  }
};

export const forceLogoutUser = async (req, res) => {
  try {
    const { userId } = req.params;
    await withTransaction(async (connection) => {
      const user = await connection.execute(`SELECT ID AS "id" FROM ${SETUP_TABLES.users} WHERE ID=:userId AND NVL(IS_DELETED,0)=0 FETCH FIRST 1 ROWS ONLY`, { userId });
      if (!user.rows?.length) throw Object.assign(new Error('User not found'), { statusCode: 404 });
      await connection.execute(`UPDATE ${SETUP_TABLES.userSecuritySettings} SET FORCE_LOGOUT_AT=SYSTIMESTAMP, UPDATED_AT=SYSTIMESTAMP WHERE USER_ID=:userId`, { userId });
      await audit('USER_SECURITY', 'FORCE_LOGOUT', userId, req, null, { userId }, connection);
    });
    return success(res, { userId }, 'User session invalidated');
  } catch (err) {
    if (err.statusCode === 404) return notFound(res, err.message);
    return error(res, err.message);
  }
};

export default {
  bootstrap,
  getUserAccess,
  saveUserAccess,
  addUserRole,
  removeUserRole,
  setPrimaryUserRole,
  saveUserSecurity,
  forceLogoutUser,
  getRolePermissions,
  createRolePermissions,
  updateRolePermissions,
  deleteRolePermissions,
  getScreens,
  createScreen,
  updateScreen,
  deleteScreen,
  getFeatures,
  createFeature,
  updateFeature,
  deleteFeature,
};
