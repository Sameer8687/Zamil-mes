import { success, created, notFound, badRequest, error, paginated } from '../utils/response.js';
import { executeRows, executeOne, executeCommit } from '../config/oracle.js';
import {
  SETUP_TABLES,
  newUuid,
  nextNumber,
  toFlag,
  toBool,
  jsonString,
  asJson,
  mapRole,
  fetchRoleByAny,
} from '../models/setupAccess.model.js';

const buildPayload = (body = {}) => ({
  code: body.code || null,
  name: body.name,
  description: body.description || null,
  permissions: jsonString(body.permissions || {}, {}),
  icon: body.icon || null,
  color: body.color || null,
  isSystem: toFlag(body.isSystem, 0),
  isActive: toFlag(body.isActive, 1),
});

export const getRoles = async (req, res) => {
  try {
    const { page = 1, limit = 50, search, isActive, includeDeleted = 'false' } = req.query;
    const where = [];
    const binds = {};

    if (includeDeleted !== 'true') where.push('NVL(IS_DELETED,0)=0');
    if (isActive !== undefined) { where.push('NVL(IS_ACTIVE,1)=:isActive'); binds.isActive = toFlag(isActive, 1); }
    if (search) {
      where.push('(LOWER(NAME) LIKE LOWER(:search) OR LOWER(NVL(CODE,\'\')) LIKE LOWER(:search) OR LOWER(NVL(DESCRIPTION,\'\')) LIKE LOWER(:search))');
      binds.search = `%${search}%`;
    }
    const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
    const safePage = Math.max(Number(page) || 1, 1);
    const safeLimit = Math.max(Number(limit) || 50, 1);
    const offset = (safePage - 1) * safeLimit;

    const countRow = await executeOne(`SELECT COUNT(1) AS "count" FROM ${SETUP_TABLES.roles} ${whereSql}`, binds);
    const rows = await executeRows(
      `
      SELECT ID AS "id", ROLE_ID AS "role_id", CODE AS "code", NAME AS "name",
             ICON AS "icon", COLOR AS "color", DESCRIPTION AS "description",
             PERMISSIONS AS "permissions", IS_SYSTEM AS "isSystem", IS_ACTIVE AS "isActive",
             IS_DELETED AS "isDeleted", CREATED_AT AS "createdAt", UPDATED_AT AS "updatedAt"
      FROM ${SETUP_TABLES.roles}
      ${whereSql}
      ORDER BY ROLE_ID ASC
      OFFSET :offset ROWS FETCH NEXT :limit ROWS ONLY
      `,
      { ...binds, offset, limit: safeLimit },
    );

    return paginated(res, { rows: rows.map(mapRole), count: Number(countRow?.count || 0) }, safePage, safeLimit);
  } catch (err) { return error(res, err.message); }
};

export const getRole = async (req, res) => {
  try {
    const role = await fetchRoleByAny(req.params.id);
    if (!role) return notFound(res, 'Role not found');
    return success(res, role);
  } catch (err) { return error(res, err.message); }
};

export const createRole = async (req, res) => {
  try {
    if (!req.body.name) return badRequest(res, 'Role name is required');
    const p = buildPayload(req.body);
    const id = newUuid();
    const roleId = await nextNumber(SETUP_TABLES.roles, 'ROLE_ID');

    await executeCommit(
      `
      INSERT INTO ${SETUP_TABLES.roles}
      (ID, ROLE_ID, CODE, NAME, ICON, COLOR, DESCRIPTION, PERMISSIONS, IS_SYSTEM,
       CREATED_BY, UPDATED_BY, IS_ACTIVE, IS_DELETED, CREATED_AT, UPDATED_AT)
      VALUES
      (:id, :roleId, :code, :name, :icon, :color, :description, :permissions, :isSystem,
       :userName, :userName, :isActive, 0, SYSTIMESTAMP, SYSTIMESTAMP)
      `,
      { ...p, id, roleId, userName: req.user?.username || 'system' },
    );

    return created(res, mapRole({ id, role_id: roleId, ...p, isDeleted: 0 }), 'Role created');
  } catch (err) { return error(res, err.message); }
};

export const updateRole = async (req, res) => {
  try {
    const existing = await fetchRoleByAny(req.params.id);
    if (!existing) return notFound(res, 'Role not found');
    const p = buildPayload({ ...existing, ...req.body });
    await executeCommit(
      `
      UPDATE ${SETUP_TABLES.roles}
      SET CODE=:code, NAME=:name, ICON=:icon, COLOR=:color, DESCRIPTION=:description,
          PERMISSIONS=:permissions, IS_SYSTEM=:isSystem, IS_ACTIVE=:isActive,
          UPDATED_BY=:userName, UPDATED_AT=SYSTIMESTAMP
      WHERE ID=:id
      `,
      { ...p, id: existing.id, userName: req.user?.username || 'system' },
    );
    const fresh = await fetchRoleByAny(existing.id);
    return success(res, fresh, 'Role updated');
  } catch (err) { return error(res, err.message); }
};

export const deleteRole = async (req, res) => {
  try {
    const role = await fetchRoleByAny(req.params.id);
    if (!role) return notFound(res, 'Role not found');
    if (role.isSystem) return badRequest(res, 'System role cannot be deleted');

    const assigned = await executeOne(
      `SELECT COUNT(1) AS "count" FROM ${SETUP_TABLES.userRoles} WHERE ROLE_ID=:roleId`,
      { roleId: role.role_id },
    );
    if (Number(assigned?.count || 0) > 0) {
      return badRequest(res, 'Role is assigned to users. Remove user role mapping first.');
    }

    await executeCommit(
      `UPDATE ${SETUP_TABLES.roles} SET IS_DELETED=1, IS_ACTIVE=0, UPDATED_BY=:userName, UPDATED_AT=SYSTIMESTAMP WHERE ID=:id`,
      { id: role.id, userName: req.user?.username || 'system' },
    );
    return success(res, null, 'Role deleted');
  } catch (err) { return error(res, err.message); }
};

export const toggleRoleStatus = async (req, res) => {
  try {
    const role = await fetchRoleByAny(req.params.id);
    if (!role) return notFound(res, 'Role not found');
    await executeCommit(
      `UPDATE ${SETUP_TABLES.roles} SET IS_ACTIVE=:isActive, UPDATED_BY=:userName, UPDATED_AT=SYSTIMESTAMP WHERE ID=:id`,
      { id: role.id, isActive: role.isActive ? 0 : 1, userName: req.user?.username || 'system' },
    );
    const fresh = await fetchRoleByAny(role.id);
    return success(res, fresh, 'Role status updated');
  } catch (err) { return error(res, err.message); }
};

export const updateRolePermissions = async (req, res) => {
  try {
    const role = await fetchRoleByAny(req.params.id);
    if (!role) return notFound(res, 'Role not found');
    await executeCommit(
      `UPDATE ${SETUP_TABLES.roles} SET PERMISSIONS=:permissions, UPDATED_BY=:userName, UPDATED_AT=SYSTIMESTAMP WHERE ID=:id`,
      { id: role.id, permissions: jsonString(req.body.permissions || {}), userName: req.user?.username || 'system' },
    );
    const fresh = await fetchRoleByAny(role.id);
    return success(res, fresh, 'Role permissions updated');
  } catch (err) { return error(res, err.message); }
};

export default {
  getRoles,
  getRole,
  createRole,
  updateRole,
  deleteRole,
  toggleRoleStatus,
  updateRolePermissions,
};
