import { success, created, notFound, error, paginated } from '../utils/response.js';
import * as wasteModel from '../models/waste.model.js';

const mapRecord = (r) => ({
  id: r.id,
  time: r.createdAt ? new Date(r.createdAt).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }) : '—',
  wo: r.woNumber || r.woId || '—',
  woId: r.woId,
  woNumber: r.woNumber,
  machineId: r.machineId,
  machine: r.machineCode || r.machineName,
  cmp: r.wasteType || '—',
  wasteType: r.wasteType,
  qty: r.quantity || 0,
  quantity: r.quantity || 0,
  uom: r.unit || 'KG',
  unit: r.unit || 'KG',
  reason: r.category || '—',
  category: r.category,
  by: r.recordedByName || r.createdBy || '—',
  type: r.disposalMethod || 'scrap',
  disposalMethod: r.disposalMethod || 'scrap',
  notes: r.notes,
  costTotal: r.totalCost,
  totalCost: r.totalCost,
  createdAt: r.createdAt,
  updatedAt: r.updatedAt,
});

export const getWasteRecords = async (req, res) => {
  try {
    const { page = 1, limit = 50 } = req.query;
    const result = await wasteModel.listWasteRecords(req.query);
    return paginated(res, { ...result, rows: result.rows.map(mapRecord) }, page, limit);
  } catch (err) {
    return error(res, err.message);
  }
};

export const createWasteRecord = async (req, res) => {
  try {
    const { component, reason, mode, qty, uom, ...rest } = req.body;
    const payload = {
      ...rest,
      wasteType: rest.wasteType || component,
      quantity: rest.quantity ?? qty,
      unit: rest.unit || uom || 'KG',
      category: rest.category || reason,
      disposalMethod: rest.disposalMethod || mode || 'scrap',
      recordedById: rest.recordedById || req.user?.id,
    };

    const id = await wasteModel.createWasteRecord(payload, req.user);
    const record = await wasteModel.getWasteRecordById(id);
    return created(res, mapRecord(record), 'Waste record created');
  } catch (err) {
    return error(res, err.message);
  }
};

export const updateWasteRecord = async (req, res) => {
  try {
    const affected = await wasteModel.updateWasteRecord(req.params.id, req.body, req.user);
    if (!affected) return notFound(res, 'Waste record not found');
    const record = await wasteModel.getWasteRecordById(req.params.id);
    return success(res, mapRecord(record), 'Waste record updated');
  } catch (err) {
    return error(res, err.message);
  }
};

export const deleteWasteRecord = async (req, res) => {
  try {
    const affected = await wasteModel.deleteWasteRecord(req.params.id, req.user);
    if (!affected) return notFound(res, 'Waste record not found');
    return success(res, null, 'Waste record deleted');
  } catch (err) {
    return error(res, err.message);
  }
};

export const getWasteSummary = async (req, res) => {
  try {
    const summary = await wasteModel.getWasteSummary(req.query);
    const reasons = await wasteModel.listWasteRecords({ ...req.query, page: 1, limit: 500 });
    const reasonCounts = {};
    reasons.rows.forEach((r) => {
      if (r.category) reasonCounts[r.category] = (reasonCounts[r.category] || 0) + 1;
    });
    const topReason = Object.entries(reasonCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || '—';

    return success(res, {
      totalQty: summary?.totalQty || 0,
      totalCost: summary?.totalCost || 0,
      returns: summary?.returns || 0,
      topReason,
      count: summary?.count || 0,
    });
  } catch (err) {
    return error(res, err.message);
  }
};

export const getWasteReasonCodes = async (req, res) => {
  try {
    const rows = await wasteModel.listWasteReasonCodes(req.query);
    return success(res, rows);
  } catch (err) {
    return error(res, err.message);
  }
};

export const createWasteTransaction = async (req, res) => {
  try {
    const id = await wasteModel.createWasteTransaction(req.body, req.user);
    return created(res, { id }, 'Waste transaction created');
  } catch (err) {
    return error(res, err.message);
  }
};

export const getWasteTransactions = async (req, res) => {
  try {
    const { page = 1, limit = 50 } = req.query;
    const result = await wasteModel.listWasteTransactions(req.query);
    return paginated(res, result, page, limit);
  } catch (err) {
    return error(res, err.message);
  }
};



export const updateWasteTransaction = async (req, res) => {
  try {
    const affected = await wasteModel.updateWasteTransaction(req.params.id, req.body || {}, req.user);
    if (!affected) return notFound(res, 'Waste transaction not found');
    const txn = await wasteModel.getWasteTransactionById(req.params.id);
    return success(res, txn, 'Waste transaction updated');
  } catch (err) {
    return error(res, err.message);
  }
};

export const deleteWasteTransaction = async (req, res) => {
  try {
    const affected = await wasteModel.deleteWasteTransaction(req.params.id);
    if (!affected) return notFound(res, 'Waste transaction not found');
    return success(res, null, 'Waste transaction deleted');
  } catch (err) {
    return error(res, err.message);
  }
};

export const reverseWasteTransaction = async (req, res) => {
  try {
    const txn = await wasteModel.reverseWasteTransaction(req.params.id, req.body || {}, req.user);
    if (!txn) return notFound(res, 'Waste transaction not found');
    return created(res, txn, 'Waste transaction reversed');
  } catch (err) {
    return error(res, err.message);
  }
};

export const approveWasteTransaction = async (req, res) => {
  try {
    const txn = await wasteModel.approveWasteTransaction(req.params.id, req.body || {}, req.user);
    if (!txn) return notFound(res, 'Waste transaction not found');
    return success(res, txn, 'Waste transaction approved');
  } catch (err) {
    return error(res, err.message);
  }
};

export const getWasteWorkOrders = async (req, res) => {
  try {
    const rows = await wasteModel.listWasteWorkOrders(req.query);
    return success(res, rows);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getWasteComponents = async (req, res) => {
  try {
    const rows = await wasteModel.listWasteComponents(req.params.woId);
    return success(res, rows);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getWasteLots = async (req, res) => {
  try {
    const rows = await wasteModel.listWasteLots(req.query);
    return success(res, rows);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getDestinationOptions = async (_req, res) => {
  return success(res, [
    { value: 'SCRAP-FPP', label: 'SCRAP-FPP — Scrap Holding Area', type: 'scrap' },
    { value: 'HOLD-QC', label: 'HOLD-QC — QC Hold', type: 'hold' },
    { value: 'REWORK-FPP', label: 'REWORK-FPP — Rework Cell', type: 'rework' },
    { value: 'RETURN-LINE', label: 'RETURN-LINE — Return to Line', type: 'return' },
  ]);
};

const csvValue = (value) => {
  if (value === undefined || value === null) return '';
  const text = String(value).replace(/"/g, '""');
  return /[",\n]/.test(text) ? `"${text}"` : text;
};

export const exportWasteTransactions = async (req, res) => {
  try {
    const result = await wasteModel.listWasteTransactions({ ...req.query, page: 1, limit: req.query.limit || 5000 });
    const headers = ['Txn ID', 'WO Number', 'Machine', 'Component', 'Reason', 'Lot', 'Quantity', 'UOM', 'Cost/Unit', 'Total Cost', 'Destination', 'Transaction Date', 'Notes'];
    const rows = result.rows.map((r) => [r.id, r.woNumber || r.woId, r.machineCode || r.machineId, r.componentCode, r.reasonCode || r.reasonName, r.lotNo, r.quantity, r.uom, r.costPerUnit, r.totalCost, r.destination, r.transactionDate, r.notes]);
    const csv = [headers, ...rows].map((row) => row.map(csvValue).join(',')).join('\n');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="waste-transactions-${new Date().toISOString().slice(0, 10)}.csv"`);
    return res.status(200).send(csv);
  } catch (err) {
    return error(res, err.message);
  }
};

export default {
  getWasteRecords,
  createWasteRecord,
  updateWasteRecord,
  deleteWasteRecord,
  getWasteSummary,
  getWasteReasonCodes,
  createWasteTransaction,
  getWasteTransactions,
  updateWasteTransaction,
  deleteWasteTransaction,
  reverseWasteTransaction,
  approveWasteTransaction,
  getWasteWorkOrders,
  getWasteComponents,
  getWasteLots,
  getDestinationOptions,
  exportWasteTransactions,
};
