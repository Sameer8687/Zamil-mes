import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

import env from '../config/env.js';
import { success, badRequest, error } from '../utils/response.js';
import logger from '../utils/logger.js';
import * as authModel from '../models/auth.model.js';

const signToken = (payload) => jwt.sign(payload, env.JWT_SECRET, {
  expiresIn: env.JWT_EXPIRES_IN || '8h',
});

export const login = async (req, res) => {

  try {
    const { empId, username, loginId, password } = req.body;
    const userLogin = empId || username || loginId;

    const isMachineIpBound = req?.machineDeviceInfo?.machineIpBound || false; // check if machine IP is bound
    const machineCode = req?.machineDeviceInfo?.code || ''; // Machine code
    const organizationId = req?.machineDeviceInfo?.organizationId || ''; // Organization ID

    if (!userLogin || !password) {
      return badRequest(res, 'Employee ID / username and password are required');
    }

    const user = await authModel.findUserByLogin(userLogin);

    if (!user) {
      return badRequest(res, 'Invalid Employee ID / username or password');
    }

    const valid = await bcrypt.compare(password, user.passwordHash || '');

    if (!valid) {
      return badRequest(res, 'Invalid Employee ID / username or password');
    }

    await authModel.updateLastLogin(user.id);

    const safeUser = authModel.sanitizeUser(user);

    const token = signToken({
      id: user.id,
      empId: user.empId,
      username: user.username,
      role: user.role,
      roleId: user.roleId,
      plant: user.plant,
      department: user.department,
      machine: {
        isIpBound: isMachineIpBound,
        code: machineCode,
        organizationId: organizationId
      },
    });
    safeUser.machine = {
      isIpBound: isMachineIpBound,
      code: machineCode,
      organizationId: organizationId
    };

    logger.info(`Login: ${user.empId || user.username} [${user.role}]`);
    return success(res, { token, user: safeUser }, 'Login successful');
  } catch (err) {
    logger.error('Login failed:', err);
    return error(res, err.message);
  }
};

export const logout = async (_req, res) => {
  return success(res, null, 'Logged out');
};

export const me = async (req, res) => {
  try {
    const user = await authModel.findUserById(req.user.id);

    if (!user) {
      return badRequest(res, 'User not found');
    }

    return success(res, user);
  } catch (err) {
    return error(res, err.message);
  }
};

export const changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
      return badRequest(res, 'Current password and new password are required');
    }

    if (String(newPassword).length < 6) {
      return badRequest(res, 'New password must be at least 6 characters');
    }

    const user = await authModel.findUserById(req.user.id, { includePassword: true });

    if (!user) {
      return badRequest(res, 'User not found');
    }

    const valid = await bcrypt.compare(currentPassword, user.passwordHash || '');

    if (!valid) {
      return badRequest(res, 'Current password is incorrect');
    }

    const hash = await bcrypt.hash(newPassword, 12);
    await authModel.updatePassword(user.id, hash, req.user);

    return success(res, null, 'Password changed successfully');
  } catch (err) {
    return error(res, err.message);
  }
};

export default {
  login,
  logout,
  me,
  changePassword,
};
