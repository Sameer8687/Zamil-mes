import { success, created, notFound, error, paginated } from '../utils/response.js';
import * as stockModel from '../models/stock.model.js';

const mapStock = (r) => ({
  id: r.id,
  org: r.org || 'Zamil Operations',
  plant: r.plant,
  machine: r.machine,
  product: r.productName,
  productCode: r.productCode,
  productName: r.productName,
  wo: r.woNum || r.woNumber,
  woId: r.woId,
  woNum: r.woNum,
  woNumber: r.woNumber,
  qty: r.quantity,
  quantity: r.quantity,
  reservedQty: r.reservedQty,
  boxNo: r.boxNo,
  pallet: r.palletCode || r.palletNumber || '—',
  palletId: r.palletId,
  palletCode: r.palletCode,
  locator: r.locatorCode,
  locatorCode: r.locatorCode,
  locationId: r.locationId,
  locationCode: r.locationCode,
  locationName: r.locationName,
  printedAt: r.createdAt ? new Date(r.createdAt).toISOString().slice(0, 16).replace('T', ' ') : '',
  qcStatus: r.qcStatus || 'pend',
  status: r.status,
  receivedAt: r.receivedAt,
  dispatchedAt: r.dispatchedAt,
  createdAt: r.createdAt,
  updatedAt: r.updatedAt,
});

export const getStockRecords = async (req, res) => {
  try {
    const { page = 1, limit = 50 } = req.query;
    const result = await stockModel.listStockRecords(req.query);
    return paginated(res, { ...result, rows: result.rows.map(mapStock) }, page, limit);
  } catch (err) {
    return error(res, err.message);
  }
};

export const getStockRecord = async (req, res) => {
  try {
    const rec = await stockModel.getStockRecordById(req.params.id);
    if (!rec) return notFound(res, 'Stock record not found');
    return success(res, mapStock(rec));
  } catch (err) {
    return error(res, err.message);
  }
};

export const createStockRecord = async (req, res) => {
  try {
    const id = await stockModel.createStockRecord(req.body, req.user);
    const rec = await stockModel.getStockRecordById(id);
    return created(res, mapStock(rec), 'Stock record created');
  } catch (err) {
    return error(res, err.message);
  }
};

export const updateStockRecord = async (req, res) => {
  try {
    const payload = { ...req.body };
    if (payload.status === 'dispatched' && !payload.dispatchedAt) payload.dispatchedAt = new Date();

    const affected = await stockModel.updateStockRecord(req.params.id, payload, req.user);
    if (!affected) return notFound(res, 'Stock record not found');

    const rec = await stockModel.getStockRecordById(req.params.id);
    return success(res, mapStock(rec), 'Stock record updated');
  } catch (err) {
    return error(res, err.message);
  }
};

export const getStockSummary = async (req, res) => {
  try {
    const summary = await stockModel.getStockSummary(req.query);
    return success(res, summary);
  } catch (err) {
    return error(res, err.message);
  }
};

export const exportStock = async (req, res) => {
  try {
    const rows = await stockModel.exportStockRows(req.query);
    const headers = ['Org', 'Plant', 'Product Code', 'Product Name', 'WO', 'Box No', 'Pallet', 'Locator', 'Qty', 'QC Status', 'Status'];
    const escapeCsv = (value) => `"${String(value ?? '').replace(/"/g, '""')}"`;
    const csvRows = rows.map((r) => [
      r.org,
      r.plant,
      r.productCode,
      r.productName,
      r.woNum || r.woNumber,
      r.boxNo,
      r.palletCode,
      r.locatorCode,
      r.quantity,
      r.qcStatus,
      r.status,
    ].map(escapeCsv).join(','));

    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="stock-register-${Date.now()}.csv"`);
    return res.status(200).send([headers.map(escapeCsv).join(','), ...csvRows].join('\n'));
  } catch (err) {
    return error(res, err.message);
  }
};

export const getItemMaster = async (req, res) => {
  try {
    const { page = 1, limit = 50 } = req.query;
    const result = await stockModel.listItemMaster(req.query);
    return paginated(res, result, page, limit);
  } catch (err) {
    return error(res, err.message);
  }
};

export const createItemMaster = async (req, res) => {
  try {
    const id = await stockModel.createItemMaster(req.body, req.user);
    return created(res, { id }, 'Item created');
  } catch (err) {
    return error(res, err.message);
  }
};



export const updateItemMaster = async (req, res) => {
  try {
    const affected = await stockModel.updateItemMaster(req.params.id, req.body, req.user);
    if (!affected) return notFound(res, 'Item not found');
    return success(res, { id: req.params.id }, 'Item updated');
  } catch (err) {
    return error(res, err.message);
  }
};

export const deleteItemMaster = async (req, res) => {
  try {
    const affected = await stockModel.deleteItemMaster(req.params.id, req.user);
    if (!affected) return notFound(res, 'Item not found');
    return success(res, null, 'Item deleted');
  } catch (err) {
    return error(res, err.message);
  }
};

export const updateInventoryLot = async (req, res) => {
  try {
    const affected = await stockModel.updateInventoryLot(req.params.id, req.body, req.user);
    if (!affected) return notFound(res, 'Inventory lot not found');
    return success(res, { id: req.params.id }, 'Inventory lot updated');
  } catch (err) {
    return error(res, err.message);
  }
};

export const deleteInventoryLot = async (req, res) => {
  try {
    const affected = await stockModel.deleteInventoryLot(req.params.id, req.user);
    if (!affected) return notFound(res, 'Inventory lot not found');
    return success(res, null, 'Inventory lot deleted');
  } catch (err) {
    return error(res, err.message);
  }
};

const stockAction = (action) => async (req, res) => {
  try {
    const rec = await stockModel.setStockAction(req.params.id, action, req.body || {}, req.user);
    if (!rec) return notFound(res, 'Stock record not found');
    return success(res, mapStock(rec), `Stock ${action} completed`);
  } catch (err) {
    return error(res, err.message);
  }
};

export const reserveStock = stockAction('reserve');
export const unreserveStock = stockAction('unreserve');
export const dispatchStock = stockAction('dispatch');
export const holdStock = stockAction('hold');

export const getStockByBox = async (req, res) => {
  try {
    const rec = await stockModel.getStockByBox(req.params.boxNo);
    if (!rec) return notFound(res, 'Stock record not found for box');
    return success(res, mapStock(rec));
  } catch (err) {
    return error(res, err.message);
  }
};

export const getStockByPallet = async (req, res) => {
  try {
    const rows = await stockModel.getStockByPallet(req.params.palletCode);
    return success(res, rows.map(mapStock));
  } catch (err) {
    return error(res, err.message);
  }
};

export const getInventoryLots = async (req, res) => {
  try {
    const { page = 1, limit = 50 } = req.query;
    const result = await stockModel.listInventoryLots(req.query);
    return paginated(res, result, page, limit);
  } catch (err) {
    return error(res, err.message);
  }
};

export const createInventoryLot = async (req, res) => {
  try {
    const id = await stockModel.createInventoryLot(req.body, req.user);
    return created(res, { id }, 'Inventory lot created');
  } catch (err) {
    return error(res, err.message);
  }
};

export default {
  getStockRecords,
  getStockRecord,
  createStockRecord,
  updateStockRecord,
  getStockSummary,
  exportStock,
  getItemMaster,
  createItemMaster,
  updateItemMaster,
  deleteItemMaster,
  getInventoryLots,
  createInventoryLot,
  updateInventoryLot,
  deleteInventoryLot,
  reserveStock,
  unreserveStock,
  dispatchStock,
  holdStock,
  getStockByBox,
  getStockByPallet,
};
