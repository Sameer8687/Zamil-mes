import axios from 'axios';

export class FusionApiError extends Error {
  constructor(message, options = {}) {
    super(message);
    this.name = 'FusionApiError';
    this.isFusionApiError = true;
    this.statusCode = options.statusCode || 502;
    this.code = options.code || 'FUSION_API_ERROR';
    this.fusionHttpStatus = options.fusionHttpStatus || null;
    this.fusionData = options.fusionData || null;
    this.fusionUrl = options.fusionUrl || null;
    this.fusionRequestPayload = options.fusionRequestPayload || null;
  }
}

const cleanText = (value) => {
  if (value === undefined || value === null) return '';
  return String(value).trim();
};

const cleanBaseUrl = (value) => cleanText(value).replace(/\/+$/, '');

const getFusionConfig = () => {
  const baseUrl = cleanBaseUrl(process.env.FUSION_BASE_URL);
  const username = cleanText(process.env.FUSION_USERNAME);
  const password = cleanText(process.env.FUSION_PASSWORD);
  const apiVersion = cleanText(process.env.FUSION_WORKORDER_API_VERSION) || '11.13.18.05';
  const timeoutMs = Number(process.env.FUSION_HTTP_TIMEOUT_MS || 60000);

  if (!baseUrl) {
    throw new FusionApiError('Fusion base URL is not configured', {
      statusCode: 500,
      code: 'FUSION_BASE_URL_MISSING',
    });
  }

  if (!username || !password) {
    throw new FusionApiError('Fusion username/password is not configured', {
      statusCode: 500,
      code: 'FUSION_CREDENTIALS_MISSING',
    });
  }

  return {
    baseUrl,
    username,
    password,
    apiVersion,
    timeoutMs: Number.isFinite(timeoutMs) && timeoutMs > 0 ? timeoutMs : 60000,
  };
};

const createFusionClient = () => {
  const config = getFusionConfig();

  const client = axios.create({
    baseURL: config.baseUrl,
    timeout: config.timeoutMs,
    auth: {
      username: config.username,
      password: config.password,
    },
    headers: {
      Accept: 'application/json',
    },
    validateStatus: () => true,
  });

  return {
    client,
    config,
  };
};

const mapFusionHttpError = ({ status, data, url }) => {
  let message = 'Fusion API failed';
  let apiStatusCode = 502;

  if (status === 400) {
    message = 'Fusion rejected the request';
    apiStatusCode = 400;
  } else if (status === 401) {
    message = 'Fusion authentication failed';
    apiStatusCode = 502;
  } else if (status === 403) {
    message = 'Fusion user is not authorized for this work order action';
    apiStatusCode = 502;
  } else if (status === 404) {
    message = 'Fusion work order was not found';
    apiStatusCode = 404;
  } else if (status === 409) {
    message = 'Fusion work order has a conflict';
    apiStatusCode = 409;
  } else if (status === 412) {
    message = 'Fusion work order precondition failed';
    apiStatusCode = 409;
  } else if (status >= 500) {
    message = 'Fusion server error';
    apiStatusCode = 502;
  }

  return new FusionApiError(message, {
    statusCode: apiStatusCode,
    code: `FUSION_HTTP_${status}`,
    fusionHttpStatus: status,
    fusionData: data,
    fusionUrl: url,
  });
};

const mapAxiosError = (err) => {
  if (err?.isFusionApiError) return err;

  if (err?.code === 'ECONNABORTED') {
    return new FusionApiError('Fusion API timeout', {
      statusCode: 504,
      code: 'FUSION_TIMEOUT',
      fusionUrl: err?.config?.url || null,
    });
  }

  if (err?.response) {
    return mapFusionHttpError({
      status: err.response.status,
      data: err.response.data,
      url: err.config?.url || null,
    });
  }

  return new FusionApiError(err?.message || 'Unable to connect to Fusion API', {
    statusCode: 502,
    code: err?.code || 'FUSION_NETWORK_ERROR',
    fusionUrl: err?.config?.url || null,
  });
};

export const normalizeFusionStatus = (item = {}) => {
  return {
    statusName: cleanText(item.WorkOrderStatusName),
    statusCode: cleanText(item.WorkOrderStatusCode),
    systemStatusCode: cleanText(item.WorkOrderSystemStatusCode),
  };
};

export const isFusionUnreleased = (item = {}) => {
  const status = normalizeFusionStatus(item);

  return (
    status.statusName.toUpperCase() === 'UNRELEASED' &&
    status.statusCode.toUpperCase() === 'ORA_UNRELEASED' &&
    status.systemStatusCode.toUpperCase() === 'UNRELEASED'
  );
};

export const isFusionReleased = (item = {}) => {
  const status = normalizeFusionStatus(item);

  return (
    status.statusName.toUpperCase() === 'RELEASED' &&
    status.statusCode.toUpperCase() === 'ORA_RELEASED' &&
    status.systemStatusCode.toUpperCase() === 'RELEASED'
  );
};

const buildWorkOrdersCollectionPath = (apiVersion) => {
  return `/fscmRestApi/resources/${apiVersion}/workOrders`;
};

const buildWorkOrderItemPath = (apiVersion, workOrderId) => {
  return `/fscmRestApi/resources/${apiVersion}/workOrders/${encodeURIComponent(String(workOrderId))}`;
};

const validateWorkOrderNumber = (workOrderNumber) => {
  const value = cleanText(workOrderNumber);

  if (!value) {
    throw new FusionApiError('Work order number is required for Fusion lookup', {
      statusCode: 400,
      code: 'FUSION_WORK_ORDER_NUMBER_REQUIRED',
    });
  }

  if (value.includes("'")) {
    throw new FusionApiError('Invalid work order number', {
      statusCode: 400,
      code: 'INVALID_WORK_ORDER_NUMBER',
    });
  }

  return value;
};

const validateWorkOrderId = (workOrderId) => {
  const value = cleanText(workOrderId);

  if (!value || !/^\d+$/.test(value)) {
    throw new FusionApiError('Invalid Fusion work order ID', {
      statusCode: 400,
      code: 'INVALID_FUSION_WORK_ORDER_ID',
    });
  }

  return value;
};

export async function getFusionWorkOrderByNumber(workOrderNumber) {
  const safeWorkOrderNumber = validateWorkOrderNumber(workOrderNumber);
  const { client, config } = createFusionClient();

  const path = buildWorkOrdersCollectionPath(config.apiVersion);
  const q = `WorkOrderNumber='${safeWorkOrderNumber}'`;

  try {
    const response = await client.get(path, {
      params: {
        q,
        limit: 2,
        offset: 0,
      },
    });

    if (response.status < 200 || response.status >= 300) {
      throw mapFusionHttpError({
        status: response.status,
        data: response.data,
        url: `${config.baseUrl}${path}`,
      });
    }

    const data = response.data || {};
    const items = Array.isArray(data.items) ? data.items : [];

    if (items.length === 0) {
      throw new FusionApiError(`Fusion work order ${safeWorkOrderNumber} was not found`, {
        statusCode: 404,
        code: 'FUSION_WORK_ORDER_NOT_FOUND',
        fusionHttpStatus: response.status,
        fusionData: data,
        fusionUrl: `${config.baseUrl}${path}`,
      });
    }

    if (items.length > 1) {
      throw new FusionApiError(`Fusion returned multiple work orders for ${safeWorkOrderNumber}`, {
        statusCode: 409,
        code: 'FUSION_MULTIPLE_WORK_ORDERS_FOUND',
        fusionHttpStatus: response.status,
        fusionData: data,
        fusionUrl: `${config.baseUrl}${path}`,
      });
    }

    const item = items[0];

    if (cleanText(item.WorkOrderNumber).toUpperCase() !== safeWorkOrderNumber.toUpperCase()) {
      throw new FusionApiError('Fusion returned a different work order number', {
        statusCode: 409,
        code: 'FUSION_WORK_ORDER_NUMBER_MISMATCH',
        fusionHttpStatus: response.status,
        fusionData: item,
        fusionUrl: `${config.baseUrl}${path}`,
      });
    }

    return {
      success: true,
      httpStatus: response.status,
      item,
      raw: data,
      status: normalizeFusionStatus(item),
    };
  } catch (err) {
    throw mapAxiosError(err);
  }
}

export async function releaseFusionWorkOrderById(workOrderId) {
  const safeWorkOrderId = validateWorkOrderId(workOrderId);
  const { client, config } = createFusionClient();

  const path = buildWorkOrderItemPath(config.apiVersion, safeWorkOrderId);

  try {
    const response = await client.patch(
      path,
      {
        WorkOrderStatusCode: 'ORA_RELEASED',
      },
      {
        headers: {
          'Content-Type': 'application/vnd.oracle.adf.resourceitem+json',
          Accept: 'application/json',
        },
      }
    );

    if (response.status < 200 || response.status >= 300) {
      throw mapFusionHttpError({
        status: response.status,
        data: response.data,
        url: `${config.baseUrl}${path}`,
      });
    }

    const item = response.data || {};

    if (!isFusionReleased(item)) {
      throw new FusionApiError('Fusion release was not confirmed in response', {
        statusCode: 502,
        code: 'FUSION_RELEASE_NOT_CONFIRMED',
        fusionHttpStatus: response.status,
        fusionData: item,
        fusionUrl: `${config.baseUrl}${path}`,
      });
    }

    return {
      success: true,
      httpStatus: response.status,
      item,
      status: normalizeFusionStatus(item),
    };
  } catch (err) {
    throw mapAxiosError(err);
  }
}

const buildWorkOrderOperationsPath = (apiVersion, workOrderId) => {
  return `/fscmRestApi/resources/${apiVersion}/workOrders/${encodeURIComponent(
    String(workOrderId)
  )}/child/WorkOrderOperation`;
};

const buildDispatchListOperationsPath = (apiVersion) => {
  return `/fscmRestApi/resources/${apiVersion}/dispatchListWorkOrderOperations`;
};

const buildOperationTransactionsPath = (apiVersion) => {
  return `/fscmRestApi/resources/${apiVersion}/operationTransactions`;
};

const cleanNumber = (value, fallback = null) => {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
};

const isTrueFlag = (value) => {
  return String(value || '').trim().toLowerCase() === 'true';
};

const toFusionDateTime = (value = new Date()) => {
  const date = value instanceof Date ? value : new Date(value);

  if (!Number.isFinite(date.getTime())) {
    throw new FusionApiError('Invalid transaction date', {
      statusCode: 400,
      code: 'INVALID_TRANSACTION_DATE',
    });
  }

  return date.toISOString().replace('Z', '+00:00');
};

const numbersEqual = (a, b) => {
  return Math.abs(Number(a || 0) - Number(b || 0)) < 0.000001;
};

const firstDetail = (data = {}) => {
  const details = Array.isArray(data.OperationTransactionDetail)
    ? data.OperationTransactionDetail
    : [];

  return details[0] || {};
};

const extractFusionTransactionId = (data = {}) => {
  const detail = firstDetail(data);

  return (
    cleanText(detail.WoOperationTransactionId) ||
    cleanText(detail.OperationTransactionId) ||
    cleanText(detail.TransactionId) ||
    cleanText(data.WoOperationTransactionId) ||
    cleanText(data.OperationTransactionId) ||
    cleanText(data.TransactionId) ||
    null
  );
};

const extractFusionRequestId = (data = {}) => {
  const detail = firstDetail(data);

  return (
    cleanText(detail.RequestId) ||
    cleanText(detail.RequestID) ||
    cleanText(data.RequestId) ||
    cleanText(data.RequestID) ||
    null
  );
};

const extractOperationTransactionError = (data = {}) => {
  const detail = firstDetail(data);

  return {
    code:
      cleanText(detail.ErrorMessageNames) ||
      cleanText(detail.ErrorCode) ||
      cleanText(data.ErrorMessageNames) ||
      cleanText(data.ErrorCode) ||
      'FUSION_OPERATION_TRANSACTION_ERROR',

    message:
      cleanText(detail.ErrorMessages) ||
      cleanText(detail.ErrorMessage) ||
      cleanText(data.ErrorMessages) ||
      cleanText(data.ErrorMessage) ||
      'Fusion rejected the operation transaction',
  };
};

const hasOperationTransactionErrors = (data = {}) => {
  if (isTrueFlag(data.ErrorsExistFlag)) return true;

  const details = Array.isArray(data.OperationTransactionDetail)
    ? data.OperationTransactionDetail
    : [];

  return details.some((detail) => {
    return (
      isTrueFlag(detail.ErrorsExistFlag) ||
      cleanText(detail.ErrorMessages) ||
      cleanText(detail.ErrorMessage) ||
      cleanText(detail.ErrorMessageNames)
    );
  });
};

export async function getFusionWorkOrderOperations(workOrderId) {
  const safeWorkOrderId = validateWorkOrderId(workOrderId);
  const { client, config } = createFusionClient();

  const path = buildWorkOrderOperationsPath(config.apiVersion, safeWorkOrderId);

  try {
    const response = await client.get(path, {
      params: {
        limit: 100,
        offset: 0,
      },
    });

    if (response.status < 200 || response.status >= 300) {
      throw mapFusionHttpError({
        status: response.status,
        data: response.data,
        url: `${config.baseUrl}${path}`,
      });
    }

    const data = response.data || {};
    const items = Array.isArray(data.items) ? data.items : [];

    if (!items.length) {
      throw new FusionApiError('Fusion work order operation was not found', {
        statusCode: 404,
        code: 'FUSION_WORK_ORDER_OPERATION_NOT_FOUND',
        fusionHttpStatus: response.status,
        fusionData: data,
        fusionUrl: `${config.baseUrl}${path}`,
      });
    }

    return {
      success: true,
      httpStatus: response.status,
      items,
      raw: data,
    };
  } catch (err) {
    throw mapAxiosError(err);
  }
}

export async function getFusionWorkOrderOperation(workOrderId, preferredSequenceNumber = null) {
  const result = await getFusionWorkOrderOperations(workOrderId);
  const items = result.items || [];

  let operation = null;

  if (preferredSequenceNumber !== undefined && preferredSequenceNumber !== null && preferredSequenceNumber !== '') {
    const preferred = Number(preferredSequenceNumber);

    operation = items.find((item) => {
      return Number(item.OperationSequenceNumber) === preferred;
    });

    if (!operation) {
      throw new FusionApiError(
        `Fusion operation sequence ${preferredSequenceNumber} was not found for work order`,
        {
          statusCode: 404,
          code: 'FUSION_OPERATION_SEQUENCE_NOT_FOUND',
          fusionData: result.raw,
        }
      );
    }
  } else {
    operation = items[0];
  }

  return {
    success: true,
    httpStatus: result.httpStatus,
    item: operation,
    raw: result.raw,
  };
}

export async function getFusionReadyDispatchOperation({
  organizationCode,
  workOrderNumber,
  operationSequenceNumber,
}) {
  const safeOrganizationCode = cleanText(organizationCode);
  const safeWorkOrderNumber = validateWorkOrderNumber(workOrderNumber);
  const safeOperationSequenceNumber = cleanNumber(operationSequenceNumber);

  if (!safeOrganizationCode) {
    throw new FusionApiError('Organization code is required for Fusion dispatch lookup', {
      statusCode: 400,
      code: 'FUSION_ORGANIZATION_CODE_REQUIRED',
    });
  }

  if (!safeOperationSequenceNumber) {
    throw new FusionApiError('Operation sequence number is required for Fusion dispatch lookup', {
      statusCode: 400,
      code: 'FUSION_OPERATION_SEQUENCE_REQUIRED',
    });
  }

  const { client, config } = createFusionClient();
  const path = buildDispatchListOperationsPath(config.apiVersion);

  const q = [
    `OrganizationCode=${safeOrganizationCode}`,
    `WorkOrderNumber=${safeWorkOrderNumber}`,
    `OperationSequenceNumber=${safeOperationSequenceNumber}`,
    'DispatchState=READY',
  ].join(';');

  try {
    const response = await client.get(path, {
      params: {
        q,
        limit: 2,
        offset: 0,
      },
    });

    if (response.status < 200 || response.status >= 300) {
      throw mapFusionHttpError({
        status: response.status,
        data: response.data,
        url: `${config.baseUrl}${path}`,
      });
    }

    const data = response.data || {};
    const items = Array.isArray(data.items) ? data.items : [];

    if (!items.length) {
      throw new FusionApiError('No READY quantity found in Fusion dispatch list', {
        statusCode: 400,
        code: 'FUSION_READY_DISPATCH_NOT_FOUND',
        fusionHttpStatus: response.status,
        fusionData: data,
        fusionUrl: `${config.baseUrl}${path}`,
      });
    }

    if (items.length > 1) {
      throw new FusionApiError('Fusion returned multiple READY dispatch records', {
        statusCode: 409,
        code: 'FUSION_MULTIPLE_READY_DISPATCH_FOUND',
        fusionHttpStatus: response.status,
        fusionData: data,
        fusionUrl: `${config.baseUrl}${path}`,
      });
    }

    const item = items[0];

    if (cleanText(item.DispatchState).toUpperCase() !== 'READY') {
      throw new FusionApiError('Fusion dispatch state is not READY', {
        statusCode: 400,
        code: 'FUSION_DISPATCH_NOT_READY',
        fusionHttpStatus: response.status,
        fusionData: item,
        fusionUrl: `${config.baseUrl}${path}`,
      });
    }

    return {
      success: true,
      httpStatus: response.status,
      item,
      raw: data,
    };
  } catch (err) {
    throw mapAxiosError(err);
  }
}

export async function postFusionOperationTransaction(payload) {
  const { client, config } = createFusionClient();
  const path = buildOperationTransactionsPath(config.apiVersion);

  try {
    const response = await client.post(path, payload, {
      headers: {
        'Content-Type': 'application/vnd.oracle.adf.resourceitem+json',
        Accept: 'application/json',
      },
    });

    if (response.status < 200 || response.status >= 300) {
      const mappedError = mapFusionHttpError({
        status: response.status,
        data: response.data,
        url: `${config.baseUrl}${path}`,
      });

      mappedError.fusionRequestPayload = payload;
      throw mappedError;
    }

    const data = response.data || {};

    if (hasOperationTransactionErrors(data)) {
      const fusionError = extractOperationTransactionError(data);

      throw new FusionApiError(fusionError.message, {
        statusCode: 400,
        code: fusionError.code,
        fusionHttpStatus: response.status,
        fusionData: data,
        fusionUrl: `${config.baseUrl}${path}`,
        fusionRequestPayload: payload,
      });
    }

    return {
      success: true,
      httpStatus: response.status,
      data,
      fusionTransactionId: extractFusionTransactionId(data),
      fusionRequestId: extractFusionRequestId(data),
    };
  } catch (err) {
    throw mapAxiosError(err);
  }
}

export async function postLabelPrintQtyToFusion({
  workOrderNumber,
  quantity,
  boxBarcode,
  transactionDate = new Date(),
  operationSequenceNumber = null,
}) {
  const safeWorkOrderNumber = validateWorkOrderNumber(workOrderNumber);
  const safeQty = cleanNumber(quantity);

  if (!safeQty || safeQty <= 0) {
    throw new FusionApiError('Transaction quantity must be greater than zero', {
      statusCode: 400,
      code: 'INVALID_TRANSACTION_QUANTITY',
    });
  }

  const safeBoxBarcode = cleanText(boxBarcode);

  if (!safeBoxBarcode) {
    throw new FusionApiError('Box barcode is required for Fusion posting', {
      statusCode: 400,
      code: 'BOX_BARCODE_REQUIRED',
    });
  }

  const fusionWorkOrderResult = await getFusionWorkOrderByNumber(safeWorkOrderNumber);
  const fusionWorkOrder = fusionWorkOrderResult.item;

  if (!isFusionReleased(fusionWorkOrder)) {
    throw new FusionApiError('Fusion work order must be in Released status before quantity posting', {
      statusCode: 400,
      code: 'FUSION_WORK_ORDER_NOT_RELEASED',
      fusionData: fusionWorkOrder,
    });
  }

  const operationResult = await getFusionWorkOrderOperation(
    fusionWorkOrder.WorkOrderId,
    operationSequenceNumber
  );

  const operation = operationResult.item;
  const operationSeqNo = operation.OperationSequenceNumber;

  const dispatchResult = await getFusionReadyDispatchOperation({
    organizationCode: fusionWorkOrder.OrganizationCode,
    workOrderNumber: safeWorkOrderNumber,
    operationSequenceNumber: operationSeqNo,
  });

  const dispatch = dispatchResult.item;
  const readyQty = cleanNumber(dispatch.Quantity, 0);

  if (readyQty <= 0) {
    throw new FusionApiError('Fusion READY quantity is zero', {
      statusCode: 400,
      code: 'FUSION_READY_QTY_ZERO',
      fusionData: dispatch,
    });
  }

  if (safeQty > readyQty) {
    throw new FusionApiError(
      `Transaction quantity ${safeQty} is greater than Fusion READY quantity ${readyQty}`,
      {
        statusCode: 400,
        code: 'FUSION_READY_QTY_EXCEEDED',
        fusionData: dispatch,
      }
    );
  }

  const completeOperationFlag = numbersEqual(safeQty, readyQty);
  const fusionTransactionDate = toFusionDateTime(transactionDate);

  const payload = {
    SourceSystemCode: 'ZAMIL_MES',
    SourceSystemType: 'EXTERNAL',
    OperationTransactionDetail: [
      {
        SourceSystemCode: 'ZAMIL_MES',
        OrganizationCode: fusionWorkOrder.OrganizationCode,
        WorkOrderNumber: safeWorkOrderNumber,
        WoOperationSequenceNumber: Number(operationSeqNo),
        FromDispatchState: 'READY',
        ToDispatchState: 'COMPLETE',
        TransactionQuantity: safeQty,
        TransactionUnitOfMeasure:
          cleanText(dispatch.UnitOfMeasure) ||
          cleanText(operation.UnitOfMeasure) ||
          cleanText(fusionWorkOrder.UnitOfMeasure) ||
          'Units',
        TransactionDate: fusionTransactionDate,
        ExternalSystemPackingUnit: safeBoxBarcode,
        CompleteOperationFlag: completeOperationFlag,
      },
    ],
  };

  const postResult = await postFusionOperationTransaction(payload);

  return {
    success: true,
    httpStatus: postResult.httpStatus,
    payload,
    response: postResult.data,
    fusionTransactionId: postResult.fusionTransactionId,
    fusionRequestId: postResult.fusionRequestId,
    fusionWorkOrder,
    operation,
    dispatch,
    organizationId: fusionWorkOrder.OrganizationId,
    organizationCode: fusionWorkOrder.OrganizationCode,
    productCode: fusionWorkOrder.ItemNumber,
    transactionUomCode:
      cleanText(dispatch.UnitOfMeasure) ||
      cleanText(operation.UnitOfMeasure) ||
      cleanText(fusionWorkOrder.UnitOfMeasure) ||
      'Units',
    readyQty,
    completeOperationFlag,
    transactionDate: fusionTransactionDate,
  };
}

export default {
  getFusionWorkOrderByNumber,
  releaseFusionWorkOrderById,
  normalizeFusionStatus,
  isFusionUnreleased,
  isFusionReleased,

  getFusionWorkOrderOperations,
  getFusionWorkOrderOperation,
  getFusionReadyDispatchOperation,
  postFusionOperationTransaction,
  postLabelPrintQtyToFusion,
};