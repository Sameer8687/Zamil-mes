export const success  = (res, data, message = 'OK', code = 200) => res.status(code).json({ success: true, message, data });
export const created  = (res, data, message = 'Created')        => res.status(201).json({ success: true, message, data });
export const notFound = (res, message = 'Not found')            => res.status(404).json({ success: false, message });
export const badRequest=(res, message = 'Bad request')          => res.status(400).json({ success: false, message });
export const forbidden= (res, message = 'Forbidden')            => res.status(403).json({ success: false, message });
export const error    = (res, message = 'Server error', code = 500) => res.status(code).json({ success: false, message });

export const paginated = (res, result, page, limit) => {
  const data  = result.rows ?? result.data ?? result;
  const total = result.count ?? result.total ?? (Array.isArray(data) ? data.length : 0);
  res.status(200).json({
    success: true,
    data,
    pagination: {
      total,
      page:  parseInt(page),
      limit: parseInt(limit),
      pages: Math.ceil(total / parseInt(limit)),
    },
  });
};
