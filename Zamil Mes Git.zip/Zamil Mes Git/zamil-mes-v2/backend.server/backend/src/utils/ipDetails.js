import net from "node:net";

const IPV4_MAPPED_IPV6_PREFIX = "::ffff:";

export const normalizeIp = (value) => {
    if (!value) return null;

    let ip = String(value).trim();

    if (!ip) return null;

    // x-forwarded-for can be: "192.168.1.25, 10.0.0.1"
    if (ip.includes(",")) {
        ip = ip.split(",")[0].trim();
    }

    // Remove quotes
    ip = ip.replace(/^"+|"+$/g, "");

    // Remove IPv6 zone index: fe80::1%lo0
    if (ip.includes("%")) {
        ip = ip.split("%")[0];
    }

    // Convert IPv4 mapped IPv6: ::ffff:192.168.1.25
    if (ip.startsWith(IPV4_MAPPED_IPV6_PREFIX)) {
        ip = ip.replace(IPV4_MAPPED_IPV6_PREFIX, "");
    }

    // Convert localhost IPv6
    if (ip === "::1") {
        ip = "127.0.0.1";
    }

    // Remove IPv4 port: 192.168.1.25:55432
    if (/^\d{1,3}(\.\d{1,3}){3}:\d+$/.test(ip)) {
        ip = ip.split(":")[0];
    }

    // Remove IPv6 brackets: [2001:db8::1]
    if (ip.startsWith("[") && ip.endsWith("]")) {
        ip = ip.slice(1, -1);
    }

    if (!net.isIP(ip)) {
        return null;
    }

    return ip;
};

const parseForwardedFor = (value) => {
    if (!value) return [];

    return String(value)
        .split(",")
        .map((item) => normalizeIp(item))
        .filter(Boolean);
};

const getIPv4Scope = (ip) => {
    const parts = ip.split(".").map(Number);
    const [a, b, c, d] = parts;

    if (parts.length !== 4 || parts.some((n) => Number.isNaN(n))) {
        return "invalid";
    }

    if (a === 10) return "private";
    if (a === 172 && b >= 16 && b <= 31) return "private";
    if (a === 192 && b === 168) return "private";

    if (a === 127) return "loopback";
    if (a === 169 && b === 254) return "link_local";
    if (a === 100 && b >= 64 && b <= 127) return "carrier_grade_nat";

    if (a === 0) return "reserved";
    if (a >= 224 && a <= 239) return "multicast";
    if (a >= 240) return "reserved";
    if (a === 255 && b === 255 && c === 255 && d === 255) return "broadcast";

    return "public";
};

const getIPv6Scope = (ip) => {
    const lower = ip.toLowerCase();

    if (lower === "::1") return "loopback";
    if (lower === "::") return "unspecified";

    // Unique local address fc00::/7
    if (lower.startsWith("fc") || lower.startsWith("fd")) {
        return "private";
    }

    // Link local fe80::/10
    if (
        lower.startsWith("fe8") ||
        lower.startsWith("fe9") ||
        lower.startsWith("fea") ||
        lower.startsWith("feb")
    ) {
        return "link_local";
    }

    // Multicast ff00::/8
    if (lower.startsWith("ff")) {
        return "multicast";
    }

    // Documentation 2001:db8::/32
    if (lower.startsWith("2001:db8")) {
        return "documentation";
    }

    return "public";
};

export const classifyIp = (value) => {
    const ip = normalizeIp(value);

    if (!ip) {
        return {
            ip: null,
            version: null,
            scope: "invalid",
            isValid: false,
            isPrivate: false,
            isPublic: false,
        };
    }

    const version = net.isIP(ip);

    const scope = version === 4 ? getIPv4Scope(ip) : getIPv6Scope(ip);

    return {
        ip,
        version,
        scope,
        isValid: true,
        isPrivate: ["private", "loopback", "link_local", "carrier_grade_nat"].includes(scope),
        isPublic: scope === "public",
    };
};

const getTrustProxyStatus = (req) => {
    const value = req.app?.get("trust proxy");

    return {
        enabled: value !== false && value !== undefined && value !== null,
        value,
    };
};

export const getIpDetailsFromRequest = (req) => {
    const trustProxy = getTrustProxyStatus(req);

    const socketIp = normalizeIp(req.socket?.remoteAddress);
    const expressIp = normalizeIp(req.ip);

    const xForwardedForRaw = req.headers["x-forwarded-for"] || null;
    const xForwardedForIps = parseForwardedFor(xForwardedForRaw);

    const xRealIp = normalizeIp(req.headers["x-real-ip"]);
    const xClientIp = normalizeIp(req.headers["x-client-ip"]);

    const xClientPublicIp = normalizeIp(req.headers["x-client-public-ip"]);
    const xClientPublicIpv4 = normalizeIp(req.headers["x-client-public-ipv4"]);
    const xClientPublicIpv6 = normalizeIp(req.headers["x-client-public-ipv6"]);

    let selectedIp = null;
    let selectedIpSource = null;

    if (trustProxy.enabled && expressIp) {
        selectedIp = expressIp;
        selectedIpSource = "req.ip_trust_proxy";
    } else if (socketIp) {
        selectedIp = socketIp;
        selectedIpSource = "req.socket.remoteAddress";
    } else if (expressIp) {
        selectedIp = expressIp;
        selectedIpSource = "req.ip";
    }

    const selected = classifyIp(selectedIp);

    const privateIp = selected.isPrivate ? selected.ip : null;

    let publicIp = null;

    if (selected.isPublic) {
        publicIp = selected.ip;
    } else if (xClientPublicIpv4 && classifyIp(xClientPublicIpv4).isPublic) {
        publicIp = xClientPublicIpv4;
    } else if (xClientPublicIpv6 && classifyIp(xClientPublicIpv6).isPublic) {
        publicIp = xClientPublicIpv6;
    } else if (xClientPublicIp && classifyIp(xClientPublicIp).isPublic) {
        publicIp = xClientPublicIp;
    }

    const candidates = [
        {
            source: "selected",
            value: selectedIp,
            details: classifyIp(selectedIp),
        },
        {
            source: "req.socket.remoteAddress",
            value: socketIp,
            details: classifyIp(socketIp),
        },
        {
            source: "req.ip",
            value: expressIp,
            details: classifyIp(expressIp),
        },
        {
            source: "x-real-ip",
            value: xRealIp,
            details: classifyIp(xRealIp),
        },
        {
            source: "x-client-ip",
            value: xClientIp,
            details: classifyIp(xClientIp),
        },
        {
            source: "x-client-public-ip",
            value: xClientPublicIp,
            details: classifyIp(xClientPublicIp),
        },
        {
            source: "x-client-public-ipv4",
            value: xClientPublicIpv4,
            details: classifyIp(xClientPublicIpv4),
        },
        {
            source: "x-client-public-ipv6",
            value: xClientPublicIpv6,
            details: classifyIp(xClientPublicIpv6),
        },
    ];

    return {
        selectedIp: {
            ip: selected.ip,
            version: selected.version,
            scope: selected.scope,
            isPrivate: selected.isPrivate,
            isPublic: selected.isPublic,
            source: selectedIpSource,
        },

        privateIp,
        publicIp,

        trustProxy,

        candidates,

        proxy: {
            xForwardedForRaw,
            xForwardedForIps,
            xRealIp,
            xClientIp,
        },

        clientProvidedPublicIp: {
            any: xClientPublicIp,
            ipv4: xClientPublicIpv4,
            ipv6: xClientPublicIpv6,
        },

        request: {
            method: req.method,
            originalUrl: req.originalUrl,
            protocol: req.protocol,
            hostname: req.hostname,
            userAgent: req.headers["user-agent"] || null,
        },
    };
};