import { createLogger, format, transports } from 'winston';
const { combine, timestamp, printf, colorize } = format;
const fmt = printf(({ level, message, timestamp }) => `${timestamp} [${level}]: ${message}`);
const logger = createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: combine(timestamp({ format:'YYYY-MM-DD HH:mm:ss' }), fmt),
  transports: [new transports.Console({ format: combine(colorize(), timestamp({ format:'HH:mm:ss' }), fmt) })],
});
export default logger;
