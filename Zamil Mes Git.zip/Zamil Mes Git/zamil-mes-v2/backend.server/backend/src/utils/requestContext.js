import { AsyncLocalStorage } from 'node:async_hooks';

const requestContext = new AsyncLocalStorage();

export const runRequestContext = (context, callback) => {
  return requestContext.run(context, callback);
};

export const getRequestContext = () => {
  return requestContext.getStore() || {};
};

export const getMachineDeviceInfo = () => {
  return getRequestContext().machineDeviceInfo || null;
};

export const getIpDetails = () => {
  return getRequestContext().ipDetails || null;
};

export default {
  runRequestContext,
  getRequestContext,
  getMachineDeviceInfo,
  getIpDetails,
};