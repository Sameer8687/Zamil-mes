/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['DM Sans', 'sans-serif'],
        mono: ['Space Mono', 'monospace'],
      },
      colors: {
        // Map Tailwind color names to CSS custom properties (theme-aware)
        bg:    'var(--bg)',
        bg2:   'var(--bg2)',
        bg3:   'var(--bg3)',
        bg4:   'var(--bg4)',
        bg5:   'var(--bg5)',
        bor:   'var(--bor)',
        bor2:  'var(--bor2)',
        bor3:  'var(--bor3)',
        tx:    'var(--tx)',
        tx2:   'var(--tx2)',
        tx3:   'var(--tx3)',
        blu:   'var(--blu)',
        blu2:  'var(--blu2)',
        blu3:  'var(--blu3)',
        grn:   'var(--grn)',
        grn2:  'var(--grn2)',
        grn3:  'var(--grn3)',
        amb:   'var(--amb)',
        amb2:  'var(--amb2)',
        amb3:  'var(--amb3)',
        red:   'var(--red)',
        red2:  'var(--red2)',
        red3:  'var(--red3)',
        pur:   'var(--pur)',
        pur2:  'var(--pur2)',
        tel:   'var(--tel)',
        tel2:  'var(--tel2)',
        ora:   'var(--ora)',
        ora2:  'var(--ora2)',
      },
      borderRadius: {
        sm:  'var(--r)',
        md:  'var(--rl)',
        lg:  'var(--rxl)',
      },
      screens: {
        'xs': '480px',
      },
      animation: {
        pulse2: 'pulse2 2s infinite',
      },
      keyframes: {
        pulse2: {
          '0%,100%': { opacity: '1', transform: 'scale(1)' },
          '50%': { opacity: '.4', transform: 'scale(1.4)' },
        },
      },
    },
  },
  plugins: [],
}
