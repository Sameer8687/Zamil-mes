import { useState, useEffect } from 'react'

const SHIFTS = [
  { name: 'Shift A – Morning',   start: 6,  end: 14 },
  { name: 'Shift B – Afternoon', start: 14, end: 22 },
  { name: 'Shift C – Night',     start: 22, end: 6  },
]

export default function useClock() {
  const [now, setNow] = useState(new Date())

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000)
    return () => clearInterval(id)
  }, [])

  const h = now.getHours()
  const shift = SHIFTS.find(s =>
    s.start < s.end ? (h >= s.start && h < s.end) : (h >= s.start || h < s.end)
  )

  return {
    time:  now.toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    date:  now.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
    shift: shift?.name || 'Shift A – Morning',
    shiftCode: shift?.name?.charAt(6) || 'A',
    now,
  }
}
