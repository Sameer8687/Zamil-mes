import { useState, useEffect, useCallback, useRef } from 'react';

/**
 * Generic API hook
 * @param {Function} fetchFn - async function that returns data
 * @param {Array} deps - dependencies that trigger re-fetch
 * @param {Object} opts - { immediate: bool, transform: fn }
 */
export function useApi(fetchFn, deps = [], opts = {}) {
  const { immediate = true, transform } = opts;
  const [data, setData]       = useState(null);
  const [loading, setLoading] = useState(immediate);
  const [error, setError]     = useState(null);
  const mountedRef             = useRef(true);

  useEffect(() => { mountedRef.current = true; return () => { mountedRef.current = false; }; }, []);

  const execute = useCallback(async (...args) => {
    setLoading(true);
    setError(null);
    try {
      const result = await fetchFn(...args);
      const value  = transform ? transform(result) : (result?.data ?? result);
      if (mountedRef.current) setData(value);
      return value;
    } catch (err) {
      if (mountedRef.current) setError(err?.message || 'Request failed');
      throw err;
    } finally {
      if (mountedRef.current) setLoading(false);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  useEffect(() => {
    if (immediate) execute();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [execute]);

  return { data, loading, error, refetch: execute };
}

/**
 * Mutation hook — for POST/PUT/DELETE
 */
export function useMutation(mutateFn, opts = {}) {
  const { onSuccess, onError } = opts;
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState(null);

  const mutate = useCallback(async (...args) => {
    setLoading(true);
    setError(null);
    try {
      const result = await mutateFn(...args);
      onSuccess?.(result);
      return result;
    } catch (err) {
      const msg = err?.message || 'Operation failed';
      setError(msg);
      onError?.(err);
      throw err;
    } finally {
      setLoading(false);
    }
  }, [mutateFn, onSuccess, onError]);

  return { mutate, loading, error };
}

/**
 * Paginated list hook
 */
export function useList(fetchFn, defaultParams = {}) {
  const [params, setParams]   = useState({ page: 1, limit: 20, ...defaultParams });
  const [items, setItems]     = useState([]);
  const [total, setTotal]     = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState(null);

  const load = useCallback(async (p = params) => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetchFn(p);
      setItems(res?.data ?? res ?? []);
      setTotal(res?.pagination?.total ?? res?.data?.length ?? 0);
    } catch (err) {
      setError(err?.message || 'Failed to load');
    } finally {
      setLoading(false);
    }
  }, [fetchFn, params]);

  useEffect(() => { load(); }, [load]);

  const setFilter = useCallback((updates) => {
    const next = { ...params, ...updates, page: 1 };
    setParams(next);
  }, [params]);

  const setPage = useCallback((page) => {
    const next = { ...params, page };
    setParams(next);
  }, [params]);

  return { items, total, loading, error, params, setFilter, setPage, refetch: load };
}

export default useApi;
