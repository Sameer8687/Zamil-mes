import { useState, useEffect, useCallback } from 'react';
import { setupService, referenceService } from '../services/api';

// Fallback static data used ONLY when API is unavailable (development mode)
const FALLBACK = {
  machines: [
    { id: 'ZFP001', code: 'ZFP001', name: 'ZFP001 – INJECTION',      type: 'Injection', status: 'running' },
    { id: 'ZFP002', code: 'ZFP002', name: 'ZFP002 – INJECTION',      type: 'Injection', status: 'running' },
    { id: 'ZBL010', code: 'ZBL010', name: 'ZBL010 – BLOW MOULDING',  type: 'Blow',      status: 'idle'    },
    { id: 'ZPK005', code: 'ZPK005', name: 'ZPK005 – PACKAGING LINE', type: 'Packaging', status: 'running' },
    { id: 'INJ-077', code: 'INJ-077', name: 'INJ-077 – INJECTION',   type: 'Injection', status: 'running' },
    { id: 'INJ-083', code: 'INJ-083', name: 'INJ-083 – INJECTION',   type: 'Injection', status: 'breakdown'},
    { id: 'INJ-103', code: 'INJ-103', name: 'INJ-103 – INJECTION',   type: 'Injection', status: 'running' },
    { id: 'INJ-106', code: 'INJ-106', name: 'INJ-106 – INJECTION',   type: 'Injection', status: 'idle'    },
  ],
  shifts: [
    { id: 'A', name: 'Shift A – Morning',   startTime: '06:00', endTime: '14:00' },
    { id: 'B', name: 'Shift B – Afternoon', startTime: '14:00', endTime: '22:00' },
    { id: 'C', name: 'Shift C – Night',     startTime: '22:00', endTime: '06:00' },
  ],
  locations: [
    { id: 'WH-A',     code: 'WH-A',    name: 'Warehouse A',  type: 'warehouse' },
    { id: 'WH-B',     code: 'WH-B',    name: 'Warehouse B',  type: 'warehouse' },
    { id: 'STAGING',  code: 'STAGING', name: 'Staging Area', type: 'staging'   },
    { id: 'DISPATCH', code: 'DISPATCH',name: 'Dispatch Bay', type: 'dispatch'  },
  ],
  workOrders: [
    { id: 'wo1', woNumber: 'FPP-WO-414', product: 'HDPE Film 200µm',      plannedQty: 15000, producedQty: 11200, status: 'active', boxQty: 50  },
    { id: 'wo2', woNumber: 'FPP-WO-494', product: 'LDPE Liner Bag 100µm', plannedQty: 8000,  producedQty: 3400,  status: 'active', boxQty: 100 },
    { id: 'wo3', woNumber: 'FPP-WO-477', product: 'PP Woven Sack 50kg',   plannedQty: 5000,  producedQty: 5000,  status: 'completed', boxQty: 25 },
    { id: 'wo4', woNumber: 'IPP-WO-221', product: 'PP Crate 60L Blue',    plannedQty: 2000,  producedQty: 1650,  status: 'active', boxQty: 10  },
    { id: 'wo5', woNumber: 'IPP-WO-198', product: 'HDPE Jerry Can 20L',   plannedQty: 3000,  producedQty: 2900,  status: 'active', boxQty: 20  },
  ],
  wasteTypes: ['Runner/Sprue', 'Short Shot', 'Flash/Burr', 'Sink Mark', 'Contamination', 'Colour Mismatch', 'Dimensional OOS', 'Other'],
  downtimeCategories: ['Mechanical Breakdown', 'Electrical Fault', 'Material Change', 'Mold Change', 'Planned Maintenance', 'Quality Hold', 'Operator Absence', 'Power Failure', 'Other'],
  defectTypes: ['Flash', 'Short Shot', 'Sink Mark', 'Weld Line', 'Colour Off', 'Dimension OOS', 'Surface Scratch', 'Black Spot', 'Warpage', 'Other'],
  roles: ['admin', 'tech', 'operator', 'qc', 'packer', 'viewer'],
};

let _cache = null;

export function useReference() {
  const [ref, setRef] = useState(_cache || {
    machines: [], shifts: [], locations: [], workOrders: [],
    wasteTypes: [], downtimeCategories: [], defectTypes: [], roles: [],
    loaded: false,
  });

  const load = useCallback(async () => {
    if (_cache?.loaded) { setRef(_cache); return; }
    try {
      const [machinesRes, shiftsRes, locRes] = await Promise.allSettled([
        setupService.getMachines(),
        setupService.getShifts(),
        setupService.getLocations(),
      ]);

      const machines  = machinesRes.status  === 'fulfilled' ? (machinesRes.value?.data  ?? machinesRes.value)  : FALLBACK.machines;
      const shifts    = shiftsRes.status    === 'fulfilled' ? (shiftsRes.value?.data    ?? shiftsRes.value)    : FALLBACK.shifts;
      const locations = locRes.status       === 'fulfilled' ? (locRes.value?.data       ?? locRes.value)       : FALLBACK.locations;

      _cache = {
        machines, shifts, locations,
        workOrders: FALLBACK.workOrders,
        wasteTypes: FALLBACK.wasteTypes,
        downtimeCategories: FALLBACK.downtimeCategories,
        defectTypes: FALLBACK.defectTypes,
        roles: FALLBACK.roles,
        loaded: true,
      };
      setRef(_cache);
    } catch (_) {
      _cache = { ...FALLBACK, loaded: true };
      setRef(_cache);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const invalidate = () => { _cache = null; load(); };

  return { ...ref, invalidate };
}

export { FALLBACK };
export default useReference;
