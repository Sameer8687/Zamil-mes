import axios from "axios";

const API_BASE = import.meta.env.VITE_API_URL || "/api/v1";

const api = axios.create({
  baseURL: API_BASE,
  timeout: 30000,
  headers: { "Content-Type": "application/json" },
});

api.interceptors.request.use(
  (config) => {
    const token = sessionStorage.getItem("mes_token");

    config._hadAuthToken = !!token;

    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }

    return config;
  },
  (error) => Promise.reject(error),
);

api.interceptors.response.use(
  (response) => response.data,
  (error) => {
    const status = error.response?.status;
    const hadAuthToken = error.config?._hadAuthToken;
    const skipAuthLogout = error.config?._skipAuthLogout;
    const url = error.config?.url || "";

    const isLoginRequest = url.includes("/auth/login");
    const isLogoutRequest = url.includes("/auth/logout");

    if (
      status === 401 &&
      hadAuthToken &&
      !skipAuthLogout &&
      !isLoginRequest &&
      !isLogoutRequest
    ) {
      sessionStorage.removeItem("mes_token");
      sessionStorage.removeItem("mes_user");
      sessionStorage.removeItem("mes_machine");
      window.dispatchEvent(new Event("auth:logout"));
    }

    const msg =
      (typeof error.response?.data === "object"
        ? error.response?.data?.message
        : null) ||
      error.message ||
      "Request failed";

    return Promise.reject(new Error(msg));
  },
);

export default api;

/* ─── Auth ───────────────────────────────────────────────────────────── */
export const authService = {
  login: (data) => api.post("/auth/login", data),
  logout: () => {
    const token = sessionStorage.getItem("mes_token");

    if (!token) {
      return Promise.resolve({ success: true });
    }

    return api.post("/auth/logout", null, {
      _skipAuthLogout: true,
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
  },
  me: () => api.get("/auth/me"),
  changePassword: (data) => api.put("/auth/change-password", data),
};

/* ─── Reference / Dropdowns ──────────────────────────────────────────── */
export const refService = {
  getMachines: (params) => api.get("/setup/machines", { params }),
  getLocations: (params) => api.get("/setup/locations", { params }),
  getShifts: () => api.get("/setup/shifts"),
  getWorkOrders: (params) => api.get("/production/work-orders", { params }),
  getConfig: (key) => api.get("/setup/configs", { params: { key } }),
};

/* ─── Production ─────────────────────────────────────────────────────── */
export const productionService = {
  getWorkOrders: (params) => api.get("/production/work-orders", { params }),
  getWorkOrder: (id) => api.get(`/production/work-orders/${id}`),
  createWorkOrder: (data) => api.post("/production/work-orders", data),
  updateWorkOrder: (id, data) => api.put(`/production/work-orders/${id}`, data),
  deleteWorkOrder: (id) => api.delete(`/production/work-orders/${id}`),
  getLogs: (params) => api.get("/production/logs", { params }),
  createLog: (data) => api.post("/production/logs", data),
  getMachines: (params) => api.get("/production/machines", { params }),
  getDashboard: () => api.get("/production/dashboard"),
};

/* ─── Operator ───────────────────────────────────────────────────────── */
export const operatorService = {
  getActiveWO: (machineId) =>
    api.get("/production/work-orders", {
      params: { 
        // machineId, 
        status: "active", limit: 1 },
    }),
  logProduction: (data) => api.post("/production/logs", data),
  printLabel: (data) => api.post("/packer/boxes", data),
  getLabels: (params) => api.get("/packer/boxes", { params }),
};

/* ─── QC ─────────────────────────────────────────────────────────────── */
export const qcService = {
  getResults: (params) => api.get("/qc", { params }),
  getResult: (id) => api.get(`/qc/${id}`),
  create: (data) => api.post("/qc", data),
  update: (id, data) => api.put(`/qc/${id}`, data),
  getSummary: (params) => api.get("/qc/summary", { params }),
  getDefectTypes: () => api.get("/reference/defect-types"),
  getCheckItems: () => api.get("/reference/qc-checklist"),
};

/* ─── Waste ──────────────────────────────────────────────────────────── */
export const wasteService = {
  getRecords: (params) => api.get("/waste", { params }),
  create: (data) => api.post("/waste", data),
  update: (id, data) => api.put(`/waste/${id}`, data),
  delete: (id) => api.delete(`/waste/${id}`),
  getSummary: (params) => api.get("/waste/summary", { params }),
  getWasteTypes: () => api.get("/reference/waste-types"),
};

/* ─── Downtime ───────────────────────────────────────────────────────── */
export const downtimeService = {
  getRecords: (params) => api.get("/downtime", { params }),
  create: (data) => api.post("/downtime", data),
  update: (id, data) => api.put(`/downtime/${id}`, data),
  getSummary: (params) => api.get("/downtime/summary", { params }),
  getCategories: () => api.get("/reference/downtime-categories"),
};

/* ─── Packer ─────────────────────────────────────────────────────────── */
export const packerService = {
  getBoxes: (params) => api.get("/packer/boxes", { params }),
  createBox: (data) => api.post("/packer/boxes", data),
  updateBox: (id, data) => api.put(`/packer/boxes/${id}`, data),
  getPallets: (params) => api.get("/packer/pallets", { params }),
  createPallet: (data) => api.post("/packer/pallets", data),
  addBoxToPallet: (id, data) => api.post(`/packer/pallets/${id}/boxes`, data),
  finalizePallet: (id) => api.put(`/packer/pallets/${id}/finalize`),
  printLabel: (id) => api.post(`/packer/pallets/${id}/print`),
};

/* ─── Line Clearance ─────────────────────────────────────────────────── */
export const lcService = {
  getAll: (params) => api.get("/line-clearance", { params }),
  getOne: (id) => api.get(`/line-clearance/${id}`),
  create: (data) => api.post("/line-clearance", data),
  update: (id, data) => api.put(`/line-clearance/${id}`, data),
  approve: (id, data) => api.post(`/line-clearance/${id}/approve`, data),
  getChecklist: () => api.get("/reference/lc-checklist"),
};

/* ─── Stock ──────────────────────────────────────────────────────────── */
export const stockService = {
  getRecords: (params) => api.get("/stock", { params }),
  getRecord: (id) => api.get(`/stock/${id}`),
  create: (data) => api.post("/stock", data),
  update: (id, data) => api.put(`/stock/${id}`, data),
  getSummary: () => api.get("/stock/summary"),
  export: (params) =>
    api.get("/stock/export", { params, responseType: "blob" }),
};

/* ─── Setup ──────────────────────────────────────────────────────────── */
export const setupService = {
  // Machines
  getMachines: (params) => api.get("/setup/machines", { params }),
  createMachine: (data) => api.post("/setup/machines", data),
  
  updateMachine: (id, data) => api.put(`/setup/machines/${id}`, data),
  deleteMachine: (id) => api.delete(`/setup/machines/${id}`),
  // Locations
  getLocations: (params) => api.get("/setup/locations", { params }),
  createLocation: (data) => api.post("/setup/locations", data),
  updateLocation: (id, data) => api.put(`/setup/locations/${id}`, data),
  deleteLocation: (id) => api.delete(`/setup/locations/${id}`),
  // Shifts
  getShifts: () => api.get("/setup/shifts"),
  createShift: (data) => api.post("/setup/shifts", data),
  updateShift: (id, data) => api.put(`/setup/shifts/${id}`, data),
  deleteShift: (id) => api.delete(`/setup/shifts/${id}`),
  // Configs / Box Qty
  getConfigs: (params) => api.get("/setup/configs", { params }),
  upsertConfig: (data) => api.post("/setup/configs", data),
  getBoxQtyReport: (params) => api.get("/setup/box-qty-report", { params }),
  saveBoxQtyRecords: (data) => api.post("/setup/box-qty-records", data),
  deleteBoxQtyRecord: (id) => api.delete(`/setup/box-qty-records/${id}`),
};

/* ─── Users / Admin ──────────────────────────────────────────────────── */
export const userService = {
  getAll: (params) => api.get("/users", { params }),
  getOne: (id) => api.get(`/users/${id}`),
  create: (data) => api.post("/users", data),
  update: (id, data) => api.put(`/users/${id}`, data),
  delete: (id) => api.delete(`/users/${id}`),
  updatePermissions: (id, data) => api.put(`/users/${id}/permissions`, data),
  getRoles: () => api.get("/users/roles"),
  getActivityLog: (id, params) => api.get(`/users/${id}/activity`, { params }),
};

export const roleService = {
  getAll: (params = {}) => api.get("/roles", { params }),
  getOne: (id) => api.get(`/roles/${id}`),
  create: (data) => api.post("/roles", data),
  update: (id, data) => api.put(`/roles/${id}`, data),
  delete: (id) => api.delete(`/roles/${id}`),
};

export const accessService = {
  bootstrap: () => api.get("/access/bootstrap"),

  getUserAccess: (userId) => api.get(`/access/users/${userId}`),
  saveUserAccess: (userId, data) => api.put(`/access/users/${userId}`, data),

  saveUserSecurity: (userId, data) =>
  api.put(`/access/users/${userId}/security`, data),

forceLogoutUser: (userId) =>
  api.post(`/access/users/${userId}/force-logout`),

  addUserRole: (userId, data) =>
    api.post(`/access/users/${userId}/roles`, data),

  removeUserRole: (userId, roleId) =>
    api.delete(`/access/users/${userId}/roles/${roleId}`),

  setPrimaryUserRole: (userId, roleId) =>
    api.put(`/access/users/${userId}/roles/${roleId}/primary`),


  getRolePermissions: (roleId) =>
    api.get(`/access/roles/${roleId}/permissions`),

  createRolePermissions: (roleId, data) =>
    api.post(`/access/roles/${roleId}/permissions`, data),

  updateRolePermissions: (roleId, data) =>
    api.put(`/access/roles/${roleId}/permissions`, data),

  deleteRolePermissions: (roleId) =>
    api.delete(`/access/roles/${roleId}/permissions`),

  getScreens: () => api.get("/access/screens"),
  createScreen: (data) => api.post("/access/screens", data),
  updateScreen: (id, data) => api.put(`/access/screens/${id}`, data),
  deleteScreen: (id) => api.delete(`/access/screens/${id}`),

  getFeatures: () => api.get("/access/features"),
  createFeature: (data) => api.post("/access/features", data),
  updateFeature: (id, data) => api.put(`/access/features/${id}`, data),
  deleteFeature: (id) => api.delete(`/access/features/${id}`),
};

/* ─── Install ────────────────────────────────────────────────────────── */
export const installService = {
  status: () => api.get("/install/status"),
  testConnection: (data) => api.post("/install/test-connection", data),
  createSchema: (data) => api.post("/install/create-schema", data),
  seedData: (data) => api.post("/install/seed-data", data),
  finalize: () => api.post("/install/finalize"),
};

/* ─── Reference Data ─────────────────────────────────────────────────── */
export const referenceService = {
  getDefectTypes: () => api.get("/reference/defect-types"),
  getWasteTypes: () => api.get("/reference/waste-types"),
  getDowntimeCategories: () => api.get("/reference/downtime-categories"),
  getLCChecklist: () => api.get("/reference/lc-checklist"),
  getQCChecklist: () => api.get("/reference/qc-checklist"),
};