import { Outlet } from "react-router-dom";
import Topbar from "../components/common/Topbar";
import Navbar from "../components/common/Navbar";

export default function DashboardLayout() {
  return (
    <div className="min-h-screen" style={{ background: "var(--bg)" }}>
      <Topbar />
      <Navbar />

      <main className="">
        <Outlet />
      </main>
    </div>
  );
}