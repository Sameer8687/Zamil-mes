import { Outlet, Navigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

export default function AuthLayout() {
  const { state } = useAuth();
  if (state.isAuthenticated) return <Navigate to="/app" replace />;
  return <Outlet />;
}
