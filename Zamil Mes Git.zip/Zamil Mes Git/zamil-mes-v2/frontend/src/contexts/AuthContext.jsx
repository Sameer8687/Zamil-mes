import {
  createContext,
  useContext,
  useState,
  useCallback,
  useEffect,
} from "react";
import { authService, setupService } from "../services/api";

const AuthContext = createContext(null);

// Credentials for the quick-fill cards on the login page — must match the seeded DB
// Admin: EMP-0001 / Admin@1234 (auto-created on first boot)
// Others: Demo@1234 (set by seed.js)
export const DEMO_ACCOUNTS = {
  tech:     { empId: 'EMP-2479', password: 'Demo@1234', role: 'tech',     name: 'Syed Hussaini' },
  operator: { empId: 'EMP-5012', password: 'Demo@1234', role: 'operator', name: 'Ahmed Hassan' },
  qc:       { empId: 'EMP-1001', password: 'Demo@1234', role: 'qc',       name: 'Mustafa Al Maqrodh' },
  packer:   { empId: 'EMP-3301', password: 'Demo@1234', role: 'packer',   name: 'Ahmed Al Rashidi' },
  admin:    { empId: 'EMP-0001', password: 'Admin@1234', role: 'admin',   name: 'System Administrator' },
  multi:    { empId: 'EMP-2122', password: 'Demo@1234', role: 'tech',     name: 'Amro Faisal' },
};

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [machine, setMachineState] = useState(null);
  const [loading, setLoading] = useState(true);

  const clearSession = useCallback(() => {
    setUser(null);
    setMachineState(null);
    sessionStorage.removeItem("mes_token");
    sessionStorage.removeItem("mes_user");
    sessionStorage.removeItem("mes_machine");
  }, []);

  // Restore session — only if a real JWT token exists alongside the saved user
  useEffect(() => {
    const token  = sessionStorage.getItem("mes_token");
    const saved  = sessionStorage.getItem("mes_user");
    const savedMc = sessionStorage.getItem("mes_machine");

    if (token && saved) {
      try {
        setUser(JSON.parse(saved));
      } catch (_) {
        // Corrupted user JSON — clear everything
        sessionStorage.removeItem("mes_user");
        sessionStorage.removeItem("mes_token");
      }
    } else if (!token && saved) {
      // Stale demo / tokenless session — clear it so we land on login
      sessionStorage.removeItem("mes_user");
      sessionStorage.removeItem("mes_machine");
    }

    if (savedMc) {
      try {
        setMachineState(JSON.parse(savedMc));
      } catch (_) {
        sessionStorage.removeItem("mes_machine");
      }
    }

    setLoading(false);

    const handler = () => clearSession();
    window.addEventListener("auth:logout", handler);
    return () => window.removeEventListener("auth:logout", handler);
  }, [clearSession]);

  const login = useCallback(async ({ empId, password, machineId }) => {
    // Throws on network error or bad credentials — caller handles the message
    const res = await authService.login({ empId, password });

    // Backend: { success, message, data: { token, user } }
    // After interceptor (response => response.data): { success, message, data: { token, user } }
    const authData = res?.data ?? res;
    const { token, user: apiUser } = authData ?? {};

    if (!token) throw new Error("Login failed — server did not return a token");

    sessionStorage.setItem("mes_token", token);
    sessionStorage.setItem("mes_user", JSON.stringify(apiUser));
    setUser(apiUser);

    if (machineId) {
      try {
        const mcRes = await setupService.getMachines({ code: machineId });
        const machines = mcRes?.data ?? mcRes;
        const mc = Array.isArray(machines) ? machines[0] : null;
        if (mc) {
          setMachineState(mc);
          sessionStorage.setItem("mes_machine", JSON.stringify(mc));
        }
      } catch (_) {}
    }

    return apiUser;
  }, []);

  const logout = useCallback(() => {
    void authService.logout().catch(() => {});
    clearSession();
  }, [clearSession]);

  const setMachine = useCallback((mc) => {
    setMachineState(mc);
    sessionStorage.setItem("mes_machine", JSON.stringify(mc));
  }, []);

  const hasRole = useCallback(
    (...roles) => {
      if (!user) return false;
      if (user.role === "admin") return true;
      return roles.includes(user.role);
    },
    [user]
  );

  return (
    <AuthContext.Provider
      value={{
        user,
        machine,
        setMachine,
        login,
        logout,
        hasRole,
        isAuthenticated: !!user,
        loading,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be inside AuthProvider");
  return ctx;
}

export default AuthContext;
