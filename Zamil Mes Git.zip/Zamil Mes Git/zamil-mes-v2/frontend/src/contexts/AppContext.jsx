import { createContext, useContext, useState, useCallback, useEffect } from 'react'

const AppContext = createContext(null)

export function AppProvider({ children }) {
  const [theme, setThemeState]   = useState(() => localStorage.getItem('mes_theme') || 'black')
  const [screen, setScreen]      = useState('production')
  const [screenHistory, setHistory] = useState([])
  const [toast, setToast]        = useState(null)

  // Apply theme to body
  useEffect(() => {
    document.body.removeAttribute('data-theme')
    if (theme !== 'black') document.body.setAttribute('data-theme', theme)
    localStorage.setItem('mes_theme', theme)
  }, [theme])

  const setTheme = useCallback((t) => setThemeState(t), [])

  const goScreen = useCallback((s, pushHistory = true) => {
    if (pushHistory) setHistory(h => [...h.slice(-9), screen])
    setScreen(s)
    window.scrollTo(0, 0)
  }, [screen])

  const goBack = useCallback(() => {
    setHistory(h => {
      const prev = h[h.length - 1]
      if (prev) { setScreen(prev); return h.slice(0, -1) }
      return h
    })
  }, [])

  const showToast = useCallback((message, type = 'success', duration = 3000) => {
    setToast({ message, type, id: Date.now() })
    setTimeout(() => setToast(null), duration)
  }, [])

  return (
    <AppContext.Provider value={{ theme, setTheme, screen, goScreen, goBack, toast, showToast }}>
      {children}
      {toast && <GlobalToast toast={toast} onDismiss={() => setToast(null)} />}
    </AppContext.Provider>
  )
}

function GlobalToast({ toast, onDismiss }) {
  const colors = {
    success: 'bg-grn2 border-bor text-grn border-[var(--grn)]',
    error:   'bg-red2 border-bor text-red border-[var(--red)]',
    warning: 'bg-amb2 border-bor text-amb border-[var(--amb)]',
    info:    'bg-blu2 border-bor text-blu border-[var(--blu)]',
  }
  const icons = { success: '✓', error: '✕', warning: '⚠', info: 'ℹ' }
  return (
    <div className="fixed bottom-6 right-6 z-[999] fade-in">
      <div className={`flex items-center gap-2.5 px-4 py-3 rounded-lg border shadow-xl text-sm font-medium cursor-pointer ${colors[toast.type] || colors.success}`}
        onClick={onDismiss}>
        <span className="font-bold">{icons[toast.type] || icons.success}</span>
        <span>{toast.message}</span>
      </div>
    </div>
  )
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be inside AppProvider')
  return ctx
}

export default AppContext
