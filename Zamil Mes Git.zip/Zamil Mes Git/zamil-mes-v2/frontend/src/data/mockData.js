// ═══════════════════════════════════════════════════════════
// ZAMIL MES – Central Mock Data Store
// ═══════════════════════════════════════════════════════════

export const MACHINES = [
  { id: 'ZFP001', name: 'ZFP001 – INJECTION',      type: 'Injection Moulding', plant: 'FPP BU', status: 'running',   oee: 82, cavities: 16, material: 'HDPE',   shots: 12400, cycleTime: 28, tonnage: 180  },
  { id: 'ZFP002', name: 'ZFP002 – INJECTION',      type: 'Injection Moulding', plant: 'FPP BU', status: 'running',   oee: 79, cavities: 8,  material: 'PP',     shots: 9800,  cycleTime: 32, tonnage: 120  },
  { id: 'ZBL010', name: 'ZBL010 – BLOW MOULDING',  type: 'Blow Moulding',      plant: 'FPP BU', status: 'idle',      oee: 0,  cavities: 4,  material: 'HDPE',   shots: 0,     cycleTime: 45, tonnage: 50   },
  { id: 'ZPK005', name: 'ZPK005 – PACKAGING LINE', type: 'Packaging',          plant: 'FPP BU', status: 'running',   oee: 91, cavities: 1,  material: 'N/A',    shots: 3200,  cycleTime: 8,  tonnage: 0    },
  { id: 'INJ-077', name: 'INJ-077 – INJECTION',    type: 'Injection Moulding', plant: 'IPP BU', status: 'running',   oee: 74, cavities: 12, material: 'ABS',    shots: 8100,  cycleTime: 35, tonnage: 150  },
  { id: 'INJ-083', name: 'INJ-083 – INJECTION',    type: 'Injection Moulding', plant: 'IPP BU', status: 'breakdown', oee: 0,  cavities: 8,  material: 'Nylon',  shots: 0,     cycleTime: 40, tonnage: 90   },
  { id: 'INJ-103', name: 'INJ-103 – INJECTION',    type: 'Injection Moulding', plant: 'IPP BU', status: 'running',   oee: 85, cavities: 16, material: 'PP',     shots: 11200, cycleTime: 30, tonnage: 200  },
  { id: 'INJ-106', name: 'INJ-106 – INJECTION',    type: 'Injection Moulding', plant: 'IPP BU', status: 'idle',      oee: 0,  cavities: 8,  material: 'HDPE',   shots: 0,     cycleTime: 38, tonnage: 110  },
]

export const WORK_ORDERS = [
  { id: 'FPP-WO-414', sku: 'FG30281',  product: 'HDPE Container 5L', machine: 'ZFP001', qty: 83298,  produced: 61200, rejected: 820,  boxes: 16, packed: 7,  priority: 'High',   status: 'In Progress', unit: 'PCS', shift: 'Day', plant: 'FPP BU', bom: 'BOM-FG30281-01' },
  { id: 'FPP-WO-494', sku: 'SF336',    product: 'PP Cap Assembly',   machine: 'ZFP001', qty: 2500900,produced: 940000,rejected: 12000, boxes: 8,  packed: 0,  priority: 'Medium', status: 'In Progress', unit: 'PCS', shift: 'Day', plant: 'FPP BU', bom: 'BOM-SF336-02'   },
  { id: 'FPP-WO-477', sku: 'FG3412',   product: 'Jerry Can 20L',     machine: 'ZFP002', qty: 73200,  produced: 22000, rejected: 400,  boxes: 12, packed: 2,  priority: 'Low',    status: 'In Progress', unit: 'PCS', shift: 'Day', plant: 'FPP BU', bom: 'BOM-FG3412-01'  },
  { id: 'IPP-WO-221', sku: 'FG30033',  product: 'ABS Bracket Set',   machine: 'INJ-077',qty: 937600, produced: 510000,rejected: 8200,  boxes: 12, packed: 5,  priority: 'High',   status: 'In Progress', unit: 'PCS', shift: 'Day', plant: 'IPP BU', bom: 'BOM-FG30033-01' },
  { id: 'IPP-WO-198', sku: 'SF9322',   product: 'Nylon Gear Housing', machine: 'INJ-103',qty: 353600, produced: 180000,rejected: 2100,  boxes: 1,  packed: 0,  priority: 'Medium', status: 'In Progress', unit: 'PCS', shift: 'Day', plant: 'IPP BU', bom: 'BOM-SF9322-01'  },
]

export const LOCATORS = {
  ZFP001: ['FPP-SILO-A1', 'FPP-SILO-A2', 'FPP-LINE-1-SIDE', 'FPP-STAGING-01'],
  ZFP002: ['FPP-SILO-B1', 'FPP-LINE-2-SIDE', 'FPP-STAGING-02'],
  ZBL010: ['FPP-BL-SILO', 'FPP-BL-STAGING'],
  ZPK005: ['FPP-PKG-INPUT', 'FPP-PKG-OUTPUT', 'FPP-PKG-REWORK'],
  'INJ-077': ['IPP-SILO-C1', 'IPP-LINE-A-SIDE'],
  'INJ-083': ['IPP-SILO-C2'],
  'INJ-103': ['IPP-SILO-D1', 'IPP-LINE-B-SIDE', 'IPP-STAGING-01'],
  'INJ-106': ['IPP-SILO-D2'],
}

export const QC_CHECKLIST = [
  'Dimensional Check', 'Visual Inspection', 'Weight Verification',
  'Surface Defects', 'Flash / Burrs', 'Colour Accuracy',
  'Wall Thickness', 'Gate Quality', 'Weld Lines', 'Sink Marks',
]

export const BOX_QUANTITIES = [
  { id: 'BQ-001', org: 'FPP BU', itemCode: 'FG30281', description: 'HDPE Container 5L', qtyPerBox: 83298, effectiveDate: '2025-01-01', createdBy: 'EMP-1770' },
  { id: 'BQ-002', org: 'FPP BU', itemCode: 'SF336',   description: 'PP Cap Assembly',   qtyPerBox: 2500900, effectiveDate: '2025-01-01', createdBy: 'EMP-1770' },
  { id: 'BQ-003', org: 'FPP BU', itemCode: 'FG3412',  description: 'Jerry Can 20L',     qtyPerBox: 73200, effectiveDate: '2025-01-01', createdBy: 'EMP-1770' },
  { id: 'BQ-004', org: 'IPP BU', itemCode: 'FG30033', description: 'ABS Bracket Set',   qtyPerBox: 937600, effectiveDate: '2025-01-01', createdBy: 'EMP-1770' },
  { id: 'BQ-005', org: 'IPP BU', itemCode: 'SF9322',  description: 'Nylon Gear Housing',qtyPerBox: 353600, effectiveDate: '2025-01-15', createdBy: 'EMP-2479' },
]

export const DOWNTIME_CATEGORIES = [
  { id: 'PLM', label: 'Planned Maintenance', color: 'blu' },
  { id: 'UBR', label: 'Unplanned Breakdown', color: 'red' },
  { id: 'MCH', label: 'Mould/Tool Change',    color: 'amb' },
  { id: 'MAT', label: 'Material Shortage',    color: 'ora' },
  { id: 'QCH', label: 'Quality Hold',         color: 'pur' },
  { id: 'SET', label: 'Setup / Changeover',   color: 'tel' },
  { id: 'UTL', label: 'Utilities Failure',    color: 'red' },
  { id: 'OTH', label: 'Other',               color: 'tx3' },
]

export const WASTE_REASONS = {
  'W-001': { lbl: 'Dimensional Out of Spec',  color: 'red',  share: 35 },
  'W-002': { lbl: 'Surface Defect',           color: 'amb',  share: 22 },
  'W-003': { lbl: 'Flash / Burrs',            color: 'ora',  share: 18 },
  'W-004': { lbl: 'Short Shot',               color: 'pur',  share: 12 },
  'W-005': { lbl: 'Sink Mark',                color: 'tel',  share: 8  },
  'W-006': { lbl: 'Colour Variation',         color: 'grn',  share: 5  },
}

export const WASTE_WORK_ORDERS = {
  'FPP-WO-414': { id: 'FPP-WO-414', sku: 'FG30281', product: 'HDPE Container 5L', qty: 83298, produced: 61200, rejected: 820, scrap: 340, unit: 'PCS', machine: 'ZFP001' },
  'FPP-WO-494': { id: 'FPP-WO-494', sku: 'SF336',   product: 'PP Cap Assembly',   qty: 2500900, produced: 940000, rejected: 12000, scrap: 5200, unit: 'PCS', machine: 'ZFP001' },
  'FPP-WO-477': { id: 'FPP-WO-477', sku: 'FG3412',  product: 'Jerry Can 20L',     qty: 73200, produced: 22000, rejected: 400, scrap: 180, unit: 'PCS', machine: 'ZFP002' },
}

export const WASTE_COMPONENTS = [
  { id: 'RM-HDPE-N', name: 'HDPE Natural Pellets',       uom: 'KG',  costEa: 4.20,  issued: 5200, onhand: 820,  scrapped: 140 },
  { id: 'RM-HDPE-B', name: 'HDPE Blue Masterbatch',      uom: 'KG',  costEa: 8.50,  issued: 420,  onhand: 65,   scrapped: 12  },
  { id: 'RM-CAP-PP', name: 'PP Cap Resin',               uom: 'KG',  costEa: 3.80,  issued: 3800, onhand: 490,  scrapped: 95  },
  { id: 'RM-LUBE-1', name: 'Mould Release Agent',        uom: 'LTR', costEa: 12.00, issued: 45,   onhand: 8,    scrapped: 2   },
  { id: 'RM-LABL-A', name: 'Product Label Roll',         uom: 'ROL', costEa: 28.00, issued: 12,   onhand: 3,    scrapped: 1   },
]

export const USERS_DATA = [
  { id: 'USR-001', name: 'Syed Hussaini',     empId: 'EMP-2479', role: 'technician', plant: 'FPP BU', status: 'active',  email: 'syed.hussaini@zamil.com'   },
  { id: 'USR-002', name: 'Ahmed Hassan',       empId: 'EMP-5012', role: 'operator',   plant: 'FPP BU', status: 'active',  email: 'ahmed.hassan@zamil.com'    },
  { id: 'USR-003', name: 'Mustafa Al Maqrodh',empId: 'EMP-1001', role: 'inspector',  plant: 'FPP BU', status: 'active',  email: 'mustafa.maqrodh@zamil.com' },
  { id: 'USR-004', name: 'Ahmed Al Rashidi',   empId: 'EMP-3301', role: 'packer',     plant: 'FPP BU', status: 'active',  email: 'ahmed.rashidi@zamil.com'   },
  { id: 'USR-005', name: 'Muhannad Ali Saeed', empId: 'EMP-1770', role: 'admin',      plant: 'ALL',    status: 'active',  email: 'muhannad.saeed@zamil.com'  },
  { id: 'USR-006', name: 'Amro Faisal',        empId: 'EMP-2122', role: 'multi',      plant: 'IPP BU', status: 'active',  email: 'amro.faisal@zamil.com'     },
  { id: 'USR-007', name: 'Khalid Mansour',     empId: 'EMP-4410', role: 'technician', plant: 'IPP BU', status: 'inactive',email: 'khalid.mansour@zamil.com'  },
]

export const PRODUCTION_SCHEDULE = [
  { id: 'PS-001', woId: 'FPP-WO-414', machine: 'ZFP001', product: 'HDPE Container 5L', sku: 'FG30281', plannedStart: '06:30', plannedEnd: '14:00', actualStart: '06:35', status: 'In Progress', priority: 1 },
  { id: 'PS-002', woId: 'FPP-WO-494', machine: 'ZFP001', product: 'PP Cap Assembly',   sku: 'SF336',   plannedStart: '14:00', plannedEnd: '22:00', actualStart: null,    status: 'Pending',     priority: 2 },
  { id: 'PS-003', woId: 'FPP-WO-477', machine: 'ZFP002', product: 'Jerry Can 20L',     sku: 'FG3412',  plannedStart: '06:30', plannedEnd: '18:00', actualStart: '06:45', status: 'In Progress', priority: 1 },
  { id: 'PS-004', woId: 'IPP-WO-221', machine: 'INJ-077', product: 'ABS Bracket Set',  sku: 'FG30033', plannedStart: '08:00', plannedEnd: '20:00', actualStart: '08:10', status: 'In Progress', priority: 1 },
]

export const LINE_CLEARANCE_RECORDS = []
export const DOWNTIME_RECORDS = []
export const WASTE_TRANSACTIONS = []
export const STOCK_REGISTER = [
  { id: 'STK-001', itemCode: 'FG30281', description: 'HDPE Container 5L', plant: 'FPP BU', location: 'FG-STORE-A', uom: 'PCS', onhand: 4820, reserved: 1200, available: 3620, reorderPt: 500, lastMovement: '2025-05-22' },
  { id: 'STK-002', itemCode: 'SF336',   description: 'PP Cap Assembly',   plant: 'FPP BU', location: 'FG-STORE-A', uom: 'PCS', onhand: 158000, reserved: 40000, available: 118000, reorderPt: 10000, lastMovement: '2025-05-22' },
  { id: 'STK-003', itemCode: 'FG3412',  description: 'Jerry Can 20L',     plant: 'FPP BU', location: 'FG-STORE-B', uom: 'PCS', onhand: 2200, reserved: 600,  available: 1600, reorderPt: 200, lastMovement: '2025-05-21'  },
  { id: 'STK-004', itemCode: 'FG30033', description: 'ABS Bracket Set',   plant: 'IPP BU', location: 'IPP-STORE-A',uom: 'PCS', onhand: 51000, reserved: 12000, available: 39000, reorderPt: 5000, lastMovement: '2025-05-22' },
  { id: 'STK-005', itemCode: 'SF9322',  description: 'Nylon Gear Housing', plant: 'IPP BU',location: 'IPP-STORE-B',uom: 'PCS', onhand: 18000, reserved: 4000, available: 14000, reorderPt: 2000, lastMovement: '2025-05-20' },
  { id: 'STK-006', itemCode: 'RM-HDPE-N',description:'HDPE Natural Pellets',plant:'FPP BU',location:'RM-SILO-01', uom: 'KG',  onhand: 18500, reserved: 5200, available: 13300, reorderPt: 2000, lastMovement: '2025-05-22' },
]
