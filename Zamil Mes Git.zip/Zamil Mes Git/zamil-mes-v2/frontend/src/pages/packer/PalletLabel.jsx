import { useState, useEffect, useMemo } from 'react'
import { useAuth } from '../../contexts/AuthContext'
import { useApp } from '../../contexts/AppContext'
import { packerService, productionService, setupService } from '../../services/api'
import useClock from '../../hooks/useClock'

const MAX_BOXES = 50
const BARCODE_HEIGHTS = [40,32,40,28,40,34,40,30,40,36,40,28,40,34,40]

const FALLBACK_DESTINATIONS = [
  'Cold Storage — Bay 04', 'Cold Storage — Bay 05',
  'Ambient — Rack A', 'Ambient — Rack B',
  'Dispatch — Zone 1', 'Dispatch — Zone 2',
]

// Build a unique key for a box slot (real or virtual)
const boxKey = (woId, num) => `${woId}:${num}`

export default function PalletLabel() {
  const { user } = useAuth()
  const { showToast } = useApp()
  const { date, time } = useClock()

  const [woGroups,   setWoGroups]   = useState([])  // [{wo, boxes:[]}]
  const [shifts,     setShifts]     = useState([])
  const [locations,  setLocations]  = useState([])
  const [history,    setHistory]    = useState([])
  const [loading,    setLoading]    = useState(true)
  const [saving,     setSaving]     = useState(false)

  // chosen is a Set of boxKey strings
  const [chosen,   setChosen]   = useState(new Set())
  const [packer,   setPacker]   = useState(user?.empId || user?.name || '')
  const [dest,     setDest]     = useState('')
  const [shift,    setShift]    = useState('')

  useEffect(() => { load() }, [])

  const load = async () => {
    setLoading(true)
    try {
      const [woRes, boxRes, sRes, lRes, pRes] = await Promise.all([
        productionService.getWorkOrders({ status: 'active', limit: 100 }),
        packerService.getBoxes({ limit: 500 }).catch(() => []),
        setupService.getShifts().catch(() => []),
        setupService.getLocations().catch(() => []),
        packerService.getPallets({}).catch(() => []),
      ])
      const rawWOs    = woRes?.data  ?? woRes  ?? []
      const rawBoxes  = boxRes?.data ?? boxRes ?? []
      const rawShifts = sRes?.data   ?? sRes   ?? []
      const rawLocs   = lRes?.data   ?? lRes   ?? []
      const rawPallets = pRes?.data  ?? pRes   ?? []

      // Build box groups per WO
      // For each WO, merge real API boxes with virtual stubs to fill up totalBoxes slots
      const groups = rawWOs.map(wo => {
        const woId = wo.id
        const total = parseInt(wo.totalBoxes || wo.boxes || 0, 10)
        const apiBoxes = rawBoxes.filter(b => b.woId === woId)

        // Build a slot map: boxNumber → box object (real or virtual)
        const slotMap = {}
        apiBoxes.forEach(b => {
          const n = parseInt(b.boxNumber, 10) || 0
          if (n > 0) slotMap[n] = { ...b, virtual: false, key: boxKey(woId, n) }
        })

        // Fill remaining slots with virtual stubs
        const count = Math.max(total, apiBoxes.length, 1)
        const boxes = []
        for (let n = 1; n <= count; n++) {
          if (slotMap[n]) {
            boxes.push(slotMap[n])
          } else {
            boxes.push({
              id: null,
              virtual: true,
              key: boxKey(woId, n),
              woId,
              woNumber: wo.woNumber,
              boxNumber: n,
              product:  wo.product,
              productCode: wo.productCode || wo.itemCode || '—',
              qcStatus: 'appr',   // virtual = assumed approved
              status:   'pending',
            })
          }
        }
        // Only show non-palletized boxes
        const available = boxes.filter(b => b.status !== 'palletized' && b.status !== 'packed')
        return { wo, boxes: available }
      }).filter(g => g.boxes.length > 0)

      setWoGroups(groups)
      setShifts(rawShifts)
      setLocations(rawLocs)
      setHistory(rawPallets.slice(0, 20))

      if (rawShifts.length) setShift(rawShifts[0].name || rawShifts[0])
      const destOpts = rawLocs.length ? rawLocs.map(l => l.name) : FALLBACK_DESTINATIONS
      if (destOpts.length) setDest(destOpts[0])
    } catch (_) {}
    finally { setLoading(false) }
  }

  const toggleBox = (box) => {
    setChosen(prev => {
      const next = new Set(prev)
      if (next.has(box.key)) {
        next.delete(box.key)
      } else {
        if (next.size >= MAX_BOXES) { showToast(`Max ${MAX_BOXES} boxes per pallet`, 'warning'); return prev }
        next.add(box.key)
      }
      return next
    })
  }

  const selectAllGroup = (woId) => {
    const group = woGroups.find(g => g.wo.id === woId)
    if (!group) return
    setChosen(prev => {
      const next = new Set(prev)
      for (const b of group.boxes) {
        if (next.size >= MAX_BOXES) break
        next.add(b.key)
      }
      return next
    })
  }

  const autoArrange = () => {
    const keys = []
    for (const g of woGroups) {
      for (const b of g.boxes) {
        if (keys.length >= MAX_BOXES) break
        keys.push(b.key)
      }
      if (keys.length >= MAX_BOXES) break
    }
    setChosen(new Set(keys))
  }

  const clearPallet = () => setChosen(new Set())

  const confirmPack = async () => {
    if (!chosen.size) { showToast('Add boxes to the pallet first', 'warning'); return }
    setSaving(true)
    try {
      const palletRes = await packerService.createPallet({
        notes: `Destination: ${dest} | Shift: ${shift} | Packer: ${packer}`,
      })
      const pallet = palletRes?.data ?? palletRes

      // Add real (non-virtual) boxes to the pallet via API
      const allChosen = woGroups.flatMap(g => g.boxes.filter(b => chosen.has(b.key)))
      const realBoxes = allChosen.filter(b => !b.virtual && b.id)
      await Promise.all(realBoxes.map(b =>
        packerService.addBoxToPallet(pallet.id, { boxId: b.id })
      ))
      await packerService.finalizePallet(pallet.id)

      // Mark virtual boxes as packed locally
      setWoGroups(prev => prev.map(g => ({
        ...g,
        boxes: g.boxes.filter(b => !chosen.has(b.key))
      })).filter(g => g.boxes.length > 0))

      setChosen(new Set())
      setHistory(prev => [{
        ...pallet,
        boxCount: chosen.size,
        dest,
        _time: new Date().toLocaleTimeString()
      }, ...prev])
      showToast(`📦 ${pallet.palletNumber || 'Pallet'} confirmed — ${chosen.size} boxes`, 'success')
    } catch (err) {
      showToast(err?.message || 'Failed to create pallet', 'error')
    }
    setSaving(false)
  }

  // Flatten chosen boxes for the label preview
  const chosenBoxes = woGroups.flatMap(g => g.boxes.filter(b => chosen.has(b.key)))
  const uniqueWOs   = [...new Set(chosenBoxes.map(b => b.woNumber || b.woId))].length
  const palletFill  = Math.round(chosen.size * 100 / MAX_BOXES)

  // 10×5 grid
  const grid = useMemo(() => {
    const cells = Array(50).fill(null)
    chosenBoxes.forEach((b, i) => { if (i < 50) cells[i] = b })
    return cells
  }, [chosenBoxes])

  const labelProducts = [...new Set(chosenBoxes.map(b => b.woNumber || b.woId).filter(Boolean))]
  const destOptions   = locations.length ? locations.map(l => l.name || l.code) : FALLBACK_DESTINATIONS
  const shiftOptions  = shifts.length ? shifts.map(s => s.name) : ['Day Shift 06:30–18:30', 'Night Shift 18:30–06:30']
  const totalAvail    = woGroups.reduce((s, g) => s + g.boxes.length, 0)

  return (
    <div>
      {/* Breadcrumb */}
      <div className="bc">
        <div className="bci"><div className="bcn done">✓</div>View Approved</div><div className="bcs">›</div>
        <div className="bci cur"><div className="bcn act">2</div>Select Boxes</div><div className="bcs">›</div>
        <div className="bci cur"><div className="bcn act">3</div>Build Pallet</div><div className="bcs">›</div>
        <div className="bci"><div className="bcn pend">4</div>Print &amp; Move</div>
      </div>

      <div className="lay3">

        {/* ── LEFT: Box Pool grouped by WO ── */}
        <div style={{background:'var(--bg2)',borderRight:'1px solid var(--bor)',display:'flex',flexDirection:'column',overflow:'hidden'}}>
          <div className="pphdr">
            <div className="pphdr-t"><div className="pphdd" style={{background:'var(--grn)'}}/>Approved Box Pool</div>
            <span style={{fontSize:'10px',color:'var(--tx3)'}}>{totalAvail - chosen.size} available</span>
          </div>
          <div className="pbody2" style={{padding:'8px'}}>
            {loading && <div style={{fontSize:'11px',color:'var(--tx3)',padding:'10px'}}>Loading boxes…</div>}
            {!loading && woGroups.length === 0 && (
              <div style={{fontSize:'11px',color:'var(--tx3)',padding:'10px',textAlign:'center'}}>
                No active work orders with boxes found.
              </div>
            )}
            {woGroups.map(({ wo, boxes }) => (
              <div key={wo.id} style={{marginBottom:'13px'}}>
                {/* WO group header */}
                <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'7px 10px',background:'var(--bg3)',borderRadius:'8px 8px 0 0',border:'1px solid var(--bor)'}}>
                  <div>
                    <div style={{fontFamily:"'Space Mono',monospace",fontSize:'11px',color:'var(--blu)',fontWeight:700}}>{wo.woNumber}</div>
                    <div style={{fontSize:'10px',color:'var(--tx3)',marginTop:'1px'}}>{(wo.product || '').split('–')[0].trim().slice(0, 40)}</div>
                  </div>
                  <button
                    className="btn bgh bsm"
                    onClick={() => selectAllGroup(wo.id)}
                    style={{fontSize:'10px',padding:'3px 9px'}}>
                    Select All
                  </button>
                </div>
                {/* Box chips */}
                <div style={{background:'var(--bg4)',border:'1px solid var(--bor)',borderTop:'none',borderRadius:'0 0 8px 8px',padding:'8px',display:'flex',flexWrap:'wrap',gap:'5px'}}>
                  {boxes.map(box => {
                    const isChosen = chosen.has(box.key)
                    return (
                      <div
                        key={box.key}
                        onClick={() => toggleBox(box)}
                        title={`${box.woNumber} · Box B${box.boxNumber}`}
                        style={{
                          width:'40px',height:'40px',borderRadius:'8px',
                          display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',
                          gap:'2px',cursor:'pointer',position:'relative',transition:'.12s',
                          border: isChosen ? '1.5px solid var(--amb)' : '1.5px solid var(--grn)',
                          background: isChosen ? 'var(--amb2)' : 'var(--grn3)',
                          boxShadow: isChosen ? '0 0 0 2px var(--amb3)' : 'none',
                        }}>
                        <div style={{
                          position:'absolute',top:'4px',right:'4px',
                          width:'7px',height:'7px',borderRadius:'50%',
                          background: isChosen ? 'var(--amb)' : 'var(--grn)',
                        }}/>
                        <div style={{fontFamily:"'Space Mono',monospace",fontSize:'10px',fontWeight:700,color: isChosen ? 'var(--amb)' : 'var(--grn)'}}>
                          B{box.boxNumber}
                        </div>
                        <div style={{fontSize:'8px',color: isChosen ? 'var(--amb2)' : 'var(--grn2)'}}>
                          {isChosen ? 'On Pallet' : 'Available'}
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ── MIDDLE: Pallet Builder ── */}
        <div className="mpanel">
          <div className="pphdr">
            <div className="pphdr-t">
              <div className="pphdd" style={{background:'var(--ora)'}}/>
              Pallet Builder &nbsp;·&nbsp;
              <span style={{color:'var(--amb)',fontFamily:"'Space Mono',monospace"}}>
                {history[0]?.palletNumber || 'PLT-NEW'}
              </span>
            </div>
            <div style={{display:'flex',gap:'7px'}}>
              <button className="btn bgh bsm" onClick={clearPallet}>Clear Pallet</button>
              <button className="btn bamb bsm" onClick={autoArrange}>Auto-Arrange</button>
            </div>
          </div>

          <div className="pkbody">
            {/* 4-stat summary */}
            <div className="ps4">
              <div className="ps4c"><div className="ps4v" style={{color:'var(--amb)'}}>{chosen.size}</div><div className="ps4l">Selected</div></div>
              <div className="ps4c"><div className="ps4v" style={{color:'var(--grn)'}}>{uniqueWOs}</div><div className="ps4l">Work Orders</div></div>
              <div className="ps4c"><div className="ps4v" style={{color:'var(--tel)'}}>{palletFill}%</div><div className="ps4l">Pallet Fill</div></div>
              <div className="ps4c"><div className="ps4v" style={{color:'var(--pur)'}}>{MAX_BOXES - chosen.size}</div><div className="ps4l">Slots Free</div></div>
            </div>

            {/* 10×5 Grid */}
            <div style={{background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'var(--rl)',padding:'15px',marginBottom:'15px'}}>
              <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:'12px'}}>
                <div className="st"><div className="sd" style={{background:'var(--ora)'}}/>Pallet Layout (10 × 5)</div>
                <div style={{fontSize:'11px',color:'var(--tx3)'}}>{chosen.size} of {MAX_BOXES} filled</div>
              </div>
              <div className="pgrid">
                {grid.map((box, i) => (
                  <div key={i}
                    className={`pslot ${box ? 'fil' : 'emp'}`}
                    onClick={() => box && toggleBox(box)}
                    title={box ? `B${box.boxNumber} — ${box.woNumber || box.woId}` : 'Empty slot'}>
                    {box ? `B${box.boxNumber}` : ''}
                  </div>
                ))}
              </div>
              <div style={{display:'flex',gap:'12px',fontSize:'10px',color:'var(--tx3)',marginTop:'8px'}}>
                <span style={{display:'flex',alignItems:'center',gap:'4px'}}>
                  <span style={{width:'11px',height:'11px',borderRadius:'3px',background:'var(--amb2)',border:'1px solid var(--amb)',display:'inline-block'}}/>Filled
                </span>
                <span style={{display:'flex',alignItems:'center',gap:'4px'}}>
                  <span style={{width:'11px',height:'11px',borderRadius:'3px',background:'var(--bg3)',border:'1px dashed var(--bor2)',display:'inline-block'}}/>Empty (click box to remove)
                </span>
              </div>
            </div>

            {/* Pallet Details Form */}
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'9px',marginBottom:'14px'}}>
              <div className="pdr">
                <div className="pdl2">Packer Name / ID</div>
                <input type="text" value={packer} onChange={e => setPacker(e.target.value)}
                  style={{fontSize:'12px',padding:'5px 9px',marginTop:'2px'}}/>
              </div>
              <div className="pdr">
                <div className="pdl2">Destination</div>
                <select value={dest} onChange={e => setDest(e.target.value)}
                  style={{padding:'5px 9px',marginTop:'2px',fontSize:'12px'}}>
                  {destOptions.map(d => <option key={d} value={d}>{d}</option>)}
                </select>
              </div>
              <div className="pdr">
                <div className="pdl2">Shift</div>
                <select value={shift} onChange={e => setShift(e.target.value)}
                  style={{padding:'5px 9px',marginTop:'2px',fontSize:'12px'}}>
                  {shiftOptions.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
            </div>

            <div style={{display:'flex',gap:'9px',marginBottom:'15px'}}>
              <button
                className="btn bamb"
                style={{flex:1,justifyContent:'center',fontSize:'13px',fontWeight:600,opacity: saving ? 0.6 : 1}}
                onClick={confirmPack}
                disabled={saving}>
                {saving ? '⏳ Saving…' : '📦 Confirm Pack & Generate Label'}
              </button>
              <button className="btn bgh" onClick={clearPallet}>Reset</button>
            </div>

            {/* Pallet History */}
            <div className="pack-hist">
              <div className="ph2t"><div className="sd" style={{background:'var(--blu)'}}/>Pallet History — Today</div>
              {history.length === 0 ? (
                <div style={{fontSize:'11px',color:'var(--tx3)',padding:'8px 0'}}>No pallets packed yet today.</div>
              ) : history.map((p, i) => (
                <div key={p.id || i} style={{display:'flex',alignItems:'center',justifyContent:'space-between',
                  padding:'6px 0',borderBottom:'1px solid var(--bor)',fontSize:'12px'}}>
                  <div>
                    <span className="woid" style={{fontSize:'11px'}}>{p.palletNumber}</span>
                    <span style={{color:'var(--tx3)',marginLeft:'8px',fontSize:'10px'}}>{p.boxCount} boxes</span>
                  </div>
                  <span style={{color:'var(--tx3)',fontFamily:"'Space Mono',monospace",fontSize:'10px'}}>
                    {p._time || (p.createdAt ? new Date(p.createdAt).toLocaleTimeString() : '—')}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* ── RIGHT: Label Preview ── */}
        <div className="rppanel">
          <div className="pphdr">
            <div className="pphdr-t"><div className="pphdd" style={{background:'var(--blu)'}}/>Pallet Label Preview</div>
            <span className={`bdg ${chosen.size > 0 ? 'bd' : 'bp'}`}>
              {chosen.size > 0 ? 'Ready' : 'Select boxes first'}
            </span>
          </div>
          <div className="rbody">
            {/* Label Preview Card */}
            <div className="lprev">
              <div className="lph">
                <div className="lpbrand">ZAMIL OPS</div>
                <span className="bdg bp">Pallet Label</span>
              </div>
              <div className="lbody">
                <div className="lpid">
                  <div style={{fontSize:'9px',textTransform:'uppercase',letterSpacing:'1.5px',color:'var(--tx3)',marginBottom:'3px'}}>Pallet ID</div>
                  <div className="lpid-v">{history[0]?.palletNumber || 'PLT-PENDING'}</div>
                </div>

                <div style={{display:'flex',gap:'12px',marginBottom:'11px'}}>
                  {/* Barcode */}
                  <div style={{width:'80px',background:'var(--bg3)',border:'1px solid var(--bor)',borderRadius:'7px',
                    padding:'9px 6px',flexShrink:0,display:'flex',flexDirection:'column',alignItems:'center',gap:'4px'}}>
                    <div className="bcbar" style={{height:'42px',gap:'1px',margin:0}}>
                      {BARCODE_HEIGHTS.map((h, i) => (
                        <div key={i} className="bcl" style={{height:`${h}px`,width: i%4===2?'3px':'2px'}}/>
                      ))}
                    </div>
                    <div style={{fontFamily:"'Space Mono',monospace",fontSize:'8px',color:'var(--tx3)'}}>
                      {(history[0]?.palletNumber || 'PLT-NEW').replace('PLT-','').slice(0,10)}
                    </div>
                  </div>

                  {/* Label rows */}
                  <div style={{flex:1}}>
                    <div className="lrow"><div className="ll">Date</div><div className="lv lvm">{date || '—'}</div></div>
                    <div className="lrow"><div className="ll">Time</div><div className="lv lvm">{time ? time.slice(0,8) : '—'}</div></div>
                    <div className="lrow"><div className="ll">Packer</div><div className="lv lvm">{packer || '—'}</div></div>
                    <div className="lrow"><div className="ll">Shift</div><div className="lv">{shift ? shift.split(' ')[0] : '—'}</div></div>
                    <div className="lrow"><div className="ll">Total Boxes</div><div className="lv lvb">{chosen.size}</div></div>
                  </div>
                </div>

                <div className="ldiv"/>

                <div style={{marginBottom:'10px'}}>
                  <div style={{fontSize:'9px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',marginBottom:'6px'}}>
                    Products on Pallet
                  </div>
                  {labelProducts.length === 0
                    ? <div style={{fontSize:'11px',color:'var(--tx3)'}}>No boxes selected yet.</div>
                    : labelProducts.map(wo => (
                      <div key={wo} style={{fontSize:'11px',color:'var(--tx)',marginBottom:'3px'}}>• {wo}</div>
                    ))
                  }
                </div>

                <div style={{fontSize:'9px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',marginBottom:'6px'}}>
                  Box Numbers
                </div>
                <div className="lchips">
                  {chosenBoxes.length === 0
                    ? <span style={{fontSize:'11px',color:'var(--tx3)'}}>—</span>
                    : chosenBoxes.map(b => (
                      <span key={b.key} className="bdg bp" style={{fontSize:'9px',fontFamily:"'Space Mono',monospace"}}>
                        B{b.boxNumber}
                      </span>
                    ))
                  }
                </div>

                <div className="ldiv"/>

                <div style={{display:'flex',alignItems:'center',gap:'12px'}}>
                  <div style={{
                    width:'58px',height:'58px',background:'var(--bg3)',border:'1px solid var(--bor)',
                    borderRadius:'7px',display:'grid',gridTemplateColumns:'repeat(3,1fr)',padding:'6px',gap:'3px',flexShrink:0
                  }}>
                    {Array.from({length:9},(_,i)=>(
                      <div key={i} style={{background:i!==4?'var(--tx2)':'transparent',borderRadius:'2px'}}/>
                    ))}
                  </div>
                  <div>
                    <div style={{fontSize:'9px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',marginBottom:'4px'}}>Destination</div>
                    <div style={{fontSize:'13px',fontWeight:600,color:'var(--tx)'}}>{dest || '—'}</div>
                    <div style={{fontSize:'10px',color:'var(--tx3)',marginTop:'2px'}}>Scan QR for manifest</div>
                  </div>
                </div>
              </div>
              <div className="lpft">
                <span>Zamil Operations · FPP BU</span>
                <span>QC Verified · {date || '—'}</span>
              </div>
            </div>

            {/* Action buttons */}
            <div className="lacts">
              <button className="la-btn la-print" onClick={() => window.print()}>🖨 Print Pallet Label</button>
              <button className="la-btn la-dl" onClick={() => showToast(`📥 PDF downloaded`, 'success')}>↓ Download PDF Label</button>
              <button className="la-btn la-save" onClick={() => showToast('🔖 Label saved to records', 'success')}>🔖 Save to Records</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
