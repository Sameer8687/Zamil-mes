import { useState, useEffect } from 'react'
import { useAuth } from '../../contexts/AuthContext'
import { useApp } from '../../contexts/AppContext'
import { productionService, packerService } from '../../services/api'

export default function PackerOverview() {
  const { user } = useAuth()
  const { showToast, goScreen } = useApp()

  const [wos,        setWos]        = useState([])
  const [boxes,      setBoxes]      = useState([])
  const [loading,    setLoading]    = useState(true)
  const [movedCount, setMovedCount] = useState(0)

  useEffect(() => { load() }, [])

  const load = async () => {
    setLoading(true)
    try {
      const [wRes, bRes] = await Promise.all([
        productionService.getWorkOrders({ status: 'active', limit: 50 }),
        packerService.getBoxes({ limit: 500 }),
      ])
      setWos(wRes?.data ?? wRes ?? [])
      setBoxes(bRes?.data ?? bRes ?? [])
    } catch (_) {}
    finally { setLoading(false) }
  }

  const moveBoxes = async (woId, type) => {
    const woBoxes = boxes.filter(b => b.woId === woId)
    const targets = type === 'appr'
      ? woBoxes.filter(b => b.qcStatus === 'appr' && b.status !== 'packed')
      : woBoxes.filter(b => b.qcStatus === 'rejt')

    if (!targets.length) {
      showToast(type === 'appr' ? 'No approved boxes to move' : 'No rejected boxes to return', 'warning')
      return
    }
    const n = targets.length

    if (type === 'appr') {
      try { await Promise.all(targets.map(b => packerService.updateBox(b.id, { status: 'packed' }))) } catch (_) {}
      setBoxes(prev => prev.map(b => targets.find(t => t.id === b.id) ? { ...b, status: 'packed' } : b))
      setMovedCount(c => c + n)
      showToast(`${n} approved box${n > 1 ? 'es' : ''} moved to storage`, 'success')
    } else {
      try { await Promise.all(targets.map(b => packerService.updateBox(b.id, { qcStatus: 'pend' }))) } catch (_) {}
      setBoxes(prev => prev.map(b => targets.find(t => t.id === b.id) ? { ...b, qcStatus: 'pend' } : b))
      setMovedCount(c => c + n)
      showToast(`${n} rejected box${n > 1 ? 'es' : ''} returned to line`, 'warning')
    }
  }

  const woData = wos.map(wo => {
    const woBoxes = boxes.filter(b => b.woId === wo.id)
    const approved = woBoxes.filter(b => b.qcStatus === 'appr' && b.status !== 'packed')
    const rejected = woBoxes.filter(b => b.qcStatus === 'rejt')
    return { ...wo, woBoxes, approved, rejected, boxCount: woBoxes.length }
  })

  const totalApproved = woData.reduce((s, w) => s + w.approved.length, 0)
  const totalRejected = woData.reduce((s, w) => s + w.rejected.length, 0)
  const totalPending  = boxes.filter(b => !b.qcStatus || b.qcStatus === 'pend').length

  const initials = (user?.fullName || user?.name || 'PK').split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase()

  return (
    <div className="content">

      {/* Identity Strip */}
      <div className="strip">
        <div className="av" style={{background:'var(--amb2)',borderColor:'var(--amb)',color:'var(--amb)'}}>
          {initials || 'PK'}
        </div>
        <div style={{flex:1}}>
          <div className="oname">{(user?.fullName || user?.name || 'Packer Station').toUpperCase()}</div>
          <div className="ometa">FPP BU &nbsp;·&nbsp; All Machines &nbsp;·&nbsp; Box Movement View</div>
        </div>
        <div className="cstatus" style={{background:'var(--amb2)',borderColor:'var(--amb)',color:'var(--amb)'}}>
          <div className="cdot" style={{background:'var(--amb)'}}/>Ready for Movement
        </div>
      </div>

      {/* Summary Row — 4 pills */}
      <div className="sumrow">
        <div className="sp">
          <div className="spic" style={{background:'var(--grn2)'}}>✓</div>
          <div>
            <div className="spv" style={{color:'var(--grn)'}}>{totalApproved}</div>
            <div className="spl">Approved Boxes</div>
          </div>
        </div>
        <div className="sp">
          <div className="spic" style={{background:'var(--red2)'}}>✕</div>
          <div>
            <div className="spv" style={{color:'var(--red)'}}>{totalRejected}</div>
            <div className="spl">Rejected Boxes</div>
          </div>
        </div>
        <div className="sp">
          <div className="spic" style={{background:'var(--amb2)'}}>⏳</div>
          <div>
            <div className="spv" style={{color:'var(--amb)'}}>{totalPending}</div>
            <div className="spl">Awaiting QC</div>
          </div>
        </div>
        <div className="sp">
          <div className="spic" style={{background:'var(--blu2)'}}>↗</div>
          <div>
            <div className="spv" style={{color:'var(--blu)'}}>{movedCount}</div>
            <div className="spl">Boxes Moved</div>
          </div>
        </div>
      </div>

      {loading && <div style={{textAlign:'center',padding:'32px',color:'var(--tx3)',fontSize:'13px'}}>Loading work orders…</div>}

      {!loading && woData.length === 0 && (
        <div style={{textAlign:'center',padding:'32px',color:'var(--tx3)',fontSize:'13px'}}>
          No active work orders found.
        </div>
      )}

      {/* Packer Movement Cards — one per WO */}
      {!loading && woData.map(wo => (
        <div key={wo.id} className="mcard" style={{marginBottom:'12px'}}>
          <div style={{display:'flex',alignItems:'flex-start',justifyContent:'space-between',marginBottom:'12px'}}>
            <div>
              <div style={{display:'flex',alignItems:'center',gap:'8px'}}>
                <span className="woid" style={{fontSize:'13px'}}>{wo.woNumber}</span>
                {wo.approved.length > 0 && <span className="bdg bd">{wo.approved.length} Approved</span>}
                {wo.rejected.length > 0 && <span className="bdg brj">{wo.rejected.length} Rejected</span>}
              </div>
              <div style={{fontSize:'11px',color:'var(--tx3)',marginTop:'3px'}}>
                {wo.product} · {wo.boxCount} Total Boxes
              </div>
            </div>
          </div>

          <div className="mgrid">
            {/* Approved section */}
            <div className="ms">
              <div className="mstit" style={{color:'var(--grn)'}}>
                <div className="msq" style={{background:'var(--grn)'}}/>
                Approved – Ready to Move
              </div>
              <div>
                {wo.approved.length === 0
                  ? <span style={{fontSize:'11px',color:'var(--tx3)'}}>No approved boxes yet</span>
                  : wo.approved.map(b => (
                    <span key={b.id} className="btag btap">B{b.boxNumber}</span>
                  ))
                }
              </div>
              <div style={{marginTop:'9px',display:'flex',gap:'6px'}}>
                <button className="btn bsuc bsm" onClick={() => moveBoxes(wo.id, 'appr')}>
                  Move to Storage
                </button>
              </div>
            </div>

            {/* Rejected section */}
            <div className="ms">
              <div className="mstit" style={{color:'var(--red)'}}>
                <div className="msq" style={{background:'var(--red)'}}/>
                Rejected – Return to Line
              </div>
              <div>
                {wo.rejected.length === 0
                  ? <span style={{fontSize:'11px',color:'var(--tx3)'}}>No rejected boxes</span>
                  : wo.rejected.map(b => (
                    <span key={b.id} className="btag btar">B{b.boxNumber}</span>
                  ))
                }
              </div>
              <div style={{marginTop:'9px',display:'flex',gap:'6px'}}>
                <button className="btn bdan bsm" onClick={() => moveBoxes(wo.id, 'rejt')}>
                  Return to Line
                </button>
              </div>
            </div>
          </div>
        </div>
      ))}

      {/* Footer action */}
      <div className="sh" style={{marginTop:'8px'}}>
        <div className="st">
          <div className="sd" style={{background:'var(--blu)'}}/>
          Ready when QC approves boxes — go to Pallet + Label screen to build pallets
        </div>
        <button className="btn bpri" onClick={() => goScreen('pallet')}>Build Pallet →</button>
      </div>
    </div>
  )
}
