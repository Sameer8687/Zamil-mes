import { useState, useEffect, useMemo } from 'react'
import { useMutation } from '../../hooks/useApi'
import { lcService, setupService } from '../../services/api'
import { useApp } from '../../contexts/AppContext'
import { useAuth } from '../../contexts/AuthContext'

const LC_HYGIENE = [
  {sno:1,  en:'Excess scrap cleaned up from surrounding area',            ar:'المنتجات التالفة تم إزالتها من محيط الماكنة',                         resp:'Process Technician'},
  {sno:2,  en:'Old labels removed / cleared from machine',                ar:'الليبل القديم تم ازالته من الماكنه و ما حولها',                      resp:'Process Technician'},
  {sno:3,  en:'All previous molded part removed out from the surrounding area', ar:'المنتجات الجاهزة من التي تم تشغيلها مسبقا تم إزالتها',       resp:'Process Technician'},
  {sno:4,  en:'No oil & water leakage',                                   ar:'لا وجود لزيوت او مياه',                                              resp:'Process Technician'},
  {sno:5,  en:"Excess check labels / tag discarded by QC",                ar:'بطاقة التعريف للمنتج السابق تم إتلافها من قبل الجودة',               resp:'QC Inspector'},
  {sno:6,  en:'All previous packaging removed',                           ar:'مواد التغليف للمنتج السابق تم إزالتها',                              resp:'Process Technician'},
  {sno:7,  en:'Conveyor / stacking table cleaned and sanitized',          ar:'طاولة و سير التجميع تم تنظيفه و تعقيمه',                           resp:'QC Inspector / Packer'},
  {sno:8,  en:'Mold cleaned and sanitized',                               ar:'القالب تم تنظيفه و تعقيمه',                                         resp:'Process Technician'},
  {sno:9,  en:'Robot dummy cleaned / sanitized',                          ar:'الروبوت تم تنظيفه و تعقيمه',                                        resp:'Process Technician'},
  {sno:10, en:'No foreign bodies (screw, washer, etc.)',                  ar:'لا وجود لاجسام غريبة على الماكنة (براغي، صواميل، الخ)',             resp:'QC Inspector / Packer'},
]
const LC_OPS = [
  {sno:11, en:'New packaging prepared',                                   ar:'تم التأكد من مواد التغليف للمنتج المراد تشغيله و تحضيرها',         resp:'Process Technician'},
  {sno:12, en:'New label fixed on the magazine',                          ar:'تم تحضير الليبل للمنتج المراد تشغيله في مكانه و التأكد منه',      resp:'Process Technician'},
  {sno:13, en:'Vision system works fine without any issue',               ar:'نظام الكامرة يعمل بون مشاكل',                                       resp:'Process Technician', specialYesNA:true},
  {sno:14, en:'Packing instruction in place',                             ar:'تم تزويد عمال الانتاج بتعليمات التعبئة و التغليف',                 resp:'Process Technician'},
  {sno:15, en:'QC checked the check_ specification',                      ar:'تم التأكد من مواصفات المنتج النهائي من قبل الجودة',                resp:'QC Inspector'},
  {sno:16, en:'QC provided packers with defect types and needed information', ar:'تم تزويد عمال الانتاج بالمعلومات اللازمة عن المنتج و انواع العيوب', resp:'Process Technician'},
  {sno:17, en:'Inspection of 5 continuous shots visually',                ar:'تم فحص 5 دفعات متواصلة من المنتج',                                 resp:'QC Inspector'},
  {sno:18, en:'Air, Water, Heater cables are properly fixed and connected', ar:'يتم إصلاح الهواء والماء، وكابلات سخان بشكل صحيح ومتصلة',       resp:'Process Technician'},
]
const LC_MOLD = [
  {sno:19, en:'Mold polished and previous material is purged (if required)', ar:'ازالة المتبقي من المواد من نظام الحقن و صقل القالب في حال الحاجة', resp:'Process Technician / TR'},
  {sno:20, en:'Mold setup is perfect and inspect the mold holder',        ar:'إعداد القالب مثالي',                                                resp:'Process Technician'},
  {sno:21, en:'Correct mold hoses connection',                            ar:'اتصال خرطوم القالب الصحيح',                                        resp:'Process Technician'},
  {sno:22, en:'Machine logbook updated',                                  ar:'سجل الآلة محدث',                                                    resp:'Process Technician'},
  {sno:23, en:'Machine has been clean from oil and grease',               ar:'تم تنظيف الماكنة من بقايا الزيت والشحم',                          resp:'Process Technician / QC'},
]
const ALL_ITEMS = [...LC_HYGIENE, ...LC_OPS, ...LC_MOLD]

export default function LineClearance() {
  const { showToast, goScreen } = useApp()
  const { user, machine } = useAuth()

  const [machines, setMachines] = useState([])
  const [shifts,   setShifts]   = useState([])

  useEffect(() => {
    setupService.getMachines().then(r => setMachines(r?.data ?? r ?? [])).catch(() => setMachines([]))
    setupService.getShifts().then(r => setShifts(r?.data ?? r ?? [])).catch(() => setShifts([]))
  }, [])

  const initChecks = useMemo(() => {
    const r = {}
    ALL_ITEMS.forEach(i => { r[i.sno] = { product: false, quality: false } })
    return r
  }, [])

  const [form, setForm] = useState({
    plant: 'FPP BU',
    machine: machine?.code || '',
    clearanceType: 'Changing Mold',
    jobOrder: '',
    submissionDate: new Date().toISOString().slice(0,10),
    productCode: '',
    productName: '',
    submissionShift: '',
    submissionTime: '',
    reqNo: `LC-2026-${String(Date.now()).slice(-4)}`,
    techName: user?.fullName || user?.name || '',
    qiName: '',
    comment: '',
  })
  const [checks,  setChecks]  = useState(initChecks)
  const [status,  setStatus]  = useState('Draft')
  const [error,   setError]   = useState('')
  const setF = (k, v) => setForm(f => ({...f, [k]: v}))

  const checkItem = (sno, type) => setChecks(c => ({...c, [sno]: {...c[sno], [type]: !c[sno][type]}}))

  const bulkCheck = (section, type) => {
    const items = section === 'hygiene' ? LC_HYGIENE : section === 'operations' ? LC_OPS : LC_MOLD
    setChecks(c => {
      const n = {...c}
      items.forEach(i => {
        n[i.sno] = {...n[i.sno]}
        if (type === 'both' || type === 'product') n[i.sno].product = true
        if (type === 'both' || type === 'quality') n[i.sno].quality = true
      })
      return n
    })
  }

  const done  = ALL_ITEMS.filter(i => checks[i.sno]?.product && checks[i.sno]?.quality).length
  const total = ALL_ITEMS.length
  const pending = total - done
  const pct   = Math.round(done * 100 / total)

  const { mutate: save, loading } = useMutation(
    () => lcService.create({ ...form, checks, status: 'submitted', totalItems: total, completedItems: done }),
    { onSuccess: () => { showToast('Line Clearance submitted', 'success'); goScreen('lc-report') } }
  )

  const handleSubmit = (submitStatus) => {
    if (submitStatus !== 'Draft' && done < total) {
      setError(`Complete all ${total} checklist items (${done}/${total} done)`)
      return
    }
    setError('')
    setStatus(submitStatus)
    try { save() } catch (_) {}
    showToast(`LC ${submitStatus}`, 'success')
    if (submitStatus === 'Approved') goScreen('lc-report')
  }

  return (
    <div>
      {/* Green Header Bar */}
      <div style={{background:'var(--grn)',padding:'13px 28px',display:'flex',alignItems:'center',gap:'28px'}}>
        <div style={{display:'flex',alignItems:'center',gap:'12px'}}>
          <div style={{background:'#fff',padding:'4px 8px',borderRadius:'6px',fontSize:'11px',fontWeight:800,
            color:'var(--grn)',fontFamily:"'Space Mono',monospace"}}>
            Zamil<span style={{color:'var(--amb)'}}>✓</span>
          </div>
          <div style={{fontSize:'17px',fontWeight:700,color:'#fff',fontFamily:"'Space Mono',monospace",letterSpacing:'.3px'}}>
            LINE CLEARANCE &amp; RELEASE (FOOD)
          </div>
        </div>
        <div style={{display:'flex',gap:'14px',marginLeft:'16px'}}>
          <button className="btn bgh bsm" onClick={() => goScreen('operator')} style={{color:'#fff',borderColor:'rgba(255,255,255,.4)',background:'rgba(255,255,255,.15)'}}>🏠 Home</button>
          <button className="btn bgh bsm" onClick={() => goScreen('lc-report')} style={{color:'#fff',borderColor:'rgba(255,255,255,.4)',background:'rgba(255,255,255,.15)'}}>≡ LC Report</button>
          <button className="btn bgh bsm" style={{color:'#fff',borderColor:'rgba(255,255,255,.6)',background:'rgba(255,255,255,.35)',fontWeight:700,textDecoration:'underline'}}>≡ Form</button>
        </div>
      </div>

      <div style={{padding:'22px 30px'}}>

        {/* Header Info Card */}
        <div style={{background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'var(--rl)',padding:'22px 26px',marginBottom:'20px'}}>
          {/* Row 1: 4 cols */}
          <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:'14px',marginBottom:'16px'}}>
            <div>
              <label style={{color:'var(--tel)',fontWeight:700,fontSize:'11px',letterSpacing:'.5px'}}>Title</label>
              <div style={{fontSize:'12px',color:'var(--tx2)',marginTop:'3px',fontStyle:'italic'}}>Line Clearance Release (NonFood)</div>
            </div>
            <div>
              <label style={{color:'var(--tel)',fontWeight:700,fontSize:'11px'}}>Pages</label>
              <div style={{fontSize:'12px',color:'var(--tx2)',marginTop:'3px'}}>Page 1 of 1</div>
            </div>
            <div>
              <label style={{color:'var(--tel)',fontWeight:700,fontSize:'11px'}}>Plant</label>
              <select value={form.plant} onChange={e => setF('plant', e.target.value)}
                style={{marginTop:'4px',fontSize:'12px',padding:'5px 9px'}}>
                <option value="FPP BU">FPP BU</option>
                <option value="IPP BU">IPP BU</option>
                <option value="ZPC BU">ZPC BU</option>
              </select>
            </div>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'8px'}}>
              <div>
                <label style={{color:'var(--tel)',fontWeight:700,fontSize:'11px'}}>Control NBR.</label>
                <div style={{fontSize:'11px',color:'var(--tx3)',marginTop:'3px',fontFamily:"'Space Mono',monospace"}}>ZPI.QCD.FM.09</div>
              </div>
              <div>
                <label style={{color:'var(--tel)',fontWeight:700,fontSize:'11px'}}>Version</label>
                <div style={{fontSize:'11px',color:'var(--tx3)',marginTop:'3px',fontFamily:"'Space Mono',monospace"}}>1.8</div>
              </div>
            </div>
          </div>

          {/* Row 2: 4 cols */}
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr 1fr',gap:'14px',marginBottom:'14px'}}>
            <div>
              <label style={{color:'var(--tel)',fontWeight:700,fontSize:'11px'}}>Revision Date</label>
              <div style={{fontSize:'12px',color:'var(--tx2)',marginTop:'3px',fontFamily:"'Space Mono',monospace"}}>05-May-2026</div>
            </div>
            <div>
              <label style={{color:'var(--tel)',fontWeight:700,fontSize:'11px'}}>Machine</label>
              <select value={form.machine} onChange={e => setF('machine', e.target.value)}
                style={{marginTop:'4px',fontSize:'12px',padding:'5px 9px'}}>
                <option value="">Select Machine</option>
                {machines.map(m => (
                  <option key={m.id} value={m.machineId || m.name}>{m.machineId || m.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label style={{color:'var(--tel)',fontWeight:700,fontSize:'11px'}}>Clearance Type</label>
              <select value={form.clearanceType} onChange={e => setF('clearanceType', e.target.value)}
                style={{marginTop:'4px',fontSize:'12px',padding:'5px 9px'}}>
                {['Changing Mold','Product Change','Startup','End of Shift'].map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <div>
              <label style={{color:'var(--tel)',fontWeight:700,fontSize:'11px'}}>Status</label>
              <div style={{marginTop:'4px',display:'inline-flex',padding:'4px 14px',borderRadius:'20px',fontSize:'12px',fontWeight:700,
                background: status === 'Approved' ? 'var(--grn2)' : status === 'Draft' ? 'var(--amb2)' : 'var(--blu2)',
                border: `1px solid ${status === 'Approved' ? 'var(--grn)' : status === 'Draft' ? 'var(--amb)' : 'var(--blu)'}`,
                color: status === 'Approved' ? 'var(--grn)' : status === 'Draft' ? 'var(--amb)' : 'var(--blu)',
              }}>{status}</div>
            </div>
          </div>

          {/* Row 3: 4 cols */}
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr 1fr',gap:'14px'}}>
            <div>
              <label style={{color:'var(--tel)',fontWeight:700,fontSize:'11px'}}>Job Order No</label>
              <input type="text" value={form.jobOrder} onChange={e => setF('jobOrder', e.target.value)}
                placeholder="e.g. 4518870"
                style={{marginTop:'4px',fontSize:'12px',padding:'5px 9px',fontFamily:"'Space Mono',monospace"}}/>
            </div>
            <div>
              <label style={{color:'var(--tel)',fontWeight:700,fontSize:'11px'}}>Submission Date</label>
              <input type="date" value={form.submissionDate} onChange={e => setF('submissionDate', e.target.value)}
                style={{marginTop:'4px',fontSize:'12px',padding:'5px 9px'}}/>
            </div>
            <div>
              <label style={{color:'var(--tel)',fontWeight:700,fontSize:'11px'}}>Product Code</label>
              <input type="text" value={form.productCode} onChange={e => setF('productCode', e.target.value)}
                placeholder="e.g. FG9406"
                style={{marginTop:'4px',fontSize:'12px',padding:'5px 9px',fontFamily:"'Space Mono',monospace"}}/>
            </div>
            <div>
              <label style={{color:'var(--tel)',fontWeight:700,fontSize:'11px'}}>Product Name</label>
              <input type="text" value={form.productName} onChange={e => setF('productName', e.target.value)}
                placeholder="Auto-filled or type manually"
                style={{marginTop:'4px',fontSize:'12px',padding:'5px 9px'}}/>
            </div>
            <div>
              <label style={{color:'var(--tel)',fontWeight:700,fontSize:'11px'}}>Submission Shift</label>
              <select value={form.submissionShift} onChange={e => setF('submissionShift', e.target.value)}
                style={{marginTop:'4px',fontSize:'12px',padding:'5px 9px'}}>
                <option value="">Select</option>
                {(shifts.length
                  ? shifts.map(s => s.name)
                  : ['Day Shift', 'Night Shift', 'Morning', 'Evening']
                ).map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div>
              <label style={{color:'var(--tel)',fontWeight:700,fontSize:'11px'}}>Submission Time</label>
              <input type="time" value={form.submissionTime} onChange={e => setF('submissionTime', e.target.value)}
                style={{marginTop:'4px',fontSize:'12px',padding:'5px 9px'}}/>
            </div>
            <div>
              <label style={{color:'var(--tel)',fontWeight:700,fontSize:'11px'}}>Request No</label>
              <input type="text" value={form.reqNo} readOnly
                style={{marginTop:'4px',fontSize:'12px',padding:'5px 9px',fontFamily:"'Space Mono',monospace",opacity:.7}}/>
            </div>
            <div style={{display:'flex',alignItems:'flex-end'}}>
              <div style={{fontSize:'10px',color:'var(--tx3)',lineHeight:1.5}}>
                Control NBR: <b style={{color:'var(--tx)'}}>ZPI.QCD.FM.09</b><br/>
                Version <b style={{color:'var(--tx)'}}>1.8</b>
              </div>
            </div>
          </div>
        </div>

        {/* Hygiene Checklist */}
        <CheckSection title="🧹 Hygiene Criteria" items={LC_HYGIENE} checks={checks}
          onCheck={checkItem} onBulk={bulkCheck} section="hygiene" color="var(--grn)" />

        {/* Operations Checklist */}
        <CheckSection title="⚙️ Operations Criteria" items={LC_OPS} checks={checks}
          onCheck={checkItem} onBulk={bulkCheck} section="operations" color="var(--blu)" />

        {/* Mold Checklist */}
        <CheckSection title="🔧 Changing Mold Criteria" items={LC_MOLD} checks={checks}
          onCheck={checkItem} onBulk={bulkCheck} section="mold" color="var(--amb)" moldOnly />

        {/* Progress */}
        <div style={{background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'var(--rl)',padding:'16px 22px',marginBottom:'20px'}}>
          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:'10px'}}>
            <div style={{fontSize:'13px',fontWeight:600,color:'var(--tx)'}}>Completion Progress</div>
            <div style={{fontFamily:"'Space Mono',monospace",fontSize:'13px',fontWeight:700,color:'var(--grn)'}}>
              {done} / {total} items
            </div>
          </div>
          <div style={{height:'10px',background:'var(--bg3)',borderRadius:'10px',overflow:'hidden',marginBottom:'12px'}}>
            <div style={{height:'100%',width:`${pct}%`,background:'linear-gradient(90deg,var(--grn),var(--tel))',borderRadius:'10px',transition:'width .4s'}}/>
          </div>
          <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:'10px'}}>
            {[
              { val: done,    label: 'Checked',  bg: 'var(--grn3)', border: 'var(--grn)', color: 'var(--grn)' },
              { val: pending, label: 'Pending',  bg: 'var(--amb2)', border: 'var(--amb)', color: 'var(--amb)' },
              { val: 0,       label: 'N/A',      bg: 'var(--red2)', border: 'var(--red)', color: 'var(--red)' },
              { val: total,   label: 'Total',    bg: 'var(--blu2)', border: 'var(--blu)', color: 'var(--blu)' },
            ].map(s => (
              <div key={s.label} style={{textAlign:'center',background:s.bg,border:`1px solid ${s.border}`,borderRadius:'var(--r)',padding:'10px'}}>
                <div style={{fontFamily:"'Space Mono',monospace",fontSize:'18px',fontWeight:700,color:s.color}}>{s.val}</div>
                <div style={{fontSize:'10px',color:s.color,textTransform:'uppercase',letterSpacing:'.8px',marginTop:'2px'}}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Comment + Signatures */}
        <div style={{background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'var(--rl)',padding:'22px 26px',marginBottom:'20px'}}>
          <div style={{marginBottom:'18px'}}>
            <label style={{color:'var(--tel)',fontWeight:700,fontSize:'12px',letterSpacing:'.5px'}}>Comment</label>
            <textarea value={form.comment} onChange={e => setF('comment', e.target.value)}
              placeholder="Add comments or observations..."
              style={{marginTop:'6px',minHeight:'80px'}}/>
          </div>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'26px'}}>
            {[
              { nk: 'techName', label: 'Process Technician / Engineer Name', sigLabel: 'Process Technician / Engineer Name & Signature' },
              { nk: 'qiName',   label: 'QC Inspector Name',                   sigLabel: 'QC Inspector Name & Signature' },
            ].map(({ nk, label, sigLabel }) => (
              <div key={nk}>
                <label style={{color:'var(--tel)',fontWeight:700,fontSize:'12px'}}>{label}</label>
                <input type="text" value={form[nk]} onChange={e => setF(nk, e.target.value)}
                  placeholder="Full name" style={{marginTop:'6px'}}/>
                <div style={{marginTop:'14px'}}>
                  <label style={{color:'var(--tel)',fontWeight:700,fontSize:'12px'}}>Signature (type your name to sign)</label>
                  <div style={{marginTop:'6px',borderBottom:'2px solid var(--bor2)',minHeight:'36px',padding:'4px 8px',
                    fontFamily:'cursive',fontSize:'18px',color:'var(--tx2)',letterSpacing:'2px'}}>
                    {form[nk]}
                  </div>
                  <div style={{fontSize:'10px',color:'var(--tx3)',marginTop:'4px',textTransform:'uppercase',letterSpacing:'.8px'}}>
                    {sigLabel}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Error message */}
        {error && (
          <div style={{display:'block',background:'var(--red2)',border:'1px solid var(--red)',borderRadius:'var(--r)',
            padding:'11px 16px',color:'var(--red)',fontSize:'13px',marginBottom:'14px'}}>
            {error}
          </div>
        )}

        {/* Action buttons */}
        <div style={{display:'flex',gap:'12px',justifyContent:'center',paddingBottom:'30px'}}>
          <button style={{background:'var(--amb2)',border:'1.5px solid var(--amb)',color:'var(--amb)',fontSize:'14px',
            fontWeight:600,padding:'11px 30px',borderRadius:'9px',cursor:'pointer',fontFamily:"'DM Sans',sans-serif"}}
            onClick={() => handleSubmit('Draft')}>
            Save as Draft
          </button>
          <button style={{background:'var(--grn)',border:'none',color:'#fff',fontSize:'14px',fontWeight:600,
            padding:'11px 38px',borderRadius:'9px',cursor:'pointer',fontFamily:"'DM Sans',sans-serif"}}
            disabled={loading}
            onClick={() => handleSubmit('Submitted')}>
            {loading ? 'Submitting…' : 'Submit for Approval'}
          </button>
          <button style={{background:'var(--blu)',border:'none',color:'#fff',fontSize:'14px',fontWeight:600,
            padding:'11px 30px',borderRadius:'9px',cursor:'pointer',fontFamily:"'DM Sans',sans-serif"}}
            onClick={() => handleSubmit('Approved')}>
            Approve &amp; Release
          </button>
          <button style={{background:'transparent',border:'1px solid var(--bor2)',color:'var(--tx2)',fontSize:'13px',
            padding:'11px 22px',borderRadius:'9px',cursor:'pointer',fontFamily:"'DM Sans',sans-serif"}}
            onClick={() => { setChecks(initChecks); setForm(f => ({...f, jobOrder:'', productCode:'', productName:'', comment:''})); setError('') }}>
            Clear Form
          </button>
        </div>
      </div>
    </div>
  )
}

function CheckSection({ title, items, checks, onCheck, onBulk, section, color, moldOnly }) {
  return (
    <div style={{background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'var(--rl)',overflow:'hidden',marginBottom:'16px'}}>
      <div style={{background:color,padding:'10px 20px',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
        <div style={{color:'#fff',fontSize:'13px',fontWeight:700,display:'flex',alignItems:'center',gap:'8px'}}>{title}</div>
        <div style={{display:'flex',gap:'8px'}}>
          {!moldOnly && (
            <>
              <button onClick={() => onBulk(section,'product')}
                style={{background:'rgba(255,255,255,.2)',border:'1px solid rgba(255,255,255,.4)',color:'#fff',
                  fontSize:'11px',padding:'4px 12px',borderRadius:'6px',cursor:'pointer',fontFamily:"'DM Sans',sans-serif"}}>
                ✓ All Product
              </button>
              <button onClick={() => onBulk(section,'quality')}
                style={{background:'rgba(255,255,255,.2)',border:'1px solid rgba(255,255,255,.4)',color:'#fff',
                  fontSize:'11px',padding:'4px 12px',borderRadius:'6px',cursor:'pointer',fontFamily:"'DM Sans',sans-serif"}}>
                ✓ All Quality
              </button>
            </>
          )}
          <button onClick={() => onBulk(section,'both')}
            style={{background:'rgba(255,255,255,.35)',border:'1px solid rgba(255,255,255,.6)',color:'#fff',
              fontSize:'11px',padding:'4px 12px',borderRadius:'6px',cursor:'pointer',fontFamily:"'DM Sans',sans-serif",fontWeight:600}}>
            ✓ All
          </button>
        </div>
      </div>
      <table style={{width:'100%',borderCollapse:'collapse',fontSize:'12px'}}>
        <thead>
          <tr style={{background:'var(--bg3)'}}>
            <th style={thStyle}>S.No</th>
            <th style={thStyle}>Item (EN / AR)</th>
            <th style={thStyle}>Responsibility</th>
            <th style={{...thStyle,textAlign:'center',width:'120px',color:'var(--tel)'}}>Product Check</th>
            <th style={{...thStyle,textAlign:'center',width:'120px',color:'var(--grn)'}}>Quality Check</th>
          </tr>
        </thead>
        <tbody>
          {items.map(it => {
            const c = checks[it.sno] || {}
            return (
              <tr key={it.sno} style={{borderBottom:'1px solid var(--bor)'}}>
                <td style={{padding:'10px 14px',fontFamily:"'Space Mono',monospace",fontSize:'10px',color:'var(--tx3)',textAlign:'center'}}>
                  {it.sno}
                </td>
                <td style={{padding:'10px 14px'}}>
                  <div style={{fontSize:'12px',color:'var(--tx)'}}>{it.en}</div>
                  <div style={{fontSize:'10px',color:'var(--tx3)',marginTop:'3px',direction:'rtl',textAlign:'right'}}>{it.ar}</div>
                </td>
                <td style={{padding:'10px 14px',fontSize:'11px',color:'var(--tx3)'}}>{it.resp}</td>
                <td style={{padding:'10px',textAlign:'center'}}>
                  <CheckBox checked={c.product} onChange={() => onCheck(it.sno,'product')} color="tel" />
                </td>
                <td style={{padding:'10px',textAlign:'center'}}>
                  <CheckBox checked={c.quality} onChange={() => onCheck(it.sno,'quality')} color="grn" />
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}

const thStyle = {
  padding:'9px 14px', textAlign:'left', fontSize:'10px', textTransform:'uppercase',
  letterSpacing:'1px', color:'var(--tx3)', borderBottom:'1px solid var(--bor)',
}

function CheckBox({ checked, onChange, color }) {
  const c = `var(--${color})`
  return (
    <div
      style={{
        display:'inline-flex',alignItems:'center',justifyContent:'center',
        width:'28px',height:'28px',borderRadius:'7px',border:'2px solid',
        cursor:'pointer',fontSize:'12px',fontWeight:700,transition:'.12s',
        background: checked ? c : 'var(--bg3)',
        borderColor: checked ? c : 'var(--bor2)',
        color: checked ? '#fff' : 'transparent',
      }}
      onClick={onChange}>
      {checked ? '✓' : ''}
    </div>
  )
}
