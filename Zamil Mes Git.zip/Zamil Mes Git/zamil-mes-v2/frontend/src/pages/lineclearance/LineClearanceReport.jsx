import { useState } from 'react'
import { useList, useMutation } from '../../hooks/useApi'
import { lcService } from '../../services/api'
import { useApp } from '../../contexts/AppContext'

const STATUS_MAP = {
  Draft:      { cls: 'bp',  label: 'Draft'      },
  Submitted:  { cls: 'bpa', label: 'Submitted'  },
  Approved:   { cls: 'bd',  label: 'Approved'   },
  Rejected:   { cls: 'brj', label: 'Rejected'   },
}

export default function LineClearanceReport() {
  const { showToast, goScreen } = useApp()
  const [viewItem, setViewItem] = useState(null)

  const [filter, setFilter] = useState({ plant:'', machine:'', status:'', from:'', to:'', search:'' })
  const setF = (k, v) => setFilter(f => ({...f, [k]: v}))

  const { items: apiItems, loading, refetch } = useList(lcService.getAll, { limit: 50 })
  const records = apiItems ?? []

  const filtered = records.filter(r => {
    if (filter.plant   && r.plant   !== filter.plant)   return false
    if (filter.machine && !r.machine?.toLowerCase().includes(filter.machine.toLowerCase())) return false
    if (filter.status  && r.status  !== filter.status)  return false
    if (filter.search  && !JSON.stringify(r).toLowerCase().includes(filter.search.toLowerCase())) return false
    return true
  })

  const totalRec  = filtered.length
  const approved  = filtered.filter(r => r.status === 'Approved').length
  const draftSub  = filtered.filter(r => r.status === 'Draft' || r.status === 'Submitted').length
  const uniqueMC  = new Set(filtered.map(r => r.machine)).size

  const { mutate: updateStatus } = useMutation(
    (data) => lcService.update(data.id, { status: data.status }),
    {
      onSuccess: (_, data) => {
        showToast(`Record ${data?.status || 'updated'}`, 'success')
        refetch()
      },
      onError: () => showToast('Failed to update status', 'error'),
    }
  )

  return (
    <div>
      {/* Green Header Bar */}
      <div style={{background:'var(--grn)',padding:'13px 28px',display:'flex',alignItems:'center',gap:'28px'}}>
        <div style={{display:'flex',alignItems:'center',gap:'12px'}}>
          <div style={{background:'#fff',padding:'4px 8px',borderRadius:'6px',fontSize:'11px',fontWeight:800,
            color:'var(--grn)',fontFamily:"'Space Mono',monospace"}}>
            Zamil<span style={{color:'var(--amb)'}}>✓</span>
          </div>
          <div style={{fontSize:'17px',fontWeight:700,color:'#fff',fontFamily:"'Space Mono',monospace"}}>
            LINE CLEARANCE REPORT
          </div>
        </div>
        <div style={{display:'flex',gap:'14px',marginLeft:'16px'}}>
          <button className="btn bgh bsm" onClick={() => goScreen('operator')} style={{color:'#fff',borderColor:'rgba(255,255,255,.4)',background:'rgba(255,255,255,.15)'}}>🏠 Home</button>
          <button className="btn bgh bsm" onClick={() => goScreen('line-clearance')} style={{color:'#fff',borderColor:'rgba(255,255,255,.4)',background:'rgba(255,255,255,.15)'}}>≡ Form</button>
          <button className="btn bgh bsm" style={{color:'#fff',borderColor:'rgba(255,255,255,.6)',background:'rgba(255,255,255,.35)',fontWeight:700,textDecoration:'underline'}}>≡ Report</button>
        </div>
      </div>

      {/* Filter Bar */}
      <div style={{padding:'14px 28px',background:'var(--bg2)',borderBottom:'1px solid var(--bor)',display:'flex',alignItems:'flex-end',gap:'14px',flexWrap:'wrap'}}>
        <div>
          <label style={{fontSize:'11px',color:'var(--tx3)',fontWeight:600,display:'block',marginBottom:'4px'}}>Plant</label>
          <select style={{width:'120px'}} value={filter.plant} onChange={e => setF('plant', e.target.value)}>
            <option value="">All Plants</option>
            <option>FPP BU</option>
            <option>IPP BU</option>
            <option>ZPC BU</option>
          </select>
        </div>
        <div>
          <label style={{fontSize:'11px',color:'var(--tx3)',fontWeight:600,display:'block',marginBottom:'4px'}}>Machine</label>
          <input type="text" placeholder="All" style={{width:'120px'}} value={filter.machine} onChange={e => setF('machine', e.target.value)}/>
        </div>
        <div>
          <label style={{fontSize:'11px',color:'var(--tx3)',fontWeight:600,display:'block',marginBottom:'4px'}}>Status</label>
          <select style={{width:'130px'}} value={filter.status} onChange={e => setF('status', e.target.value)}>
            <option value="">All</option>
            <option>Draft</option>
            <option>Submitted</option>
            <option>Approved</option>
            <option>Rejected</option>
          </select>
        </div>
        <div>
          <label style={{fontSize:'11px',color:'var(--tx3)',fontWeight:600,display:'block',marginBottom:'4px'}}>From</label>
          <input type="date" style={{width:'150px'}} value={filter.from} onChange={e => setF('from', e.target.value)}/>
        </div>
        <div>
          <label style={{fontSize:'11px',color:'var(--tx3)',fontWeight:600,display:'block',marginBottom:'4px'}}>To</label>
          <input type="date" style={{width:'150px'}} value={filter.to} onChange={e => setF('to', e.target.value)}/>
        </div>
        <button style={{background:'var(--tel)',border:'none',color:'#fff',fontSize:'13px',fontWeight:600,
          padding:'9px 20px',borderRadius:'8px',cursor:'pointer',fontFamily:"'DM Sans',sans-serif"}}>
          Filter
        </button>
        <button onClick={() => setFilter({ plant:'', machine:'', status:'', from:'', to:'', search:'' })}
          style={{background:'transparent',border:'1px solid var(--bor2)',color:'var(--tx2)',fontSize:'12px',
            padding:'9px 14px',borderRadius:'8px',cursor:'pointer',fontFamily:"'DM Sans',sans-serif"}}>
          Clear
        </button>
      </div>

      <div style={{padding:'20px 28px'}}>

        {/* 4 KPI Stats */}
        <div className="g4" style={{marginBottom:'18px'}}>
          <div className="sc" style={{'--sa':'var(--blu)'}}>
            <div className="slbl">Total Records</div>
            <div className="sval" style={{color:'var(--blu)'}}>{totalRec}</div>
            <div className="ssub">All submissions</div>
          </div>
          <div className="sc" style={{'--sa':'var(--grn)'}}>
            <div className="slbl">Approved</div>
            <div className="sval" style={{color:'var(--grn)'}}>{approved}</div>
            <div className="ssub">Released for production</div>
          </div>
          <div className="sc" style={{'--sa':'var(--amb)'}}>
            <div className="slbl">Draft / Submitted</div>
            <div className="sval" style={{color:'var(--amb)'}}>{draftSub}</div>
            <div className="ssub">Pending review</div>
          </div>
          <div className="sc" style={{'--sa':'var(--tel)'}}>
            <div className="slbl">Machines</div>
            <div className="sval" style={{color:'var(--tel)'}}>{uniqueMC}</div>
            <div className="ssub">Unique machines</div>
          </div>
        </div>

        {/* Toolbar */}
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:'12px',flexWrap:'wrap',gap:'10px'}}>
          <div style={{display:'flex',gap:'8px'}}>
            <button style={{background:'var(--bg2)',border:'1px solid var(--bor2)',color:'var(--tx2)',fontSize:'12px',
              padding:'7px 14px',borderRadius:'8px',cursor:'pointer',fontFamily:"'DM Sans',sans-serif"}}>
              📥 Download Excel
            </button>
            <button onClick={() => goScreen('line-clearance')}
              style={{background:'var(--grn)',border:'none',color:'#fff',fontSize:'12px',padding:'7px 14px',
                borderRadius:'8px',cursor:'pointer',fontFamily:"'DM Sans',sans-serif"}}>
              + New Clearance
            </button>
          </div>
          <div style={{display:'flex',alignItems:'center',gap:'8px'}}>
            <label style={{fontSize:'12px',color:'var(--tx3)'}}>Search:</label>
            <input type="text" placeholder="Search..." style={{width:'190px'}}
              value={filter.search} onChange={e => setF('search', e.target.value)}/>
          </div>
        </div>

        {/* Table */}
        <div className="twrap" style={{marginBottom:0,overflowX:'auto'}}>
          <table style={{minWidth:'1100px'}}>
            <thead>
              <tr>
                <th>#</th><th>Plant</th><th>Machine</th><th>Job Order</th><th>Date</th>
                <th>Product Code</th><th>Product Name</th><th>Shift</th><th>Type</th>
                <th>Checked</th><th>Technician</th><th>QC Inspector</th><th>Status</th><th>Action</th>
              </tr>
            </thead>
            <tbody>
              {loading && (
                <tr><td colSpan={14} style={{textAlign:'center',color:'var(--tx3)',padding:'28px'}}>Loading…</td></tr>
              )}
              {!loading && filtered.length === 0 && (
                <tr><td colSpan={14} style={{textAlign:'center',color:'var(--tx3)',padding:'28px'}}>
                  No line clearance records yet.{' '}
                  <span style={{color:'var(--grn)',cursor:'pointer'}} onClick={() => goScreen('line-clearance')}>Create one →</span>
                </td></tr>
              )}
              {filtered.map((r, i) => {
                const st = STATUS_MAP[r.status] || STATUS_MAP.Draft
                return (
                  <tr key={r.id}>
                    <td style={{fontFamily:"'Space Mono',monospace",fontSize:'10px',color:'var(--tx3)'}}>{i+1}</td>
                    <td style={{fontSize:'11px'}}>{r.plant}</td>
                    <td><span className="mtag">{r.machine}</span></td>
                    <td><span className="woid" style={{fontSize:'11px'}}>{r.jobOrder}</span></td>
                    <td style={{fontFamily:"'Space Mono',monospace",fontSize:'10px',color:'var(--tx3)'}}>{r.date}</td>
                    <td style={{fontFamily:"'Space Mono',monospace",fontSize:'10px'}}>{r.productCode}</td>
                    <td style={{fontSize:'11px'}}>{r.productName}</td>
                    <td style={{fontSize:'11px',color:'var(--tx3)'}}>{r.shift}</td>
                    <td style={{fontSize:'11px',color:'var(--tx3)'}}>{r.type}</td>
                    <td style={{fontFamily:"'Space Mono',monospace",fontSize:'10px',
                      color: r.checked?.startsWith('23') ? 'var(--grn)' : 'var(--amb)'}}>{r.checked}</td>
                    <td style={{fontSize:'11px'}}>{r.tech}</td>
                    <td style={{fontSize:'11px'}}>{r.qi}</td>
                    <td><span className={`bdg ${st.cls}`}>{st.label}</span></td>
                    <td>
                      <div style={{display:'flex',gap:'5px'}}>
                        <button className="btn bgh bsm" onClick={() => setViewItem(r)}>View</button>
                        {r.status !== 'Approved' && (
                          <button className="btn bsuc bsm" onClick={() => updateStatus({ id: r.id, status: 'Approved' })}>✓</button>
                        )}
                        {r.status !== 'Rejected' && r.status !== 'Approved' && (
                          <button className="btn bdan bsm" onClick={() => updateStatus({ id: r.id, status: 'Rejected' })}>✕</button>
                        )}
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
        <div style={{padding:'10px 4px',fontSize:'11px',color:'var(--tx3)'}}>{filtered.length} records</div>
      </div>

      {/* View Modal */}
      {viewItem && (
        <div className="modal-backdrop" onClick={e => e.target === e.currentTarget && setViewItem(null)}>
          <div className="modal" style={{width:'700px',maxHeight:'85vh',overflowY:'auto'}}>
            <div className="modal-header">
              <span className="font-semibold text-sm text-tx">Line Clearance Record — {viewItem.jobOrder}</span>
              <button className="text-tx3 hover:text-tx" onClick={() => setViewItem(null)}>✕</button>
            </div>
            <div className="modal-body">
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'12px',marginBottom:'16px'}}>
                {[
                  ['Plant', viewItem.plant], ['Machine', viewItem.machine],
                  ['Job Order', viewItem.jobOrder], ['Date', viewItem.date],
                  ['Product Code', viewItem.productCode], ['Product Name', viewItem.productName],
                  ['Shift', viewItem.shift], ['Type', viewItem.type],
                  ['Checked', viewItem.checked], ['Technician', viewItem.tech],
                  ['QC Inspector', viewItem.qi], ['Status', viewItem.status],
                ].map(([k, v]) => (
                  <div key={k} style={{borderBottom:'1px solid var(--bor)',paddingBottom:'8px'}}>
                    <div style={{fontSize:'10px',color:'var(--tx3)',textTransform:'uppercase',letterSpacing:'.8px'}}>{k}</div>
                    <div style={{fontSize:'12px',color:'var(--tx)',fontWeight:500,marginTop:'2px'}}>{v}</div>
                  </div>
                ))}
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn bgh" onClick={() => setViewItem(null)}>Close</button>
              <button className="btn bsuc" onClick={() => { updateStatus({ id: viewItem.id, status: 'Approved' }); setViewItem(null) }}>✓ Approve</button>
              <button className="btn bdan" onClick={() => { updateStatus({ id: viewItem.id, status: 'Rejected' }); setViewItem(null) }}>✕ Reject</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
