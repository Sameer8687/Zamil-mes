import { useState, useEffect } from 'react'
import { useList, useMutation } from '../../hooks/useApi'
import { setupService, userService } from '../../services/api'
import { useApp } from '../../contexts/AppContext'

const TABS = [
  { id:'boxqty',    label:'📦 Box Quantity' },
  { id:'machines',  label:'⚙ Machines'     },
  { id:'locations', label:'📍 Locations'   },
  { id:'shifts',    label:'🕐 Shifts'      },
  { id:'users',     label:'👤 Users'       },
]

export default function Setup() {
  const { goScreen } = useApp()
  const [tab, setTab] = useState('boxqty')

  return (
    <div style={{background:'var(--bg)',minHeight:'calc(100vh - 96px)'}}>
      <div style={{background:'var(--pur2)',borderBottom:'1px solid var(--bor)',padding:'16px 28px',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
        <div>
          <div style={{fontSize:'16px',fontWeight:700,color:'var(--tx)'}}>⚙ Setup &amp; Configuration</div>
          <div style={{fontSize:'12px',color:'var(--tx3)',marginTop:'2px'}}>Manage box quantities, machines, shifts and reference data</div>
        </div>
        <div style={{display:'flex',gap:'8px'}}>
          <button className="btn bgh bsm" onClick={() => goScreen('operator')}>← Back to Dashboard</button>
        </div>
      </div>

      <div style={{padding:'20px 28px'}}>
        <div style={{display:'flex',borderBottom:'2px solid var(--bor)',marginBottom:'20px',gap:0}}>
          {TABS.map(t => (
            <button key={t.id}
              className={`setup-stab ${tab === t.id ? 'on' : ''}`}
              onClick={() => setTab(t.id)}>
              {t.label}
            </button>
          ))}
        </div>

        {tab === 'boxqty'    && <BoxQtyTab />}
        {tab === 'machines'  && <MachinesTab />}
        {tab === 'locations' && <LocationsTab />}
        {tab === 'shifts'    && <ShiftsTab />}
        {tab === 'users'     && <UsersTab />}
      </div>
    </div>
  )
}

/* ── Box Qty Tab ──────────────────────────────────────────────────── */
function BoxQtyTab() {
  const { showToast } = useApp()
  const [innerTab, setInnerTab] = useState('form')

  const [form, setForm] = useState({ org:'', date: new Date().toISOString().slice(0,10), user:'' })
  const [items, setItems] = useState([])
  const [showAddItem, setShowAddItem] = useState(false)
  const [newItem, setNewItem] = useState({ code:'', desc:'', qty:'' })

  const { items: apiBq, refetch: refetchBq } = useList(setupService.getBoxQtyReport)
  const [bqList, setBqList] = useState([])
  const [bqFilter, setBqFilter] = useState({ org:'', code:'', search:'' })

  useEffect(() => {
    if (apiBq?.length) setBqList(apiBq)
  }, [apiBq])

  const { mutate: saveBqApi } = useMutation(setupService.saveBoxQtyRecords, {
    onSuccess: () => { refetchBq(); showToast('Box quantities saved successfully','success') },
    onError: () => showToast('Save failed — check required fields','error'),
  })

  const addItem = () => {
    if (!newItem.code || !newItem.qty) { showToast('Item code and qty required','error'); return }
    setItems(prev => [{ ...newItem, id: Date.now() }, ...prev])
    setNewItem({ code:'', desc:'', qty:'' })
    setShowAddItem(false)
  }

  const removeItem = id => setItems(prev => prev.filter(x => x.id !== id))

  const saveForm = () => {
    if (!form.org) { showToast('Select an Organization','error'); return }
    if (!items.length) { showToast('Add at least one item','error'); return }
    saveBqApi({ org: form.org, date: form.date, user: form.user, items })
    setItems([])
  }

  const filteredBq = bqList.filter(r => {
    if (bqFilter.org    && r.org  !== bqFilter.org) return false
    if (bqFilter.code   && !r.code?.toLowerCase().includes(bqFilter.code.toLowerCase())) return false
    if (bqFilter.search && !JSON.stringify(r).toLowerCase().includes(bqFilter.search.toLowerCase())) return false
    return true
  })

  return (
    <div>
      <div style={{display:'flex',gap:'6px',marginBottom:'18px'}}>
        <button className={`bq-itab ${innerTab === 'form' ? 'on' : ''}`} onClick={() => setInnerTab('form')}>Form</button>
        <button className={`bq-itab ${innerTab === 'report' ? 'on' : ''}`} onClick={() => setInnerTab('report')}>Report / List</button>
      </div>

      {innerTab === 'form' && (
        <div style={{background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'14px',padding:'22px'}}>
          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:'18px',paddingBottom:'14px',borderBottom:'1px solid var(--bor)'}}>
            <div>
              <div style={{fontSize:'13px',fontWeight:600,color:'var(--tx)',display:'flex',alignItems:'center',gap:'7px'}}>
                <span style={{width:'7px',height:'7px',borderRadius:'50%',background:'var(--pur)',display:'inline-block'}}/>
                Box Quantity Form
              </div>
              <div style={{fontSize:'11px',color:'var(--tx3)',marginTop:'3px'}}>Define how many units are packed per box for each item code</div>
            </div>
            <div style={{fontSize:'11px',padding:'4px 12px',borderRadius:'20px',background:'var(--pur2)',border:'1px solid var(--pur)',color:'var(--pur)'}}>ZPI.MFG.BQ.01</div>
          </div>

          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:'16px',marginBottom:'16px'}}>
            <div>
              <label style={{fontSize:'11px',fontWeight:600,textTransform:'uppercase',letterSpacing:'.8px',color:'var(--tx3)',display:'block',marginBottom:'5px'}}>Organization <span style={{color:'var(--red)'}}>*</span></label>
              <select style={{width:'100%'}} value={form.org} onChange={e => setForm(f=>({...f,org:e.target.value}))}>
                <option value="">Select Organization</option>
                <option value="FPP BU">FPP BU</option>
                <option value="IPP BU">IPP BU</option>
                <option value="ZPC BU">ZPC BU</option>
              </select>
              <div style={{fontSize:'11px',color:'var(--tx3)',marginTop:'3px'}}>Scopes item search to the selected org.</div>
            </div>
            <div>
              <label style={{fontSize:'11px',fontWeight:600,textTransform:'uppercase',letterSpacing:'.8px',color:'var(--tx3)',display:'block',marginBottom:'5px'}}>Effective Date</label>
              <input type="date" value={form.date} onChange={e => setForm(f=>({...f,date:e.target.value}))} />
            </div>
            <div>
              <label style={{fontSize:'11px',fontWeight:600,textTransform:'uppercase',letterSpacing:'.8px',color:'var(--tx3)',display:'block',marginBottom:'5px'}}>Created By</label>
              <input type="text" placeholder="Name or Employee ID" value={form.user} onChange={e => setForm(f=>({...f,user:e.target.value}))} />
            </div>
          </div>

          <div style={{display:'flex',gap:'8px',marginBottom:'16px'}}>
            <button className="btn bpri" onClick={() => setShowAddItem(true)}>+ Add Item</button>
            <button className="btn bgh" onClick={() => { setItems([]); setForm({ org:'', date: new Date().toISOString().slice(0,10), user:'' }) }}>Clear All</button>
          </div>

          {showAddItem && (
            <div style={{background:'var(--bg3)',border:'1px solid var(--bor)',borderRadius:'10px',padding:'14px',marginBottom:'14px',display:'grid',gridTemplateColumns:'1fr 2fr 1fr auto',gap:'10px',alignItems:'end'}}>
              <div>
                <label style={{fontSize:'11px',color:'var(--tx3)',display:'block',marginBottom:'4px'}}>Item Code</label>
                <input type="text" placeholder="e.g. FG9406" value={newItem.code} onChange={e => setNewItem(n=>({...n,code:e.target.value}))} style={{fontFamily:"'Space Mono',monospace"}} />
              </div>
              <div>
                <label style={{fontSize:'11px',color:'var(--tx3)',display:'block',marginBottom:'4px'}}>Item Description</label>
                <input type="text" placeholder="Product description" value={newItem.desc} onChange={e => setNewItem(n=>({...n,desc:e.target.value}))} />
              </div>
              <div>
                <label style={{fontSize:'11px',color:'var(--tx3)',display:'block',marginBottom:'4px'}}>Qty Per Box</label>
                <input type="number" placeholder="e.g. 2400" value={newItem.qty} onChange={e => setNewItem(n=>({...n,qty:e.target.value}))} />
              </div>
              <div style={{display:'flex',gap:'6px'}}>
                <button className="btn bsuc bsm" onClick={addItem}>Add</button>
                <button className="btn bgh bsm" onClick={() => setShowAddItem(false)}>✕</button>
              </div>
            </div>
          )}

          <div style={{border:'1px solid var(--bor)',borderRadius:'10px',overflow:'hidden',marginBottom:'10px'}}>
            <table style={{width:'100%',borderCollapse:'collapse',fontSize:'12px'}}>
              <thead>
                <tr style={{background:'var(--bg3)'}}>
                  <th style={{padding:'9px 14px',textAlign:'left',fontSize:'10px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',borderBottom:'1px solid var(--bor)',width:'36px'}}>#</th>
                  <th style={{padding:'9px 14px',textAlign:'left',fontSize:'10px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',borderBottom:'1px solid var(--bor)'}}>Item Code</th>
                  <th style={{padding:'9px 14px',textAlign:'left',fontSize:'10px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',borderBottom:'1px solid var(--bor)'}}>Item Description</th>
                  <th style={{padding:'9px 14px',textAlign:'right',fontSize:'10px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',borderBottom:'1px solid var(--bor)',width:'130px'}}>Qty Per Box</th>
                  <th style={{padding:'9px 14px',textAlign:'center',fontSize:'10px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',borderBottom:'1px solid var(--bor)',width:'100px'}}>Action</th>
                </tr>
              </thead>
              <tbody>
                {items.length === 0 ? (
                  <tr><td colSpan={5} style={{textAlign:'center',padding:'28px',color:'var(--tx3)'}}>
                    <div style={{fontSize:'22px',marginBottom:'6px'}}>📦</div>No items added yet.
                  </td></tr>
                ) : items.map((it, i) => (
                  <tr key={it.id} style={{borderBottom:'1px solid var(--bor)'}}>
                    <td style={{padding:'9px 14px',fontFamily:"'Space Mono',monospace",fontSize:'10px',color:'var(--tx3)'}}>{i+1}</td>
                    <td style={{padding:'9px 14px',fontFamily:"'Space Mono',monospace",fontSize:'11px',color:'var(--pur)',fontWeight:600}}>{it.code}</td>
                    <td style={{padding:'9px 14px',fontSize:'11px'}}>{it.desc}</td>
                    <td style={{padding:'9px 14px',textAlign:'right',fontFamily:"'Space Mono',monospace",fontSize:'12px',fontWeight:700,color:'var(--tx)'}}>{Number(it.qty).toLocaleString()}</td>
                    <td style={{padding:'9px 14px',textAlign:'center'}}>
                      <button className="btn bdan bsm" onClick={() => removeItem(it.id)}>✕ Remove</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',paddingTop:'14px',borderTop:'1px solid var(--bor)'}}>
            <div style={{fontSize:'11px',color:'var(--tx3)'}}>You can add multiple items — each new one appears at the top.</div>
            <div style={{display:'flex',gap:'8px'}}>
              <button className="btn bgh" onClick={() => setItems([])}>Reset</button>
              <button className="btn bpri" onClick={saveForm}>💾 Save</button>
            </div>
          </div>
        </div>
      )}

      {innerTab === 'report' && (
        <div style={{background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'14px',padding:'22px'}}>
          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:'16px',paddingBottom:'14px',borderBottom:'1px solid var(--bor)'}}>
            <div style={{fontSize:'13px',fontWeight:600,color:'var(--tx)',display:'flex',alignItems:'center',gap:'7px'}}>
              <span style={{width:'7px',height:'7px',borderRadius:'50%',background:'var(--pur)',display:'inline-block'}}/>
              Box Quantity List
            </div>
            <div style={{fontSize:'11px',color:'var(--tx3)'}}>View, filter and manage all saved records</div>
          </div>

          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr auto',gap:'10px',alignItems:'end',marginBottom:'16px'}}>
            <div>
              <label style={{fontSize:'11px',fontWeight:600,textTransform:'uppercase',letterSpacing:'.8px',color:'var(--tx3)',display:'block',marginBottom:'5px'}}>Organization</label>
              <select value={bqFilter.org} onChange={e => setBqFilter(f=>({...f,org:e.target.value}))}>
                <option value="">Select Organization ID</option>
                <option value="FPP BU">FPP BU</option>
                <option value="IPP BU">IPP BU</option>
                <option value="ZPC BU">ZPC BU</option>
              </select>
            </div>
            <div>
              <label style={{fontSize:'11px',fontWeight:600,textTransform:'uppercase',letterSpacing:'.8px',color:'var(--tx3)',display:'block',marginBottom:'5px'}}>Item Code</label>
              <input type="text" placeholder="Enter Item Code" value={bqFilter.code} onChange={e => setBqFilter(f=>({...f,code:e.target.value}))} />
            </div>
            <button className="btn bpri">🔍 Search</button>
          </div>

          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:'12px',gap:'10px',flexWrap:'wrap'}}>
            <div style={{display:'flex',gap:'8px',alignItems:'center'}}>
              <button className="btn bgh bsm">📥 Export Excel</button>
              <span style={{fontSize:'11px',color:'var(--tx3)'}}>{filteredBq.length} records</span>
            </div>
            <div style={{display:'flex',alignItems:'center',gap:'8px'}}>
              <span style={{fontSize:'12px',color:'var(--tx3)'}}>Search:</span>
              <input type="text" placeholder="Search any field..." style={{width:'200px'}} value={bqFilter.search} onChange={e => setBqFilter(f=>({...f,search:e.target.value}))} />
            </div>
          </div>

          <div style={{border:'1px solid var(--bor)',borderRadius:'10px',overflow:'hidden',marginBottom:'8px',overflowX:'auto'}}>
            <table style={{width:'100%',borderCollapse:'collapse',fontSize:'12px',minWidth:'800px'}}>
              <thead>
                <tr style={{background:'var(--bg3)'}}>
                  {/* <th style={{padding:'9px 14px',textAlign:'left',fontSize:'10px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',borderBottom:'1px solid var(--bor)',width:'48px'}}>ID</th> */}
                  <th style={{padding:'9px 14px',textAlign:'left',fontSize:'10px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',borderBottom:'1px solid var(--bor)'}}>Org ID</th>
                  <th style={{padding:'9px 14px',textAlign:'left',fontSize:'10px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',borderBottom:'1px solid var(--bor)'}}>Item Code</th>
                  <th style={{padding:'9px 14px',textAlign:'left',fontSize:'10px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',borderBottom:'1px solid var(--bor)'}}>Item Description</th>
                  <th style={{padding:'9px 14px',textAlign:'right',fontSize:'10px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',borderBottom:'1px solid var(--bor)',width:'120px'}}>Qty Per Box</th>
                  <th style={{padding:'9px 14px',textAlign:'center',fontSize:'10px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',borderBottom:'1px solid var(--bor)',width:'80px'}}>Action</th>
                </tr>
              </thead>
              <tbody>
                {filteredBq.length === 0 ? (
                  <tr><td colSpan={6} style={{textAlign:'center',padding:'28px',color:'var(--tx3)'}}>No records found.</td></tr>
                ) : filteredBq.map(r => (
                  <tr key={r.id} style={{borderBottom:'1px solid var(--bor)'}}>
                    {/* <td style={{padding:'9px 14px',fontFamily:"'Space Mono',monospace",fontSize:'10px',color:'var(--tx3)'}}>{r.id}</td> */}
                    <td style={{padding:'9px 14px',fontSize:'11px'}}>{r.org}</td>
                    <td style={{padding:'9px 14px',fontFamily:"'Space Mono',monospace",fontSize:'11px',color:'var(--pur)',fontWeight:600}}>{r.code}</td>
                    <td style={{padding:'9px 14px',fontSize:'11px'}}>{r.desc}</td>
                    <td style={{padding:'9px 14px',textAlign:'right',fontFamily:"'Space Mono',monospace",fontSize:'12px',fontWeight:700}}>{Number(r.qty).toLocaleString()}</td>
                    <td style={{padding:'9px 14px',textAlign:'center'}}>
                      <button className="btn bdan bsm" onClick={() => { if(window.confirm('Delete?')) { setupService.deleteBoxQtyRecord(r.id).then(refetchBq).catch(()=>{}) } }}>🗑</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div style={{fontSize:'11px',color:'var(--tx3)',paddingTop:'10px'}}>{filteredBq.length} records</div>
        </div>
      )}
    </div>
  )
}

/* ── Machines Tab ─────────────────────────────────────────────────── */
function MachinesTab() {
  const { showToast } = useApp()
  const [innerTab, setInnerTab] = useState('list')
  const [editItem, setEditItem] = useState(null)
  const [filter, setFilter] = useState({ plant:'', dept:'', status:'', search:'' })

  const { items: apiMachines, refetch: refetchMachines } = useList(setupService.getMachines)
  const [machines, setMachines] = useState([])

  useEffect(() => {
    if (apiMachines?.length) setMachines(apiMachines)
  }, [apiMachines])

  const { mutate: createMachineApi } = useMutation(setupService.createMachine, {
    onSuccess: () => { refetchMachines(); showToast('Machine added','success'); setInnerTab('list') },
    onError: (e) => showToast(e?.message || 'Failed to save machine','error'),
  })
  const { mutate: updateMachineApi } = useMutation(
    (data) => setupService.updateMachine(data.id, data),
    { onSuccess: () => { refetchMachines(); showToast('Machine updated','success'); setInnerTab('list') },
      onError: (e) => showToast(e?.message || 'Failed to update machine','error') }
  )
  const { mutate: deleteMachineApi } = useMutation(setupService.deleteMachine, {
    onSuccess: () => { refetchMachines(); showToast('Machine removed','warning') },
    onError: (e) => showToast(e?.message || 'Failed to delete machine','error'),
  })

  const filtered = machines.filter(m => {
    if (filter.plant  && m.plant  !== filter.plant)  return false
    if (filter.dept   && m.dept   !== filter.dept)   return false
    if (filter.status && m.status !== filter.status) return false
    if (filter.search && !JSON.stringify(m).toLowerCase().includes(filter.search.toLowerCase())) return false
    return true
  })

  const totalMC = filtered.length
  const running = filtered.filter(m => m.status === 'Running').length
  const idle    = filtered.filter(m => m.status === 'Idle').length
  const fault   = filtered.filter(m => m.status === 'Fault').length
  const maint   = filtered.filter(m => m.status === 'Maintenance').length

  const openForm = (m) => { setEditItem(m || {}); setInnerTab('form') }

  const saveForm = (data) => {
    if (data.id) updateMachineApi(data)
    else createMachineApi(data)
  }

  return (
    <div>
      <div style={{display:'flex',gap:'6px',marginBottom:'18px'}}>
        <button className={`bq-itab ${innerTab === 'list' ? 'on' : ''}`} onClick={() => setInnerTab('list')}>🖥 Machine List</button>
        <button className={`bq-itab ${innerTab === 'form' ? 'on' : ''}`} onClick={() => openForm(null)}>➕ Add / Edit Machine</button>
      </div>

      {innerTab === 'list' && (
        <>
          <div style={{display:'grid',gridTemplateColumns:'repeat(5,1fr)',gap:'10px',marginBottom:'14px'}}>
            {[['Total Machines',totalMC,'var(--blu)'],['Running',running,'var(--grn)'],['Idle',idle,'var(--amb)'],['Fault / Alarm',fault,'var(--red)'],['Maintenance Due',maint,'var(--tel)']].map(([l,v,c]) => (
              <div key={l} style={{background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'var(--r)',padding:'12px 14px'}}>
                <div style={{fontSize:'10px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',fontWeight:600,marginBottom:'5px'}}>{l}</div>
                <div style={{fontFamily:"'Space Mono',monospace",fontSize:'20px',fontWeight:700,color:c}}>{v}</div>
              </div>
            ))}
          </div>

          <div style={{background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'14px',padding:'14px 18px',marginBottom:'14px',display:'flex',alignItems:'flex-start',gap:'12px',flexWrap:'wrap'}}>
            <div className="fgrp" style={{minWidth:'120px'}}>
              <label>Plant / Org</label>
              <select style={{fontSize:'12px',padding:'6px 9px'}} value={filter.plant} onChange={e => setFilter(f=>({...f,plant:e.target.value}))}>
                <option value="">All Plants</option>
                <option value="FPP">FPP BU</option>
                <option value="IPP">IPP BU</option>
              </select>
            </div>
            <div className="fgrp" style={{minWidth:'150px'}}>
              <label>Department</label>
              <select style={{fontSize:'12px',padding:'6px 9px'}} value={filter.dept} onChange={e => setFilter(f=>({...f,dept:e.target.value}))}>
                <option value="">All Departments</option>
                <option value="INJECTION">Injection</option>
                <option value="BLOWMOLDIN">Blow Moulding</option>
                <option value="PRINTING">Printing</option>
                <option value="EXTRUSION">Extrusion</option>
                <option value="ASSEMBLY">Assembly</option>
              </select>
            </div>
            <div className="fgrp" style={{minWidth:'130px'}}>
              <label>Status</label>
              <select style={{fontSize:'12px',padding:'6px 9px'}} value={filter.status} onChange={e => setFilter(f=>({...f,status:e.target.value}))}>
                <option value="">All</option>
                <option value="Running">Running</option>
                <option value="Idle">Idle</option>
                <option value="Fault">Fault</option>
                <option value="Maintenance">Maintenance</option>
              </select>
            </div>
            <div className="fgrp" style={{flex:1,minWidth:'180px'}}>
              <label>Search</label>
              <input type="text" placeholder="Machine ID, name, OEM, model..." style={{fontSize:'12px',padding:'6px 9px'}} value={filter.search} onChange={e => setFilter(f=>({...f,search:e.target.value}))} />
            </div>
            <div style={{display:'flex',gap:'6px',alignItems:'flex-start' ,marginTop:'23px'}}>
              <button className="btn bpri bsm" onClick={() => openForm(null)}>+ Add Machine</button>
              <button className="btn bgh bsm">📥 Export</button>
              <button className="btn bgh bsm" onClick={() => setFilter({plant:'',dept:'',status:'',search:''})}>Clear</button>
            </div>
          </div>

          <div style={{background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'14px',overflow:'hidden',overflowX:'auto'}}>
            <div style={{padding:'12px 16px',borderBottom:'1px solid var(--bor)',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
              <div style={{fontSize:'13px',fontWeight:600,color:'var(--tx)',display:'flex',alignItems:'center',gap:'7px'}}>
                <span style={{width:'7px',height:'7px',borderRadius:'50%',background:'var(--pur)',display:'inline-block'}}/>
                Machine Registry
              </div>
              <span style={{fontSize:'11px',color:'var(--tx3)'}}>{filtered.length} machines</span>
            </div>
            <table style={{width:'100%',borderCollapse:'collapse',fontSize:'12px',minWidth:'1100px'}}>
              <thead>
                <tr style={{background:'var(--bg3)'}}>
                  {['Machine ID','Machine Name','Dept / Plant','OEM / Model','Cycle Time (s)','Cavities','IP Address','Status','MES Code','PM Freq','Action'].map(h => (
                    <th key={h} style={{padding:'9px 12px',textAlign: h==='Cycle Time (s)'||h==='Cavities'?'right':'left',fontSize:'10px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',borderBottom:'1px solid var(--bor)'}}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.length === 0 ? (
                  <tr><td colSpan={11} style={{textAlign:'center',padding:'28px',color:'var(--tx3)'}}>No machines found.</td></tr>
                ) : filtered.map(m => (
                  <tr key={m.id} style={{borderBottom:'1px solid var(--bor)'}}>
                    <td style={{padding:'9px 12px',fontFamily:"'Space Mono',monospace",fontSize:'11px',color:'var(--pur)',fontWeight:600}}>{m.machineId}</td>
                    <td style={{padding:'9px 12px',fontSize:'11px'}}>{m.name}</td>
                    <td style={{padding:'9px 12px',fontSize:'11px',color:'var(--tx3)'}}>{m.dept} / {m.plant}</td>
                    <td style={{padding:'9px 12px',fontSize:'11px',color:'var(--tx3)'}}>{m.oem} {m.model}</td>
                    <td style={{padding:'9px 12px',textAlign:'right',fontFamily:"'Space Mono',monospace",fontSize:'10px'}}>{m.cycleTime}</td>
                    <td style={{padding:'9px 12px',textAlign:'right',fontFamily:"'Space Mono',monospace",fontSize:'10px'}}>{m.cavities}</td>
                    <td style={{padding:'9px 12px',fontFamily:"'Space Mono',monospace",fontSize:'10px',color:'var(--tel)'}}>{m.ip}</td>
                    <td style={{padding:'9px 12px'}}>
                      <span className={`bdg ${m.status==='Running'?'bd':m.status==='Idle'?'bp':m.status==='Maintenance'?'bpa':'brj'}`}>{m.status}</span>
                    </td>
                    <td style={{padding:'9px 12px',fontFamily:"'Space Mono',monospace",fontSize:'10px',color:'var(--tx3)'}}>{m.mesCode}</td>
                    <td style={{padding:'9px 12px',fontSize:'11px',color:'var(--tx3)'}}>{m.pmFreq}</td>
                    <td style={{padding:'9px 12px'}}>
                      <div style={{display:'flex',gap:'4px'}}>
                        <button className="btn bgh bsm" onClick={() => { setEditItem(m); setInnerTab('form') }}>Edit</button>
                        <button className="btn bdan bsm" onClick={() => { if (window.confirm('Delete machine?')) deleteMachineApi(m.id) }}>🗑</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'10px 14px',fontSize:'11px',color:'var(--tx3)',borderTop:'1px solid var(--bor)'}}>
              <span>{filtered.length} records</span>
            </div>
          </div>
        </>
      )}

      {innerTab === 'form' && (
        <MachineForm machine={editItem} onSave={saveForm} onCancel={() => setInnerTab('list')} />
      )}
    </div>
  )
}

function MachineForm({ machine, onSave, onCancel }) {
  const [form, setForm] = useState({
    machineId: machine?.machineId || '', name: machine?.name || '',
    type: machine?.type || '', mesCode: machine?.mesCode || '',
    oem: machine?.oem || '', model: machine?.model || '',
    serial: machine?.serial || '', tonnage: machine?.tonnage || '',
    plant: machine?.plant || '', dept: machine?.dept || '',
    area: machine?.area || '', locator: machine?.locator || '',
    cycleTime: machine?.cycleTime || '', cavities: machine?.cavities || '',
    pps: machine?.pps || '', clampForce: machine?.clampForce || '',
    shotWeight: machine?.shotWeight || '',
    plcType: machine?.plcType || '', commProtocol: machine?.commProtocol || '',
    ip: machine?.ip || '', port: machine?.port || '',
    tagRun: machine?.tagRun || '', tagProd: machine?.tagProd || '',
    tagReject: machine?.tagReject || '', tagAlarm: machine?.tagAlarm || '',
    tagMode: machine?.tagMode || '',
    pmFreq: machine?.pmFreq || '', lastPmDate: machine?.lastPmDate || '',
    nextPmDate: machine?.nextPmDate || '',
    status: machine?.status || 'Idle', notes: machine?.notes || '',
  })
  const set = (k,v) => setForm(f=>({...f,[k]:v}))

  return (
    <div style={{background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'14px',overflow:'hidden'}}>
      <div style={{padding:'16px 22px',borderBottom:'1px solid var(--bor)',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
        <div style={{fontSize:'13px',fontWeight:600,color:'var(--tx)',display:'flex',alignItems:'center',gap:'7px'}}>
          <span style={{width:'7px',height:'7px',borderRadius:'50%',background:'var(--pur)',display:'inline-block'}}/>
          {machine?.id ? 'Edit Machine' : 'Add Machine'}
        </div>
        <div style={{display:'flex',gap:'8px',alignItems:'center'}}>
          <span style={{fontSize:'11px',color:'var(--tx3)'}}>Fields marked <span style={{color:'var(--red)'}}>*</span> are required</span>
          <button className="btn bgh bsm" onClick={onCancel}>← Back to List</button>
        </div>
      </div>

      {/* Section 1: Basic Identification */}
      <div style={{padding:'16px 22px',borderBottom:'1px solid var(--bor)'}}>
        <div style={{fontSize:'11px',fontWeight:700,textTransform:'uppercase',letterSpacing:'.8px',color:'var(--pur)',marginBottom:'12px'}}>
          <span style={{background:'var(--pur2)',borderRadius:'6px',padding:'3px 8px',border:'1px solid var(--pur)'}}>🪪 Basic Identification</span>
        </div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 2fr 1fr 1fr',gap:'14px',marginBottom:'12px'}}>
          <div className="fgrp">
            <label>Machine ID <span style={{color:'var(--red)'}}>*</span></label>
            <input type="text" placeholder="e.g. ZFP-01" value={form.machineId} onChange={e=>set('machineId',e.target.value)} style={{fontFamily:"'Space Mono',monospace"}}/>
          </div>
          <div className="fgrp">
            <label>Machine Name <span style={{color:'var(--red)'}}>*</span></label>
            <input type="text" placeholder="Full machine name" value={form.name} onChange={e=>set('name',e.target.value)}/>
          </div>
          <div className="fgrp">
            <label>Machine Type <span style={{color:'var(--red)'}}>*</span></label>
            <select value={form.type} onChange={e=>set('type',e.target.value)}>
              <option value="">Select</option>
              <option value="INJECTION">Injection Moulding</option>
              <option value="BLOW">Blow Moulding</option>
              <option value="PRINTING">Printing</option>
              <option value="EXTRUSION">Extrusion</option>
              <option value="ASSEMBLY">Assembly</option>
              <option value="CNC">CNC</option>
              <option value="OTHER">Other</option>
            </select>
          </div>
          <div className="fgrp">
            <label>MES Machine Code</label>
            <input type="text" placeholder="e.g. MES-ZFP-01" value={form.mesCode} onChange={e=>set('mesCode',e.target.value)} style={{fontFamily:"'Space Mono',monospace"}}/>
          </div>
        </div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr 1fr',gap:'14px'}}>
          <div className="fgrp">
            <label>Manufacturer (OEM)</label>
            <input type="text" placeholder="e.g. BMB, JSW, TOYO" value={form.oem} onChange={e=>set('oem',e.target.value)}/>
          </div>
          <div className="fgrp">
            <label>Model Number</label>
            <input type="text" placeholder="e.g. eKW 28Pi/700" value={form.model} onChange={e=>set('model',e.target.value)}/>
          </div>
          <div className="fgrp">
            <label>Serial Number</label>
            <input type="text" placeholder="e.g. SN12345" value={form.serial} onChange={e=>set('serial',e.target.value)}/>
          </div>
          <div className="fgrp">
            <label>Tonnage / Capacity</label>
            <input type="text" placeholder="e.g. 280T" value={form.tonnage} onChange={e=>set('tonnage',e.target.value)}/>
          </div>
        </div>
      </div>

      {/* Section 2: Plant & Location */}
      <div style={{padding:'16px 22px',borderBottom:'1px solid var(--bor)'}}>
        <div style={{fontSize:'11px',fontWeight:700,textTransform:'uppercase',letterSpacing:'.8px',color:'var(--grn)',marginBottom:'12px'}}>
          <span style={{background:'var(--grn2)',borderRadius:'6px',padding:'3px 8px',border:'1px solid var(--grn)'}}>🏭 Plant &amp; Location</span>
        </div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr 1fr',gap:'14px'}}>
          <div className="fgrp">
            <label>Plant <span style={{color:'var(--red)'}}>*</span></label>
            <select value={form.plant} onChange={e=>set('plant',e.target.value)}>
              <option value="">Select</option>
              <option value="FPP">FPP BU</option>
              <option value="IPP">IPP BU</option>
              <option value="ZPC">ZPC BU</option>
            </select>
          </div>
          <div className="fgrp">
            <label>Department</label>
            <select value={form.dept} onChange={e=>set('dept',e.target.value)}>
              <option value="">Select</option>
              <option value="INJECTION">Injection</option>
              <option value="BLOWMOLDIN">Blow Moulding</option>
              <option value="PRINTING">Printing</option>
              <option value="EXTRUSION">Extrusion</option>
              <option value="ASSEMBLY">Assembly</option>
            </select>
          </div>
          <div className="fgrp">
            <label>Area / Bay</label>
            <input type="text" placeholder="e.g. Bay A" value={form.area} onChange={e=>set('area',e.target.value)}/>
          </div>
          <div className="fgrp">
            <label>Locator Code</label>
            <input type="text" placeholder="Auto-generated" value={form.locator} onChange={e=>set('locator',e.target.value)} style={{fontFamily:"'Space Mono',monospace"}}/>
          </div>
        </div>
      </div>

      {/* Section 3: Production Parameters */}
      <div style={{padding:'16px 22px',borderBottom:'1px solid var(--bor)'}}>
        <div style={{fontSize:'11px',fontWeight:700,textTransform:'uppercase',letterSpacing:'.8px',color:'var(--amb)',marginBottom:'12px'}}>
          <span style={{background:'var(--amb2)',borderRadius:'6px',padding:'3px 8px',border:'1px solid var(--amb)'}}>⚙ Production Parameters</span>
        </div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr 1fr 1fr',gap:'14px'}}>
          <div className="fgrp">
            <label>Cycle Time (sec) <span style={{color:'var(--red)'}}>*</span></label>
            <input type="number" placeholder="e.g. 28" value={form.cycleTime} onChange={e=>set('cycleTime',e.target.value)}/>
          </div>
          <div className="fgrp">
            <label>No. of Cavities <span style={{color:'var(--red)'}}>*</span></label>
            <input type="number" placeholder="e.g. 4" value={form.cavities} onChange={e=>set('cavities',e.target.value)}/>
          </div>
          <div className="fgrp">
            <label>Parts Per Shot</label>
            <input type="number" placeholder="e.g. 4" value={form.pps} onChange={e=>set('pps',e.target.value)}/>
          </div>
          <div className="fgrp">
            <label>Clamp Force (T)</label>
            <input type="text" placeholder="e.g. 280" value={form.clampForce} onChange={e=>set('clampForce',e.target.value)}/>
          </div>
          <div className="fgrp">
            <label>Shot Weight (g)</label>
            <input type="text" placeholder="e.g. 450" value={form.shotWeight} onChange={e=>set('shotWeight',e.target.value)}/>
          </div>
        </div>
      </div>

      {/* Section 4: PLC / Connectivity */}
      <div style={{padding:'16px 22px',borderBottom:'1px solid var(--bor)'}}>
        <div style={{fontSize:'11px',fontWeight:700,textTransform:'uppercase',letterSpacing:'.8px',color:'var(--tel)',marginBottom:'12px'}}>
          <span style={{background:'rgba(6,182,212,.12)',borderRadius:'6px',padding:'3px 8px',border:'1px solid var(--tel)'}}>🔌 PLC / Connectivity</span>
        </div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr 1fr',gap:'14px'}}>
          <div className="fgrp">
            <label>PLC Type</label>
            <input type="text" placeholder="e.g. Siemens S7-300" value={form.plcType} onChange={e=>set('plcType',e.target.value)}/>
          </div>
          <div className="fgrp">
            <label>Protocol</label>
            <select value={form.commProtocol} onChange={e=>set('commProtocol',e.target.value)}>
              <option value="">Select</option>
              <option value="OPC-UA">OPC-UA</option>
              <option value="OPC-DA">OPC-DA</option>
              <option value="MQTT">MQTT</option>
              <option value="Modbus TCP">Modbus TCP</option>
              <option value="Modbus RTU">Modbus RTU</option>
              <option value="EtherNet/IP">EtherNet/IP</option>
              <option value="PROFINET">PROFINET</option>
              <option value="S7">S7 (Siemens)</option>
            </select>
          </div>
          <div className="fgrp">
            <label>IP Address</label>
            <input type="text" placeholder="e.g. 192.168.1.10" value={form.ip} onChange={e=>set('ip',e.target.value)} style={{fontFamily:"'Space Mono',monospace"}}/>
          </div>
          <div className="fgrp">
            <label>Port</label>
            <input type="number" placeholder="e.g. 4840" value={form.port} onChange={e=>set('port',e.target.value)} style={{fontFamily:"'Space Mono',monospace"}}/>
          </div>
        </div>
      </div>

      {/* Section 5: OPC / MES Tag Mapping */}
      <div style={{padding:'16px 22px',borderBottom:'1px solid var(--bor)'}}>
        <div style={{fontSize:'11px',fontWeight:700,textTransform:'uppercase',letterSpacing:'.8px',color:'var(--blu)',marginBottom:'12px'}}>
          <span style={{background:'rgba(59,130,246,.1)',borderRadius:'6px',padding:'3px 8px',border:'1px solid var(--blu)'}}>🏷 OPC / MES Tag Mapping</span>
        </div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr 1fr 1fr',gap:'14px'}}>
          <div className="fgrp">
            <label>Tag: Run Status</label>
            <input type="text" placeholder="e.g. ns=2;s=Run" value={form.tagRun} onChange={e=>set('tagRun',e.target.value)} style={{fontFamily:"'Space Mono',monospace",fontSize:'11px'}}/>
          </div>
          <div className="fgrp">
            <label>Tag: Production Count</label>
            <input type="text" placeholder="e.g. ns=2;s=ProdCnt" value={form.tagProd} onChange={e=>set('tagProd',e.target.value)} style={{fontFamily:"'Space Mono',monospace",fontSize:'11px'}}/>
          </div>
          <div className="fgrp">
            <label>Tag: Reject Count</label>
            <input type="text" placeholder="e.g. ns=2;s=Reject" value={form.tagReject} onChange={e=>set('tagReject',e.target.value)} style={{fontFamily:"'Space Mono',monospace",fontSize:'11px'}}/>
          </div>
          <div className="fgrp">
            <label>Tag: Alarm</label>
            <input type="text" placeholder="e.g. ns=2;s=Alarm" value={form.tagAlarm} onChange={e=>set('tagAlarm',e.target.value)} style={{fontFamily:"'Space Mono',monospace",fontSize:'11px'}}/>
          </div>
          <div className="fgrp">
            <label>Tag: Mode</label>
            <input type="text" placeholder="e.g. ns=2;s=Mode" value={form.tagMode} onChange={e=>set('tagMode',e.target.value)} style={{fontFamily:"'Space Mono',monospace",fontSize:'11px'}}/>
          </div>
        </div>
      </div>

      {/* Section 6: PM & Status */}
      <div style={{padding:'16px 22px',borderBottom:'1px solid var(--bor)'}}>
        <div style={{fontSize:'11px',fontWeight:700,textTransform:'uppercase',letterSpacing:'.8px',color:'var(--pur)',marginBottom:'12px'}}>
          <span style={{background:'var(--pur2)',borderRadius:'6px',padding:'3px 8px',border:'1px solid var(--pur)'}}>🔧 Preventive Maintenance</span>
        </div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr 1fr',gap:'14px',marginBottom:'12px'}}>
          <div className="fgrp">
            <label>PM Frequency <span style={{color:'var(--red)'}}>*</span></label>
            <select value={form.pmFreq} onChange={e=>set('pmFreq',e.target.value)}>
              <option value="">Select</option>
              <option value="Daily">Daily</option>
              <option value="Weekly">Weekly</option>
              <option value="Monthly">Monthly</option>
              <option value="Quarterly">Quarterly</option>
              <option value="Annually">Annually</option>
            </select>
          </div>
          <div className="fgrp">
            <label>Last PM Date</label>
            <input type="date" value={form.lastPmDate} onChange={e=>set('lastPmDate',e.target.value)}/>
          </div>
          <div className="fgrp">
            <label>Next PM Date</label>
            <input type="date" value={form.nextPmDate} onChange={e=>set('nextPmDate',e.target.value)}/>
          </div>
          <div className="fgrp">
            <label>Status</label>
            <select value={form.status} onChange={e=>set('status',e.target.value)}>
              <option value="Running">Running</option>
              <option value="Idle">Idle</option>
              <option value="Fault">Fault</option>
              <option value="Maintenance">Maintenance</option>
            </select>
          </div>
        </div>
        <div className="fgrp">
          <label>Notes / Remarks</label>
          <textarea rows={2} placeholder="Any additional notes about this machine..." value={form.notes} onChange={e=>set('notes',e.target.value)} style={{width:'100%',resize:'vertical'}}/>
        </div>
      </div>

      <div style={{padding:'16px 22px',display:'flex',justifyContent:'flex-end',gap:'8px'}}>
        <button className="btn bgh" onClick={onCancel}>Cancel</button>
        <button className="btn bpri" onClick={() => onSave({ ...form, id: machine?.id })}>💾 Save Machine</button>
      </div>
    </div>
  )
}

/* ── Locations Tab ────────────────────────────────────────────────── */
/* ── Locations Tab ────────────────────────────────────────────────── */
/*
  Backend table supports only:
  id, code, name, type, plant, createdBy, updatedBy, isActive, isDeleted, createdAt, updatedAt

  UI mapping:
  code     = Locator Code / Barcode base
  name     = Area / Location Name
  type     = Zone / Location Type
  plant    = Division / BU
  isActive = Active / Inactive
*/

const LOC_TYPE_OPTIONS = [
  { value: 'PRD', label: 'PRD – Production', icon: '🏭', color: 'var(--pur)' },
  { value: 'SIL', label: 'SIL – Silo', icon: '🛢', color: 'var(--amb)' },
  { value: 'STG', label: 'STG – Staging', icon: '📦', color: 'var(--tel)' },
  { value: 'ASM', label: 'ASM – Assembly', icon: '🔩', color: 'var(--blu)' },
  { value: 'QA',  label: 'QA – Quality', icon: '🔍', color: 'var(--grn)' },
  { value: 'RJT', label: 'RJT – Rejected', icon: '✕', color: 'var(--red)' },
  { value: 'HLD', label: 'HLD – Hold', icon: '⏸', color: 'var(--tx3)' },
]

const LOC_TYPE_STYLE = {
  PRD: { background:'var(--pur2)', border:'1px solid var(--pur)', color:'var(--pur)' },
  SIL: { background:'var(--amb2)', border:'1px solid var(--amb)', color:'var(--amb)' },
  STG: { background:'var(--tel2)', border:'1px solid var(--tel)', color:'var(--tel)' },
  ASM: { background:'var(--blu2)', border:'1px solid var(--blu)', color:'var(--blu)' },
  QA:  { background:'var(--grn2)', border:'1px solid var(--grn)', color:'var(--grn)' },
  RJT: { background:'var(--red2)', border:'1px solid var(--red)', color:'var(--red)' },
  HLD: { background:'var(--bg3)', border:'1px solid var(--bor2)', color:'var(--tx3)' },
}

const normalizeLocType = (value) => {
  const v = String(value || '').trim().toUpperCase()

  if (['PRODUCTION', 'PROD'].includes(v)) return 'PRD'
  if (['WAREHOUSE', 'WH', 'STAGING'].includes(v)) return 'STG'
  if (['SILO'].includes(v)) return 'SIL'
  if (['ASSEMBLY'].includes(v)) return 'ASM'
  if (['QUALITY', 'QC'].includes(v)) return 'QA'
  if (['SCRAP', 'REJECTED'].includes(v)) return 'RJT'
  if (['HOLD'].includes(v)) return 'HLD'

  return ['PRD','SIL','STG','ASM','QA','RJT','HLD'].includes(v) ? v : 'PRD'
}

const getLocTypeLabel = (type) => {
  const normalized = normalizeLocType(type)
  return LOC_TYPE_OPTIONS.find(x => x.value === normalized)?.label || normalized
}

const getLocTypeIcon = (type) => {
  const normalized = normalizeLocType(type)
  return LOC_TYPE_OPTIONS.find(x => x.value === normalized)?.icon || '📍'
}

const getLocStatus = (loc) => {
  if (loc?.status) return loc.status
  return loc?.isActive === false ? 'Inactive' : 'Active'
}

const getLocationBarcodeValue = (loc) => {
  const code = String(loc?.code || '').trim()
  return code ? `LOC-${code}` : 'LOC-BARCODE'
}

const getLocationDerivedLevel = (loc) => {
  const code = String(loc?.code || '')
  const match = code.match(/L\d+/i)
  return match ? match[0].toUpperCase() : 'L1'
}

const getLocationDerivedCapacity = (loc) => {
  const code = String(loc?.code || loc?.id || '')
  let n = 0
  for (let i = 0; i < code.length; i++) n += code.charCodeAt(i)
  const maxLPN = 8 + (n % 18)
  const usedLPN = loc?.isActive === false ? 0 : Math.min(maxLPN, n % maxLPN)
  return { maxLPN, usedLPN }
}

const normalizeLocation = (loc = {}) => {
  const code = String(loc.code || '').trim()
  const name = String(loc.name || '').trim()
  const type = normalizeLocType(loc.type)
  const plant = String(loc.plant || 'FPP').trim().toUpperCase()
  const { maxLPN, usedLPN } = getLocationDerivedCapacity({ ...loc, code })

  return {
    ...loc,
    id: loc.id,
    code,
    name,
    type,
    plant,
    barcode: getLocationBarcodeValue({ code }),
    level: getLocationDerivedLevel({ code }),
    maxLPN,
    usedLPN,
    status: getLocStatus(loc),
    isActive: loc.isActive !== false,
    createdAt: loc.createdAt,
    updatedAt: loc.updatedAt,
  }
}

const buildLocationPayload = (form) => ({
  code: String(form.code || '').trim().toUpperCase(),
  name: String(form.name || '').trim(),
  type: normalizeLocType(form.type),
  plant: String(form.plant || 'FPP').trim().toUpperCase(),
  isActive: form.status !== 'Inactive',
})

function drawSetupBarcodeBars(text, width = 340, height = 50) {
  const barW = 2.2
  const gap = 1.1
  let bars = []
  const value = String(text || 'LOC-BARCODE')

  for (let i = 0; i < value.length; i++) {
    const c = value.charCodeAt(i)
    bars.push((c % 3 === 0 ? 3 : c % 3 === 1 ? 2 : 1.5) * barW)
    bars.push(gap + (i % 4 === 0 ? gap : 0))
  }

  bars = [
    barW * 2,
    gap,
    barW * 2,
    gap * 2,
    ...bars,
    gap * 2,
    barW * 2,
    gap,
    barW * 2,
  ]

  const rects = []
  let x = 10

  bars.forEach((w, i) => {
    if (i % 2 === 0) {
      rects.push(
        <rect
          key={i}
          x={Number(x.toFixed(1))}
          y={4}
          width={Number(w.toFixed(1))}
          height={height - 8}
          fill="#000"
        />,
      )
    }
    x += w
  })

  return {
    viewBox: `0 0 ${width} ${height}`,
    rects,
  }
}

function LocationsTab() {
  const { showToast } = useApp()
  const [innerTab, setInnerTab] = useState('list')
  const [editLoc, setEditLoc] = useState(null)
  const [barcodeLoc, setBarcodeLoc] = useState(null)
  const [barcodeBatch, setBarcodeBatch] = useState([])
  const [filter, setFilter] = useState({ plant:'', type:'', status:'', search:'' })
  const [showCount, setShowCount] = useState(50)
  const [page, setPage] = useState(1)

  const { items: apiLocs, refetch: refetchLocs } = useList(setupService.getLocations)
  const [locations, setLocations] = useState([])

  useEffect(() => {
    setLocations(Array.isArray(apiLocs) ? apiLocs.map(normalizeLocation) : [])
  }, [apiLocs])

  const { mutate: createLocApi } = useMutation(setupService.createLocation, {
    onSuccess: () => {
      refetchLocs()
      showToast('Location added', 'success')
      setInnerTab('list')
    },
    onError: (e) => showToast(e?.message || 'Failed to add location', 'error'),
  })

  const { mutate: updateLocApi } = useMutation(
    (data) => setupService.updateLocation(data.id, data),
    {
      onSuccess: () => {
        refetchLocs()
        showToast('Location updated', 'success')
        setInnerTab('list')
      },
      onError: (e) => showToast(e?.message || 'Failed to update location', 'error'),
    },
  )

  const { mutate: deleteLocApi } = useMutation(setupService.deleteLocation, {
    onSuccess: () => {
      refetchLocs()
      showToast('Location removed', 'warning')
    },
    onError: (e) => showToast(e?.message || 'Failed to delete location', 'error'),
  })

  const filtered = locations.filter(l => {
    if (filter.plant && l.plant !== filter.plant) return false
    if (filter.type && l.type !== filter.type) return false
    if (filter.status && l.status !== filter.status) return false

    const search = filter.search.toLowerCase().trim()
    if (search) {
      const hay = [
        l.code,
        l.name,
        l.type,
        l.plant,
        l.barcode,
        l.status,
      ].join(' ').toLowerCase()

      if (!hay.includes(search)) return false
    }

    return true
  })

  const totalLoc = locations.length
  const activeLoc = locations.filter(l => l.status === 'Active').length
  const inactiveLoc = locations.filter(l => l.status === 'Inactive').length
  const production = locations.filter(l => l.type === 'PRD').length
  const staging = locations.filter(l => ['SIL','STG'].includes(l.type)).length
  const assembly = locations.filter(l => l.type === 'ASM').length
  const totalLPN = locations.reduce((s,l) => s + Number(l.maxLPN || 0), 0)
  const usedLPN = locations.reduce((s,l) => s + Number(l.usedLPN || 0), 0)
  const utilPct = totalLPN > 0 ? Math.round((usedLPN / totalLPN) * 100) : 0

  const totalPages = Math.max(1, Math.ceil(filtered.length / showCount))
  const safePage = Math.min(page, totalPages)
  const start = (safePage - 1) * showCount
  const rows = filtered.slice(start, start + showCount)

  const openForm = (loc) => {
    setEditLoc(loc ? normalizeLocation(loc) : {})
    setInnerTab('addedit')
  }

  const saveLoc = (data) => {
    const payload = buildLocationPayload(data)

    if (!payload.code || !payload.name || !payload.type || !payload.plant) {
      showToast('Code, Name, Type and Plant are required', 'error')
      return
    }

    if (data.id) updateLocApi({ id: data.id, ...payload })
    else createLocApi(payload)
  }

  const clearFilter = () => {
    setFilter({ plant:'', type:'', status:'', search:'' })
    setPage(1)
  }

  const openBarcodeModal = (loc) => {
    setBarcodeBatch([])
    setBarcodeLoc(normalizeLocation(loc))
  }

  const openBatchBarcodeModal = () => {
    if (!filtered.length) {
      showToast('No locations available for barcode printing', 'warning')
      return
    }

    setBarcodeLoc(null)
    setBarcodeBatch(filtered.map(normalizeLocation))
  }

  const closeBarcodeModal = () => {
    setBarcodeLoc(null)
    setBarcodeBatch([])
  }

  const exportLocations = () => {
    const headers = ['ID','Code','Name','Type','Plant','Status','Barcode','Created At','Updated At']
    const body = filtered.map(l => [
      l.id,
      l.code,
      l.name,
      l.type,
      l.plant,
      l.status,
      l.barcode,
      l.createdAt || '',
      l.updatedAt || '',
    ].join('\t')).join('\n')

    const blob = new Blob([headers.join('\t') + '\n' + body], { type:'text/tab-separated-values' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = 'Inventory_Locations.xls'
    a.click()

    showToast('Inventory_Locations.xls downloaded', 'success')
  }

  return (
    <div>
      <div style={{display:'flex',gap:'6px',marginBottom:'18px'}}>
        <button className={`bq-itab ${innerTab === 'list' ? 'on' : ''}`} onClick={() => setInnerTab('list')}>📍 Location List</button>
        <button className={`bq-itab ${innerTab === 'card' ? 'on' : ''}`} onClick={() => setInnerTab('card')}>🗃 Card View</button>
        <button className={`bq-itab ${innerTab === 'zone' ? 'on' : ''}`} onClick={() => setInnerTab('zone')}>🗺 Zone Map</button>
        <button className={`bq-itab ${innerTab === 'addedit' ? 'on' : ''}`} onClick={() => openForm(null)}>➕ Add Location</button>
      </div>

      <div style={{display:'grid',gridTemplateColumns:'repeat(6,1fr)',gap:'10px',marginBottom:'14px'}}>
        {[
          ['Total Locations', totalLoc, 'var(--blu)', 'All saved records'],
          ['Active', activeLoc, 'var(--grn)', `${inactiveLoc} inactive`],
          ['Production', production, 'var(--pur)', 'PRD zone'],
          ['Silo / Staging', staging, 'var(--amb)', 'SIL + STG'],
          ['Assembly', assembly, 'var(--tel)', 'ASM zone'],
          ['Utilization', `${utilPct}%`, 'var(--red)', `${usedLPN}/${totalLPN} virtual LPN`],
        ].map(([l,v,c,s]) => (
          <div key={l} style={{background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'var(--r)',padding:'12px 14px',position:'relative',overflow:'hidden'}}>
            <div style={{fontSize:'10px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',fontWeight:600,marginBottom:'5px'}}>{l}</div>
            <div style={{fontFamily:"'Space Mono',monospace",fontSize:'20px',fontWeight:700,color:c}}>{v}</div>
            <div style={{fontSize:'10px',color:'var(--tx3)',marginTop:'4px'}}>{s}</div>
          </div>
        ))}
      </div>

      {innerTab === 'list' && (
        <>
          <div style={{background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'14px',padding:'13px 18px',marginBottom:'14px',display:'flex',alignItems:'flex-end',gap:'10px',flexWrap:'wrap'}}>
            <div className="fgrp" style={{minWidth:'120px',marginBottom:0}}>
              <label>Division / BU</label>
              <select style={{fontSize:'12px',padding:'6px 9px'}} value={filter.plant} onChange={e => { setFilter(f=>({...f,plant:e.target.value})); setPage(1) }}>
                <option value="">All</option>
                <option value="FPP">FPP</option>
                <option value="IPP">IPP</option>
                <option value="ZPC">ZPC</option>
              </select>
            </div>

            <div className="fgrp" style={{minWidth:'150px',marginBottom:0}}>
              <label>Zone / Type</label>
              <select style={{fontSize:'12px',padding:'6px 9px'}} value={filter.type} onChange={e => { setFilter(f=>({...f,type:e.target.value})); setPage(1) }}>
                <option value="">All Zones</option>
                {LOC_TYPE_OPTIONS.map(t => (
                  <option key={t.value} value={t.value}>{t.label}</option>
                ))}
              </select>
            </div>

            <div className="fgrp" style={{minWidth:'120px',marginBottom:0}}>
              <label>Status</label>
              <select style={{fontSize:'12px',padding:'6px 9px'}} value={filter.status} onChange={e => { setFilter(f=>({...f,status:e.target.value})); setPage(1) }}>
                <option value="">All</option>
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </select>
            </div>

            <div className="fgrp" style={{flex:1,minWidth:'190px',marginBottom:0}}>
              <label>Search</label>
              <input type="text" placeholder="Code, name, barcode, plant..." style={{fontSize:'12px',padding:'6px 9px'}} value={filter.search} onChange={e => { setFilter(f=>({...f,search:e.target.value})); setPage(1) }} />
            </div>

            <div style={{display:'flex',gap:'6px',alignItems:'flex-end',flexWrap:'wrap'}}>
              <button className="btn bpri bsm" onClick={() => openForm(null)}>+ Add Location</button>
              <button className="btn bgh bsm" onClick={exportLocations}>📥 Export</button>
              <button className="btn bgh bsm" onClick={openBatchBarcodeModal}>🖨 Print Barcodes</button>
              <button className="btn bgh bsm" onClick={clearFilter}>Clear</button>
            </div>
          </div>

          <div style={{background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'14px',overflow:'hidden',overflowX:'auto'}}>
            <div style={{padding:'11px 16px',borderBottom:'1px solid var(--bor)',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
              <div style={{fontSize:'13px',fontWeight:600,color:'var(--tx)',display:'flex',alignItems:'center',gap:'7px'}}>
                <span style={{width:'7px',height:'7px',borderRadius:'50%',background:'var(--grn)',display:'inline-block'}}/>
                Location Registry
              </div>

              <div style={{display:'flex',alignItems:'center',gap:'8px'}}>
                <span style={{fontSize:'11px',color:'var(--tx3)'}}>{filtered.length} location{filtered.length !== 1 ? 's' : ''}</span>
                <select value={showCount} onChange={e => { setShowCount(Number(e.target.value)); setPage(1) }} style={{fontSize:'11px',padding:'3px 6px',border:'1px solid var(--bor)',borderRadius:'7px',background:'var(--bg3)',width:'70px'}}>
                  <option value={25}>25</option>
                  <option value={50}>50</option>
                  <option value={100}>100</option>
                </select>
              </div>
            </div>

            <table style={{width:'100%',borderCollapse:'collapse',fontSize:'12px',minWidth:'1080px'}}>
              <thead>
                <tr style={{background:'var(--bg3)'}}>
                  {['#','Locator Code','Barcode','Division','Zone / Type','Area / Name','Level','Capacity','Status','Created','Updated','Action'].map((h,i) => (
                    <th key={h} style={{padding:'8px 12px',textAlign:i === 11 ? 'center' : 'left',fontSize:'10px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',borderBottom:'1px solid var(--bor)',width:i === 0 ? '36px' : i === 11 ? '150px' : 'auto'}}>{h}</th>
                  ))}
                </tr>
              </thead>

              <tbody>
                {rows.length === 0 ? (
                  <tr>
                    <td colSpan={12} style={{textAlign:'center',padding:'28px',color:'var(--tx3)'}}>
                      No locations match your filters.
                    </td>
                  </tr>
                ) : rows.map((l, i) => {
                  const pct = l.maxLPN > 0 ? Math.round((l.usedLPN / l.maxLPN) * 100) : 0
                  const barColor = pct >= 90 ? 'var(--red)' : pct >= 60 ? 'var(--amb)' : 'var(--grn)'
                  const typeStyle = LOC_TYPE_STYLE[l.type] || LOC_TYPE_STYLE.PRD

                  return (
                    <tr key={l.id || l.code}>
                      <td style={{padding:'8px 12px',fontFamily:"'Space Mono',monospace",fontSize:'10px',color:'var(--tx3)'}}>{start + i + 1}</td>

                      <td style={{padding:'8px 12px'}}>
                        <div style={{fontFamily:"'Space Mono',monospace",fontSize:'11px',color:'var(--pur)',fontWeight:700}}>{l.code}</div>
                        <div style={{fontSize:'9px',color:'var(--tx3)',marginTop:'1px'}}>ID: {l.id}</div>
                      </td>

                      <td style={{padding:'8px 12px',fontFamily:"'Space Mono',monospace",fontSize:'10px',color:'var(--tel)'}}>{l.barcode}</td>

                      <td style={{padding:'8px 12px',fontFamily:"'Space Mono',monospace",fontSize:'10px',fontWeight:700,color:'var(--tx2)'}}>{l.plant}</td>

                      <td style={{padding:'8px 12px'}}>
                        <span style={{display:'inline-flex',alignItems:'center',gap:'4px',padding:'2px 8px',borderRadius:'20px',fontSize:'9px',fontWeight:700,...typeStyle}}>
                          {getLocTypeIcon(l.type)} {l.type}
                        </span>
                      </td>

                      <td style={{padding:'8px 12px'}}>
                        <div style={{fontSize:'11px',fontWeight:600,color:'var(--tx)'}}>{l.name}</div>
                        <div style={{fontSize:'9px',color:'var(--tx3)',marginTop:'1px'}}>{getLocTypeLabel(l.type)}</div>
                      </td>

                      <td style={{padding:'8px 12px',fontFamily:"'Space Mono',monospace",fontSize:'10px'}}>{l.level}</td>

                      <td style={{padding:'8px 12px',minWidth:'120px'}}>
                        <div style={{fontSize:'10px',color:'var(--tx3)',marginBottom:'3px'}}>{l.usedLPN}/{l.maxLPN} LPN</div>
                        <div style={{height:'5px',background:'var(--bg3)',borderRadius:'5px',overflow:'hidden'}}>
                          <div style={{height:'100%',width:`${Math.min(100,pct)}%`,background:barColor,borderRadius:'5px'}} />
                        </div>
                      </td>

                      <td style={{padding:'8px 12px'}}>
                        <span className={`bdg ${l.status === 'Active' ? 'bd' : 'bpa'}`}>{l.status}</span>
                      </td>

                      <td style={{padding:'8px 12px',fontSize:'10px',color:'var(--tx3)'}}>
                        {l.createdAt ? new Date(l.createdAt).toLocaleDateString() : '—'}
                      </td>

                      <td style={{padding:'8px 12px',fontSize:'10px',color:'var(--tx3)'}}>
                        {l.updatedAt ? new Date(l.updatedAt).toLocaleDateString() : '—'}
                      </td>

                      <td style={{padding:'8px 12px',textAlign:'center'}}>
                        <div style={{display:'flex',gap:'4px',justifyContent:'center'}}>
                          <button className="btn bgh bsm" onClick={() => openForm(l)}>Edit</button>
                          <button className="btn bgh bsm" onClick={() => openBarcodeModal(l)}>🏷</button>
                          <button className="btn bdan bsm" onClick={() => { if(window.confirm(`Delete ${l.code}?`)) deleteLocApi(l.id) }}>🗑</button>
                        </div>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>

            <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'10px 14px',fontSize:'11px',color:'var(--tx3)',borderTop:'1px solid var(--bor)'}}>
              <span>{filtered.length ? `Showing ${start + 1}–${Math.min(start + showCount, filtered.length)} of ${filtered.length}` : 'No records'}</span>
              <div style={{display:'flex',gap:'6px'}}>
                <button className="btn bgh bsm" disabled={safePage <= 1} onClick={() => setPage(p => Math.max(1, p - 1))}>← Prev</button>
                <button className="btn bgh bsm" disabled={safePage >= totalPages} onClick={() => setPage(p => Math.min(totalPages, p + 1))}>Next →</button>
              </div>
            </div>
          </div>
        </>
      )}

      {innerTab === 'card' && (
        <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(255px,1fr))',gap:'12px'}}>
          {filtered.length === 0 ? (
            <div style={{gridColumn:'1/-1',background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'14px',padding:'36px',textAlign:'center',color:'var(--tx3)'}}>
              No locations found.
            </div>
          ) : filtered.map(l => {
            const pct = l.maxLPN > 0 ? Math.round((l.usedLPN / l.maxLPN) * 100) : 0
            const typeStyle = LOC_TYPE_STYLE[l.type] || LOC_TYPE_STYLE.PRD

            return (
              <div key={l.id || l.code} style={{background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'12px',padding:'14px',position:'relative',overflow:'hidden'}}>
                <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:'8px'}}>
                  <span style={{fontFamily:"'Space Mono',monospace",fontSize:'11px',fontWeight:700,color:'var(--pur)'}}>{l.code}</span>
                  <span style={{display:'inline-flex',alignItems:'center',gap:'4px',padding:'2px 8px',borderRadius:'20px',fontSize:'9px',fontWeight:700,...typeStyle}}>
                    {getLocTypeIcon(l.type)} {l.type}
                  </span>
                </div>

                <div style={{fontSize:'13px',fontWeight:600,color:'var(--tx)',marginBottom:'2px'}}>{l.name}</div>
                <div style={{fontSize:'11px',color:'var(--tx3)',marginBottom:'10px'}}>{l.plant} · {l.level} · {l.barcode}</div>

                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'8px',marginBottom:'10px'}}>
                  <div style={{background:'var(--bg3)',border:'1px solid var(--bor)',borderRadius:'8px',padding:'8px'}}>
                    <div style={{fontSize:'9px',color:'var(--tx3)',textTransform:'uppercase',letterSpacing:'.7px'}}>Virtual LPN</div>
                    <div style={{fontFamily:"'Space Mono',monospace",fontSize:'14px',fontWeight:700,color:'var(--tx)',marginTop:'2px'}}>{l.usedLPN}/{l.maxLPN}</div>
                  </div>
                  <div style={{background:'var(--bg3)',border:'1px solid var(--bor)',borderRadius:'8px',padding:'8px'}}>
                    <div style={{fontSize:'9px',color:'var(--tx3)',textTransform:'uppercase',letterSpacing:'.7px'}}>Status</div>
                    <div style={{fontSize:'11px',fontWeight:700,color:l.status === 'Active' ? 'var(--grn)' : 'var(--amb)',marginTop:'3px'}}>{l.status}</div>
                  </div>
                </div>

                <div style={{height:'6px',background:'var(--bg3)',borderRadius:'6px',overflow:'hidden',marginBottom:'12px'}}>
                  <div style={{height:'100%',width:`${Math.min(100,pct)}%`,background:pct>=90?'var(--red)':pct>=60?'var(--amb)':'var(--grn)'}} />
                </div>

                <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',gap:'6px'}}>
                  <button className="btn bgh bsm" onClick={() => openBarcodeModal(l)}>🏷 Barcode</button>
                  <button className="btn bgh bsm" onClick={() => openForm(l)}>Edit</button>
                </div>
              </div>
            )
          })}
        </div>
      )}

      {innerTab === 'zone' && (
        <div style={{background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'14px',padding:'18px'}}>
          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:'16px'}}>
            <div style={{fontSize:'13px',fontWeight:600,color:'var(--tx)',display:'flex',alignItems:'center',gap:'7px'}}>
              <span style={{width:'7px',height:'7px',borderRadius:'50%',background:'var(--pur)',display:'inline-block'}}/>
              Zone Map
            </div>
            <button className="btn bgh bsm" onClick={openBatchBarcodeModal}>🖨 Print Zone Barcodes</button>
          </div>

          <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:'12px'}}>
            {LOC_TYPE_OPTIONS.map(zone => {
              const list = filtered.filter(l => l.type === zone.value)
              const typeStyle = LOC_TYPE_STYLE[zone.value] || LOC_TYPE_STYLE.PRD

              return (
                <div key={zone.value} style={{background:'var(--bg3)',border:'1px solid var(--bor)',borderRadius:'12px',padding:'12px',minHeight:'150px'}}>
                  <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:'10px'}}>
                    <span style={{display:'inline-flex',alignItems:'center',gap:'5px',padding:'3px 9px',borderRadius:'20px',fontSize:'10px',fontWeight:700,...typeStyle}}>
                      {zone.icon} {zone.value}
                    </span>
                    <span style={{fontSize:'11px',color:'var(--tx3)'}}>{list.length}</span>
                  </div>

                  <div style={{fontSize:'11px',fontWeight:600,color:'var(--tx)',marginBottom:'8px'}}>{zone.label}</div>

                  <div style={{display:'flex',flexWrap:'wrap',gap:'5px'}}>
                    {list.length === 0 ? (
                      <div style={{fontSize:'11px',color:'var(--tx3)',padding:'10px 0'}}>No locations</div>
                    ) : list.slice(0,30).map(l => (
                      <button
                        key={l.id || l.code}
                        onClick={() => openForm(l)}
                        title={`${l.code} · ${l.name}`}
                        style={{
                          fontFamily:"'Space Mono',monospace",
                          fontSize:'9px',
                          border:'1px solid var(--bor2)',
                          background:l.status === 'Active' ? 'var(--bg2)' : 'var(--amb2)',
                          color:l.status === 'Active' ? 'var(--tx2)' : 'var(--amb)',
                          borderRadius:'6px',
                          padding:'4px 7px',
                          cursor:'pointer',
                        }}
                      >
                        {l.code}
                      </button>
                    ))}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}

      {innerTab === 'addedit' && (
        <LocationForm location={editLoc} onSave={saveLoc} onCancel={() => setInnerTab('list')} />
      )}

      {(barcodeLoc || barcodeBatch.length > 0) && (
        <LocationBarcodeModal
          location={barcodeLoc}
          locations={barcodeBatch}
          onClose={closeBarcodeModal}
        />
      )}
    </div>
  )
}

function LocationForm({ location, onSave, onCancel }) {
  const loc = normalizeLocation(location || {})

  const [form, setForm] = useState({
    id: loc.id || '',
    code: loc.code || '',
    name: loc.name || '',
    type: loc.type || 'PRD',
    plant: loc.plant || 'FPP',
    status: loc.status || 'Active',
  })

  const set = (k,v) => setForm(f => ({ ...f, [k]: v }))

  const autoCode = () => {
    const type = normalizeLocType(form.type)
    const namePart = String(form.name || '')
      .replace(/[^a-z0-9]/gi, '')
      .toUpperCase()
      .slice(0, 10)

    const code = `${type}${namePart || 'AREA'}L1`
    set('code', code)
  }

  const submit = () => {
    const payload = buildLocationPayload(form)

    if (!payload.code || !payload.name || !payload.type || !payload.plant) {
      alert('Code, Name, Type and Plant are required.')
      return
    }

    onSave({ id: form.id, ...payload })
  }

  const previewLoc = normalizeLocation({
    ...form,
    isActive: form.status !== 'Inactive',
  })

  return (
    <div style={{background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'14px',overflow:'hidden'}}>
      <div style={{padding:'16px 22px',borderBottom:'1px solid var(--bor)',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
        <div style={{fontSize:'13px',fontWeight:600,color:'var(--tx)',display:'flex',alignItems:'center',gap:'7px'}}>
          <span style={{width:'7px',height:'7px',borderRadius:'50%',background:'var(--grn)',display:'inline-block'}}/>
          {form.id ? 'Edit Location' : 'Add Location'}
        </div>

        <div style={{display:'flex',gap:'8px',alignItems:'center'}}>
          <span style={{fontSize:'11px',color:'var(--tx3)'}}>
            Saving only real DB fields: code, name, type, plant, isActive
          </span>
          <button className="btn bgh bsm" onClick={onCancel}>← Back to List</button>
        </div>
      </div>

      <div style={{display:'grid',gridTemplateColumns:'1fr 340px',gap:'18px',padding:'18px 22px'}}>
        <div>
          <div style={{paddingBottom:'16px',borderBottom:'1px solid var(--bor)',marginBottom:'16px'}}>
            <div style={{fontSize:'11px',fontWeight:700,textTransform:'uppercase',letterSpacing:'.8px',color:'var(--pur)',marginBottom:'12px'}}>
              <span style={{background:'var(--pur2)',borderRadius:'6px',padding:'3px 8px',border:'1px solid var(--pur)'}}>📍 Location Identity</span>
            </div>

            <div style={{display:'grid',gridTemplateColumns:'1fr 2fr',gap:'14px',marginBottom:'14px'}}>
              <div className="fgrp">
                <label>Locator Code <span style={{color:'var(--red)'}}>*</span></label>
                <input
                  value={form.code}
                  onChange={e=>set('code', e.target.value.toUpperCase())}
                  placeholder="PRDZFP002L1"
                  style={{fontFamily:"'Space Mono',monospace"}}
                />
              </div>

              <div className="fgrp">
                <label>Location Name / Area <span style={{color:'var(--red)'}}>*</span></label>
                <input
                  value={form.name}
                  onChange={e=>set('name', e.target.value)}
                  placeholder="ZFP002 / Bay A / Staging Area"
                />
              </div>
            </div>

            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:'14px'}}>
              <div className="fgrp">
                <label>Division / BU <span style={{color:'var(--red)'}}>*</span></label>
                <select value={form.plant} onChange={e=>set('plant', e.target.value)}>
                  <option value="FPP">FPP BU</option>
                  <option value="IPP">IPP BU</option>
                  <option value="ZPC">ZPC BU</option>
                </select>
              </div>

              <div className="fgrp">
                <label>Zone / Type <span style={{color:'var(--red)'}}>*</span></label>
                <select value={form.type} onChange={e=>set('type', e.target.value)}>
                  {LOC_TYPE_OPTIONS.map(t => (
                    <option key={t.value} value={t.value}>{t.label}</option>
                  ))}
                </select>
              </div>

              <div className="fgrp">
                <label>Status</label>
                <select value={form.status} onChange={e=>set('status', e.target.value)}>
                  <option value="Active">Active</option>
                  <option value="Inactive">Inactive</option>
                </select>
              </div>
            </div>

            <div style={{display:'flex',gap:'8px',marginTop:'14px'}}>
              <button className="btn bgh bsm" onClick={autoCode}>⚡ Auto Code</button>
              <button className="btn bgh bsm" onClick={() => setForm({ id: form.id, code:'', name:'', type:'PRD', plant:'FPP', status:'Active' })}>Clear</button>
            </div>
          </div>

          <div style={{padding:'12px 14px',background:'var(--blu3)',border:'1px solid var(--blu2)',borderRadius:'10px',fontSize:'12px',color:'var(--blu)'}}>
            <b>Note:</b> Barcode, level, and capacity are generated for HTML-style display only. They are not saved because your location table does not have those columns.
          </div>
        </div>

        <div>
          <div style={{fontSize:'10px',color:'var(--tx3)',textTransform:'uppercase',letterSpacing:'1px',fontWeight:700,marginBottom:'8px'}}>
            Barcode Preview
          </div>
          <SingleLocationBarcodeCard loc={previewLoc} compact />
        </div>
      </div>

      <div style={{padding:'14px 22px',background:'var(--bg3)',borderTop:'1px solid var(--bor)',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
        <span style={{fontSize:'11px',color:'var(--tx3)'}}>Fields marked <span style={{color:'var(--red)'}}>*</span> are required</span>

        <div style={{display:'flex',gap:'8px'}}>
          <button className="btn bgh bsm" onClick={onCancel}>Cancel</button>
          <button className="btn bpri bsm" onClick={submit}>💾 Save Location</button>
        </div>
      </div>
    </div>
  )
}

function LocationBarcodeModal({ location, locations = [], onClose }) {
  const [copies, setCopies] = useState(1)
  const isBatch = locations.length > 0
  const rows = isBatch ? locations : location ? [location] : []

  return (
    <div
      className="modal-bg on"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose()
      }}
      style={{zIndex:900,backdropFilter:'blur(4px)'}}
    >
      <div
        className="modal"
        onMouseDown={(event) => event.stopPropagation()}
        style={{
          width: isBatch ? '760px' : '460px',
          maxWidth:'96vw',
          padding:'20px 22px',
          borderRadius:'var(--rxl)',
        }}
      >
        <button className="mclose" onClick={onClose} type="button">✕</button>

        <div className="mtit" style={{marginBottom:'4px',display:'flex',alignItems:'center',gap:'8px'}}>
          <span style={{width:'28px',height:'28px',borderRadius:'8px',background:'var(--grn)',color:'#fff',display:'inline-flex',alignItems:'center',justifyContent:'center',fontSize:'14px'}}>🏷</span>
          {isBatch ? 'Print Location Barcodes' : 'Location Barcode'}
        </div>

        <div style={{fontSize:'11px',color:'var(--tx3)',marginBottom:'14px',paddingLeft:'36px'}}>
          {isBatch ? `${rows.length} filtered locations ready for printing` : `Barcode preview for ${location?.code || 'Location'}`}
        </div>

        {!isBatch && location && (
          <SingleLocationBarcodeCard loc={location} />
        )}

        {isBatch && (
          <div style={{maxHeight:'430px',overflowY:'auto',border:'1px solid var(--bor)',borderRadius:'12px',background:'var(--bg3)',padding:'10px',display:'grid',gridTemplateColumns:'repeat(2, 1fr)',gap:'10px'}}>
            {rows.map(loc => (
              <SingleLocationBarcodeCard key={loc.id || loc.code} loc={loc} compact />
            ))}
          </div>
        )}

        <div style={{display:'grid',gridTemplateColumns:'1fr auto',gap:'10px',alignItems:'end',marginTop:'14px',paddingTop:'14px',borderTop:'1px solid var(--bor)'}}>
          <div>
            <label style={{fontSize:'9px',textTransform:'uppercase',letterSpacing:'.8px',color:'var(--tx3)',fontWeight:700,display:'block',marginBottom:'4px'}}>
              Printer
            </label>
            <select style={{width:'100%',background:'var(--bg3)',border:'1px solid var(--bor2)',borderRadius:'8px',padding:'8px 10px',fontSize:'12px',color:'var(--tx)',fontFamily:"'DM Sans',sans-serif",outline:'none'}}>
              <option>Zebra ZT410 — Location Labels</option>
              <option>Zebra ZT230 — Warehouse Bay</option>
              <option>Default Printer</option>
            </select>
          </div>

          <div>
            <label style={{fontSize:'9px',textTransform:'uppercase',letterSpacing:'.8px',color:'var(--tx3)',fontWeight:700,display:'block',marginBottom:'4px'}}>
              Copies
            </label>
            <input
              type="number"
              min={1}
              max={20}
              value={copies}
              onChange={(e) => setCopies(Math.max(1, Math.min(20, Number(e.target.value) || 1)))}
              style={{width:'68px',background:'var(--bg3)',border:'1px solid var(--bor2)',borderRadius:'8px',padding:'8px 10px',fontSize:'13px',color:'var(--tx)',fontFamily:"'Space Mono',monospace",outline:'none',textAlign:'center'}}
            />
          </div>
        </div>

        <div className="mfooter" style={{marginTop:'14px',paddingTop:'14px'}}>
          <button className="btn bgh" onClick={onClose} type="button">Cancel</button>
          <button className="btn bpri" onClick={() => window.print()} type="button">
            🖨 Print {isBatch ? `${rows.length} Barcodes` : 'Barcode'}
          </button>
        </div>
      </div>
    </div>
  )
}

function SingleLocationBarcodeCard({ loc, compact = false }) {
  const barcodeValue = getLocationBarcodeValue(loc)
  const barcode = drawSetupBarcodeBars(barcodeValue, compact ? 280 : 340, compact ? 44 : 50)
  const typeStyle = LOC_TYPE_STYLE[loc?.type] || LOC_TYPE_STYLE.PRD
  const pct = Number(loc?.maxLPN || 0) > 0
    ? Math.round((Number(loc?.usedLPN || 0) / Number(loc?.maxLPN || 0)) * 100)
    : 0

  return (
    <div style={{background:'#fff',border:'1px solid #c9d6ce',borderRadius:compact?'8px':'10px',padding:compact?'10px 11px':'13px 15px',color:'#111',fontFamily:'Arial, sans-serif',boxShadow:compact?'none':'0 3px 16px rgba(0,0,0,.12)'}}>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',borderBottom:'2px solid #111',paddingBottom:compact?'6px':'8px',marginBottom:compact?'7px':'10px'}}>
        <div>
          <div style={{fontSize:compact?'17px':'20px',fontWeight:900,color:'#1a5e2a',letterSpacing:'-1px',fontFamily:"'Arial Black', Arial, sans-serif",lineHeight:1}}>
            Zamil <span style={{color:'#2a7a3a',fontSize:compact?'12px':'15px'}}>✔</span>
          </div>
          <div style={{fontSize:compact?'8px':'9px',color:'#1a5e2a',fontWeight:700,lineHeight:1.2}}>Plastics</div>
        </div>

        <div style={{textAlign:'right',fontSize:compact?'8px':'9px',textTransform:'uppercase',color:'#555',fontWeight:700,letterSpacing:'.5px'}}>
          Location Label
        </div>
      </div>

      <div style={{textAlign:'center',fontFamily:"'Courier New', monospace",fontSize:compact?'17px':'22px',fontWeight:900,color:'#111',letterSpacing:'.8px',marginBottom:compact?'4px':'6px'}}>
        {loc?.code || '—'}
      </div>

      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',border:'1px solid #cfd8d2',marginBottom:compact?'7px':'9px'}}>
        <div style={{padding:compact?'5px 7px':'6px 8px',borderRight:'1px solid #cfd8d2'}}>
          <div style={{fontSize:'8px',textTransform:'uppercase',color:'#1a5e2a',fontWeight:800}}>Division</div>
          <div style={{fontSize:compact?'10px':'11px',fontWeight:800,fontFamily:"'Courier New',monospace"}}>{loc?.plant || 'FPP'}</div>
        </div>

        <div style={{padding:compact?'5px 7px':'6px 8px'}}>
          <div style={{fontSize:'8px',textTransform:'uppercase',color:'#1a5e2a',fontWeight:800}}>Zone</div>
          <div style={{fontSize:compact?'10px':'11px',fontWeight:800,fontFamily:"'Courier New',monospace"}}>{loc?.type || 'PRD'}</div>
        </div>

        <div style={{padding:compact?'5px 7px':'6px 8px',borderTop:'1px solid #cfd8d2',borderRight:'1px solid #cfd8d2'}}>
          <div style={{fontSize:'8px',textTransform:'uppercase',color:'#1a5e2a',fontWeight:800}}>Area / Name</div>
          <div style={{fontSize:compact?'10px':'11px',fontWeight:700}}>{loc?.name || '—'}</div>
        </div>

        <div style={{padding:compact?'5px 7px':'6px 8px',borderTop:'1px solid #cfd8d2'}}>
          <div style={{fontSize:'8px',textTransform:'uppercase',color:'#1a5e2a',fontWeight:800}}>Level / Cap.</div>
          <div style={{fontSize:compact?'10px':'11px',fontWeight:700}}>{loc?.level || 'L1'} · {loc?.usedLPN || 0}/{loc?.maxLPN || 0}</div>
        </div>
      </div>

      <div style={{textAlign:'center',padding:compact?'4px 0 2px':'7px 0 3px'}}>
        <svg viewBox={barcode.viewBox} style={{maxWidth:'100%',height:compact?'45px':'54px',display:'block',margin:'0 auto'}}>
          {barcode.rects}
        </svg>

        <div style={{fontSize:compact?'8px':'9px',fontFamily:"'Courier New', monospace",color:'#555',marginTop:'2px',letterSpacing:'.8px'}}>
          {barcodeValue}
        </div>
      </div>

      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',gap:'8px',borderTop:'1px solid #cfd8d2',marginTop:compact?'6px':'8px',paddingTop:compact?'6px':'8px'}}>
        <span style={{display:'inline-flex',padding:'2px 7px',borderRadius:'20px',fontSize:'8px',fontWeight:800,...typeStyle}}>
          {loc?.type || 'PRD'}
        </span>

        <span style={{fontSize:'8px',color:'#555',fontWeight:700}}>
          Utilization: {pct}%
        </span>

        <span style={{fontSize:'8px',color:loc?.status === 'Inactive' ? '#d97706' : '#00884a',fontWeight:800}}>
          {loc?.status || 'Active'}
        </span>
      </div>
    </div>
  )
}

/* ── Shifts Tab ───────────────────────────────────────────────────── */
function ShiftsTab() {
  return (
    <div style={{background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'14px',padding:'60px',textAlign:'center'}}>
      <div style={{fontSize:'36px',marginBottom:'10px'}}>🕐</div>
      <div style={{fontSize:'14px',fontWeight:600,color:'var(--tx)',marginBottom:'6px'}}>Shift configuration — coming soon</div>
      <div style={{fontSize:'12px',color:'var(--tx3)'}}>Shift schedules and rotation patterns will be managed here.</div>
    </div>
  )
}

/* ── UA constants ─────────────────────────────────────────────────── */
const UA_PALETTE = ['#a78bfa','#4f8ef7','#2dd4a0','#f5a623','#22d3ee','#f25f5c','#ff8c42','#84cc16','#dc2626']
function uaColor(name) {
  let h = 0
  const s = name || '?'
  for (let i = 0; i < s.length; i++) h = s.charCodeAt(i) + ((h << 5) - h)
  return UA_PALETTE[Math.abs(h) % UA_PALETTE.length]
}
function uaInits(name) {
  return (name || '?').split(' ').filter(Boolean).slice(0, 2).map(w => w[0]).join('').toUpperCase()
}
const UA_SCREENS = [
  { id:'production',    label:'Production Scheduling',  mod:'Production', icon:'📅' },
  { id:'technician',    label:'Process Tech Dashboard',  mod:'Production', icon:'👨‍🔧' },
  { id:'operator',      label:'Operator Print Screen',   mod:'Production', icon:'🖨' },
  { id:'qcoverview',    label:'QC Overview',             mod:'Quality',    icon:'🔍' },
  { id:'qcdetail',      label:'QC Inspection Detail',    mod:'Quality',    icon:'🔬' },
  { id:'lineclearance', label:'Line Clearance Form',     mod:'Quality',    icon:'✅' },
  { id:'lcrpt',         label:'Line Clearance Report',   mod:'Quality',    icon:'📋' },
  { id:'packer',        label:'Packer Dashboard',        mod:'Packing',    icon:'📦' },
  { id:'packerdetail',  label:'Pallet Builder & Label',  mod:'Packing',    icon:'🏷' },
  { id:'dtform',        label:'Downtime Entry Form',     mod:'Downtime',   icon:'⏱' },
  { id:'dtreport',      label:'Downtime Report',         mod:'Downtime',   icon:'📊' },
  { id:'setup_bq',      label:'Setup – Box Quantity',    mod:'Setup',      icon:'📦' },
  { id:'setup_mc',      label:'Setup – Machines',        mod:'Setup',      icon:'⚙' },
  { id:'setup_loc',     label:'Setup – Locations',       mod:'Setup',      icon:'📍' },
  { id:'setup_users',   label:'User Access Management',  mod:'Setup',      icon:'👤' },
]
const UA_FEATURES = [
  { id:'print_labels',   label:'Print Labels',             cat:'Production', desc:'Print box labels from operator screen' },
  { id:'start_wo',       label:'Start / Hold Work Orders', cat:'Production', desc:'Change WO status' },
  { id:'add_wo',         label:'Add Work Orders',          cat:'Production', desc:'Manually add work orders' },
  { id:'set_priority',   label:'Set WO Priority',          cat:'Production', desc:'Change priority on work orders' },
  { id:'change_machine', label:'Reassign Machine',         cat:'Production', desc:'Move WO to a different machine' },
  { id:'qc_approve',     label:'Approve / Reject Boxes',   cat:'Quality',    desc:'Approve or reject quality inspection' },
  { id:'qc_bulk',        label:'Bulk QC Actions',          cat:'Quality',    desc:'Approve all / Reject all at once' },
  { id:'lc_submit',      label:'Submit Line Clearance',    cat:'Quality',    desc:'Submit line clearance for approval' },
  { id:'lc_approve',     label:'Approve Line Clearance',   cat:'Quality',    desc:'Final approval of LC records' },
  { id:'build_pallet',   label:'Build Pallets',            cat:'Packing',    desc:'Create pallet and generate label' },
  { id:'print_pallet',   label:'Print Pallet Labels',      cat:'Packing',    desc:'Print pallet barcode label' },
  { id:'dt_submit',      label:'Submit Downtime',          cat:'Downtime',   desc:'Create downtime entry records' },
  { id:'dt_edit',        label:'Edit/Delete Downtime',     cat:'Downtime',   desc:'Modify or delete downtime records' },
  { id:'export_data',    label:'Export to Excel',          cat:'Reports',    desc:'Download any report as Excel' },
  { id:'view_all_divs',  label:'View All Divisions',       cat:'Data Access',desc:'See FPP and IPP data simultaneously' },
  { id:'setup_edit',     label:'Edit Setup Data',          cat:'Setup',      desc:'Modify machines, locations, box qty' },
  { id:'user_manage',    label:'Manage Users',             cat:'Setup',      desc:'Create, edit, delete user accounts' },
  { id:'change_theme',   label:'Change Theme',             cat:'UI',         desc:'Switch between Black/White/Zamil themes' },
]
const UA_ROLES_DATA = [
  { id:'Admin', name:'System Admin', icon:'🛡', color:'#a78bfa', system:true,
    desc:'Full access to every module, all settings and user management.',
    screens:{ ALL:{view:true,create:true,edit:true,delete:true,export:true} }, features:{ ALL:true } },
  { id:'Process Technician', name:'Process Technician', icon:'👨‍🔧', color:'#4f8ef7',
    desc:'Manage work orders, start/hold/terminate, production scheduling.',
    screens:{production:{view:true,create:true,edit:true,delete:false,export:true},technician:{view:true,create:true,edit:true,delete:false,export:false},operator:{view:true,create:false,edit:false,delete:false,export:false},dtform:{view:true,create:true,edit:false,delete:false,export:false},dtreport:{view:true,create:false,edit:false,delete:false,export:true},setup_bq:{view:true,create:false,edit:false,delete:false,export:false},setup_mc:{view:true,create:false,edit:false,delete:false,export:false}},
    features:{start_wo:true,set_priority:true,change_machine:true,dt_submit:true,print_labels:true,add_wo:true} },
  { id:'Operator', name:'Operator', icon:'🖨', color:'#22d3ee',
    desc:'Print-only access to running work orders.',
    screens:{operator:{view:true,create:false,edit:false,delete:false,export:false}}, features:{print_labels:true} },
  { id:'QC Inspector', name:'QC Inspector', icon:'🔍', color:'#2dd4a0',
    desc:'Box inspection, line clearance, quality dashboards.',
    screens:{qcoverview:{view:true,create:true,edit:true,delete:false,export:true},qcdetail:{view:true,create:true,edit:true,delete:false,export:false},lineclearance:{view:true,create:true,edit:false,delete:false,export:false},lcrpt:{view:true,create:false,edit:false,delete:false,export:true}},
    features:{qc_approve:true,qc_bulk:false,lc_submit:true,export_data:true} },
  { id:'Packer', name:'Packer', icon:'📦', color:'#f5a623',
    desc:'Packer dashboard, pallet builder, label printing.',
    screens:{packer:{view:true,create:true,edit:false,delete:false,export:false},packerdetail:{view:true,create:true,edit:true,delete:false,export:false}},
    features:{build_pallet:true,print_pallet:true,print_labels:true} },
  { id:'Supervisor', name:'Supervisor', icon:'📊', color:'#84cc16',
    desc:'View all screens & reports, no setup modification.',
    screens:{ALL:{view:true,create:false,edit:false,delete:false,export:true}},
    features:{export_data:true,view_all_divs:true,qc_approve:true,lc_approve:true} },
  { id:'Maintenance', name:'Maintenance', icon:'🔧', color:'#f25f5c',
    desc:'Downtime entry, machine status. Read-only production.',
    screens:{production:{view:true,create:false,edit:false,delete:false,export:false},dtform:{view:true,create:true,edit:true,delete:false,export:false},dtreport:{view:true,create:false,edit:false,delete:false,export:true},setup_mc:{view:true,create:false,edit:true,delete:false,export:false}},
    features:{dt_submit:true,dt_edit:true} },
  { id:'Read Only', name:'Read Only', icon:'👁', color:'#9aa4b8', system:true,
    desc:'View dashboards and reports — cannot edit anything.',
    screens:{ALL:{view:true,create:false,edit:false,delete:false,export:false}}, features:{} },
]
const UA_ORG_TREE = [
  { id:'zg', name:'Zamil Group', icon:'🏢', children:[
    { id:'fpp', name:'FPP BU · Flexible Packaging', icon:'📦', children:[
      { id:'fpp-ext', name:'Extrusion', icon:'🔄', children:[
        { id:'fpp-ext-01', name:'EXT-01 · Reifenhauser 5-layer' },
        { id:'fpp-ext-02', name:'EXT-02 · Macchi 3-layer' },
        { id:'fpp-ext-03', name:'EXT-03 · Hosokawa Alpine' },
      ]},
      { id:'fpp-print', name:'Printing', icon:'🖨', children:[
        { id:'fpp-pr-01', name:'PR-01 · W&H Miraflex 8C' },
        { id:'fpp-pr-02', name:'PR-02 · Soma Optima 8C' },
      ]},
      { id:'fpp-slit', name:'Slitting & Finishing', icon:'✂', children:[
        { id:'fpp-sl-01', name:'SL-01 · Atlas Titan' },
        { id:'fpp-sl-02', name:'SL-02 · Atlas Titan' },
      ]},
    ]},
    { id:'ipp', name:'IPP BU · Injection Plastics', icon:'🧪', children:[
      { id:'ipp-inj', name:'Injection Moulding', icon:'⚙', children:[
        { id:'ipp-inj-01', name:'IM-01 · ZFP001 Engel 320T' },
        { id:'ipp-inj-02', name:'IM-02 · ZFP002 Engel 500T' },
        { id:'ipp-inj-03', name:'IM-03 · Husky H-300' },
        { id:'ipp-inj-04', name:'IM-04 · Husky H-450' },
      ]},
      { id:'ipp-asm', name:'Assembly', icon:'🔩', children:[
        { id:'ipp-asm-01', name:'ASM-01 · Bottle Assembly' },
        { id:'ipp-asm-02', name:'ASM-02 · Cap Assembly' },
      ]},
      { id:'ipp-blow', name:'Blow Moulding', icon:'💨', children:[
        { id:'ipp-bl-01', name:'BL-01 · ZBL010' },
        { id:'ipp-bl-02', name:'BL-02 · ZBL020' },
      ]},
    ]},
  ]},
]
function uaDefaultScreens(roleId) {
  const r = UA_ROLES_DATA.find(x => x.id.toLowerCase() === (roleId||'').toLowerCase() || x.name.toLowerCase() === (roleId||'').toLowerCase())
  if (!r) return UA_SCREENS.reduce((a,s)=>({...a,[s.id]:{view:false,create:false,edit:false,delete:false,export:false}}),{})
  if (r.screens.ALL) return UA_SCREENS.reduce((a,s)=>({...a,[s.id]:{...r.screens.ALL}}),{})
  return UA_SCREENS.reduce((a,s)=>({...a,[s.id]:r.screens[s.id]||{view:false,create:false,edit:false,delete:false,export:false}}),{})
}
function uaDefaultFeatures(roleId) {
  const r = UA_ROLES_DATA.find(x => x.id.toLowerCase() === (roleId||'').toLowerCase() || x.name.toLowerCase() === (roleId||'').toLowerCase())
  if (!r) return UA_FEATURES.reduce((a,f)=>({...a,[f.id]:false}),{})
  if (r.features.ALL) return UA_FEATURES.reduce((a,f)=>({...a,[f.id]:true}),{})
  return UA_FEATURES.reduce((a,f)=>({...a,[f.id]:!!(r.features[f.id])}),{})
}

/* ── Scope Tree Node ─────────────────────────────────────────────── */
function ScopeNode({ node, level, checked, expanded, onCheck, onExpand }) {
  const kids = node.children || []
  const hasKids = kids.length > 0
  return (
    <>
      <div className={`ua-scope-row lvl-${level}`}>
        <button className={`ua-stog ${!hasKids?'empty':''}`} onClick={()=>hasKids&&onExpand(node.id)}>
          {hasKids ? (expanded.has(node.id)?'▼':'▶') : ''}
        </button>
        <div className={`ua-schk ${checked.has(node.id)?'checked':''}`} onClick={()=>onCheck(node.id)} />
        {node.icon && <span className="ua-sicon">{node.icon}</span>}
        <span className="ua-slbl">{node.name}</span>
        {level >= 3 && kids.length > 0 && <span className="ua-smeta">{kids.length} mach</span>}
      </div>
      {expanded.has(node.id) && kids.map(c => (
        <ScopeNode key={c.id} node={c} level={level+1} checked={checked} expanded={expanded} onCheck={onCheck} onExpand={onExpand} />
      ))}
    </>
  )
}

/* ── Users Tab ────────────────────────────────────────────────────── */
function UsersTab() {
  const { showToast } = useApp()
  const [viewMode, setViewMode]     = useState('users')
  const [search, setSearch]         = useState('')
  const [stFilter, setStFilter]     = useState('all')
  const [selectedUser, setSelUser]  = useState(null)
  const [detailTab, setDetailTab]   = useState('profile')
  const [selectedRole, setSelRole]  = useState(null)
  const [showCreate, setShowCreate] = useState(false)

  const [profileEdit, setProfile]   = useState({})
  const [userScreens, setUScreens]  = useState({})
  const [userFeatures, setUFeats]   = useState({})
  const [scopeChk, setScopeChk]     = useState(new Set(['zg']))
  const [scopeExp, setScopeExp]     = useState(new Set(['zg','fpp','ipp']))
  const [actLog, setActLog]         = useState([])
  const [loadAct, setLoadAct]       = useState(false)
  const [secSet, setSecSet]         = useState({ pwReset:'none', pwStr:'medium', lockout:'5', timeout:'240', hours:'ANY', device:'ANY', audit:true, emailNotify:true, twoFA:false, ipRestrict:false })
  const [newUser, setNewUser]       = useState({ empId:'', fullName:'', username:'', email:'', dept:'', role:'operator', plant:'FPP', password:'' })

  const { items: apiUsers, refetch: refetchUsers } = useList(userService.getAll)
  const [rawUsers, setRawUsers] = useState([])

  useEffect(() => {
    if (apiUsers?.length) {
      setRawUsers(apiUsers.map(u => ({ ...u, name: u.fullName || u.name || '' })))
    }
  }, [apiUsers])

  useEffect(() => {
    if (!selectedUser) return
    setProfile({ fullName:selectedUser.fullName||selectedUser.name||'', username:selectedUser.username||'', email:selectedUser.email||'', dept:selectedUser.dept||'', title:selectedUser.title||'', plant:selectedUser.plant||'FPP', shift:selectedUser.shift||'ANY', status:selectedUser.isActive!==false?'ACTIVE':'INACTIVE' })
    setUScreens(uaDefaultScreens(selectedUser.role))
    setUFeats(uaDefaultFeatures(selectedUser.role))
    setDetailTab('profile')
    setActLog([])
  }, [selectedUser?.id])

  useEffect(() => {
    if (detailTab !== 'activity' || !selectedUser?.id) return
    setLoadAct(true)
    userService.getActivityLog(selectedUser.id, { limit:30 })
      .then(r => setActLog(Array.isArray(r) ? r : (r?.data || [])))
      .catch(() => setActLog([]))
      .finally(() => setLoadAct(false))
  }, [detailTab, selectedUser?.id])

  const { mutate: updateApi } = useMutation(d => userService.update(d.id, d), {
    onSuccess: () => { refetchUsers(); showToast('User saved','success') },
    onError: e => showToast(e?.message||'Save failed','error'),
  })
  const { mutate: deleteApi } = useMutation(userService.delete, {
    onSuccess: () => { refetchUsers(); setSelUser(null); showToast('User deleted','warning') },
    onError: e => showToast(e?.message||'Delete failed','error'),
  })
  const { mutate: createApi } = useMutation(userService.create, {
    onSuccess: () => { refetchUsers(); setShowCreate(false); showToast('User created','success'); setNewUser({ empId:'', fullName:'', username:'', email:'', dept:'', role:'operator', plant:'FPP', password:'' }) },
    onError: e => showToast(e?.message||'Create failed','error'),
  })

  const filtered = rawUsers.filter(u => {
    const q = search.toLowerCase()
    if (q && !JSON.stringify(u).toLowerCase().includes(q)) return false
    if (stFilter === 'all') return true
    if (stFilter === 'ACTIVE') return u.isActive !== false
    if (stFilter === 'INACTIVE') return u.isActive === false
    return u.role?.toLowerCase() === stFilter.toLowerCase()
  })

  const totalUsers = rawUsers.length
  const active     = rawUsers.filter(u => u.isActive !== false).length
  const suspended  = rawUsers.filter(u => u.isActive === false).length
  const locked     = rawUsers.filter(u => u.isLocked).length
  const admins     = rawUsers.filter(u => u.role === 'admin').length
  const roleCount  = [...new Set(rawUsers.map(u => u.role))].length

  const saveProfile = () => {
    if (!selectedUser) return
    updateApi({ id:selectedUser.id, fullName:profileEdit.fullName, username:profileEdit.username, email:profileEdit.email, dept:profileEdit.dept, title:profileEdit.title, plant:profileEdit.plant, shift:profileEdit.shift, isActive:profileEdit.status==='ACTIVE' })
  }

  const scrByMod   = UA_SCREENS.reduce((a,s)=>{ if(!a[s.mod])a[s.mod]=[]; a[s.mod].push(s); return a },{})
  const featByCat  = UA_FEATURES.reduce((a,f)=>{ if(!a[f.cat])a[f.cat]=[]; a[f.cat].push(f); return a },{})

  const toggleScr  = (id,act) => setUScreens(p=>({...p,[id]:{...p[id],[act]:!p[id]?.[act]}}))
  const allScr     = v => { const x={}; UA_SCREENS.forEach(s=>{x[s.id]={view:v,create:v,edit:v,delete:v,export:v}}); setUScreens(x) }
  const toggleFeat = id => setUFeats(p=>({...p,[id]:!p[id]}))
  const allFeat    = v => { const x={}; UA_FEATURES.forEach(f=>{x[f.id]=v}); setUFeats(x) }

  const scopeText = () => {
    if (scopeChk.has('zg')) return 'All operations (Zamil Group)'
    const p = [scopeChk.has('fpp')&&'FPP BU', scopeChk.has('ipp')&&'IPP BU'].filter(Boolean)
    return p.length ? p.join(' + ') : 'No scope selected.'
  }
  const applyPreset = k => {
    if (k==='all') setScopeChk(new Set(['zg','fpp','ipp']))
    else if (k==='fpp') setScopeChk(new Set(['fpp']))
    else if (k==='ipp') setScopeChk(new Set(['ipp']))
    else setScopeChk(new Set())
  }

  const handleCreate = () => {
    if (!newUser.empId || !newUser.fullName) { showToast('Employee ID and Full Name required','error'); return }
    if (!newUser.password) { showToast('Password is required','error'); return }
    createApi({ ...newUser, isActive:true })
  }

  const actIcon = a => ({ login:'🔑', logout:'🚪', create:'➕', update:'✏', delete:'🗑' }[a]||'📋')

  return (
    <div>
      {/* Header */}
      <div style={{display:'flex',alignItems:'flex-start',justifyContent:'space-between',gap:'14px',marginBottom:'16px',flexWrap:'wrap'}}>
        <div>
          <div style={{fontSize:'14px',fontWeight:600,color:'var(--tx)',display:'flex',alignItems:'center',gap:'7px'}}>
            <span style={{width:'7px',height:'7px',borderRadius:'50%',background:'var(--pur)',display:'inline-block'}}/>
            User Access Management
          </div>
          <div style={{fontSize:'11px',color:'var(--tx3)',marginTop:'3px'}}>Define roles · assign multi-role to users · scope visibility to Org → Plant → Area → Machine</div>
        </div>
        <div style={{display:'flex',gap:'8px',flexWrap:'wrap',alignItems:'center'}}>
          <div className="ua-vmode">
            <button className={viewMode==='users'?'on':''} onClick={()=>setViewMode('users')}>
              👤 Users <span className="ua-vc">{rawUsers.length}</span>
            </button>
            <button className={viewMode==='roles'?'on':''} onClick={()=>setViewMode('roles')}>
              🎭 Roles <span className="ua-vc">{UA_ROLES_DATA.length}</span>
            </button>
          </div>
          <button className="btn bgh bsm" onClick={()=>setShowCreate(true)}>➕ Create User</button>
          <button className="btn bgh bsm" onClick={()=>showToast('Export — coming soon','info')}>📤 Export</button>
        </div>
      </div>

      {/* Stats */}
      <div className="ua-stats">
        {[['Total Users',totalUsers,'var(--blu)'],['Active',active,'var(--grn)'],['Suspended',suspended,'var(--amb)'],['Locked',locked,'var(--red)'],['Admins',admins,'var(--pur)'],['Defined Roles',roleCount,'var(--tel)']].map(([l,v,c])=>(
          <div key={l} className="ua-stc" style={{borderLeftColor:c}}>
            <div className="ua-stlbl">{l}</div>
            <div className="ua-stval" style={{color:c}}>{v}</div>
          </div>
        ))}
      </div>

      {/* ── USERS VIEW ──────────────────────────────────────────── */}
      {viewMode === 'users' && (
        <div className="ua-layout">
          <div className="ua-side">
            <div className="ua-side-hdr">
              <div style={{fontSize:'12px',fontWeight:600,color:'var(--tx)',display:'flex',alignItems:'center',gap:'7px'}}>
                <span style={{width:'7px',height:'7px',borderRadius:'50%',background:'var(--blu)',display:'inline-block'}}/>
                Users <span style={{color:'var(--tx3)',fontWeight:400}}>({filtered.length})</span>
              </div>
              <button className="btn bpri bsm" onClick={()=>setShowCreate(true)}>+ New</button>
            </div>
            <div className="ua-side-search">
              <input type="text" placeholder="🔍 Search users..." value={search} onChange={e=>setSearch(e.target.value)} />
            </div>
            <div className="ua-side-filter">
              {[['all','All'],['ACTIVE','Active'],['INACTIVE','Susp.'],['admin','Admin'],['tech','Tech'],['operator','Op'],['qc','QC'],['packer','Packer']].map(([v,l])=>(
                <button key={v} className={`ua-sf ${stFilter===v?'on':''}`} onClick={()=>setStFilter(v)}>{l}</button>
              ))}
            </div>
            <div className="ua-user-list">
              {filtered.length === 0 && <div style={{padding:'24px',textAlign:'center',color:'var(--tx3)',fontSize:'12px'}}>No users found.</div>}
              {filtered.map(u => (
                <div key={u.id} className={`ua-user-item ${selectedUser?.id===u.id?'active':''}`} onClick={()=>setSelUser(u)}>
                  <div className="ua-uav" style={{background:uaColor(u.name||u.empId||'?')}}>{uaInits(u.name||u.empId||'?')}</div>
                  <div className="ua-uinfo">
                    <div className="ua-uname">{u.name}</div>
                    <div className="ua-utitle">{u.empId} · {u.role}</div>
                  </div>
                  <div className="ua-ustatus" style={{background:u.isActive!==false?'var(--grn)':'var(--amb)'}}/>
                </div>
              ))}
            </div>
          </div>

          <div className="ua-main">
            {!selectedUser ? (
              <div className="ua-card" style={{padding:'48px',textAlign:'center',color:'var(--tx3)'}}>
                <div style={{fontSize:'42px',marginBottom:'10px'}}>👤</div>
                <div style={{fontSize:'14px',fontWeight:600,color:'var(--tx)',marginBottom:'6px'}}>Select a user to manage access</div>
                <div style={{fontSize:'11px',maxWidth:'300px',margin:'0 auto'}}>Click a user from the list to view and edit their profile, roles, screen access, scope and features.</div>
                <button className="btn bpri bsm" style={{marginTop:'16px'}} onClick={()=>setShowCreate(true)}>➕ Create First User</button>
              </div>
            ) : (
              <>
                {/* User header card */}
                <div className="ua-card">
                  <div style={{padding:'16px 18px',display:'flex',alignItems:'flex-start',gap:'14px',flexWrap:'wrap'}}>
                    <div className="ua-uav" style={{width:'56px',height:'56px',borderRadius:'50%',fontSize:'16px',background:uaColor(selectedUser.name||'?')}}>
                      {uaInits(selectedUser.name||'?')}
                    </div>
                    <div style={{flex:1,minWidth:'200px'}}>
                      <div style={{display:'flex',alignItems:'center',gap:'8px',flexWrap:'wrap',marginBottom:'4px'}}>
                        <div style={{fontSize:'16px',fontWeight:700,color:'var(--tx)'}}>{selectedUser.name}</div>
                        <span className={`bdg ${selectedUser.isActive!==false?'bd':'bgh'}`}>{selectedUser.isActive!==false?'Active':'Suspended'}</span>
                        <span className="bdg bpa">{selectedUser.role}</span>
                      </div>
                      <div style={{fontSize:'11px',color:'var(--tx3)',marginBottom:'3px'}}>{selectedUser.title||selectedUser.dept||'—'}</div>
                      <div style={{fontSize:'11px',color:'var(--tx3)'}}>
                        Emp <span style={{fontFamily:"'Space Mono',monospace",color:'var(--tx)'}}>{selectedUser.empId}</span>
                        &nbsp;·&nbsp;<span style={{color:'var(--tx)'}}>{selectedUser.dept||'—'}</span>
                        {selectedUser.email && <>&nbsp;·&nbsp;<span style={{color:'var(--blu)'}}>{selectedUser.email}</span></>}
                      </div>
                    </div>
                    <div style={{display:'flex',gap:'6px',flexWrap:'wrap'}}>
                      <button className="btn bgh bsm" onClick={()=>showToast('Password reset link sent','info')}>🔑 Reset Pwd</button>
                      <button className={`btn ${selectedUser.isActive!==false?'bamb':'bsuc'} bsm`}
                        onClick={()=>updateApi({id:selectedUser.id,isActive:selectedUser.isActive===false})}>
                        {selectedUser.isActive!==false?'⏸ Suspend':'▶ Activate'}
                      </button>
                      <button className="btn bdan bsm" onClick={()=>{if(window.confirm('Delete this user?'))deleteApi(selectedUser.id)}}>🗑 Delete</button>
                      <button className="btn bpri bsm" onClick={saveProfile}>💾 Save</button>
                    </div>
                  </div>
                </div>

                {/* Tab pills */}
                <div style={{display:'flex',gap:'4px',flexWrap:'wrap'}}>
                  {[['profile','👤 Profile'],['role','🎭 Roles'],['scope','🏭 Scope'],['screens','🖥 Screens'],['features','⚙ Features'],['security','🔐 Security'],['activity','📋 Activity']].map(([t,l])=>(
                    <button key={t} className={`ua-tab ${detailTab===t?'on':''}`} onClick={()=>setDetailTab(t)}>{l}</button>
                  ))}
                </div>

                {/* ── PROFILE ── */}
                {detailTab === 'profile' && (
                  <div className="ua-card">
                    <div className="ua-card-hdr">
                      <div style={{fontSize:'12px',fontWeight:600,color:'var(--tx)',display:'flex',alignItems:'center',gap:'7px'}}>
                        <span style={{width:'7px',height:'7px',borderRadius:'50%',background:'var(--grn)',display:'inline-block'}}/>User Profile
                      </div>
                    </div>
                    <div style={{padding:'14px 16px'}}>
                      <div className="ua-g3">
                        <div className="ua-fg"><label>Employee Number</label><input type="text" value={selectedUser.empId||''} readOnly style={{opacity:.6}} /></div>
                        <div className="ua-fg"><label>Full Name *</label><input type="text" value={profileEdit.fullName||''} onChange={e=>setProfile(p=>({...p,fullName:e.target.value}))} /></div>
                        <div className="ua-fg"><label>Username / Login</label><input type="text" style={{fontFamily:"'Space Mono',monospace"}} value={profileEdit.username||''} onChange={e=>setProfile(p=>({...p,username:e.target.value}))} /></div>
                      </div>
                      <div className="ua-g3" style={{marginTop:'10px'}}>
                        <div className="ua-fg"><label>Email</label><input type="email" value={profileEdit.email||''} onChange={e=>setProfile(p=>({...p,email:e.target.value}))} /></div>
                        <div className="ua-fg"><label>Department</label><input type="text" value={profileEdit.dept||''} onChange={e=>setProfile(p=>({...p,dept:e.target.value}))} /></div>
                        <div className="ua-fg"><label>Job Title</label><input type="text" value={profileEdit.title||''} onChange={e=>setProfile(p=>({...p,title:e.target.value}))} /></div>
                      </div>
                      <div className="ua-g3" style={{marginTop:'10px'}}>
                        <div className="ua-fg"><label>Plant</label>
                          <select value={profileEdit.plant||'FPP'} onChange={e=>setProfile(p=>({...p,plant:e.target.value}))}>
                            <option value="FPP">FPP BU</option><option value="IPP">IPP BU</option><option value="BOTH">FPP + IPP</option><option value="ZPC">ZPC BU</option>
                          </select>
                        </div>
                        <div className="ua-fg"><label>Shift</label>
                          <select value={profileEdit.shift||'ANY'} onChange={e=>setProfile(p=>({...p,shift:e.target.value}))}>
                            <option value="ANY">Any Shift</option><option value="DAY">Day Shift</option><option value="NIGHT">Night Shift</option><option value="ADMIN">Admin / Office</option>
                          </select>
                        </div>
                        <div className="ua-fg"><label>Account Status</label>
                          <select value={profileEdit.status||'ACTIVE'} onChange={e=>setProfile(p=>({...p,status:e.target.value}))}>
                            <option value="ACTIVE">Active</option><option value="INACTIVE">Suspended</option><option value="LOCKED">Locked</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* ── ROLES ── */}
                {detailTab === 'role' && (
                  <div className="ua-card">
                    <div className="ua-card-hdr">
                      <div style={{fontSize:'12px',fontWeight:600,color:'var(--tx)',display:'flex',alignItems:'center',gap:'7px'}}>
                        <span style={{width:'7px',height:'7px',borderRadius:'50%',background:'var(--pur)',display:'inline-block'}}/>Assigned Roles
                      </div>
                      <div style={{fontSize:'11px',color:'var(--tx3)'}}>Pick one or more · ⭐ marks primary</div>
                    </div>
                    <div style={{padding:'14px 16px'}}>
                      <div className="ua-role-grid">
                        {UA_ROLES_DATA.map(r => {
                          const isPrim = selectedUser.role?.toLowerCase()===r.id.toLowerCase()||selectedUser.role===r.name
                          return (
                            <div key={r.id} className={`ua-role-tile ${isPrim?'primary sel':''}`}
                              onClick={()=>showToast('Role changes require admin confirmation','info')}>
                              <div className="ua-rmark"/>
                              <button className="ua-rprim" onClick={e=>e.stopPropagation()}>⭐</button>
                              <div className="ua-rhdr"><span className="ri">{r.icon}</span><span className="rn">{r.name}</span></div>
                              <div className="ua-rd">{r.desc}</div>
                            </div>
                          )
                        })}
                      </div>
                      <div className="ua-role-summary">
                        <span className="ua-rs-lbl">Active Roles:</span>
                        <span className="ua-rs-chip prim">
                          <span className="mrk" style={{background:UA_ROLES_DATA.find(r=>r.id.toLowerCase()===selectedUser.role?.toLowerCase())?.color||'var(--pur)'}}>★</span>
                          {selectedUser.role}
                        </span>
                      </div>
                      <div style={{marginTop:'12px',padding:'11px 14px',background:'rgba(59,130,246,.08)',border:'1px solid var(--blu)',borderRadius:'9px',fontSize:'12px',color:'var(--blu)',display:'flex',alignItems:'flex-start',gap:'9px'}}>
                        <span style={{fontSize:'14px'}}>ℹ</span>
                        <div><b>How multi-role works:</b> the user's effective access is the <b>union</b> of all selected roles. Customise individual screens or features on the next two tabs.</div>
                      </div>
                    </div>
                  </div>
                )}

                {/* ── SCOPE ── */}
                {detailTab === 'scope' && (
                  <div className="ua-card">
                    <div className="ua-card-hdr">
                      <div style={{fontSize:'12px',fontWeight:600,color:'var(--tx)',display:'flex',alignItems:'center',gap:'7px'}}>
                        <span style={{width:'7px',height:'7px',borderRadius:'50%',background:'var(--tel)',display:'inline-block'}}/>Operational Scope
                      </div>
                      <div style={{fontSize:'11px',color:'var(--tx3)'}}>Limits which WOs, downtime & reports the user sees</div>
                    </div>
                    <div style={{padding:'14px 16px'}}>
                      <div className="ua-scope-summary">
                        <div className="ua-ss-ic">🎯</div>
                        <div style={{flex:1}}>
                          <div style={{fontSize:'10px',fontWeight:700,color:'var(--grn)',textTransform:'uppercase',letterSpacing:'.5px',marginBottom:'4px'}}>Effective Visibility</div>
                          <div style={{fontSize:'12px',color:'var(--tx)'}}>{scopeText()}</div>
                        </div>
                      </div>
                      <div style={{marginTop:'14px'}}>
                        <div style={{fontSize:'10px',fontWeight:700,color:'var(--tx3)',textTransform:'uppercase',letterSpacing:'.8px',marginBottom:'8px'}}>Quick Presets</div>
                        <div className="ua-scope-presets">
                          {[['all','🌐 All Operations'],['fpp','📦 FPP BU only'],['ipp','🧪 IPP BU only'],['clear','✕ Clear All']].map(([k,l])=>(
                            <button key={k} className="ua-spreset" onClick={()=>applyPreset(k)}>{l}</button>
                          ))}
                        </div>
                      </div>
                      <div style={{marginTop:'14px',border:'1px solid var(--bor)',borderRadius:'10px',overflow:'hidden'}}>
                        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'8px 12px',background:'var(--bg3)',borderBottom:'1px solid var(--bor)'}}>
                          <div style={{fontSize:'10px',fontWeight:700,color:'var(--tx3)',textTransform:'uppercase',letterSpacing:'.8px'}}>Scope Tree · Org → Plant → Area → Machine</div>
                          <div style={{display:'flex',gap:'5px'}}>
                            <button className="btn bgh bsm" style={{fontSize:'10px',padding:'3px 9px'}} onClick={()=>setScopeExp(new Set(['zg','fpp','ipp','fpp-ext','fpp-print','fpp-slit','ipp-inj','ipp-asm','ipp-blow']))}>⊕ Expand</button>
                            <button className="btn bgh bsm" style={{fontSize:'10px',padding:'3px 9px'}} onClick={()=>setScopeExp(new Set(['zg']))}>⊖ Collapse</button>
                          </div>
                        </div>
                        <div className="ua-scope-tree">
                          {UA_ORG_TREE.map(n => (
                            <ScopeNode key={n.id} node={n} level={1} checked={scopeChk} expanded={scopeExp}
                              onCheck={id=>setScopeChk(p=>{const s=new Set(p); s.has(id)?s.delete(id):s.add(id); return s})}
                              onExpand={id=>setScopeExp(p=>{const s=new Set(p); s.has(id)?s.delete(id):s.add(id); return s})} />
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* ── SCREENS ── */}
                {detailTab === 'screens' && (
                  <div className="ua-card">
                    <div className="ua-card-hdr">
                      <div style={{fontSize:'12px',fontWeight:600,color:'var(--tx)',display:'flex',alignItems:'center',gap:'7px'}}>
                        <span style={{width:'7px',height:'7px',borderRadius:'50%',background:'var(--blu)',display:'inline-block'}}/>Screen &amp; Module Access
                      </div>
                      <div style={{display:'flex',gap:'5px'}}>
                        <button className="btn bgh bsm" style={{fontSize:'10px',padding:'3px 9px'}} onClick={()=>allScr(true)}>✓ Grant All</button>
                        <button className="btn bgh bsm" style={{fontSize:'10px',padding:'3px 9px'}} onClick={()=>allScr(false)}>✕ Revoke All</button>
                      </div>
                    </div>
                    <div style={{overflowX:'auto'}}>
                      <div className="ua-perm-matrix">
                        <div className="ua-pm-row" style={{gridTemplateColumns:'220px repeat(5,80px)',background:'var(--bg3)'}}>
                          <div className="ua-pm-col-hdr" style={{textAlign:'left'}}>Screen</div>
                          {['View','Create','Edit','Delete','Export'].map(a=><div key={a} className="ua-pm-col-hdr">{a}</div>)}
                        </div>
                        {Object.entries(scrByMod).map(([mod,scrns])=>(
                          <div key={mod}>
                            <div className="ua-mod-hdr">{mod}</div>
                            {scrns.map(s=>(
                              <div key={s.id} className="ua-pm-row" style={{gridTemplateColumns:'220px repeat(5,80px)'}}>
                                <div className="ua-pm-cell"><div className="ua-pm-screen">{s.icon} {s.label}</div><div className="ua-pm-sub">{s.id}</div></div>
                                {['view','create','edit','delete','export'].map(a=>(
                                  <div key={a} className="ua-pm-cell"><div className="ua-pm-check"><input type="checkbox" checked={!!(userScreens[s.id]?.[a])} onChange={()=>toggleScr(s.id,a)} /></div></div>
                                ))}
                              </div>
                            ))}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* ── FEATURES ── */}
                {detailTab === 'features' && (
                  <div className="ua-card">
                    <div className="ua-card-hdr">
                      <div style={{fontSize:'12px',fontWeight:600,color:'var(--tx)',display:'flex',alignItems:'center',gap:'7px'}}>
                        <span style={{width:'7px',height:'7px',borderRadius:'50%',background:'var(--amb)',display:'inline-block'}}/>Feature Flags
                      </div>
                      <div style={{display:'flex',gap:'5px'}}>
                        <button className="btn bgh bsm" style={{fontSize:'10px',padding:'3px 9px'}} onClick={()=>allFeat(true)}>✓ Enable All</button>
                        <button className="btn bgh bsm" style={{fontSize:'10px',padding:'3px 9px'}} onClick={()=>allFeat(false)}>✕ Disable All</button>
                      </div>
                    </div>
                    <div style={{padding:'6px 16px 14px'}}>
                      {Object.entries(featByCat).map(([cat,feats])=>(
                        <div key={cat}>
                          <div className="ua-feature-cat">{cat}</div>
                          <div className="ua-feature-grid">
                            {feats.map(f=>(
                              <div key={f.id} className="ua-feature-row" onClick={()=>toggleFeat(f.id)}>
                                <label className="ua-toggle-sw" onClick={e=>e.stopPropagation()}>
                                  <input type="checkbox" checked={!!(userFeatures[f.id])} onChange={()=>toggleFeat(f.id)} />
                                  <span className="ua-toggle-slider"/>
                                </label>
                                <div><div className="flbl">{f.label}</div><div className="fdsc">{f.desc}</div></div>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* ── SECURITY ── */}
                {detailTab === 'security' && (
                  <div className="ua-card">
                    <div className="ua-card-hdr">
                      <div style={{fontSize:'12px',fontWeight:600,color:'var(--tx)',display:'flex',alignItems:'center',gap:'7px'}}>
                        <span style={{width:'7px',height:'7px',borderRadius:'50%',background:'var(--red)',display:'inline-block'}}/>Security Settings
                      </div>
                    </div>
                    <div style={{padding:'14px 16px'}}>
                      <div className="ua-sec-ttl">🔑 Password Policy</div>
                      <div className="ua-g3">
                        <div className="ua-fg"><label>Force Password Reset</label>
                          <select value={secSet.pwReset} onChange={e=>setSecSet(s=>({...s,pwReset:e.target.value}))}>
                            <option value="none">Never</option><option value="first_login">On First Login</option><option value="30d">Every 30 Days</option><option value="90d">Every 90 Days</option>
                          </select>
                        </div>
                        <div className="ua-fg"><label>Strength</label>
                          <select value={secSet.pwStr} onChange={e=>setSecSet(s=>({...s,pwStr:e.target.value}))}>
                            <option value="basic">Basic</option><option value="medium">Medium</option><option value="strong">Strong</option>
                          </select>
                        </div>
                        <div className="ua-fg"><label>Lockout After</label>
                          <select value={secSet.lockout} onChange={e=>setSecSet(s=>({...s,lockout:e.target.value}))}>
                            <option value="3">3 attempts</option><option value="5">5 attempts</option><option value="10">10 attempts</option>
                          </select>
                        </div>
                      </div>
                      <div className="ua-sec-ttl" style={{marginTop:'18px'}}>🕐 Session &amp; Access</div>
                      <div className="ua-g3">
                        <div className="ua-fg"><label>Session Timeout</label>
                          <select value={secSet.timeout} onChange={e=>setSecSet(s=>({...s,timeout:e.target.value}))}>
                            <option value="30">30 min</option><option value="60">1 hour</option><option value="240">4 hours</option><option value="480">8 hours (shift)</option>
                          </select>
                        </div>
                        <div className="ua-fg"><label>Allowed Login Hours</label>
                          <select value={secSet.hours} onChange={e=>setSecSet(s=>({...s,hours:e.target.value}))}>
                            <option value="ANY">Anytime</option><option value="DAY">Day (6:30–18:30)</option><option value="NIGHT">Night (18:30–06:30)</option><option value="OFFICE">Office (8–17)</option>
                          </select>
                        </div>
                        <div className="ua-fg"><label>Login From</label>
                          <select value={secSet.device} onChange={e=>setSecSet(s=>({...s,device:e.target.value}))}>
                            <option value="ANY">Any Device</option><option value="PLANT">Plant Network Only</option><option value="TABLET">Tablet / Kiosk Only</option>
                          </select>
                        </div>
                      </div>
                      <div className="ua-sec-ttl" style={{marginTop:'18px'}}>📋 Audit &amp; Notifications</div>
                      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'8px'}}>
                        {[['audit','Log all user actions (audit trail)'],['emailNotify','Email on login'],['twoFA','Require 2FA'],['ipRestrict','IP Whitelist restriction']].map(([k,l])=>(
                          <label key={k} className="ua-cbx">
                            <input type="checkbox" checked={secSet[k]} onChange={e=>setSecSet(s=>({...s,[k]:e.target.checked}))} />{l}
                          </label>
                        ))}
                      </div>
                      <div style={{marginTop:'16px',display:'flex',gap:'8px'}}>
                        <button className="btn bpri bsm" onClick={()=>showToast('Security settings saved','success')}>💾 Save Settings</button>
                        <button className="btn bdan bsm" onClick={()=>showToast('Session invalidated','warning')}>⏻ Force Logout</button>
                      </div>
                    </div>
                  </div>
                )}

                {/* ── ACTIVITY ── */}
                {detailTab === 'activity' && (
                  <div className="ua-card">
                    <div className="ua-card-hdr">
                      <div style={{fontSize:'12px',fontWeight:600,color:'var(--tx)',display:'flex',alignItems:'center',gap:'7px'}}>
                        <span style={{width:'7px',height:'7px',borderRadius:'50%',background:'var(--tel)',display:'inline-block'}}/>Activity Log
                      </div>
                      <div style={{fontSize:'11px',color:'var(--tx3)'}}>Last 30 days</div>
                    </div>
                    {loadAct ? (
                      <div style={{padding:'40px',textAlign:'center',color:'var(--tx3)'}}>
                        <div className="spinner" style={{width:'24px',height:'24px',margin:'0 auto 10px'}}/>Loading...
                      </div>
                    ) : actLog.length === 0 ? (
                      <div style={{padding:'40px',textAlign:'center',color:'var(--tx3)',fontSize:'12px'}}>
                        <div style={{fontSize:'28px',marginBottom:'8px'}}>📋</div>No activity recorded in the last 30 days.
                      </div>
                    ) : actLog.map((a,i)=>(
                      <div key={a.id||i} className="ua-act-row">
                        <div className="ua-act-ic" style={{background:'var(--pur2)',color:'var(--pur)'}}>{actIcon(a.action)}</div>
                        <div style={{flex:1}}>
                          <div style={{fontSize:'12px',color:'var(--tx)'}}>{a.description||a.action}</div>
                          <div className="ua-act-time">{a.createdAt?new Date(a.createdAt).toLocaleString():'—'}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      )}

      {/* ── ROLES VIEW ──────────────────────────────────────────── */}
      {viewMode === 'roles' && (
        <div className="ua-layout">
          <div className="ua-side">
            <div className="ua-side-hdr">
              <div style={{fontSize:'12px',fontWeight:600,color:'var(--tx)',display:'flex',alignItems:'center',gap:'7px'}}>
                <span style={{width:'7px',height:'7px',borderRadius:'50%',background:'var(--pur)',display:'inline-block'}}/>
                Roles Library <span style={{color:'var(--tx3)',fontWeight:400}}>({UA_ROLES_DATA.length})</span>
              </div>
            </div>
            <div style={{padding:'10px 14px',borderBottom:'1px solid var(--bor)',fontSize:'11px',color:'var(--tx3)',lineHeight:1.5}}>
              Roles bundle <b style={{color:'var(--tx)'}}>screen access</b> + <b style={{color:'var(--tx)'}}>feature flags</b>.
            </div>
            <div style={{padding:'10px',display:'flex',flexDirection:'column',gap:'8px',maxHeight:'680px',overflowY:'auto'}}>
              {UA_ROLES_DATA.map(r=>(
                <div key={r.id} className={`ua-role-card ${selectedRole?.id===r.id?'active':''}`} onClick={()=>setSelRole(r)}>
                  <div className="ua-rc-ic" style={{background:r.color}}>{r.icon}</div>
                  <div className="ua-rc-body">
                    <div className="ua-rc-name">{r.name} {r.system&&<span className="bdg brj" style={{fontSize:'9px'}}>🔒</span>}</div>
                    <div className="ua-rc-desc">{r.desc}</div>
                    <div className="ua-rc-meta">
                      <span>👥 <b>{rawUsers.filter(u=>u.role?.toLowerCase()===r.id.toLowerCase()||u.role===r.name).length}</b></span>
                      <span>🖥 <b>{r.screens.ALL?UA_SCREENS.length:Object.keys(r.screens).length}</b> scr</span>
                      <span>⚙ <b>{r.features.ALL?UA_FEATURES.length:Object.keys(r.features).filter(k=>r.features[k]).length}</b> feat</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="ua-main">
            {!selectedRole ? (
              <div className="ua-card" style={{padding:'48px',textAlign:'center',color:'var(--tx3)'}}>
                <div style={{fontSize:'42px',marginBottom:'10px'}}>🎭</div>
                <div style={{fontSize:'14px',fontWeight:600,color:'var(--tx)',marginBottom:'6px'}}>Select a role to view</div>
                <div style={{fontSize:'11px',maxWidth:'340px',margin:'0 auto'}}>Define screen access, feature flags, icon and description.</div>
              </div>
            ) : (
              <>
                <div className="ua-card">
                  <div style={{padding:'16px 18px',display:'flex',alignItems:'flex-start',gap:'12px',flexWrap:'wrap'}}>
                    <div style={{width:'50px',height:'50px',borderRadius:'12px',display:'flex',alignItems:'center',justifyContent:'center',fontSize:'22px',background:selectedRole.color,flexShrink:0}}>{selectedRole.icon}</div>
                    <div style={{flex:1,minWidth:'200px'}}>
                      <div style={{display:'flex',alignItems:'center',gap:'8px',flexWrap:'wrap',marginBottom:'4px'}}>
                        <div style={{fontSize:'16px',fontWeight:700,color:'var(--tx)'}}>{selectedRole.name}</div>
                        {selectedRole.system&&<span className="bdg brj">🔒 System</span>}
                      </div>
                      <div style={{fontSize:'12px',color:'var(--tx3)',marginBottom:'8px'}}>{selectedRole.desc}</div>
                      <div style={{display:'flex',gap:'14px',fontSize:'11px',color:'var(--tx3)',fontFamily:"'Space Mono',monospace"}}>
                        <span>👥 <b style={{color:'var(--grn)'}}>{rawUsers.filter(u=>u.role?.toLowerCase()===selectedRole.id.toLowerCase()||u.role===selectedRole.name).length}</b> members</span>
                        <span>🖥 <b style={{color:'var(--blu)'}}>{selectedRole.screens.ALL?UA_SCREENS.length:Object.keys(selectedRole.screens).length}</b> screens</span>
                        <span>⚙ <b style={{color:'var(--amb)'}}>{selectedRole.features.ALL?UA_FEATURES.length:Object.keys(selectedRole.features).filter(k=>selectedRole.features[k]).length}</b> features</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div style={{background:'rgba(59,130,246,.08)',border:'1px solid var(--blu)',borderRadius:'9px',padding:'10px 14px',display:'flex',alignItems:'center',gap:'10px',color:'var(--blu)',fontSize:'12px'}}>
                  <div style={{width:'28px',height:'28px',borderRadius:'7px',background:'var(--blu)',color:'#fff',display:'flex',alignItems:'center',justifyContent:'center',fontSize:'13px'}}>⚡</div>
                  <div style={{flex:1}}>
                    <div style={{fontWeight:700,marginBottom:'1px'}}>Changes propagate live</div>
                    <div style={{fontSize:'11px',opacity:.85}}>Modifying this role auto-applies to <b>{rawUsers.filter(u=>u.role?.toLowerCase()===selectedRole.id.toLowerCase()||u.role===selectedRole.name).length} users</b>.</div>
                  </div>
                </div>

                {/* Role screens matrix */}
                <div className="ua-card">
                  <div className="ua-card-hdr">
                    <div style={{fontSize:'12px',fontWeight:600,color:'var(--tx)',display:'flex',alignItems:'center',gap:'7px'}}>
                      <span style={{width:'7px',height:'7px',borderRadius:'50%',background:'var(--blu)',display:'inline-block'}}/>Default Screen Access
                    </div>
                    <div style={{fontSize:'11px',color:'var(--tx3)'}}>Read-only view</div>
                  </div>
                  <div style={{overflowX:'auto'}}>
                    <div className="ua-perm-matrix">
                      <div className="ua-pm-row" style={{gridTemplateColumns:'220px repeat(5,80px)',background:'var(--bg3)'}}>
                        <div className="ua-pm-col-hdr" style={{textAlign:'left'}}>Screen</div>
                        {['View','Create','Edit','Delete','Export'].map(a=><div key={a} className="ua-pm-col-hdr">{a}</div>)}
                      </div>
                      {Object.entries(scrByMod).map(([mod,scrns])=>(
                        <div key={mod}>
                          <div className="ua-mod-hdr">{mod}</div>
                          {scrns.map(s=>{
                            const p = selectedRole.screens.ALL ? selectedRole.screens.ALL : (selectedRole.screens[s.id]||{view:false,create:false,edit:false,delete:false,export:false})
                            return (
                              <div key={s.id} className="ua-pm-row" style={{gridTemplateColumns:'220px repeat(5,80px)'}}>
                                <div className="ua-pm-cell"><div className="ua-pm-screen">{s.icon} {s.label}</div><div className="ua-pm-sub">{s.id}</div></div>
                                {['view','create','edit','delete','export'].map(a=>(
                                  <div key={a} className="ua-pm-cell"><div className="ua-pm-check"><input type="checkbox" checked={!!p[a]} readOnly style={{cursor:'default'}} /></div></div>
                                ))}
                              </div>
                            )
                          })}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Role features */}
                <div className="ua-card">
                  <div className="ua-card-hdr">
                    <div style={{fontSize:'12px',fontWeight:600,color:'var(--tx)',display:'flex',alignItems:'center',gap:'7px'}}>
                      <span style={{width:'7px',height:'7px',borderRadius:'50%',background:'var(--amb)',display:'inline-block'}}/>Default Feature Flags
                    </div>
                  </div>
                  <div style={{padding:'6px 16px 14px'}}>
                    {Object.entries(featByCat).map(([cat,feats])=>(
                      <div key={cat}>
                        <div className="ua-feature-cat">{cat}</div>
                        <div className="ua-feature-grid">
                          {feats.map(f=>{
                            const en = selectedRole.features.ALL||!!(selectedRole.features[f.id])
                            return (
                              <div key={f.id} className="ua-feature-row" style={{cursor:'default'}}>
                                <label className="ua-toggle-sw" onClick={e=>e.preventDefault()}>
                                  <input type="checkbox" checked={en} readOnly />
                                  <span className="ua-toggle-slider"/>
                                </label>
                                <div><div className="flbl">{f.label}</div><div className="fdsc">{f.desc}</div></div>
                              </div>
                            )
                          })}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Members */}
                <div className="ua-card">
                  <div className="ua-card-hdr">
                    <div style={{fontSize:'12px',fontWeight:600,color:'var(--tx)',display:'flex',alignItems:'center',gap:'7px'}}>
                      <span style={{width:'7px',height:'7px',borderRadius:'50%',background:'var(--grn)',display:'inline-block'}}/>Members
                    </div>
                  </div>
                  <div style={{padding:'12px 16px',display:'flex',gap:'8px',flexWrap:'wrap'}}>
                    {rawUsers.filter(u=>u.role?.toLowerCase()===selectedRole.id.toLowerCase()||u.role===selectedRole.name).length === 0
                      ? <div style={{fontSize:'12px',color:'var(--tx3)'}}>No users assigned to this role.</div>
                      : rawUsers.filter(u=>u.role?.toLowerCase()===selectedRole.id.toLowerCase()||u.role===selectedRole.name).map(u=>(
                        <div key={u.id} className="ua-member-pill" onClick={()=>{setViewMode('users');setSelUser(u)}}>
                          <div className="ua-uav" style={{width:'18px',height:'18px',fontSize:'8px',background:uaColor(u.name||'?')}}>{uaInits(u.name||'?')}</div>
                          {u.name}
                        </div>
                      ))
                    }
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* ── Create User Modal ────────────────────────────────────── */}
      {showCreate && (
        <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,.6)',zIndex:1000,display:'flex',alignItems:'center',justifyContent:'center',padding:'20px'}}>
          <div style={{background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'16px',width:'100%',maxWidth:'560px',overflow:'hidden'}}>
            <div style={{padding:'16px 20px',borderBottom:'1px solid var(--bor)',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
              <div style={{fontSize:'14px',fontWeight:700,color:'var(--tx)'}}>➕ Create New User</div>
              <button className="btn bgh bsm" onClick={()=>setShowCreate(false)}>✕</button>
            </div>
            <div style={{padding:'20px',display:'flex',flexDirection:'column',gap:'14px'}}>
              <div className="ua-g3">
                <div className="ua-fg"><label>Employee ID *</label><input type="text" placeholder="EMP-XXXX" style={{fontFamily:"'Space Mono',monospace"}} value={newUser.empId} onChange={e=>setNewUser(n=>({...n,empId:e.target.value}))} /></div>
                <div className="ua-fg" style={{gridColumn:'span 2'}}><label>Full Name *</label><input type="text" placeholder="First and last name" value={newUser.fullName} onChange={e=>setNewUser(n=>({...n,fullName:e.target.value}))} /></div>
              </div>
              <div className="ua-g3">
                <div className="ua-fg"><label>Username</label><input type="text" style={{fontFamily:"'Space Mono',monospace"}} value={newUser.username} onChange={e=>setNewUser(n=>({...n,username:e.target.value}))} /></div>
                <div className="ua-fg"><label>Email</label><input type="email" value={newUser.email} onChange={e=>setNewUser(n=>({...n,email:e.target.value}))} /></div>
                <div className="ua-fg"><label>Department</label><input type="text" value={newUser.dept} onChange={e=>setNewUser(n=>({...n,dept:e.target.value}))} /></div>
              </div>
              <div className="ua-g3">
                <div className="ua-fg"><label>Role *</label>
                  <select value={newUser.role} onChange={e=>setNewUser(n=>({...n,role:e.target.value}))}>
                    <option value="admin">Admin</option><option value="tech">Process Technician</option><option value="operator">Operator</option><option value="qc">QC Inspector</option><option value="packer">Packer</option>
                  </select>
                </div>
                <div className="ua-fg"><label>Plant</label>
                  <select value={newUser.plant} onChange={e=>setNewUser(n=>({...n,plant:e.target.value}))}>
                    <option value="FPP">FPP BU</option><option value="IPP">IPP BU</option><option value="BOTH">FPP + IPP</option><option value="ZPC">ZPC BU</option>
                  </select>
                </div>
                <div className="ua-fg"><label>Password *</label><input type="password" placeholder="Set initial password" value={newUser.password} onChange={e=>setNewUser(n=>({...n,password:e.target.value}))} /></div>
              </div>
            </div>
            <div style={{padding:'14px 20px',borderTop:'1px solid var(--bor)',display:'flex',justifyContent:'flex-end',gap:'8px'}}>
              <button className="btn bgh" onClick={()=>setShowCreate(false)}>Cancel</button>
              <button className="btn bpri" onClick={handleCreate}>Create User</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
