import { useState } from 'react'
import { useList, useMutation, useApi } from '../../hooks/useApi'
import { userService } from '../../services/api'
import { useApp } from '../../contexts/AppContext'

const ROLE_COLORS = { admin:'pur', tech:'blu', operator:'grn', qc:'tel', packer:'amb', viewer:'tx3' }
const SCREENS_LIST = [
  'production','operator','qc-overview','qc-detail','waste','downtime','downtime-report',
  'packer','pallet','line-clearance','lc-report','stock','setup','user-admin'
]
const SCREEN_LABELS = {
  'production':'Production','operator':'Operator','qc-overview':'QC Overview','qc-detail':'QC Detail',
  'waste':'Waste Recording','downtime':'Downtime Form','downtime-report':'Downtime Report',
  'packer':'Packer Overview','pallet':'Pallet & Label','line-clearance':'Line Clearance',
  'lc-report':'LC Report','stock':'Stock Register','setup':'Setup','user-admin':'User Admin'
}

export default function UserAdmin() {
  const { showToast } = useApp()
  const [tab, setTab]         = useState('users')
  const [selected, setSelected] = useState(null)
  const [showCreate, setShowCreate] = useState(false)
  const [activePane, setActivePane] = useState('profile')

  const { items, total, loading, setFilter, refetch } = useList(userService.getAll, { limit: 50 })

  const { mutate: createUser, loading: creating } = useMutation(
    userService.create,
    { onSuccess: () => { showToast('User created'); setShowCreate(false); refetch() } }
  )
  const { mutate: updateUser } = useMutation(
    (data) => userService.update(selected.id, data),
    { onSuccess: () => { showToast('User updated'); refetch() } }
  )
  const { mutate: deleteUser } = useMutation(
    () => userService.delete(selected.id),
    { onSuccess: () => { showToast('User removed', 'warning'); setSelected(null); refetch() } }
  )
  const { mutate: updatePerms } = useMutation(
    (perms) => userService.updatePermissions(selected.id, { permissions: perms }),
    { onSuccess: () => showToast('Permissions updated') }
  )

  const roleCount = (role) => items.filter(u=>u.role===role).length
  const perms = selected?.screenPermissions || {}

  return (
    <div className="content">
      {/* Stats */}
      <div className="g4">
        <StatCard label="Total Users"  value={total||items.length}  color="blu" />
        <StatCard label="Admins"        value={roleCount('admin')}  color="pur" />
        <StatCard label="Technicians"   value={roleCount('tech')}   color="tel" />
        <StatCard label="Active"        value={items.filter(u=>u.isActive!==false).length} color="grn" />
      </div>

      {/* View tabs */}
      <div className="flex gap-2 mb-4 flex-wrap">
        {['users','roles'].map(t=>(
          <button key={t} className={`btn ${tab===t?'bpri':'bgh'}`} onClick={()=>setTab(t)}>
            {t==='users'?'👥 Users':'🔐 Roles & Permissions'}
          </button>
        ))}
      </div>

      {tab === 'users' && (
        <div className="grid grid-cols-1 lg:grid-cols-[280px_1fr] gap-4">
          {/* User list */}
          <div className="sbox">
            <div className="sbox-header">
              <span className="st font-semibold">Users</span>
              <button className="btn bpri bsm" onClick={()=>setShowCreate(true)}>+ Add</button>
            </div>
            <div className="px-3 pb-2">
              <input className="text-xs" placeholder="Search name, emp ID…"
                onChange={e=>setFilter({search:e.target.value})} />
            </div>
            <div className="overflow-y-auto max-h-[600px]">
              {loading && <div className="text-center py-6 text-tx3 text-xs">Loading…</div>}
              {items.map(u=>{
                const initials = (u.fullName||u.name||'').split(' ').map(w=>w[0]).slice(0,2).join('').toUpperCase()
                const rc = ROLE_COLORS[u.role] || 'tx3'
                return (
                  <div key={u.id}
                    className={`flex items-center gap-2.5 px-3 py-2.5 cursor-pointer border-b transition-all ${selected?.id===u.id?'bg-blu2':'hover:bg-bg3'}`}
                    style={{borderColor:'var(--bor)'}}
                    onClick={()=>{setSelected(u);setActivePane('profile')}}>
                    <div className="w-8 h-8 rounded-full flex items-center justify-center text-[10px] font-bold text-white flex-shrink-0"
                      style={{background:`var(--${rc})`}}>
                      {initials}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-medium text-tx truncate">{u.fullName||u.name}</div>
                      <div className="text-[10px] text-tx3">{u.empId} · <span style={{color:`var(--${rc})`}}>{u.role}</span></div>
                    </div>
                    {u.isActive === false && <span className="bdg brj flex-shrink-0">Off</span>}
                  </div>
                )
              })}
            </div>
          </div>

          {/* Detail pane */}
          {selected ? (
            <div className="flex flex-col gap-3">
              {/* User card */}
              <div className="card">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-14 h-14 rounded-full flex items-center justify-center text-base font-bold text-white flex-shrink-0"
                    style={{background:`var(--${ROLE_COLORS[selected.role]||'blu'})`}}>
                    {(selected.fullName||selected.name||'').split(' ').map(w=>w[0]).slice(0,2).join('').toUpperCase()}
                  </div>
                  <div>
                    <div className="font-semibold text-tx">{selected.fullName||selected.name}</div>
                    <div className="text-xs text-tx3">{selected.empId} · {selected.email||'—'}</div>
                    <span className={`bdg ${selected.isActive!==false?'bd':'brj'} mt-1 inline-flex`}>
                      {selected.isActive!==false?'Active':'Inactive'}
                    </span>
                  </div>
                  <div className="ml-auto flex gap-2">
                    <button className="btn bdan bsm" onClick={()=>confirm('Delete user?')&&deleteUser()}>Delete</button>
                  </div>
                </div>
                {/* Sub-pane tabs */}
                <div className="flex gap-1 flex-wrap border-b mb-3 pb-2" style={{borderColor:'var(--bor)'}}>
                  {['profile','screens','security'].map(p=>(
                    <button key={p}
                      className={`px-3 py-1 rounded text-[11px] font-medium transition-all ${activePane===p?'bg-blu2 text-blu':'text-tx3 hover:bg-bg3'}`}
                      onClick={()=>setActivePane(p)}>
                      {p==='profile'?'Profile':p==='screens'?'Screen Access':'Security'}
                    </button>
                  ))}
                </div>

                {activePane === 'profile' && (
                  <ProfilePane user={selected} onUpdate={d=>updateUser(d)} />
                )}
                {activePane === 'screens' && (
                  <ScreensPane perms={perms} onUpdate={updatePerms} />
                )}
                {activePane === 'security' && (
                  <SecurityPane user={selected} onUpdate={d=>updateUser(d)} />
                )}
              </div>
            </div>
          ) : (
            <div className="card flex flex-col items-center justify-center py-16 gap-3">
              <div className="text-4xl">👤</div>
              <div className="text-sm text-tx3">Select a user to view details</div>
            </div>
          )}
        </div>
      )}

      {tab === 'roles' && <RolesView items={items} />}

      {showCreate && (
        <CreateUserModal onClose={()=>setShowCreate(false)} onSave={createUser} saving={creating} />
      )}
    </div>
  )
}

function ProfilePane({ user, onUpdate }) {
  const [form, setForm] = useState({ fullName: user.fullName||user.name||'', email: user.email||'', role: user.role||'operator', plant: user.plant||'', phone: user.phone||'' })
  return (
    <div>
      <div className="frow">
        <div className="fgrp"><label>Full Name</label><input value={form.fullName} onChange={e=>setForm(f=>({...f,fullName:e.target.value}))}/></div>
        <div className="fgrp"><label>Email</label><input type="email" value={form.email} onChange={e=>setForm(f=>({...f,email:e.target.value}))}/></div>
      </div>
      <div className="frow">
        <div className="fgrp">
          <label>Role</label>
          <select value={form.role} onChange={e=>setForm(f=>({...f,role:e.target.value}))}>
            {['admin','tech','operator','qc','packer','viewer'].map(r=><option key={r} value={r}>{r}</option>)}
          </select>
        </div>
        <div className="fgrp"><label>Plant</label><input value={form.plant} onChange={e=>setForm(f=>({...f,plant:e.target.value}))}/></div>
      </div>
      <button className="btn bpri bsm" onClick={()=>onUpdate(form)}>Save Profile</button>
    </div>
  )
}

function ScreensPane({ perms, onUpdate }) {
  const [p, setP] = useState(perms)
  const toggle = (screen, type) => {
    const cur = p[screen] || {}
    setP(prev=>({...prev,[screen]:{...cur,[type]:!cur[type]}}))
  }
  return (
    <div>
      <div className="text-xs text-tx3 mb-3">Control which screens this user can access and what actions they can perform.</div>
      <div className="space-y-1 max-h-[300px] overflow-y-auto">
        {SCREENS_LIST.map(s=>{
          const sp = p[s]||{}
          return (
            <div key={s} className="flex items-center gap-3 py-1.5 border-b border-bor">
              <span className="text-xs text-tx flex-1">{SCREEN_LABELS[s]||s}</span>
              {['view','edit','export'].map(t=>(
                <label key={t} className="flex items-center gap-1 cursor-pointer text-[10px] text-tx3">
                  <input type="checkbox" checked={!!sp[t]} onChange={()=>toggle(s,t)} />
                  {t}
                </label>
              ))}
            </div>
          )
        })}
      </div>
      <button className="btn bpri bsm mt-3" onClick={()=>onUpdate(p)}>Save Permissions</button>
    </div>
  )
}

function SecurityPane({ user, onUpdate }) {
  const [pwd, setPwd] = useState('')
  return (
    <div>
      <div className="text-xs text-tx3 mb-3">Reset password or toggle account status.</div>
      <div className="frow">
        <div className="fgrp">
          <label>New Password</label>
          <input type="password" value={pwd} onChange={e=>setPwd(e.target.value)} placeholder="Leave blank to keep current" />
        </div>
        <div className="fgrp">
          <label>Account Status</label>
          <select defaultValue={user.isActive!==false?'active':'inactive'}>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
      </div>
      <button className="btn bred bsm" disabled={!pwd} onClick={()=>onUpdate({password:pwd})}>
        Reset Password
      </button>
    </div>
  )
}

function RolesView({ items }) {
  const roles = ['admin','tech','operator','qc','packer','viewer']
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
      {roles.map(role=>{
        const members = items.filter(u=>u.role===role)
        const rc = ROLE_COLORS[role]||'tx3'
        return (
          <div key={role} className="card">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-10 h-10 rounded-lg flex items-center justify-center text-xl" style={{background:`var(--${rc})`,color:'#fff'}}>
                {role==='admin'?'🛡':role==='tech'?'🔧':role==='operator'?'🖨':role==='qc'?'🔍':role==='packer'?'📦':'👁'}
              </div>
              <div>
                <div className="font-semibold text-tx capitalize">{role}</div>
                <div className="text-xs text-tx3">{members.length} members</div>
              </div>
            </div>
            <div className="flex flex-wrap gap-1">
              {members.slice(0,6).map(u=>(
                <span key={u.id} className="text-[10px] px-2 py-0.5 rounded-full" style={{background:`var(--${rc}2)`,color:`var(--${rc})`}}>
                  {u.fullName?.split(' ')[0]||u.name?.split(' ')[0]||u.empId}
                </span>
              ))}
              {members.length > 6 && <span className="text-[10px] text-tx3">+{members.length-6} more</span>}
            </div>
          </div>
        )
      })}
    </div>
  )
}

function CreateUserModal({ onClose, onSave, saving }) {
  const [form, setForm] = useState({ empId:'',fullName:'',email:'',role:'operator',plant:'Zamil Plastics',password:'Welcome@1234' })
  const set = (k,v) => setForm(f=>({...f,[k]:v}))
  return (
    <div className="modal-backdrop" onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div className="modal modal-md">
        <div className="modal-header">
          <span className="font-semibold text-sm text-tx">Create New User</span>
          <button className="text-tx3 hover:text-tx" onClick={onClose}>✕</button>
        </div>
        <div className="modal-body">
          <div className="frow">
            <div className="fgrp"><label>Employee ID *</label><input value={form.empId} onChange={e=>set('empId',e.target.value)} placeholder="EMP-0001" /></div>
            <div className="fgrp"><label>Full Name *</label><input value={form.fullName} onChange={e=>set('fullName',e.target.value)} /></div>
          </div>
          <div className="frow">
            <div className="fgrp"><label>Email</label><input type="email" value={form.email} onChange={e=>set('email',e.target.value)} /></div>
            <div className="fgrp">
              <label>Role</label>
              <select value={form.role} onChange={e=>set('role',e.target.value)}>
                {['admin','tech','operator','qc','packer','viewer'].map(r=><option key={r} value={r}>{r}</option>)}
              </select>
            </div>
          </div>
          <div className="frow">
            <div className="fgrp"><label>Plant</label><input value={form.plant} onChange={e=>set('plant',e.target.value)} /></div>
            <div className="fgrp"><label>Initial Password</label><input type="password" value={form.password} onChange={e=>set('password',e.target.value)} /></div>
          </div>
        </div>
        <div className="modal-footer">
          <button className="btn bgh" onClick={onClose}>Cancel</button>
          <button className="btn bpri" disabled={saving||!form.empId||!form.fullName} onClick={()=>onSave(form)}>
            {saving?'Creating…':'Create User'}
          </button>
        </div>
      </div>
    </div>
  )
}

function StatCard({ label, value, color }) {
  const c = {blu:'var(--blu)',pur:'var(--pur)',tel:'var(--tel)',grn:'var(--grn)'}[color]
  return <div className="sc" style={{'--sa':c}}><div className="slbl">{label}</div><div className="sval" style={{color:c}}>{value}</div></div>
}