import { useState, useEffect, useRef } from "react";
import { useAuth } from "../../contexts/AuthContext";
import { useApp } from "../../contexts/AppContext";
import { operatorService, productionService } from "../../services/api";

const COOLDOWN_SEC = 60; // 1 minute
const MONTHS = [
  "JAN",
  "FEB",
  "MAR",
  "APR",
  "MAY",
  "JUN",
  "JUL",
  "AUG",
  "SEP",
  "OCT",
  "NOV",
  "DEC",
];

function pad2(n) {
  return String(n).padStart(2, "0");
}

function fmtDateLabel(d) {
  return `${pad2(d.getDate())}-${MONTHS[d.getMonth()]}-${d.getFullYear()} ${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}`;
}

function makeSeq(printNum) {
  const d = new Date();
  return `P${pad2(d.getDate())}${pad2(d.getMonth() + 1)}${String(d.getFullYear()).slice(-2)}-${String(printNum).padStart(4, "0")}`;
}

function drawBarcodeBars(text) {
  const barW = 2.2,
    gap = 1.1;
  let bars = [];
  for (let i = 0; i < text.length; i++) {
    const c = text.charCodeAt(i);
    bars.push((c % 3 === 0 ? 3 : c % 3 === 1 ? 2 : 1.5) * barW);
    bars.push(gap + (i % 4 === 0 ? gap : 0));
  }
  bars = [
    barW * 2,
    gap,
    barW * 2,
    gap * 2,
    ...bars,
    gap * 2,
    barW * 2,
    gap,
    barW * 2,
  ];
  const rects = [];
  let x = 10;
  bars.forEach((w, i) => {
    if (i % 2 === 0) {
      rects.push(
        <rect
          key={i}
          x={parseFloat(x.toFixed(1))}
          y={4}
          width={parseFloat(w.toFixed(1))}
          height={42}
          fill="#000"
        />,
      );
    }
    x += w;
  });
  return rects;
}
const getTotalBoxes = (wo) => {
  const plannedQty = Number(wo?.plannedQty || 0);
  const boxQty = Number(wo?.boxQty || 0);

  if (!plannedQty || !boxQty) return 0;

  return Math.ceil(plannedQty / boxQty);
};

const OP_COOLDOWN_KEY = "mes_operator_print_cooldown";
const OP_LAST_PRINT_KEY = "mes_operator_last_print";

const getCooldownKey = (woId, machineId) => {
  return `${OP_COOLDOWN_KEY}_${machineId || "no-machine"}_${woId || "no-wo"}`;
};

const getLastPrintKey = (woId, machineId) => {
  return `${OP_LAST_PRINT_KEY}_${machineId || "no-machine"}_${woId || "no-wo"}`;
};

const safeSessionGet = (key) => {
  try {
    return sessionStorage.getItem(key);
  } catch (_) {
    return null;
  }
};

const safeSessionSet = (key, value) => {
  try {
    sessionStorage.setItem(key, value);
  } catch (_) {}
};

const safeSessionRemove = (key) => {
  try {
    sessionStorage.removeItem(key);
  } catch (_) {}
};

export default function OperatorScreen() {
  const { user, machine } = useAuth();
  const { showToast } = useApp();

  const [activeWO, setActiveWO] = useState(null);
  const [queue, setQueue] = useState([]);
  const [loadingWO, setLoadingWO] = useState(true);

  const [printed, setPrinted] = useState(0);

  const [cooldown, setCooldown] = useState(0);
  const [printLog, setPrintLog] = useState([]);
  const [lastPrint, setLastPrint] = useState(null);
  const timerRef = useRef(null);

  const [showLabel, setShowLabel] = useState(false);
  const [labelData, setLabelData] = useState(null);
  const [copies, setCopies] = useState(1);

  useEffect(() => {
    loadActiveWO();
    loadQueue();
  }, [machine]);

  const loadPrintedBoxes = async (woId) => {
    if (!woId) {
      setPrinted(0);
      setPrintLog([]);
      return;
    }

    try {
      const res = await operatorService.getLabels({ woId });
      const rows = res?.data?.rows || res?.data || res?.rows || res || [];
      const list = Array.isArray(rows) ? rows : [];

      setPrinted(list.length);

      setPrintLog(
        list.map((r, index) => ({
          id: r.id || r.labelSeq || index,
          time: r.printedAt
            ? new Date(r.printedAt).toLocaleTimeString()
            : r.createdAt
              ? new Date(r.createdAt).toLocaleTimeString()
              : "-",
          woId: activeWO?.woNumber || woId,
          printNum: index + 1,
          total: getTotalBoxes(activeWO),
          seqStr: `LABEL-${r.id || r.labelSeq || r.seqStr ||  index + 1}`,
        })),
      );
    } catch (error) {
      console.error("Failed to load printed labels:", error);
      showToast("Failed to load printed label count from backend", "error");
    }
  };
  useEffect(() => {
    if (activeWO?.id) {
      loadPrintedBoxes(activeWO.id);
    }
  }, [activeWO?.id]);

  const loadActiveWO = async () => {
    setLoadingWO(true);

    try {
      const machineId = machine?.id || machine?.machineId;

      if (!machineId) {
        setActiveWO(null);
        return;
      }

      const res = await operatorService.getActiveWO(machineId);
      const items = res?.data ?? res ?? [];

      setActiveWO(Array.isArray(items) ? items[0] || null : items || null);
    } catch (error) {
      console.error("Failed to load active WO:", error);
      setActiveWO(null);
    } finally {
      setLoadingWO(false);
    }
  };

  const loadQueue = async () => {
    try {
      const machineId = machine?.id || machine?.machineId;

      const params = { status: "active", limit: 10 };

      // if (machineId) {
      //   params.machineId = machineId;
      // }

      const res = await productionService.getWorkOrders(params);
      // console.log("Queue data:", res);
      setQueue(res?.data ?? res ?? []);
    } catch (error) {
      console.error("Failed to load queue:", error);
      setQueue([]);
    }
  };

  useEffect(() => {
    const machineKey = machine?.id || machine?.machineId || machine?.code;
    const woKey = activeWO?.id;

    if (!machineKey || !woKey) {
      setCooldown(0);
      setLastPrint(null);
      return;
    }

    const cooldownKey = getCooldownKey(woKey, machineKey);
    const lastPrintKey = getLastPrintKey(woKey, machineKey);

    const savedLastPrint = safeSessionGet(lastPrintKey);
    if (savedLastPrint) {
      const parsed = new Date(savedLastPrint);
      if (!Number.isNaN(parsed.getTime())) {
        setLastPrint(parsed);
      }
    }

    const syncCooldown = () => {
      const currentUntil = Number(safeSessionGet(cooldownKey) || 0);
      const remaining = Math.ceil((currentUntil - Date.now()) / 1000);

      if (remaining > 0) {
        setCooldown(remaining);
      } else {
        setCooldown(0);
        safeSessionRemove(cooldownKey);
      }
    };

    syncCooldown();

    clearInterval(timerRef.current);
    timerRef.current = setInterval(syncCooldown, 1000);

    return () => clearInterval(timerRef.current);
  }, [activeWO?.id, machine?.id, machine?.machineId, machine?.code]);

  const handlePrintClick = () => {
    if (cooldown > 0) {
      showToast(`Cooldown: ${fmtTime(cooldown)} remaining`, "warning");
      return;
    }
    if (!activeWO) {
      showToast("No active work order assigned", "warning");
      return;
    }
    const now = new Date();
    const printNum = printed + 1;
    const seqStr = makeSeq(printNum);
    setLabelData({
      fg: activeWO.productCode || activeWO.itemCode || "FG—",
      qty: Number(activeWO.boxQty || activeWO.qtyPerBox || 0).toLocaleString(),
      desc: activeWO.product || activeWO.description || "—",
      prodDate: fmtDateLabel(now),
      seqStr,
      printNum,
      total: activeWO.totalBoxes || activeWO.boxes || 0,
      woId: activeWO.woNumber || activeWO.id || "—",
      time: now.toLocaleTimeString(),
    });
    setCopies(1);
    setShowLabel(true);
  };
  // console.log(activeWO)
  const handleConfirmPrint = async () => {
    if (!labelData || !activeWO?.id) return;

    try {
      setShowLabel(false);

      await operatorService.printLabel({
        woId: activeWO.id,
        machineId: machine?.id || machine?.machineId,
        quantity: Number(activeWO?.boxQty || 1),
        status: "packed",
        labelSeq: labelData.seqStr,
      });

      await loadPrintedBoxes(activeWO.id);

      const printedAt = new Date();
      const machineKey = machine?.id || machine?.machineId || machine?.code;
      const cooldownUntil = printedAt.getTime() + COOLDOWN_SEC * 1000;

      setLastPrint(printedAt);
      setCooldown(COOLDOWN_SEC);

      safeSessionSet(
        getCooldownKey(activeWO.id, machineKey),
        String(cooldownUntil),
      );
      safeSessionSet(
        getLastPrintKey(activeWO.id, machineKey),
        printedAt.toISOString(),
      );

      showToast(
        `Box label #${labelData.printNum} saved and sent to printer`,
        "success",
      );
    } catch (error) {
      console.error("Print label failed:", error);
      showToast(error?.message || "Failed to save label in database", "error");
    }
  };

  const fmtTime = (s) => `${pad2(Math.floor(s / 60))}:${pad2(s % 60)}`;
  const cdPct =
    cooldown > 0 ? ((COOLDOWN_SEC - cooldown) / COOLDOWN_SEC) * 100 : 100;
  const totalBoxes = getTotalBoxes(activeWO);

  const remaining = Math.max(0, totalBoxes - printed);

  const initials = (user?.fullName || user?.name || "AH")
    .split(" ")
    .map((w) => w[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
  const fullName = (
    user?.fullName ||
    user?.name ||
    "AHMED HASSAN"
  ).toUpperCase();
  console.log(queue);
  return (
    <div
      style={{
        background: "var(--bg)",
        minHeight: "calc(100vh - 96px)",
        padding: "18px 26px",
      }}
    >
      {/* ── Label Modal ──────────────────────────────────────────────── */}
      {showLabel && labelData && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0,0,0,.55)",
            zIndex: 1000,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
          onClick={(e) => {
            if (e.target === e.currentTarget) setShowLabel(false);
          }}
        >
          <div
            style={{
              background: "var(--bg2)",
              border: "1px solid var(--bor)",
              borderRadius: "var(--rl)",
              padding: "22px 24px",
              width: "580px",
              maxWidth: "96vw",
              maxHeight: "90vh",
              overflowY: "auto",
              position: "relative",
            }}
          >
            <button
              onClick={() => setShowLabel(false)}
              style={{
                position: "absolute",
                top: "14px",
                right: "16px",
                background: "none",
                border: "none",
                color: "var(--tx3)",
                fontSize: "18px",
                cursor: "pointer",
                lineHeight: 1,
              }}
            >
              ✕
            </button>

            {/* Modal title */}
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: "10px",
                marginBottom: "14px",
              }}
            >
              <span
                style={{
                  width: "32px",
                  height: "32px",
                  borderRadius: "9px",
                  background: "var(--grn)",
                  color: "#fff",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: "16px",
                }}
              >
                🖨
              </span>
              <span
                style={{
                  fontSize: "15px",
                  fontWeight: 700,
                  color: "var(--tx)",
                }}
              >
                Print Box Label
              </span>
            </div>

            {/* Label preview */}
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                marginBottom: "16px",
              }}
            >
              <div
                style={{
                  width: "380px",
                  maxWidth: "100%",
                  background: "#fff",
                  border: "1px solid #ccc",
                  borderRadius: "4px",
                  fontFamily: "Arial,sans-serif",
                  color: "#000",
                  overflow: "hidden",
                  boxShadow: "0 2px 12px rgba(0,0,0,.18)",
                }}
              >
                {/* Logo row */}
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "10px",
                    padding: "10px 14px 8px",
                    borderBottom: "2px solid #000",
                  }}
                >
                  <div>
                    <div
                      style={{
                        fontSize: "22px",
                        fontWeight: 900,
                        color: "#1a5e2a",
                        letterSpacing: "-1px",
                        fontFamily: "'Arial Black',Arial,sans-serif",
                      }}
                    >
                      Zamil
                      <span style={{ color: "#2a7a3a", fontSize: "16px" }}>
                        ✔
                      </span>
                    </div>
                    <div
                      style={{
                        fontSize: "10px",
                        color: "#1a5e2a",
                        fontWeight: 700,
                        lineHeight: 1.2,
                      }}
                    >
                      Plastics
                    </div>
                  </div>
                </div>
                {/* Body */}
                <div style={{ padding: "10px 14px" }}>
                  <div
                    style={{
                      fontSize: "28px",
                      fontWeight: 900,
                      textAlign: "center",
                      letterSpacing: "1px",
                      color: "#111",
                      margin: "6px 0 2px",
                      fontFamily: "Arial,sans-serif",
                    }}
                  >
                    {labelData.fg}
                  </div>
                  <div
                    style={{
                      textAlign: "center",
                      fontSize: "14px",
                      color: "#1a5e2a",
                      fontWeight: 700,
                      marginBottom: "8px",
                    }}
                  >
                    Qty: <span>{labelData.qty}</span>
                  </div>
                  <div
                    style={{
                      border: "1px solid #ccc",
                      padding: "7px 10px",
                      fontSize: "11px",
                      color: "#333",
                      marginBottom: "6px",
                      lineHeight: 1.4,
                      minHeight: "32px",
                    }}
                  >
                    {labelData.desc}
                  </div>
                  <div
                    style={{
                      display: "grid",
                      gridTemplateColumns: "1fr 1fr",
                      border: "1px solid #ccc",
                      marginBottom: "8px",
                    }}
                  >
                    <div
                      style={{
                        padding: "6px 9px",
                        gridColumn: "span 2",
                        borderBottom: "none",
                      }}
                    >
                      <div
                        style={{
                          fontSize: "9px",
                          textTransform: "uppercase",
                          color: "#1a5e2a",
                          fontWeight: 700,
                          letterSpacing: ".5px",
                        }}
                      >
                        Prod Date &amp; Shift
                      </div>
                      <div
                        style={{
                          fontSize: "12px",
                          fontWeight: 700,
                          color: "#111",
                          marginTop: "2px",
                          fontFamily: "'Courier New',monospace",
                        }}
                      >
                        {labelData.prodDate}
                      </div>
                    </div>
                  </div>
                  {/* Barcode */}
                  <div style={{ textAlign: "center", padding: "8px 0 4px" }}>
                    <svg
                      viewBox="0 0 340 50"
                      style={{ maxWidth: "100%", height: "56px" }}
                    >
                      {drawBarcodeBars(labelData.seqStr)}
                    </svg>
                    <div
                      style={{
                        fontSize: "10px",
                        fontFamily: "'Courier New',monospace",
                        color: "#555",
                        marginTop: "2px",
                        letterSpacing: "1px",
                      }}
                    >
                      {labelData.seqStr}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Printer & Copies row */}
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "1fr auto",
                gap: "10px",
                marginBottom: "14px",
                alignItems: "end",
              }}
            >
              <div>
                <label
                  style={{
                    fontSize: "9px",
                    textTransform: "uppercase",
                    letterSpacing: ".8px",
                    color: "var(--tx3)",
                    fontWeight: 700,
                    display: "block",
                    marginBottom: "4px",
                  }}
                >
                  Printer
                </label>
                <select
                  style={{
                    width: "100%",
                    background: "var(--bg3)",
                    border: "1px solid var(--bor2)",
                    borderRadius: "8px",
                    padding: "8px 10px",
                    fontSize: "12px",
                    color: "var(--tx)",
                    fontFamily: "'DM Sans',sans-serif",
                    outline: "none",
                  }}
                >
                  <option>Zebra ZT410 — Bay A (Line 1)</option>
                  <option>Zebra ZT230 — Bay B (Line 2)</option>
                  <option>Default Printer</option>
                </select>
              </div>
              <div>
                <label
                  style={{
                    fontSize: "9px",
                    textTransform: "uppercase",
                    letterSpacing: ".8px",
                    color: "var(--tx3)",
                    fontWeight: 700,
                    display: "block",
                    marginBottom: "4px",
                  }}
                >
                  Copies
                </label>
                <input
                  type="number"
                  min={1}
                  max={10}
                  value={copies}
                  onChange={(e) =>
                    setCopies(
                      Math.max(1, Math.min(10, parseInt(e.target.value) || 1)),
                    )
                  }
                  style={{
                    width: "64px",
                    background: "var(--bg3)",
                    border: "1px solid var(--bor2)",
                    borderRadius: "8px",
                    padding: "8px 10px",
                    fontSize: "13px",
                    color: "var(--tx)",
                    fontFamily: "'DM Sans',sans-serif",
                    outline: "none",
                    textAlign: "center",
                  }}
                />
              </div>
            </div>

            {/* Actions */}
            <div
              style={{
                display: "flex",
                gap: "10px",
                justifyContent: "flex-end",
                paddingTop: "14px",
                borderTop: "1px solid var(--bor)",
              }}
            >
              <button
                onClick={() => setShowLabel(false)}
                style={{
                  padding: "8px 18px",
                  background: "var(--bg3)",
                  border: "1px solid var(--bor)",
                  borderRadius: "8px",
                  color: "var(--tx)",
                  fontSize: "13px",
                  cursor: "pointer",
                  fontFamily: "'DM Sans',sans-serif",
                  fontWeight: 500,
                }}
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmPrint}
                style={{
                  padding: "8px 20px",
                  background: "var(--grn)",
                  border: "none",
                  borderRadius: "8px",
                  color: "#fff",
                  fontSize: "13px",
                  cursor: "pointer",
                  fontFamily: "'DM Sans',sans-serif",
                  fontWeight: 700,
                }}
              >
                🖨 Print Label
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── Operator Identity Strip ────────────────────────────────── */}
      <div
        style={{
          background: "var(--bg2)",
          border: "1px solid var(--bor)",
          borderRadius: "var(--rl)",
          padding: "14px 20px",
          marginBottom: "16px",
          display: "flex",
          alignItems: "center",
          gap: "14px",
        }}
      >
        <div
          style={{
            width: "44px",
            height: "44px",
            borderRadius: "50%",
            background: "var(--tel2)",
            border: "2px solid var(--tel)",
            color: "var(--tel)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: "14px",
            fontWeight: 700,
            flexShrink: 0,
            fontFamily: "'Space Mono',monospace",
          }}
        >
          {initials}
        </div>
        <div style={{ flex: 1 }}>
          <div
            style={{ fontSize: "14px", fontWeight: 600, color: "var(--tx)" }}
          >
            {fullName}
          </div>
          <div
            style={{ fontSize: "12px", color: "var(--tx3)", marginTop: "2px" }}
          >
            Operator · {user?.empId || "—"} · Checked in{" "}
            {new Date().toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            })}
          </div>
        </div>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "6px",
            background: "var(--tel2)",
            border: "1px solid var(--tel)",
            borderRadius: "20px",
            padding: "5px 14px",
            color: "var(--tel)",
            fontSize: "12px",
            fontWeight: 600,
          }}
        >
          <span
            style={{
              width: "7px",
              height: "7px",
              borderRadius: "50%",
              background: "var(--tel)",
              display: "inline-block",
            }}
          />
          Active
        </div>
      </div>

      {/* ── Info bar ───────────────────────────────────────────────── */}
      <div
        style={{
          display: "flex",

          alignItems: "center",
          gap: "7px",
          fontSize: "12px",
          marginBottom: "16px",
          padding: "9px 14px",
          background: "var(--blu3)",
          borderRadius: "10px",
          border: "1px solid var(--blu2)",
          color: "var(--blu2)",
        }}
      >
        <span style={{ fontSize: "15px", color: "var(--blu)" }}></span>
        <span className="flex ">
          <strong style={{ color: "var(--blu)" }}>Operator view</strong>
          <div style={{ color: "var(--blu)" }}>
            {" "}
            — Only the currently running work order is shown. Details are
            assigned by your Process Technician and are read-only. You can only
            press Print Label.
          </div>
        </span>
      </div>

      {/* ── Stats row ─────────────────────────────────────────────── */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(3,1fr)",
          gap: "12px",
          marginBottom: "16px",
        }}
      >
        <div
          style={{
            background: "var(--bg2)",
            border: "1px solid var(--bor)",
            borderRadius: "var(--r)",
            padding: "14px 16px",
          }}
        >
          <div
            style={{
              fontSize: "10px",
              textTransform: "uppercase",
              letterSpacing: "1.2px",
              color: "var(--tx3)",
              marginBottom: "6px",
              fontWeight: 600,
            }}
          >
            Assigned WOs
          </div>
          <div
            style={{
              fontFamily: "'Space Mono',monospace",
              fontSize: "22px",
              fontWeight: 700,
              color: "var(--tx)",
            }}
          >
            {queue.length}
          </div>
          <div
            style={{ fontSize: "11px", color: "var(--tx3)", marginTop: "4px" }}
          >
            Current shift
          </div>
        </div>
        <div
          style={{
            background: "var(--bg2)",
            border: "1px solid var(--bor)",
            borderRadius: "var(--r)",
            padding: "14px 16px",
          }}
        >
          <div
            style={{
              fontSize: "10px",
              textTransform: "uppercase",
              letterSpacing: "1.2px",
              color: "var(--tx3)",
              marginBottom: "6px",
              fontWeight: 600,
            }}
          >
            Labels Printed
          </div>
          <div
            style={{
              fontFamily: "'Space Mono',monospace",
              fontSize: "22px",
              fontWeight: 700,
              color: "var(--grn)",
            }}
          >
            {printed}
          </div>
          <div
            style={{ fontSize: "11px", color: "var(--tx3)", marginTop: "4px" }}
          >
            This session
          </div>
        </div>
        <div
          style={{
            background: "var(--bg2)",
            border: "1px solid var(--bor)",
            borderRadius: "var(--r)",
            padding: "14px 16px",
          }}
        >
          <div
            style={{
              fontSize: "10px",
              textTransform: "uppercase",
              letterSpacing: "1.2px",
              color: "var(--tx3)",
              marginBottom: "6px",
              fontWeight: 600,
            }}
          >
            Next print in
          </div>
          <div
            style={{
              fontFamily: "'Space Mono',monospace",
              fontSize: "22px",
              fontWeight: 700,
              color: cooldown > 0 ? "var(--amb)" : "var(--grn)",
            }}
          >
            {cooldown > 0 ? fmtTime(cooldown) : "Ready"}
          </div>
          <div
            style={{ fontSize: "11px", color: "var(--tx3)", marginTop: "4px" }}
          >
            {cooldown > 0 ? "Cooldown active" : "No cooldown"}
          </div>
        </div>
      </div>

      {/* ── Machine assigned card ─────────────────────────────────── */}
      <div
        style={{
          background: "var(--bg2)",
          border: "2px solid var(--grn)",
          borderRadius: "var(--rl)",
          padding: "14px 18px",
          marginBottom: "16px",
          display: "flex",
          alignItems: "center",
          gap: "14px",
        }}
      >
        <div
          style={{
            width: "44px",
            height: "44px",
            borderRadius: "12px",
            background: "var(--grn2)",
            border: "1px solid var(--grn)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: "20px",
            flexShrink: 0,
          }}
        >
          🏭
        </div>
        <div>
          <div
            style={{
              fontFamily: "'Space Mono',monospace",
              fontSize: "15px",
              fontWeight: 700,
              color: "var(--grn)",
            }}
          >
            {machine?.code || machine?.name || "—"}
          </div>
          <div
            style={{ fontSize: "11px", color: "var(--tx3)", marginTop: "2px" }}
          >
            {machine?.type || "INJECTION MOULDING"} ·{" "}
            {machine?.plant || "FPP BU"}
          </div>
          <div
            style={{ fontSize: "11px", color: "var(--tx3)", marginTop: "3px" }}
          >
            Assigned by:{" "}
            <span style={{ color: "var(--tx)", fontWeight: 500 }}>
              Process Technician
            </span>
          </div>
        </div>
        <div
          style={{
            marginLeft: "auto",
            display: "flex",
            alignItems: "center",
            gap: "5px",
            background: "var(--amb2)",
            border: "1px solid var(--amb)",
            borderRadius: "20px",
            padding: "4px 13px",
            fontSize: "11px",
            fontWeight: 700,
            color: "var(--amb)",
          }}
        >
          <span
            style={{
              width: "6px",
              height: "6px",
              borderRadius: "50%",
              background: "var(--amb)",
              display: "inline-block",
            }}
          />
          Running
        </div>
      </div>

      {/* ── Section header ────────────────────────────────────────── */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: "8px",
          marginBottom: "12px",
        }}
      >
        <span
          style={{
            width: "7px",
            height: "7px",
            borderRadius: "50%",
            background: "var(--grn)",
            display: "inline-block",
          }}
        />
        <span style={{ fontSize: "13px", fontWeight: 600, color: "var(--tx)" }}>
          Currently Running Work Order
        </span>
        <span
          style={{
            display: "flex",
            alignItems: "center",
            gap: "5px",
            background: "var(--grn2)",
            border: "1.5px solid var(--grn)",
            borderRadius: "20px",
            padding: "2px 10px",
            fontSize: "11px",
            fontWeight: 700,
            color: "var(--grn)",
          }}
        >
          <span
            style={{
              width: "5px",
              height: "5px",
              borderRadius: "50%",
              background: "var(--grn)",
              display: "inline-block",
            }}
          />
          Live
        </span>
        <span
          style={{
            marginLeft: "auto",
            fontSize: "11px",
            color: "var(--tx3)",
            fontStyle: "italic",
          }}
        >
          Only the active WO is shown · 1-min cooldown between labels
        </span>
      </div>

      {/* Loading */}
      {loadingWO && (
        <div
          style={{
            background: "var(--bg2)",
            border: "1px solid var(--bor)",
            borderRadius: "var(--rl)",
            padding: "28px",
            textAlign: "center",
            color: "var(--tx3)",
            marginBottom: "16px",
          }}
        >
          Loading active work order…
        </div>
      )}

      {/* No Running WO — amber state */}
      {!loadingWO && !activeWO && (
        <div
          style={{
            background: "var(--amb2)",
            border: "1.5px solid var(--amb)",
            borderRadius: "var(--rl)",
            padding: "28px",
            textAlign: "center",
            marginBottom: "16px",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: "10px",
          }}
        >
          <div style={{ fontSize: "36px" }}>⏳</div>
          <div
            style={{ fontSize: "15px", fontWeight: 600, color: "var(--amb)" }}
          >
            No Running Work Order
          </div>
          <div
            style={{ fontSize: "12px", color: "var(--tx3)", maxWidth: "380px" }}
          >
            Your Process Technician has not started any work order on this
            machine yet. Wait for them to start a WO from the Process Tech
            screen.
          </div>
        </div>
      )}

      {/* ── Running WO Card ───────────────────────────────────────── */}
      {!loadingWO && activeWO && (
        <div
          style={{
            background: "var(--bg2)",
            border: "2px solid var(--grn)",
            borderRadius: "var(--rl)",
            overflow: "hidden",
            marginBottom: "16px",
          }}
        >
          {/* WO Header */}
          <div
            style={{
              padding: "16px 20px",
              borderBottom: "1px solid var(--bor)",
              display: "flex",
              alignItems: "flex-start",
              justifyContent: "space-between",
              gap: "12px",
            }}
          >
            <div>
              <div
                style={{
                  fontFamily: "'Space Mono',monospace",
                  fontSize: "14px",
                  fontWeight: 700,
                  color: "var(--blu)",
                }}
              >
                {activeWO.woNumber}
              </div>
              <div
                style={{
                  fontSize: "10px",
                  color: "var(--tx3)",
                  marginTop: "2px",
                  textTransform: "uppercase",
                  letterSpacing: ".8px",
                }}
              >
                {activeWO.plant || "PRODUCTION"}
              </div>
              <div
                style={{
                  fontSize: "15px",
                  fontWeight: 600,
                  color: "var(--tx)",
                  marginTop: "5px",
                }}
              >
                {activeWO.product}
              </div>
              <div
                style={{
                  fontSize: "12px",
                  color: "var(--tx3)",
                  marginTop: "2px",
                }}
              >
                {activeWO.productCode || "—"}
              </div>
            </div>
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "flex-end",
                gap: "6px",
              }}
            >
              <span
                style={{
                  display: "inline-flex",
                  padding: "3px 10px",
                  borderRadius: "20px",
                  fontSize: "10px",
                  fontWeight: 700,
                  background: "var(--grn2)",
                  border: "1px solid var(--grn)",
                  color: "var(--grn)",
                }}
              >
                Running
              </span>
              <span style={{ fontSize: "11.5px", color: "var(--tx3)" }}>
                Machine:{" "}
                <b
                  style={{
                    color: "var(--grn)",
                    fontFamily: "'Space Mono',monospace",
                  }}
                >
                  {machine?.name || machine?.id || "—"}
                </b>
              </span>
            </div>
          </div>

          {/* WO Details grid */}
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(5,1fr)",
              borderBottom: "1px solid var(--bor)",
            }}
          >
            {[
              ["Item Code", activeWO.productCode || "—", "var(--grn)"],
              [
                "Planned Qty",
                Number(activeWO.plannedQty || 0).toLocaleString(),
                "var(--tx)",
              ],
              [
                "Produced Qty",
                Number(activeWO.producedQty || 0).toLocaleString(),
                "var(--grn)",
              ],
              [
                "Qty Per Box",
                Number(activeWO.boxQty || 0).toLocaleString(),
                "var(--tx)",
              ],
              ["Priority", activeWO.priority || "—", "var(--amb)"],
            ].map(([label, val, col], i) => (
              <div
                key={label}
                style={{
                  padding: "12px 16px",
                  borderRight: i < 4 ? "1px solid var(--bor)" : "none",
                }}
              >
                <div
                  style={{
                    fontSize: "10px",
                    textTransform: "uppercase",
                    letterSpacing: ".8px",
                    color: "var(--tx3)",
                    fontWeight: 600,
                    marginBottom: "5px",
                  }}
                >
                  {label}
                </div>
                <div
                  style={{
                    fontFamily: "'Space Mono',monospace",
                    fontSize: "12px",
                    fontWeight: 700,
                    color: col,
                  }}
                >
                  {val}
                </div>
              </div>
            ))}
          </div>

          {/* Print Zone */}
          <div
            style={{
              padding: "20px",
              background: "var(--bg3)",
              display: "flex",
              alignItems: "center",
              gap: "18px",
            }}
          >
            <button
              onClick={handlePrintClick}
              disabled={cooldown > 0}
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                gap: "6px",
                background: cooldown > 0 ? "var(--bg4)" : "var(--grn)",
                border: cooldown > 0 ? "1px solid var(--bor2)" : "none",
                color: cooldown > 0 ? "var(--tx3)" : "#fff",
                fontFamily: "'DM Sans',sans-serif",
                borderRadius: "14px",
                cursor: cooldown > 0 ? "not-allowed" : "pointer",
                transition: ".15s",
                flexShrink: 0,
                width: "148px",
                height: "84px",
                fontSize: "14px",
                fontWeight: 700,
              }}
            >
              <span style={{ fontSize: "24px", lineHeight: 1 }}>🖨</span>
              Print Label
              <span
                style={{ fontSize: "10px", opacity: 0.8, fontWeight: 400 }}
                id="op2-btn-sub"
              >
                {cooldown > 0 ? fmtTime(cooldown) : "1 label per press"}
              </span>
            </button>

            <div style={{ flex: 1, minWidth: 0 }}>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  marginBottom: "6px",
                }}
              >
                <span style={{ fontSize: "12px", color: "var(--tx2)" }}>
                  {cooldown > 0
                    ? "Cooldown active — next label in"
                    : "Ready — press Print Label to print"}
                </span>
                <span
                  style={{
                    fontFamily: "'Space Mono',monospace",
                    fontSize: "20px",
                    fontWeight: 700,
                    color: cooldown > 0 ? "var(--amb)" : "var(--grn)",
                  }}
                >
                  {cooldown > 0 ? fmtTime(cooldown) : "Ready"}
                </span>
              </div>
              <div
                style={{
                  height: "10px",
                  background: "var(--bg4)",
                  borderRadius: "10px",
                  overflow: "hidden",
                  marginBottom: "8px",
                }}
              >
                <div
                  style={{
                    height: "100%",
                    borderRadius: "10px",
                    width: `${cdPct}%`,
                    background: cooldown > 0 ? "var(--amb)" : "var(--grn)",
                    transition: "width .5s linear",
                  }}
                />
              </div>
              <div style={{ fontSize: "11px", color: "var(--tx3)" }}>
                1-minute cooldown activates after each print
              </div>
              <div
                style={{
                  fontSize: "11px",
                  color: "var(--tx3)",
                  marginTop: "3px",
                }}
              >
                {lastPrint
                  ? `Last printed: ${lastPrint.toLocaleTimeString()}`
                  : "Not yet printed this session"}
              </div>
            </div>

            <div
              style={{
                display: "flex",
                flexDirection: "column",
                gap: "7px",
                flexShrink: 0,
              }}
            >
              <div
                style={{
                  background: "var(--bg2)",
                  border: "1px solid var(--bor)",
                  borderRadius: "10px",
                  padding: "9px 16px",
                  textAlign: "center",
                  minWidth: "80px",
                }}
              >
                <div
                  style={{
                    fontFamily: "'Space Mono',monospace",
                    fontSize: "22px",
                    fontWeight: 700,
                    color: "var(--grn)",
                    lineHeight: 1,
                  }}
                >
                  {printed}
                </div>
                <div
                  style={{
                    fontSize: "9px",
                    textTransform: "uppercase",
                    letterSpacing: ".8px",
                    color: "var(--tx3)",
                    marginTop: "3px",
                  }}
                >
                  Printed
                </div>
              </div>
              <div
                style={{
                  background: "var(--bg2)",
                  border: "1px solid var(--bor)",
                  borderRadius: "10px",
                  padding: "9px 16px",
                  textAlign: "center",
                  minWidth: "80px",
                }}
              >
                <div
                  style={{
                    fontFamily: "'Space Mono',monospace",
                    fontSize: "22px",
                    fontWeight: 700,
                    color: "var(--tx)",
                    lineHeight: 1,
                  }}
                >
                  {remaining}
                </div>
                <div
                  style={{
                    fontSize: "9px",
                    textTransform: "uppercase",
                    letterSpacing: ".8px",
                    color: "var(--tx3)",
                    marginTop: "3px",
                  }}
                >
                  Remaining
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── WO Queue ──────────────────────────────────────────────── */}
      <div
        style={{
          background: "var(--bg2)",
          border: "1px solid var(--bor)",
          borderRadius: "var(--rl)",
          padding: "14px 18px",
          marginBottom: "14px",
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "7px",
            marginBottom: "10px",
          }}
        >
          <span
            style={{
              width: "7px",
              height: "7px",
              borderRadius: "50%",
              background: "var(--blu)",
              display: "inline-block",
            }}
          />
          <span
            style={{ fontSize: "12px", fontWeight: 600, color: "var(--tx)" }}
          >
            Work Order Queue — Today
          </span>
          <span
            style={{
              marginLeft: "auto",
              fontSize: "11px",
              color: "var(--tx3)",
            }}
          >
            Running WO shown above · Others queued
          </span>
        </div>
        {queue.length === 0 ? (
          <div
            style={{
              textAlign: "center",
              padding: "16px",
              color: "var(--tx3)",
              fontSize: "12px",
            }}
          >
            No work orders in queue.
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
            {queue.map((wo) => (
              <div
                key={wo.id}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                  padding: "8px 12px",
                  background:
                    wo.status === "active" ? "var(--grn2)" : "var(--bg3)",
                  borderRadius: "9px",
                  border: `1px solid ${wo.status === "active" ? "var(--grn)" : "var(--bor)"}`,
                }}
              >
                <span
                  style={{
                    fontSize: "13px",
                    color: wo.status === "active" ? "var(--grn)" : "var(--tx3)",
                  }}
                >
                  {wo.status === "active" ? "▶" : "⏱"}
                </span>
                <span
                  style={{
                    fontFamily: "'Space Mono',monospace",
                    fontSize: "11px",
                    fontWeight: 700,
                    color: "var(--blu)",
                    minWidth: "130px",
                  }}
                >
                  {wo.woNumber}
                </span>
                <span
                  style={{
                    fontSize: "11px",
                    color: "var(--tx2)",
                    flex: 1,
                    whiteSpace: "nowrap",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                  }}
                >
                  {wo.product}
                </span>
                <span
                  style={{
                    fontFamily: "'Space Mono',monospace",
                    fontSize: "11px",
                    color: "var(--tx3)",
                  }}
                >
                  {getTotalBoxes(wo)} boxes
                </span>
                <span
                  style={{
                    display: "inline-flex",
                    padding: "2px 8px",
                    borderRadius: "20px",
                    fontSize: "9px",
                    fontWeight: 700,
                    background:
                      wo.status === "active" ? "var(--grn2)" : "var(--bg3)",
                    border: `1px solid ${wo.status === "active" ? "var(--grn)" : "var(--bor2)"}`,
                    color: wo.status === "active" ? "var(--grn)" : "var(--tx3)",
                  }}
                >
                  {wo.status === "active" ? "Running" : wo.status}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ── Print Log ─────────────────────────────────────────────── */}
      <div
        style={{
          background: "var(--bg2)",
          border: "1px solid var(--bor)",
          borderRadius: "var(--rl)",
          padding: "14px 18px",
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "7px",
            marginBottom: "10px",
          }}
        >
          <span
            style={{
              width: "7px",
              height: "7px",
              borderRadius: "50%",
              background: "var(--blu)",
              display: "inline-block",
            }}
          />
          <span
            style={{ fontSize: "12px", fontWeight: 600, color: "var(--tx)" }}
          >
            Print Log — This Session
          </span>
          <span
            style={{
              marginLeft: "auto",
              fontSize: "11px",
              color: "var(--tx3)",
            }}
          >
            {printed} label{printed !== 1 ? "s" : ""} printed
          </span>
        </div>
        {printLog.length === 0 ? (
          <div
            style={{
              textAlign: "center",
              padding: "18px",
              color: "var(--tx3)",
              fontSize: "12px",
            }}
          >
            No labels printed yet. Press Print Label to begin.
          </div>
        ) : (
          <div>
            {printLog.map((e) => (
              <div
                key={e.id}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                  padding: "7px 0",
                  borderBottom: "1px solid var(--bor)",
                  fontSize: "12px",
                }}
              >
                <div
                  style={{
                    fontFamily: "'Space Mono',monospace",
                    fontSize: "11px",
                    color: "var(--tx3)",
                    minWidth: "30px",
                    textAlign: "right",
                  }}
                >
                  #{e.printNum}
                </div>
                <div
                  style={{
                    fontFamily: "'Space Mono',monospace",
                    fontSize: "11px",
                    color: "var(--tx3)",
                  }}
                >
                  {e.time}
                </div>
                <div
                  style={{
                    fontFamily: "'Space Mono',monospace",
                    color: "var(--blu)",
                    fontSize: "11px",
                    fontWeight: 700,
                  }}
                >
                  {e.woId}
                </div>
                <div style={{ flex: 1 }} />
                <div
                  style={{
                    fontSize: "10px",
                    padding: "2px 8px",
                    borderRadius: "20px",
                    background: "var(--grn2)",
                    border: "1px solid var(--grn)",
                    color: "var(--grn)",
                    fontWeight: 600,
                  }}
                >
                  Label {e.printNum} of {e.total}
                </div>
                <div
                  style={{
                    fontSize: "10px",
                    padding: "2px 8px",
                    borderRadius: "20px",
                    background: "var(--tel2)",
                    border: "1px solid var(--tel)",
                    color: "var(--tel)",
                    fontWeight: 600,
                    fontFamily: "'Space Mono',monospace",
                  }}
                >
                  {e.seqStr}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
