import { useState } from 'react'
import { installService } from '../../services/api'

const STEPS = ['Welcome','Database','Schema','Admin','Complete']

export default function InstallWizard() {
  const [step, setStep]   = useState(0)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [ok, setOk]       = useState('')

  const [db, setDb] = useState({ dialect:'sqlite', storage:'./zamil_mes.sqlite', host:'localhost', port:'5432', database:'zamil_mes', username:'postgres', password:'' })
  const [admin, setAdmin] = useState({ empId:'EMP-0001', fullName:'', password:'', seedDemoData:true })
  const setDbF  = (k,v) => setDb(f=>({...f,[k]:v}))
  const setAdmF = (k,v) => setAdmin(f=>({...f,[k]:v}))

  const run = async (fn) => {
    setLoading(true); setError(''); setOk('')
    try { await fn(); } catch(e) { setError(e?.message||'Operation failed') } finally { setLoading(false) }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{background:'var(--bg)'}}>
      <div className="w-full max-w-xl">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="mono text-2xl font-bold text-blu mb-1">ZAMIL MES</div>
          <div className="text-tx3 text-xs uppercase tracking-widest">Installation Wizard</div>
        </div>

        {/* Progress */}
        <div className="flex mb-6 relative">
          <div className="absolute top-3 left-0 right-0 h-0.5 bg-bor2 z-0"/>
          {STEPS.map((s,i)=>(
            <div key={s} className="flex-1 flex flex-col items-center relative z-10">
              <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold border-2 ${
                i<step?'bg-grn border-grn text-white':i===step?'bg-blu border-blu text-white':'bg-bg border-bor2 text-tx3'
              }`}>
                {i<step?'✓':i+1}
              </div>
              <div className={`text-[10px] mt-1 ${i===step?'text-blu font-semibold':'text-tx3'}`}>{s}</div>
            </div>
          ))}
        </div>

        {/* Step content */}
        <div className="card">
          {error && <div className="alert alert-error mb-4">{error}</div>}
          {ok    && <div className="alert alert-success mb-4">{ok}</div>}

          {step===0 && (
            <div className="text-center space-y-3">
              <div className="text-4xl">🏭</div>
              <h2 className="text-lg font-bold text-tx">Welcome to Zamil MES</h2>
              <p className="text-sm text-tx3">This wizard will guide you through setting up the Manufacturing Execution System. You'll configure the database, create the schema, and set up the administrator account.</p>
              <button className="btn bpri w-full justify-center mt-4" onClick={()=>setStep(1)}>Start Setup →</button>
            </div>
          )}

          {step===1 && (
            <div>
              <h3 className="font-semibold text-tx mb-4">Database Configuration</h3>
              <div className="fgrp">
                <label>Database Engine</label>
                <select value={db.dialect} onChange={e=>setDbF('dialect',e.target.value)}>
                  <option value="sqlite">SQLite (Recommended for single-server)</option>
                  <option value="postgres">PostgreSQL</option>
                  <option value="mysql">MySQL</option>
                </select>
              </div>
              {db.dialect==='sqlite' ? (
                <div className="fgrp"><label>Database File Path</label><input value={db.storage} onChange={e=>setDbF('storage',e.target.value)} /></div>
              ) : (
                <>
                  <div className="frow">
                    <div className="fgrp"><label>Host</label><input value={db.host} onChange={e=>setDbF('host',e.target.value)}/></div>
                    <div className="fgrp"><label>Port</label><input value={db.port} onChange={e=>setDbF('port',e.target.value)}/></div>
                  </div>
                  <div className="frow">
                    <div className="fgrp"><label>Database Name</label><input value={db.database} onChange={e=>setDbF('database',e.target.value)}/></div>
                    <div className="fgrp"><label>Username</label><input value={db.username} onChange={e=>setDbF('username',e.target.value)}/></div>
                  </div>
                  <div className="fgrp"><label>Password</label><input type="password" value={db.password} onChange={e=>setDbF('password',e.target.value)}/></div>
                </>
              )}
              <div className="flex gap-2 mt-4">
                <button className="btn bgh flex-1" onClick={()=>setStep(0)}>← Back</button>
                <button className="btn bpri flex-1" disabled={loading}
                  onClick={()=>run(async()=>{ await installService.testConnection(db); setOk('Connection successful!'); setTimeout(()=>setStep(2),1200) })}>
                  {loading?'Testing…':'Test & Continue →'}
                </button>
              </div>
            </div>
          )}

          {step===2 && (
            <div>
              <h3 className="font-semibold text-tx mb-2">Create Database Schema</h3>
              <p className="text-xs text-tx3 mb-4">This will create all required tables and indexes. Existing data will not be affected.</p>
              <div className="rounded-lg p-3 mb-4 text-xs font-mono" style={{background:'var(--bg3)'}}>
                Tables: Users · Machines · Locations · Shifts · WorkOrders ·<br/>
                QCResults · WasteRecords · DowntimeRecords · Boxes · Pallets ·<br/>
                LineClearances · StockRecords · AuditLog · SystemConfig
              </div>
              <div className="flex gap-2">
                <button className="btn bgh flex-1" onClick={()=>setStep(1)}>← Back</button>
                <button className="btn bpri flex-1" disabled={loading}
                  onClick={()=>run(async()=>{ await installService.createSchema(); setOk('Schema created!'); setTimeout(()=>setStep(3),1200) })}>
                  {loading?'Creating…':'Create Schema →'}
                </button>
              </div>
            </div>
          )}

          {step===3 && (
            <div>
              <h3 className="font-semibold text-tx mb-4">Administrator Account</h3>
              <div className="frow">
                <div className="fgrp"><label>Employee ID *</label><input value={admin.empId} onChange={e=>setAdmF('empId',e.target.value)}/></div>
                <div className="fgrp"><label>Full Name *</label><input value={admin.fullName} onChange={e=>setAdmF('fullName',e.target.value)}/></div>
              </div>
              <div className="fgrp"><label>Password *</label><input type="password" value={admin.password} onChange={e=>setAdmF('password',e.target.value)}/></div>
              <label className="flex items-center gap-2 cursor-pointer mb-4 text-xs">
                <input type="checkbox" checked={admin.seedDemoData} onChange={e=>setAdmF('seedDemoData',e.target.checked)} />
                <span className="text-tx">Seed demo data (recommended)</span>
              </label>
              <div className="flex gap-2">
                <button className="btn bgh flex-1" onClick={()=>setStep(2)}>← Back</button>
                <button className="btn bpri flex-1" disabled={loading||!admin.empId||!admin.fullName||!admin.password}
                  onClick={()=>run(async()=>{ await installService.seedData(admin); await installService.finalize(); setOk('Installation complete!'); setTimeout(()=>setStep(4),1200) })}>
                  {loading?'Installing…':'Complete Setup →'}
                </button>
              </div>
            </div>
          )}

          {step===4 && (
            <div className="text-center space-y-3">
              <div className="text-5xl">🎉</div>
              <h2 className="text-lg font-bold text-grn">Installation Complete!</h2>
              <p className="text-sm text-tx3">Zamil MES is ready. Please restart the server and log in with your administrator credentials.</p>
              <button className="btn bgrn w-full justify-center" onClick={()=>window.location.href='/login'}>
                Go to Login →
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
