import { useState, useEffect } from 'react'
import { useAuth } from '../../contexts/AuthContext'
import { useApp } from '../../contexts/AppContext'
import { setupService, productionService, packerService, referenceService } from '../../services/api'

export default function QCDetail() {
  const { user } = useAuth()
  const { showToast } = useApp()

  const [machines,     setMachines]     = useState([])
  const [locations,    setLocations]    = useState([])
  const [allWOs,       setAllWOs]       = useState([])
  const [checklist,    setChecklist]    = useState([])

  const [selMachine,   setSelMachine]   = useState(null)
  const [selLocator,   setSelLocator]   = useState(null)
  const [selWO,        setSelWO]        = useState(null)
  const [boxes,        setBoxes]        = useState([])
  const [selBox,       setSelBox]       = useState(null)
  const [boxFilter,    setBoxFilter]    = useState('all')
  const [checks,       setChecks]       = useState({})
  const [notes,        setNotes]        = useState('')
  const [log,          setLog]          = useState([])
  const [loadingBoxes, setLoadingBoxes] = useState(false)

  useEffect(() => {
    setupService.getMachines().then(r => setMachines(r?.data ?? r ?? [])).catch(() => setMachines([]))
    setupService.getLocations().then(r => setLocations(r?.data ?? r ?? [])).catch(() => setLocations([]))
    productionService.getWorkOrders({ status: 'active', limit: 50 }).then(r => setAllWOs(r?.data ?? r ?? [])).catch(() => setAllWOs([]))
    referenceService.getQCChecklist().then(r => setChecklist(r?.data ?? r ?? [])).catch(() => setChecklist([]))
  }, [])

  const selectMachine = (m) => {
    setSelMachine(m); setSelLocator(null); setSelWO(null)
    setBoxes([]); setSelBox(null)
  }

  const selectLocator = (loc) => {
    setSelLocator(loc); setSelWO(null); setBoxes([]); setSelBox(null)
  }

  const selectWO = async (wo) => {
    setSelWO(wo); setSelBox(null); setBoxFilter('all'); setChecks({}); setNotes('')
    setLoadingBoxes(true)
    try {
      const res = await packerService.getBoxes({ woId: wo.id, limit: 200 })
      setBoxes(res?.data ?? res ?? [])
    } catch (_) { setBoxes([]) }
    finally { setLoadingBoxes(false) }
  }

  const selectBox = (bx) => {
    setSelBox(bx)
    setChecks(bx.qcChecks || {})
    setNotes(bx.qcNotes || '')
  }

  const toggleCheck = (id) => {
    setChecks(prev => ({ ...prev, [id]: !prev[id] }))
  }

  const setBoxStatus = async (status) => {
    if (!selBox) return
    const payload = { qcStatus: status, qcNotes: notes, qcChecks: checks }
    try { await packerService.updateBox(selBox.id, payload) } catch (_) {}
    const updated = { ...selBox, qcStatus: status, qcNotes: notes, qcChecks: checks }
    setBoxes(prev => prev.map(b => b.id === selBox.id ? updated : b))
    const entry = {
      boxNumber: selBox.boxNumber,
      woNumber:  selBox.woNumber || selWO?.woNumber,
      status,
      time: new Date().toLocaleTimeString(),
    }
    setLog(prev => [entry, ...prev].slice(0, 30))
    showToast(`Box ${selBox.boxNumber}: ${status === 'appr' ? 'Approved' : 'Rejected'}`, status === 'appr' ? 'success' : 'error')
    setSelBox(null); setChecks({}); setNotes('')
  }

  const submitDecision = async () => {
    if (!selBox) return
    try { await packerService.updateBox(selBox.id, { qcNotes: notes, qcChecks: checks }) } catch (_) {}
    setBoxes(prev => prev.map(b => b.id === selBox.id ? { ...b, qcNotes: notes, qcChecks: checks } : b))
    showToast('Decision saved', 'success')
    setSelBox(null); setChecks({}); setNotes('')
  }

  const massApprove = async () => {
    const targets = boxes.filter(b => (b.qcStatus || 'pend') === 'pend')
    try { await Promise.all(targets.map(b => packerService.updateBox(b.id, { qcStatus: 'appr' }))) } catch (_) {}
    setBoxes(prev => prev.map(b => (b.qcStatus || 'pend') === 'pend' ? { ...b, qcStatus: 'appr' } : b))
    showToast('All pending boxes approved', 'success')
    setSelBox(null)
  }

  const massReject = async () => {
    const targets = boxes.filter(b => (b.qcStatus || 'pend') === 'pend')
    try { await Promise.all(targets.map(b => packerService.updateBox(b.id, { qcStatus: 'rejt' }))) } catch (_) {}
    setBoxes(prev => prev.map(b => (b.qcStatus || 'pend') === 'pend' ? { ...b, qcStatus: 'rejt' } : b))
    showToast('All pending boxes rejected', 'warning')
    setSelBox(null)
  }

  const approved = boxes.filter(b => b.qcStatus === 'appr').length
  const rejected = boxes.filter(b => b.qcStatus === 'rejt').length
  const pending  = boxes.filter(b => !b.qcStatus || b.qcStatus === 'pend').length
  const total    = boxes.length
  const passRate = total ? Math.round(approved * 100 / total) : 0

  const filteredBoxes = boxFilter === 'all' ? boxes : boxes.filter(b => (b.qcStatus || 'pend') === boxFilter)
  const locatorsToShow = selMachine ? locations : []
  const woList         = selLocator ? allWOs   : []

  return (
    <div>
      {/* Breadcrumb */}
      <div className="bc">
        <div className="bci"><div className="bcn done">✓</div>Select Machine</div><div className="bcs">›</div>
        <div className="bci"><div className="bcn done">✓</div>Select Locator</div><div className="bcs">›</div>
        <div className="bci"><div className="bcn done">✓</div>Select Work Order</div><div className="bcs">›</div>
        <div className="bci cur"><div className="bcn act">4</div>Inspect Boxes</div><div className="bcs">›</div>
        <div className="bci"><div className="bcn pend">5</div>Submit Report</div>
      </div>

      <div className="lay2">

        {/* ── Left Panel ── */}
        <div className="lpanel">

          {/* Select Machine */}
          <div className="psec">
            <div className="pshdr">
              <div className="pst"><div className="pphdd" style={{background:'var(--tel)'}}/>Select Machine</div>
              <span style={{fontSize:'10px',color:'var(--tx3)'}}>{machines.length} machines</span>
            </div>
            <div style={{padding:'8px'}}>
              {machines.length === 0 && (
                <div style={{fontSize:'11px',color:'var(--tx3)',textAlign:'center',padding:'10px'}}>
                  Loading machines…
                </div>
              )}
              {machines.map(m => (
                <div key={m.id} onClick={() => selectMachine(m)}
                  style={{
                    padding:'10px 12px', borderRadius:'var(--r)', marginBottom:'4px', cursor:'pointer',
                    border:'1px solid', transition:'.12s',
                    background:   selMachine?.id === m.id ? 'var(--tel2)' : 'var(--bg2)',
                    borderColor:  selMachine?.id === m.id ? 'var(--tel)'  : 'var(--bor)',
                  }}>
                  <div style={{fontSize:'12px',fontWeight:700,fontFamily:"'Space Mono',monospace",
                    color: selMachine?.id === m.id ? 'var(--tel)' : 'var(--tx)'}}>
                    {m.machineId || m.name}
                  </div>
                  <div style={{fontSize:'10px',color:'var(--tx3)',marginTop:'2px'}}>
                    {[m.type, m.plant].filter(Boolean).join(' · ') || '—'}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Locator */}
          <div className="psec">
            <div className="pshdr">
              <div className="pst"><div className="pphdd" style={{background:'var(--grn)'}}/>Locator</div>
              <span style={{fontSize:'10px',color:'var(--tx3)'}}>
                {selMachine ? `${locatorsToShow.length} available` : 'Select machine first'}
              </span>
            </div>
            <div style={{padding:'8px'}}>
              {locatorsToShow.length === 0 && (
                <div style={{fontSize:'11px',color:'var(--tx3)',textAlign:'center',padding:'10px'}}>
                  {selMachine ? 'No locations configured' : 'Select a machine first'}
                </div>
              )}
              {locatorsToShow.map(loc => (
                <div key={loc.id} onClick={() => selectLocator(loc)}
                  style={{
                    padding:'8px 12px', borderRadius:'var(--r)', marginBottom:'4px', cursor:'pointer',
                    border:'1px solid', fontSize:'11px', fontWeight:600, transition:'.12s',
                    background:  selLocator?.id === loc.id ? 'var(--grn2)' : 'var(--bg2)',
                    borderColor: selLocator?.id === loc.id ? 'var(--grn)'  : 'var(--bor)',
                    color:       selLocator?.id === loc.id ? 'var(--grn)'  : 'var(--tx2)',
                  }}>
                  {loc.code || loc.name}
                </div>
              ))}
            </div>
          </div>

          {/* Work Orders */}
          <div className="psec">
            <div className="pshdr">
              <div className="pst"><div className="pphdd" style={{background:'var(--blu)'}}/>Work Orders</div>
              <span style={{fontSize:'10px',color:'var(--tx3)'}}>{woList.length} total</span>
            </div>
            <div className="wlist">
              {woList.length === 0 && (
                <div style={{fontSize:'11px',color:'var(--tx3)',textAlign:'center',padding:'12px'}}>
                  {selLocator ? 'No active work orders' : 'Select locator first'}
                </div>
              )}
              {woList.map(wo => (
                <div key={wo.id} onClick={() => selectWO(wo)}
                  style={{
                    padding:'10px 14px', borderBottom:'1px solid var(--bor)', cursor:'pointer', transition:'.12s',
                    background: selWO?.id === wo.id ? 'var(--blu2)' : 'transparent',
                  }}>
                  <div className="wrt">
                    <span className="wnum">{wo.woNumber}</span>
                    {selWO?.id === wo.id && <span className="bdg bd" style={{fontSize:'9px'}}>Active</span>}
                  </div>
                  <div className="wprod">{wo.product}</div>
                  <div className="wmeta">
                    <span>{wo.plannedQty ?? wo.qty ?? 0} units</span>
                    <span>{wo.boxQty ?? '—'} boxes</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Session Summary */}
          <div className="psec">
            <div className="pshdr">
              <div className="pst"><div className="pphdd" style={{background:'var(--amb)'}}/>Session Summary</div>
            </div>
            <div className="qmini">
              <div className="qmc">
                <div className="qmv" style={{color:'var(--grn)'}}>{approved}</div>
                <div className="qml" style={{color:'var(--grn)'}}>Approved</div>
              </div>
              <div className="qmc">
                <div className="qmv" style={{color:'var(--red)'}}>{rejected}</div>
                <div className="qml" style={{color:'var(--red)'}}>Rejected</div>
              </div>
              <div className="qmc">
                <div className="qmv" style={{color:'var(--amb)'}}>{pending}</div>
                <div className="qml" style={{color:'var(--amb)'}}>Pending</div>
              </div>
            </div>
          </div>
        </div>

        {/* ── Right Panel ── */}
        <div className="rpanel">

          {/* Inspection Header */}
          <div className="insph">
            <div className="ibadge">🔍</div>
            <div style={{flex:1}}>
              <div className="itit">
                {selWO ? `${selWO.woNumber} · Box Inspection` : 'Select Work Order'}
              </div>
              <div className="isub">
                {selMachine ? `Machine: ${selMachine.machineId || selMachine.name} · Inspector Active` : 'No machine selected'}
              </div>
              <div className="itags">
                {selWO && <span className="bdg bp">{pending} Pending</span>}
                {selWO && <span className="bdg bd">{approved} Approved</span>}
                {selWO && <span className="bdg brj">{rejected} Rejected</span>}
              </div>
            </div>
            <div style={{display:'flex',flexDirection:'column',gap:'7px',alignItems:'flex-end'}}>
              <button className="btn bsuc bsm" onClick={massApprove}>✓ Approve All</button>
              <button className="btn bdan bsm" onClick={massReject}>✕ Reject All</button>
            </div>
          </div>

          {/* Progress Section */}
          <div className="prog-sec">
            <div className="pr">
              <div className="prl">Approved</div>
              <div className="prt"><div className="prf" style={{width: total ? `${Math.round(approved*100/total)}%` : '0%', background:'var(--grn)'}}/></div>
              <div className="prc" style={{color:'var(--grn)'}}>{approved}/{total}</div>
            </div>
            <div className="pr">
              <div className="prl">Rejected</div>
              <div className="prt"><div className="prf" style={{width: total ? `${Math.round(rejected*100/total)}%` : '0%', background:'var(--red)'}}/></div>
              <div className="prc" style={{color:'var(--red)'}}>{rejected}/{total}</div>
            </div>
            <div className="pr">
              <div className="prl">Pending</div>
              <div className="prt"><div className="prf" style={{width: total ? `${Math.round(pending*100/total)}%` : '100%', background:'var(--amb)'}}/></div>
              <div className="prc" style={{color:'var(--amb)'}}>{pending}/{total}</div>
            </div>
            <div className="pstats">
              <div><div className="psv2" style={{color:'var(--grn)'}}>{approved}</div><div className="psl2">Approved</div></div>
              <div><div className="psv2" style={{color:'var(--red)'}}>{rejected}</div><div className="psl2">Rejected</div></div>
              <div><div className="psv2" style={{color:'var(--amb)'}}>{pending}</div><div className="psl2">Pending</div></div>
              <div><div className="psv2">{passRate}%</div><div className="psl2">Pass Rate</div></div>
              <div><div className="psv2" style={{color:'var(--tel)'}}>{total}</div><div className="psl2">Total</div></div>
            </div>
          </div>

          {/* Section Header + Filter */}
          <div className="sh" style={{marginBottom:'12px'}}>
            <div className="st"><div className="sd" style={{background:'var(--grn)'}}/>Select Box to Inspect</div>
            <div className="filt">
              <div className={`fc fca${boxFilter==='all'?' on':''}`} onClick={()=>setBoxFilter('all')}>All</div>
              <div className={`fc fcp${boxFilter==='pend'?' on':''}`} onClick={()=>setBoxFilter('pend')}>Pending</div>
              <div className={`fc fcg${boxFilter==='appr'?' on':''}`} onClick={()=>setBoxFilter('appr')}>Approved</div>
              <div className={`fc fcr${boxFilter==='rejt'?' on':''}`} onClick={()=>setBoxFilter('rejt')}>Rejected</div>
            </div>
          </div>

          {/* Box Grid */}
          {loadingBoxes && (
            <div style={{textAlign:'center',padding:'32px',color:'var(--tx3)',fontSize:'13px'}}>
              Loading boxes…
            </div>
          )}
          {!loadingBoxes && boxes.length === 0 && (
            <div style={{textAlign:'center',padding:'32px',color:'var(--tx3)',fontSize:'13px'}}>
              {selWO ? 'No boxes found for this work order.' : 'Select a work order to begin inspection.'}
            </div>
          )}
          {!loadingBoxes && (
            <div className="bgrid">
              {filteredBoxes.map((bx) => {
                const st = bx.qcStatus || 'pend'
                return (
                  <div
                    key={bx.id}
                    className={`bc2 ${selBox?.id === bx.id ? 'insp' : st}`}
                    onClick={() => selectBox(bx)}>
                    <div className="bsdot"/>
                    <div className="bn">{bx.boxNumber}</div>
                    <div className="bst">
                      {st === 'appr' ? 'Approved' : st === 'rejt' ? 'Rejected' : 'Pending'}
                    </div>
                  </div>
                )
              })}
            </div>
          )}

          {/* Detail Panel — visible when box is selected */}
          {selBox && (
            <div className="idp">
              <div className="idph">
                <div style={{display:'flex',alignItems:'center',gap:'11px'}}>
                  <div className="bbig">B{selBox.boxNumber}</div>
                  <div>
                    <div style={{fontSize:'14px',fontWeight:600,color:'var(--tx)'}}>
                      Box {selBox.boxNumber} of {String(total).padStart(2,'0')}
                    </div>
                    <div style={{fontSize:'11px',color:'var(--tx3)',marginTop:'2px'}}>
                      {selBox.woNumber || selWO?.woNumber} · Awaiting decision
                    </div>
                    <div style={{fontSize:'11px',marginTop:'3px'}}>
                      {(selBox.qcStatus || 'pend') === 'pend' ? '⏳ Pending'
                        : selBox.qcStatus === 'appr' ? '✓ Approved'
                        : '✕ Rejected'}
                    </div>
                  </div>
                </div>
                <div style={{display:'flex',gap:'7px'}}>
                  <button className="btn bsuc" onClick={() => setBoxStatus('appr')}>✓ Approve</button>
                  <button className="btn bdan" onClick={() => setBoxStatus('rejt')}>✕ Reject</button>
                </div>
              </div>

              <div style={{fontSize:'11px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',fontWeight:600,marginBottom:'10px'}}>
                Quality Checklist — click each item to toggle
              </div>
              <div className="cklist">
                {checklist.map(item => (
                  <div key={item.id} onClick={() => toggleCheck(item.id)}
                    style={{
                      padding:'8px 10px', borderRadius:'var(--r)', border:'1px solid', cursor:'pointer',
                      fontSize:'11px', transition:'.12s',
                      background:  checks[item.id] ? 'var(--grn2)' : 'var(--bg3)',
                      borderColor: checks[item.id] ? 'var(--grn)'  : 'var(--bor2)',
                      color:       checks[item.id] ? 'var(--grn)'  : 'var(--tx2)',
                    }}>
                    {checks[item.id] ? '✓ ' : ''}{item.label}
                  </div>
                ))}
              </div>

              <div style={{marginTop:'13px'}}>
                <label>Inspector Notes</label>
                <textarea
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  placeholder="Add notes for this box..."
                  rows={3}/>
              </div>
              <div style={{marginTop:'10px',display:'flex',gap:'8px'}}>
                <button className="btn bpri2" style={{flex:1,justifyContent:'center'}} onClick={submitDecision}>
                  Submit Decision
                </button>
                <button className="btn bgh" onClick={() => { setSelBox(null); setChecks({}); setNotes('') }}>
                  Clear
                </button>
              </div>
            </div>
          )}

          {/* Inspection Log */}
          <div style={{background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'var(--rl)',padding:'15px'}}>
            <div className="st" style={{marginBottom:'11px'}}>
              <div className="sd" style={{background:'var(--pur)'}}/>Inspection Log
            </div>
            {log.length === 0 ? (
              <div style={{fontSize:'12px',color:'var(--tx3)',textAlign:'center',padding:'16px'}}>
                No decisions logged yet. Click a box to begin.
              </div>
            ) : (
              <div style={{display:'flex',flexDirection:'column',gap:'6px'}}>
                {log.map((entry, i) => (
                  <div key={i} style={{display:'flex',alignItems:'center',justifyContent:'space-between',
                    padding:'8px 10px',borderRadius:'var(--r)',background:'var(--bg3)',fontSize:'12px'}}>
                    <div style={{display:'flex',alignItems:'center',gap:'8px'}}>
                      <span className="woid" style={{fontSize:'11px'}}>B{entry.boxNumber}</span>
                      <span style={{color:'var(--tx3)',fontSize:'10px'}}>{entry.woNumber}</span>
                    </div>
                    <div style={{display:'flex',alignItems:'center',gap:'8px'}}>
                      <span className={`bdg ${entry.status === 'appr' ? 'bd' : 'brj'}`}>
                        {entry.status === 'appr' ? 'Approved' : 'Rejected'}
                      </span>
                      <span style={{fontFamily:"'Space Mono',monospace",fontSize:'9px',color:'var(--tx3)'}}>
                        {entry.time}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
