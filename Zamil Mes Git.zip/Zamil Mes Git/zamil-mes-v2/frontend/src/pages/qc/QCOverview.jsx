import { useState, useEffect } from 'react'
import { useAuth } from '../../contexts/AuthContext'
import { useApp } from '../../contexts/AppContext'
import { packerService, productionService } from '../../services/api'

export default function QCOverview() {
  const { user } = useAuth()
  const { showToast, goScreen } = useApp()

  const [boxes, setBoxes]       = useState([])
  const [wos, setWos]           = useState([])
  const [activeWO, setActiveWO] = useState('all')
  const [loading, setLoading]   = useState(true)

  useEffect(() => {
    loadBoxes()
    loadWOs()
  }, [])

  const loadBoxes = async () => {
    setLoading(true)
    try {
      const res = await packerService.getBoxes({ limit: 500 })
      setBoxes(res?.data ?? res ?? [])
    } catch (_) {
      setBoxes([])
    } finally {
      setLoading(false)
    }
  }

  const loadWOs = async () => {
    try {
      const res = await productionService.getWorkOrders({ status: 'active', limit: 50 })
      setWos(res?.data ?? res ?? [])
    } catch (_) {
      setWos([])
    }
  }

  const massApprove = async () => {
    const targets = boxesToShow.filter(b => (b.qcStatus || 'pend') === 'pend')
    if (!targets.length) { showToast('No pending boxes to approve', 'warning'); return }
    try {
      await Promise.all(targets.map(b => packerService.updateBox(b.id, { qcStatus: 'appr' })))
    } catch (_) {}
    setBoxes(prev => prev.map(b =>
      targets.find(t => t.id === b.id) ? { ...b, qcStatus: 'appr' } : b
    ))
    showToast(`${targets.length} boxes approved`, 'success')
  }

  const massReject = async () => {
    const targets = boxesToShow.filter(b => (b.qcStatus || 'pend') === 'pend')
    if (!targets.length) { showToast('No pending boxes to reject', 'warning'); return }
    try {
      await Promise.all(targets.map(b => packerService.updateBox(b.id, { qcStatus: 'rejt' })))
    } catch (_) {}
    setBoxes(prev => prev.map(b =>
      targets.find(t => t.id === b.id) ? { ...b, qcStatus: 'rejt' } : b
    ))
    showToast(`${targets.length} boxes rejected`, 'warning')
  }

  const toggleBox = async (id) => {
    const box = boxes.find(b => b.id === id)
    if (!box) return
    const next = (box.qcStatus || 'pend') === 'pend' ? 'appr' : (box.qcStatus === 'appr') ? 'rejt' : 'pend'
    try {
      await packerService.updateBox(id, { qcStatus: next })
    } catch (_) {}
    setBoxes(prev => prev.map(b => b.id === id ? { ...b, qcStatus: next } : b))
  }

  const allBoxes    = activeWO === 'all' ? boxes : boxes.filter(b => b.woId === activeWO)
  const boxesToShow = allBoxes
  const approved    = boxes.filter(b => b.qcStatus === 'appr').length
  const rejected    = boxes.filter(b => b.qcStatus === 'rejt').length
  const pending     = boxes.filter(b => !b.qcStatus || b.qcStatus === 'pend').length

  const initials = (user?.fullName || user?.name || 'QI').split(' ').map(w=>w[0]).slice(0,2).join('').toUpperCase()

  const groupedByWO = {}
  boxes.forEach(b => {
    const key = b.woId || 'Unknown'
    if (!groupedByWO[key]) groupedByWO[key] = []
    groupedByWO[key].push(b)
  })

  const wosToShow = activeWO === 'all'
    ? Object.keys(groupedByWO)
    : [activeWO]

  return (
    <div className="content">

      {/* Identity Strip */}
      <div className="strip">
        <div className="av" style={{background:'var(--grn2)',borderColor:'var(--grn)',color:'var(--grn)'}}>{initials}</div>
        <div style={{flex:1}}>
          <div className="oname">{(user?.fullName || user?.name || 'Quality Inspector').toUpperCase()}</div>
          <div className="ometa">FPP BU &nbsp;·&nbsp; All Machines &nbsp;·&nbsp; Day Shift &nbsp;·&nbsp; {Object.keys(groupedByWO).length} WOs under review</div>
        </div>
        <div className="cstatus" style={{background:'var(--grn2)',borderColor:'var(--grn)',color:'var(--grn)'}}>
          <div className="cdot" style={{background:'var(--grn)'}}/>Active QC Session
        </div>
      </div>

      {/* 4 Stats */}
      <div className="g4">
        <div className="sc">
          <div className="slbl">Total Boxes</div>
          <div className="sval">{boxes.length}</div>
          <div className="ssub">All work orders</div>
        </div>
        <div className="sc" style={{'--sa':'var(--grn)'}}>
          <div className="slbl">Approved</div>
          <div className="sval" style={{color:'var(--grn)'}}>{approved}</div>
          <div className="pbar"><div className="pfil" style={{width: boxes.length ? `${Math.round(approved*100/boxes.length)}%` : '0%', background:'var(--grn)'}}/></div>
          <div className="ssub">Cleared for packing</div>
        </div>
        <div className="sc" style={{'--sa':'var(--red)'}}>
          <div className="slbl">Rejected</div>
          <div className="sval" style={{color:'var(--red)'}}>{rejected}</div>
          <div className="pbar"><div className="pfil" style={{width: boxes.length ? `${Math.round(rejected*100/boxes.length)}%` : '0%', background:'var(--red)'}}/></div>
          <div className="ssub">Return to line</div>
        </div>
        <div className="sc" style={{'--sa':'var(--amb)'}}>
          <div className="slbl">Pending</div>
          <div className="sval" style={{color:'var(--amb)'}}>{pending}</div>
          <div className="pbar"><div className="pfil" style={{width: boxes.length ? `${Math.round(pending*100/boxes.length)}%` : '0%', background:'var(--amb)'}}/></div>
          <div className="ssub">Awaiting review</div>
        </div>
      </div>

      {/* WO Filter Tabs */}
      <div className="itabs" style={{display:'flex',gap:'4px',marginBottom:'14px',flexWrap:'wrap'}}>
        <button className={`itab ${activeWO==='all'?'on':''}`} onClick={()=>setActiveWO('all')}>
          All WOs
        </button>
        {wos.map(wo=>(
          <button key={wo.id}
            className={`itab ${activeWO===wo.id?'on':''}`}
            onClick={()=>setActiveWO(wo.id)}>
            {wo.woNumber}
          </button>
        ))}
      </div>

      {/* Action buttons */}
      <div className="sh" style={{marginBottom:'12px'}}>
        <div className="st"><div className="sd" style={{background:'var(--grn)'}}/>Box Inspection Grid</div>
        <div style={{display:'flex',gap:'8px'}}>
          <button className="btn bsm" style={{background:'var(--grn2)',border:'1px solid var(--grn)',color:'var(--grn)'}}
            onClick={massApprove}>✓ Mass Approve Pending</button>
          <button className="btn bsm bdan" onClick={massReject}>✕ Mass Reject Pending</button>
          <button className="btn bpri bsm" onClick={()=>goScreen('qc-detail')}>📋 Detail View →</button>
        </div>
      </div>

      {loading && <div className="text-center py-12 text-tx3 text-sm">Loading boxes…</div>}

      {/* Box chip cards per WO */}
      {!loading && wosToShow.map(woId => {
        const woBoxes = groupedByWO[woId] || []
        const woInfo  = wos.find(w => w.id === woId)
        const woAp    = woBoxes.filter(b => b.qcStatus === 'appr').length
        const woRj    = woBoxes.filter(b => b.qcStatus === 'rejt').length
        const woPe    = woBoxes.filter(b => !b.qcStatus || b.qcStatus === 'pend').length

        return (
          <div key={woId} style={{background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'var(--rl)',padding:'15px',marginBottom:'12px'}}>
            <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:'8px',flexWrap:'wrap',gap:'8px'}}>
              <div style={{display:'flex',alignItems:'center',gap:'10px'}}>
                <span className="woid" style={{fontSize:'13px'}}>{woInfo?.woNumber || woId.slice(0,8)}</span>
                {woInfo && <span style={{fontSize:'11px',color:'var(--tx3)'}}>{woInfo.product}</span>}
                <span className="bdg bd">{woAp} Approved</span>
                <span className="bdg brj">{woRj} Rejected</span>
                <span className="bdg bp">{woPe} Pending</span>
              </div>
              <div style={{display:'flex',gap:'6px'}}>
                <button className="btn bsm" style={{background:'var(--grn2)',border:'1px solid var(--grn)',color:'var(--grn)',fontSize:'10px'}}
                  onClick={async () => {
                    const targets = woBoxes.filter(b => !b.qcStatus || b.qcStatus === 'pend')
                    try { await Promise.all(targets.map(b => packerService.updateBox(b.id, { qcStatus: 'appr' }))) } catch (_) {}
                    setBoxes(prev => prev.map(b => b.woId === woId && (!b.qcStatus || b.qcStatus === 'pend') ? { ...b, qcStatus: 'appr' } : b))
                    showToast(`WO boxes approved`, 'success')
                  }}>✓ Approve All</button>
                <button className="btn bsm bdan" style={{fontSize:'10px'}}
                  onClick={async () => {
                    const targets = woBoxes.filter(b => !b.qcStatus || b.qcStatus === 'pend')
                    try { await Promise.all(targets.map(b => packerService.updateBox(b.id, { qcStatus: 'rejt' }))) } catch (_) {}
                    setBoxes(prev => prev.map(b => b.woId === woId && (!b.qcStatus || b.qcStatus === 'pend') ? { ...b, qcStatus: 'rejt' } : b))
                    showToast(`WO boxes rejected`, 'warning')
                  }}>✕ Reject All</button>
              </div>
            </div>
            {/* Box chip grid */}
            <div style={{display:'flex',gap:'6px',flexWrap:'wrap'}}>
              {woBoxes.map((bx, i) => {
                const st = bx.qcStatus || 'pend'
                return (
                  <div key={bx.id}
                    onClick={() => toggleBox(bx.id)}
                    title={`Box ${bx.boxNumber || String(i+1).padStart(2,'0')} — ${st}`}
                    style={{
                      width:'38px',height:'38px',borderRadius:'8px',display:'flex',alignItems:'center',justifyContent:'center',
                      fontSize:'10px',fontWeight:700,fontFamily:"'Space Mono',monospace",
                      border:`1.5px solid ${st==='appr'?'var(--grn)':st==='rejt'?'var(--red)':'var(--bor2)'}`,
                      background:st==='appr'?'var(--grn2)':st==='rejt'?'var(--red2)':'var(--bg3)',
                      color:st==='appr'?'var(--grn)':st==='rejt'?'var(--red)':'var(--tx3)',
                      cursor:'pointer',transition:'.12s',
                    }}
                    onMouseEnter={e=>e.currentTarget.style.transform='scale(1.12)'}
                    onMouseLeave={e=>e.currentTarget.style.transform=''}
                  >
                    {bx.boxNumber || String(i+1).padStart(2,'0')}
                  </div>
                )
              })}
            </div>
          </div>
        )
      })}

      {!loading && boxes.length === 0 && (
        <div className="text-center py-12 text-tx3 text-sm">No boxes found. Operators print labels to create boxes.</div>
      )}
    </div>
  )
}
