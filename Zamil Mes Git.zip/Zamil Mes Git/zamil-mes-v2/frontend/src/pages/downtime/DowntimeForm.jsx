import { useState, useEffect } from 'react'
import { useMutation, useList } from '../../hooks/useApi'
import { downtimeService, setupService } from '../../services/api'
import { useApp } from '../../contexts/AppContext'

const DT_TYPES = ['PDT – Planned Downtime','UPDT – Unplanned Downtime','STNU – Setup Not Used','Running']
const CATEGORIES = ['Changeover','Breakdown','No Schedule','Running','Preventive Maintenance','Trial','Idle']

export default function DowntimeForm() {
  const { showToast, goScreen } = useApp()

  const [form, setForm] = useState({
    org: '', date: new Date().toISOString().slice(0,10),
    machine: '', shift: '',
    product: '', desc: '', routing: '',
    hours: 0, minute: 0,
    dtType: '', category: '', process: '', reason: '',
  })
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }))

  const [errMsg,    setErrMsg]    = useState('')
  const [okMsg,     setOkMsg]     = useState('')
  const [recent,    setRecent]    = useState([])
  const [allMachines, setAllMachines] = useState([])

  const { items: apiRecent } = useList(downtimeService.getRecords, { limit: 10 })
  useEffect(() => {
    if (apiRecent?.length) setRecent(apiRecent)
  }, [apiRecent])

  useEffect(() => {
    setupService.getMachines().then(r => setAllMachines(r?.data ?? r ?? [])).catch(() => setAllMachines([]))
  }, [])

  const { mutate: save } = useMutation(
    downtimeService.create,
    {
      onSuccess: () => {
        setOkMsg('Downtime record submitted successfully.')
        setErrMsg('')
        const newRec = { id: Date.now(), ...form, hrs: form.hours, min: form.minute }
        setRecent(r => [newRec, ...r])
        setForm(f => ({ ...f, product:'', desc:'', routing:'', hours:0, minute:0, dtType:'', category:'', process:'', reason:'' }))
      },
      onError: () => setErrMsg('Failed to save. Please check required fields.')
    }
  )

  const handleSubmit = () => {
    if (!form.org)      { setErrMsg('Please select an Org.'); setOkMsg(''); return }
    if (!form.machine)  { setErrMsg('Please select a Machine.'); setOkMsg(''); return }
    if (!form.dtType)   { setErrMsg('Please select a DT Type.'); setOkMsg(''); return }
    setErrMsg('')
    save(form)
  }

  const handleClear = () => {
    setForm({ org:'', date: new Date().toISOString().slice(0,10), machine:'', shift:'', product:'', desc:'', routing:'', hours:0, minute:0, dtType:'', category:'', process:'', reason:'' })
    setErrMsg('')
    setOkMsg('')
  }

  const machineOptions = form.org
    ? allMachines.filter(m => m.plant === form.org).map(m => m.machineId || m.name)
    : []

  return (
    <div style={{background:'var(--bg)',minHeight:'calc(100vh - 96px)'}}>

      {/* Green Header */}
      <div style={{background:'var(--grn)',padding:'14px 28px',display:'flex',alignItems:'center',gap:'28px'}}>
        <div style={{fontSize:'18px',fontWeight:700,color:'#fff',fontFamily:"'Space Mono',monospace",letterSpacing:'.5px'}}>
          Machines / Product Downtimes
        </div>
        <div style={{display:'flex',gap:'16px',marginLeft:'16px'}}>
          <button className="dtnavbtn" onClick={() => goScreen('operator')}>🏠 Home</button>
          <button className="dtnavbtn" onClick={() => goScreen('downtime-report')}>≡ Report</button>
          <button className="dtnavbtn" style={{fontWeight:700,textDecoration:'underline'}}>≡ Form</button>
        </div>
      </div>

      <div style={{padding:'28px 32px'}}>

        {/* Top filter row */}
        <div style={{background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'var(--rl)',padding:'22px 26px',marginBottom:'22px'}}>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr 1fr',gap:'18px',alignItems:'end'}}>
            <div>
              <label style={{color:'var(--grn)',fontWeight:700,fontSize:'12px',letterSpacing:'.5px',display:'block',marginBottom:'5px'}}>Org</label>
              <select value={form.org} onChange={e => { set('org', e.target.value); set('machine', '') }}>
                <option value="">Select</option>
                <option value="FPP BU">FPP BU</option>
                <option value="IPP BU">IPP BU</option>
                <option value="ZPC BU">ZPC BU</option>
              </select>
            </div>
            <div>
              <label style={{color:'var(--grn)',fontWeight:700,fontSize:'12px',letterSpacing:'.5px',display:'block',marginBottom:'5px'}}>Date</label>
              <input type="date" value={form.date} onChange={e => set('date', e.target.value)} />
            </div>
            <div>
              <label style={{color:'var(--grn)',fontWeight:700,fontSize:'12px',letterSpacing:'.5px',display:'block',marginBottom:'5px'}}>Machine</label>
              <select value={form.machine} onChange={e => set('machine', e.target.value)}>
                <option value="">Select</option>
                {machineOptions.map(m => <option key={m} value={m}>{m}</option>)}
              </select>
            </div>
            <div>
              <label style={{color:'var(--grn)',fontWeight:700,fontSize:'12px',letterSpacing:'.5px',display:'block',marginBottom:'5px'}}>Shift</label>
              <select value={form.shift} onChange={e => set('shift', e.target.value)}>
                <option value="">Select</option>
                <option value="AB">AB – Day Shift</option>
                <option value="CD">CD – Night Shift</option>
                <option value="A">A Morning</option>
                <option value="B">B Afternoon</option>
              </select>
            </div>
          </div>
        </div>

        {/* Main form fields */}
        <div style={{background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'var(--rl)',padding:'26px 28px'}}>

          {/* Row 1: Product / Desc / Routing */}
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:'20px',marginBottom:'20px'}}>
            <div>
              <label style={{color:'var(--grn)',fontWeight:700,fontSize:'12px',display:'block',marginBottom:'5px'}}>Product</label>
              <input type="text" placeholder="Enter product code" value={form.product} onChange={e => set('product', e.target.value)} />
            </div>
            <div>
              <label style={{color:'var(--grn)',fontWeight:700,fontSize:'12px',display:'block',marginBottom:'5px'}}>Desc</label>
              <input type="text" placeholder="Product description" value={form.desc} readOnly style={{background:'var(--bg3)',cursor:'default'}} />
            </div>
            <div>
              <label style={{color:'var(--grn)',fontWeight:700,fontSize:'12px',display:'block',marginBottom:'5px'}}>Routing</label>
              <input type="text" placeholder="Routing code" value={form.routing} onChange={e => set('routing', e.target.value)} />
            </div>
          </div>

          {/* Row 2: Hours / Minute / DT_Type */}
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:'20px',marginBottom:'20px'}}>
            <div>
              <label style={{color:'var(--grn)',fontWeight:700,fontSize:'12px',display:'block',marginBottom:'5px'}}>Hours</label>
              <input type="number" value={form.hours} min={0} max={24} onChange={e => set('hours', e.target.value)} />
            </div>
            <div>
              <label style={{color:'var(--grn)',fontWeight:700,fontSize:'12px',display:'block',marginBottom:'5px'}}>Minute</label>
              <input type="number" value={form.minute} min={0} max={59} onChange={e => set('minute', e.target.value)} />
            </div>
            <div>
              <label style={{color:'var(--grn)',fontWeight:700,fontSize:'12px',display:'block',marginBottom:'5px'}}>DT_Type</label>
              <select value={form.dtType} onChange={e => set('dtType', e.target.value)}>
                <option value="">Select</option>
                <option value="PDT">PDT – Planned Downtime</option>
                <option value="UPDT">UPDT – Unplanned Downtime</option>
                <option value="STNU">STNU – Setup Not Used</option>
                <option value="Running">Running</option>
              </select>
            </div>
          </div>

          {/* Row 3: Category / Process / Reason */}
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:'20px',marginBottom:'26px'}}>
            <div>
              <label style={{color:'var(--grn)',fontWeight:700,fontSize:'12px',display:'block',marginBottom:'5px'}}>Category</label>
              <select value={form.category} onChange={e => set('category', e.target.value)}>
                <option value="">Select</option>
                {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label style={{color:'var(--grn)',fontWeight:700,fontSize:'12px',display:'block',marginBottom:'5px'}}>Process</label>
              <input type="text" placeholder="Process description" value={form.process} onChange={e => set('process', e.target.value)} />
            </div>
            <div>
              <label style={{color:'var(--grn)',fontWeight:700,fontSize:'12px',display:'block',marginBottom:'5px'}}>Reason</label>
              <input type="text" placeholder="Enter reason" value={form.reason} onChange={e => set('reason', e.target.value)} />
            </div>
          </div>

          {/* Validation messages */}
          {errMsg && (
            <div style={{background:'var(--red2)',border:'1px solid var(--red)',borderRadius:'var(--r)',padding:'10px 14px',color:'var(--red)',fontSize:'12px',marginBottom:'14px'}}>
              {errMsg}
            </div>
          )}
          {okMsg && (
            <div style={{background:'var(--grn2)',border:'1px solid var(--grn)',borderRadius:'var(--r)',padding:'10px 14px',color:'var(--grn)',fontSize:'12px',marginBottom:'14px'}}>
              {okMsg}
            </div>
          )}

          {/* Actions */}
          <div style={{textAlign:'center'}}>
            <button onClick={handleSubmit}
              style={{background:'var(--grn)',border:'none',color:'#fff',fontSize:'14px',fontWeight:600,
                padding:'11px 44px',borderRadius:'9px',cursor:'pointer',fontFamily:"'DM Sans',sans-serif",transition:'.15s'}}>
              Submit
            </button>
            <button onClick={handleClear}
              style={{background:'transparent',border:'1px solid var(--bor2)',color:'var(--tx2)',fontSize:'13px',
                padding:'11px 24px',borderRadius:'9px',cursor:'pointer',fontFamily:"'DM Sans',sans-serif",marginLeft:'12px'}}>
              Clear
            </button>
          </div>
        </div>

        {/* Recent entries preview */}
        <div style={{marginTop:'22px'}}>
          <div className="sh" style={{marginBottom:'12px'}}>
            <div className="st">
              <div className="sd" style={{background:'var(--grn)'}}/>Recent Downtime Entries
            </div>
            <button className="btn bgh bsm" onClick={() => goScreen('downtime-report')}>View Full Report →</button>
          </div>
          <div className="twrap" style={{marginBottom:0,overflowX:'auto'}}>
            <table style={{minWidth:'1100px'}}>
              <thead>
                <tr>
                  <th>#</th><th>Org</th><th>Machine</th><th>Date</th><th>Product</th><th>Desc</th>
                  <th>Shift</th><th>DT Type</th><th>Category</th><th>Process</th><th>Reason</th>
                  <th>Hrs</th><th>Min</th><th>Action</th>
                </tr>
              </thead>
              <tbody>
                {recent.length === 0 ? (
                  <tr>
                    <td colSpan={14} style={{textAlign:'center',color:'var(--tx3)',padding:'20px'}}>
                      No entries yet. Submit a downtime record above.
                    </td>
                  </tr>
                ) : recent.map((r, i) => (
                  <tr key={r.id}>
                    <td style={{fontFamily:"'Space Mono',monospace",fontSize:'10px',color:'var(--tx3)'}}>{i+1}</td>
                    <td style={{fontSize:'11px'}}>{r.org}</td>
                    <td><span className="mtag">{r.machine}</span></td>
                    <td style={{fontFamily:"'Space Mono',monospace",fontSize:'10px',color:'var(--tx3)'}}>{r.date}</td>
                    <td style={{fontFamily:"'Space Mono',monospace",fontSize:'10px'}}>{r.product}</td>
                    <td style={{fontSize:'11px'}}>{r.desc}</td>
                    <td style={{fontSize:'11px',color:'var(--tx3)'}}>{r.shift}</td>
                    <td><span className="bdg bp">{r.dtType}</span></td>
                    <td style={{fontSize:'11px',color:'var(--tx3)'}}>{r.category}</td>
                    <td style={{fontSize:'11px',color:'var(--tx3)'}}>{r.process}</td>
                    <td style={{fontSize:'11px'}}>{r.reason}</td>
                    <td style={{fontFamily:"'Space Mono',monospace",fontSize:'10px',color:'var(--amb)',fontWeight:600}}>{r.hrs}</td>
                    <td style={{fontFamily:"'Space Mono',monospace",fontSize:'10px',color:'var(--tx3)'}}>{r.min}</td>
                    <td>
                      <button className="btn bgh bsm" onClick={() => showToast(`Entry ${i+1} viewed`, 'info')}>View</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </div>
  )
}
