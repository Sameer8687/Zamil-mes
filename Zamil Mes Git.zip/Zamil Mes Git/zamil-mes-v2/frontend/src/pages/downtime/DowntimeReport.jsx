import { useState } from 'react'
import { useList } from '../../hooks/useApi'
import { downtimeService } from '../../services/api'
import { useApp } from '../../contexts/AppContext'

export default function DowntimeReport() {
  const { goScreen } = useApp()

  const [filter, setFilter] = useState({ org:'', machine:'', from:'', to:'', dtType:'', cat:'', search:'' })
  const setF = (k, v) => setFilter(f => ({ ...f, [k]: v }))

  const [sortKey,  setSortKey]  = useState(null)
  const [sortDir,  setSortDir]  = useState(1)

  const { items: apiItems, loading } = useList(downtimeService.getRecords, { limit: 50 })
  const records = apiItems ?? []

  const filtered = records.filter(r => {
    if (filter.org     && !r.org?.toLowerCase().includes(filter.org.toLowerCase()))     return false
    if (filter.machine && !r.machine?.toLowerCase().includes(filter.machine.toLowerCase())) return false
    if (filter.from    && r.date < filter.from)  return false
    if (filter.to      && r.date > filter.to)    return false
    if (filter.dtType  && r.dtType !== filter.dtType)  return false
    if (filter.cat     && r.category !== filter.cat)   return false
    if (filter.search  && !JSON.stringify(r).toLowerCase().includes(filter.search.toLowerCase())) return false
    return true
  })

  const sorted = sortKey
    ? [...filtered].sort((a, b) => {
        const av = a[sortKey] ?? '', bv = b[sortKey] ?? ''
        return av < bv ? -sortDir : av > bv ? sortDir : 0
      })
    : filtered

  const toggleSort = key => {
    if (sortKey === key) setSortDir(d => -d)
    else { setSortKey(key); setSortDir(1) }
  }

  const totalRec  = sorted.length
  const totalHrs  = sorted.reduce((s, r) => s + Number(r.hrs || 0) + Number(r.min || 0) / 60, 0).toFixed(1)
  const machines  = new Set(sorted.map(r => r.machine)).size
  const pdtCount  = sorted.filter(r => r.dtType === 'PDT').length

  const col = key => `${key} ${sortKey === key ? (sortDir === 1 ? '↑' : '↓') : '↕'}`

  return (
    <div style={{background:'var(--bg)',minHeight:'calc(100vh - 96px)'}}>

      {/* Green Header */}
      <div style={{background:'var(--grn)',padding:'14px 28px',display:'flex',alignItems:'center',gap:'28px'}}>
        <div style={{fontSize:'18px',fontWeight:700,color:'#fff',fontFamily:"'Space Mono',monospace",letterSpacing:'.5px'}}>
          Machines / Product Downtime Report
        </div>
        <div style={{display:'flex',gap:'16px',marginLeft:'16px'}}>
          <button className="dtnavbtn" onClick={() => goScreen('operator')}>🏠 Home</button>
          <button className="dtnavbtn" onClick={() => goScreen('downtime')}>≡ Form</button>
          <button className="dtnavbtn" style={{fontWeight:700,textDecoration:'underline'}}>≡ Report</button>
        </div>
      </div>

      {/* Filter bar */}
      <div style={{padding:'16px 28px',background:'var(--bg2)',borderBottom:'1px solid var(--bor)',display:'flex',alignItems:'flex-end',gap:'18px',flexWrap:'wrap'}}>
        <div>
          <label style={{fontSize:'11px',color:'var(--tx3)',fontWeight:600,display:'block',marginBottom:'4px'}}>Org</label>
          <input type="text" placeholder="e.g. IPP BU" style={{width:'130px'}} value={filter.org} onChange={e => setF('org', e.target.value)} />
        </div>
        <div>
          <label style={{fontSize:'11px',color:'var(--tx3)',fontWeight:600,display:'block',marginBottom:'4px'}}>Machine</label>
          <input type="text" placeholder="ALL" style={{width:'120px'}} value={filter.machine} onChange={e => setF('machine', e.target.value)} />
        </div>
        <div>
          <label style={{fontSize:'11px',color:'var(--tx3)',fontWeight:600,display:'block',marginBottom:'4px'}}>From</label>
          <input type="date" style={{width:'150px'}} value={filter.from} onChange={e => setF('from', e.target.value)} />
        </div>
        <div>
          <label style={{fontSize:'11px',color:'var(--tx3)',fontWeight:600,display:'block',marginBottom:'4px'}}>To</label>
          <input type="date" style={{width:'150px'}} value={filter.to} onChange={e => setF('to', e.target.value)} />
        </div>
        <div>
          <label style={{fontSize:'11px',color:'var(--tx3)',fontWeight:600,display:'block',marginBottom:'4px'}}>DT Type</label>
          <select style={{width:'140px'}} value={filter.dtType} onChange={e => setF('dtType', e.target.value)}>
            <option value="">All Types</option>
            <option value="PDT">PDT</option>
            <option value="UPDT">UPDT</option>
            <option value="STNU">STNU</option>
            <option value="Running">Running</option>
          </select>
        </div>
        <div>
          <label style={{fontSize:'11px',color:'var(--tx3)',fontWeight:600,display:'block',marginBottom:'4px'}}>Category</label>
          <select style={{width:'160px'}} value={filter.cat} onChange={e => setF('cat', e.target.value)}>
            <option value="">All Categories</option>
            <option value="Changeover">Changeover</option>
            <option value="Breakdown">Breakdown</option>
            <option value="No Schedule">No Schedule</option>
            <option value="Running">Running</option>
            <option value="Preventive Maintenance">PM</option>
          </select>
        </div>
        <button style={{background:'var(--tel)',border:'none',color:'#fff',fontSize:'13px',fontWeight:600,
          padding:'9px 22px',borderRadius:'8px',cursor:'pointer',fontFamily:"'DM Sans',sans-serif"}}>
          Filter
        </button>
        <button onClick={() => setFilter({ org:'', machine:'', from:'', to:'', dtType:'', cat:'', search:'' })}
          style={{background:'transparent',border:'1px solid var(--bor2)',color:'var(--tx2)',fontSize:'12px',
            padding:'9px 16px',borderRadius:'8px',cursor:'pointer',fontFamily:"'DM Sans',sans-serif"}}>
          Clear
        </button>
      </div>

      <div style={{padding:'20px 28px'}}>

        {/* Stats row */}
        <div className="g4" style={{marginBottom:'20px'}}>
          <div className="sc" style={{'--sa':'var(--red)'}}>
            <div className="slbl">Total Records</div>
            <div className="sval" style={{color:'var(--red)'}}>{totalRec}</div>
            <div className="ssub">All downtime entries</div>
          </div>
          <div className="sc" style={{'--sa':'var(--amb)'}}>
            <div className="slbl">Total DT Hours</div>
            <div className="sval" style={{color:'var(--amb)'}}>{totalHrs}</div>
            <div className="ssub">Cumulative downtime</div>
          </div>
          <div className="sc" style={{'--sa':'var(--pur)'}}>
            <div className="slbl">Machines Affected</div>
            <div className="sval" style={{color:'var(--pur)'}}>{machines}</div>
            <div className="ssub">Unique machines</div>
          </div>
          <div className="sc" style={{'--sa':'var(--grn)'}}>
            <div className="slbl">Planned (PDT)</div>
            <div className="sval" style={{color:'var(--grn)'}}>{pdtCount}</div>
            <div className="ssub">Planned downtime entries</div>
          </div>
        </div>

        {/* Toolbar */}
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:'14px',flexWrap:'wrap',gap:'10px'}}>
          <div style={{display:'flex',gap:'8px',alignItems:'center'}}>
            <button style={{background:'var(--bg2)',border:'1px solid var(--bor2)',color:'var(--tx2)',fontSize:'12px',
              padding:'7px 16px',borderRadius:'8px',cursor:'pointer',fontFamily:"'DM Sans',sans-serif",display:'flex',alignItems:'center',gap:'5px'}}>
              📥 Download Excel
            </button>
            <button onClick={() => goScreen('downtime')}
              style={{background:'var(--grn)',border:'none',color:'#fff',fontSize:'12px',padding:'7px 16px',
                borderRadius:'8px',cursor:'pointer',fontFamily:"'DM Sans',sans-serif"}}>
              + Add Entry
            </button>
            <span style={{fontSize:'12px',color:'var(--tx3)'}}>Showing {sorted.length} records</span>
          </div>
          <div style={{display:'flex',alignItems:'center',gap:'8px'}}>
            <label style={{fontSize:'12px',color:'var(--tx3)'}}>Search:</label>
            <input type="text" placeholder="Search any field..." style={{width:'200px'}}
              value={filter.search} onChange={e => setF('search', e.target.value)} />
          </div>
        </div>

        {/* Report table */}
        <div className="twrap" style={{marginBottom:0,overflowX:'auto'}}>
          <table style={{minWidth:'1200px'}}>
            <thead>
              <tr>
                <th style={{cursor:'pointer'}} onClick={() => toggleSort('id')}>{col('#')}</th>
                <th style={{cursor:'pointer'}} onClick={() => toggleSort('org')}>{col('ORG')}</th>
                <th style={{cursor:'pointer'}} onClick={() => toggleSort('resId')}>RES_ID ↕</th>
                <th style={{cursor:'pointer'}} onClick={() => toggleSort('machine')}>{col('RES_CODE')}</th>
                <th style={{cursor:'pointer'}} onClick={() => toggleSort('date')}>{col('DOWNDATE')}</th>
                <th style={{cursor:'pointer'}} onClick={() => toggleSort('product')}>{col('PROD')}</th>
                <th>DESC</th>
                <th style={{cursor:'pointer'}} onClick={() => toggleSort('shift')}>{col('SHIFT')}</th>
                <th style={{cursor:'pointer'}} onClick={() => toggleSort('dtType')}>{col('DOWNTYPE')}</th>
                <th style={{cursor:'pointer'}} onClick={() => toggleSort('category')}>{col('CATEGORY')}</th>
                <th>PROCESS</th>
                <th>REASON</th>
                <th style={{cursor:'pointer'}} onClick={() => toggleSort('hrs')}>{col('DOWN_HRS')}</th>
                <th>DOWN_MIN</th>
                <th>ACTION</th>
              </tr>
            </thead>
            <tbody>
              {loading && (
                <tr><td colSpan={15} style={{textAlign:'center',color:'var(--tx3)',padding:'28px'}}>Loading…</td></tr>
              )}
              {!loading && sorted.length === 0 && (
                <tr><td colSpan={15} style={{textAlign:'center',color:'var(--tx3)',padding:'28px'}}>
                  No downtime records yet.{' '}
                  <span style={{color:'var(--grn)',cursor:'pointer'}} onClick={() => goScreen('downtime')}>Add a record →</span>
                </td></tr>
              )}
              {sorted.map((r, i) => (
                <tr key={r.id}>
                  <td style={{fontFamily:"'Space Mono',monospace",fontSize:'10px',color:'var(--tx3)'}}>{i+1}</td>
                  <td style={{fontSize:'11px'}}>{r.org}</td>
                  <td style={{fontFamily:"'Space Mono',monospace",fontSize:'10px',color:'var(--tx3)'}}>{r.resId || '—'}</td>
                  <td><span className="mtag">{r.machine}</span></td>
                  <td style={{fontFamily:"'Space Mono',monospace",fontSize:'10px',color:'var(--tx3)'}}>{r.date}</td>
                  <td style={{fontFamily:"'Space Mono',monospace",fontSize:'10px'}}>{r.product}</td>
                  <td style={{fontSize:'11px',color:'var(--tx3)'}}>{r.desc}</td>
                  <td style={{fontSize:'11px',color:'var(--tx3)'}}>{r.shift}</td>
                  <td>
                    <span className={`bdg ${r.dtType === 'PDT' ? 'bd' : r.dtType === 'UPDT' ? 'brj' : r.dtType === 'Running' ? 'bpa' : 'bp'}`}>
                      {r.dtType}
                    </span>
                  </td>
                  <td style={{fontSize:'11px',color:'var(--tx3)'}}>{r.category}</td>
                  <td style={{fontSize:'11px',color:'var(--tx3)'}}>{r.process}</td>
                  <td style={{fontSize:'11px'}}>{r.reason}</td>
                  <td style={{fontFamily:"'Space Mono',monospace",fontSize:'10px',color:'var(--amb)',fontWeight:600}}>{r.hrs}</td>
                  <td style={{fontFamily:"'Space Mono',monospace",fontSize:'10px',color:'var(--tx3)'}}>{r.min}</td>
                  <td>
                    <button className="btn bgh bsm">View</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div style={{display:'flex',justifyContent:'space-between',padding:'12px 4px',fontSize:'11px',color:'var(--tx3)'}}>
          <span>{sorted.length} records</span>
          <span>Zamil Operations · FPP/IPP BU</span>
        </div>

      </div>
    </div>
  )
}
