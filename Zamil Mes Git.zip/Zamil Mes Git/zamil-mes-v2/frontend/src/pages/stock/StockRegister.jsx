import { useState } from 'react'
import { useList } from '../../hooks/useApi'
import { stockService } from '../../services/api'
import { useApp } from '../../contexts/AppContext'


const QC_MAP = {
  appr: { label: 'Approved', cls: 'bd',  color: 'var(--grn)' },
  rejt: { label: 'Rejected', cls: 'brj', color: 'var(--red)' },
  pend: { label: 'Pending',  cls: 'bp',  color: 'var(--amb)' },
}

export default function StockRegister() {
  const { showToast } = useApp()

  const [search,    setSearch]    = useState('')
  const [statusF,   setStatusF]   = useState('')

  const { items: apiItems, loading } = useList(stockService.getRecords, { limit: 100 })
  const records = apiItems ?? []

  const filtered = records.filter(r => {
    if (statusF && r.qcStatus !== statusF) return false
    if (search && !JSON.stringify(r).toLowerCase().includes(search.toLowerCase())) return false
    return true
  })

  const totalBoxes  = filtered.length
  const approved    = filtered.filter(r => r.qcStatus === 'appr').length
  const rejected    = filtered.filter(r => r.qcStatus === 'rejt').length
  const pending     = filtered.filter(r => r.qcStatus === 'pend').length
  const pallets     = new Set(filtered.map(r => r.pallet).filter(p => p && p !== '—')).size

  return (
    <div style={{background:'var(--bg)',minHeight:'calc(100vh - 96px)'}}>

      {/* Purple Header */}
      <div style={{background:'var(--pur)',padding:'14px 28px',display:'flex',alignItems:'center',gap:'18px'}}>
        <div style={{fontSize:'18px',fontWeight:700,color:'#fff',fontFamily:"'Space Mono',monospace",letterSpacing:'.5px'}}>
          📦 Produced Stock Register
        </div>
        <div style={{marginLeft:'auto',display:'flex',gap:'10px'}}>
          <input
            type="text"
            placeholder="Search WO, product, locator, machine…"
            value={search}
            onChange={e => setSearch(e.target.value)}
            style={{background:'rgba(255,255,255,.15)',border:'1px solid rgba(255,255,255,.3)',borderRadius:'8px',
              padding:'7px 12px',fontSize:'12px',color:'#fff',width:'260px',outline:'none',
              fontFamily:"'DM Sans',sans-serif"}}
          />
          <select
            value={statusF}
            onChange={e => setStatusF(e.target.value)}
            style={{background:'rgba(255,255,255,.15)',border:'1px solid rgba(255,255,255,.3)',borderRadius:'8px',
              padding:'7px 12px',fontSize:'12px',color:'#fff',outline:'none',fontFamily:"'DM Sans',sans-serif"}}
          >
            <option value="">All Statuses</option>
            <option value="pend">Pending</option>
            <option value="appr">Approved</option>
            <option value="rejt">Rejected</option>
          </select>
          <button className="btn bgh bsm"
            style={{background:'rgba(255,255,255,.2)',borderColor:'rgba(255,255,255,.3)',color:'#fff'}}
            onClick={() => showToast('Export coming soon', 'info')}>
            ⬇ Export
          </button>
        </div>
      </div>

      {/* Stats bar — 5 chips */}
      <div style={{display:'grid',gridTemplateColumns:'repeat(5,1fr)',gap:0,borderBottom:'1px solid var(--bor)',background:'var(--bg2)'}}>
        <div style={{padding:'12px 18px',borderRight:'1px solid var(--bor)',textAlign:'center'}}>
          <div style={{fontSize:'20px',fontWeight:700,color:'var(--tx)',fontFamily:"'Space Mono',monospace"}}>{totalBoxes}</div>
          <div style={{fontSize:'10px',textTransform:'uppercase',letterSpacing:'.8px',color:'var(--tx3)',marginTop:'2px'}}>Total Boxes</div>
        </div>
        <div style={{padding:'12px 18px',borderRight:'1px solid var(--bor)',textAlign:'center'}}>
          <div style={{fontSize:'20px',fontWeight:700,color:'var(--grn)',fontFamily:"'Space Mono',monospace"}}>{approved}</div>
          <div style={{fontSize:'10px',textTransform:'uppercase',letterSpacing:'.8px',color:'var(--tx3)',marginTop:'2px'}}>Approved</div>
        </div>
        <div style={{padding:'12px 18px',borderRight:'1px solid var(--bor)',textAlign:'center'}}>
          <div style={{fontSize:'20px',fontWeight:700,color:'var(--red)',fontFamily:"'Space Mono',monospace"}}>{rejected}</div>
          <div style={{fontSize:'10px',textTransform:'uppercase',letterSpacing:'.8px',color:'var(--tx3)',marginTop:'2px'}}>Rejected</div>
        </div>
        <div style={{padding:'12px 18px',borderRight:'1px solid var(--bor)',textAlign:'center'}}>
          <div style={{fontSize:'20px',fontWeight:700,color:'var(--amb)',fontFamily:"'Space Mono',monospace"}}>{pending}</div>
          <div style={{fontSize:'10px',textTransform:'uppercase',letterSpacing:'.8px',color:'var(--tx3)',marginTop:'2px'}}>Pending</div>
        </div>
        <div style={{padding:'12px 18px',textAlign:'center'}}>
          <div style={{fontSize:'20px',fontWeight:700,color:'var(--pur)',fontFamily:"'Space Mono',monospace"}}>{pallets}</div>
          <div style={{fontSize:'10px',textTransform:'uppercase',letterSpacing:'.8px',color:'var(--tx3)',marginTop:'2px'}}>Pallets</div>
        </div>
      </div>

      {/* Table */}
      <div style={{overflowX:'auto',padding:'0 0 24px'}}>
        <table style={{width:'100%',borderCollapse:'collapse',fontSize:'12px'}}>
          <thead>
            <tr style={{background:'var(--bg3)',position:'sticky',top:0,zIndex:2}}>
              {['Organization','Plant','Machine','Product','Work Order','Quantity','Box #','Pallet','Locator Code','Printed At','QC Status'].map(h => (
                <th key={h} style={{padding:'10px 14px',textAlign: h === 'Quantity' ? 'right' : h === 'Box #' || h === 'Pallet' || h === 'QC Status' ? 'center' : 'left',
                  fontSize:'10px',textTransform:'uppercase',letterSpacing:'.9px',color:'var(--tx3)',
                  borderBottom:'1px solid var(--bor)',fontWeight:700,whiteSpace:'nowrap'}}>
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr><td colSpan={11} style={{textAlign:'center',color:'var(--tx3)',padding:'28px'}}>Loading…</td></tr>
            )}
            {!loading && filtered.length === 0 && (
              <tr><td colSpan={11} style={{textAlign:'center',color:'var(--tx3)',padding:'40px',fontSize:'13px'}}>
                No produced stock records yet. Print box labels to generate records.
              </td></tr>
            )}
            {filtered.map((r, i) => {
              const qc = QC_MAP[r.qcStatus] || QC_MAP.pend
              return (
                <tr key={r.id} style={{borderBottom:'1px solid var(--bor)',transition:'background .1s'}}
                  onMouseEnter={e => e.currentTarget.style.background = 'var(--bg2)'}
                  onMouseLeave={e => e.currentTarget.style.background = ''}>
                  <td style={{padding:'10px 14px',fontSize:'11px',color:'var(--tx3)'}}>{r.org}</td>
                  <td style={{padding:'10px 14px',fontSize:'11px'}}>{r.plant}</td>
                  <td style={{padding:'10px 14px'}}><span className="mtag">{r.machine}</span></td>
                  <td style={{padding:'10px 14px',fontSize:'11px'}}>{r.product}</td>
                  <td style={{padding:'10px 14px'}}><span className="woid" style={{fontSize:'11px'}}>{r.wo}</span></td>
                  <td style={{padding:'10px 14px',textAlign:'right',fontFamily:"'Space Mono',monospace",fontSize:'10px',color:'var(--pur)',fontWeight:600}}>
                    {Number(r.qty || 0).toLocaleString()}
                  </td>
                  <td style={{padding:'10px 14px',textAlign:'center',fontFamily:"'Space Mono',monospace",fontSize:'10px',fontWeight:600}}>{r.boxNo}</td>
                  <td style={{padding:'10px 14px',textAlign:'center',fontFamily:"'Space Mono',monospace",fontSize:'10px',color:'var(--tx3)'}}>{r.pallet}</td>
                  <td style={{padding:'10px 14px',fontFamily:"'Space Mono',monospace",fontSize:'10px',color:'var(--tel)'}}>{r.locator}</td>
                  <td style={{padding:'10px 14px',fontFamily:"'Space Mono',monospace",fontSize:'10px',color:'var(--tx3)'}}>{r.printedAt}</td>
                  <td style={{padding:'10px 14px',textAlign:'center'}}>
                    <span className={`bdg ${qc.cls}`}>{qc.label}</span>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}
