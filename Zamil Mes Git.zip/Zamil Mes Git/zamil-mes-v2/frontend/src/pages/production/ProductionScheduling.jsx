import { useMemo, useState, useEffect } from "react";
import { useList } from "../../hooks/useApi";
import { productionService, setupService } from "../../services/api";
import { useApp } from "../../contexts/AppContext";
import useReference, { FALLBACK } from "../../hooks/useReference";

const STATUS_MAP = {
  active: { label: "Running", cls: "bd", canonical: "running" },
  running: { label: "Running", cls: "bd", canonical: "running" },
  pending: { label: "Not Started", cls: "bp", canonical: "pending" },
  not_started: { label: "Not Started", cls: "bp", canonical: "pending" },
  "not started": { label: "Not Started", cls: "bp", canonical: "pending" },
  paused: { label: "On Hold", cls: "brv", canonical: "paused" },
  hold: { label: "On Hold", cls: "brv", canonical: "paused" },
  on_hold: { label: "On Hold", cls: "brv", canonical: "paused" },
  "on hold": { label: "On Hold", cls: "brv", canonical: "paused" },
  completed: { label: "Completed", cls: "bsuc", canonical: "completed" },
  cancelled: { label: "Terminated", cls: "brj", canonical: "cancelled" },
  canceled: { label: "Terminated", cls: "brj", canonical: "cancelled" },
  terminated: { label: "Terminated", cls: "brj", canonical: "cancelled" },
};

const PRIORITY_OPTIONS = [
  { value: "urgent", label: "1 – High" },
  { value: "normal", label: "2 – Normal" },
  { value: "low", label: "3 – Low" },
];

const STATUS_OPTIONS = [
  { value: "", label: "All Statuses" },
  { value: "pending", label: "Not Started" },
  { value: "active", label: "Running" },
  { value: "paused", label: "On Hold" },
  { value: "completed", label: "Completed" },
  { value: "cancelled", label: "Terminated" },
];

const EMPTY_SCHEDULE_FORM = {
  scheduledDate: "",
  scheduledEndDate: "",
  priority: "normal",
};

export default function ProductionScheduling() {
  const { showToast } = useApp();
  const { machines: refMachines = [] } = useReference();

  // Load machines directly — bypasses the module-level cache in useReference
  const [apiMachines, setApiMachines] = useState([]);
  const [machinesLoading, setMachinesLoading] = useState(true);

  useEffect(() => {
    setMachinesLoading(true);
    setupService.getMachines()
      .then(res => {
        const list = res?.data ?? res ?? [];
        setApiMachines(Array.isArray(list) && list.length > 0 ? list : []);
      })
      .catch(() => setApiMachines([]))
      .finally(() => setMachinesLoading(false));
  }, []);

  const {
    items,
    total,
    loading,
    params = {},
    setFilter,
    setPage,
    refetch,
  } = useList(productionService.getWorkOrders, { limit: 20 });

  const apiRows = Array.isArray(items) ? items : [];

  // Effective machine list: prefer fresh API load → useReference → FALLBACK
  const machineRows = useMemo(() => {
    if (apiMachines.length > 0) return apiMachines;
    if (Array.isArray(refMachines) && refMachines.length > 0) return refMachines;
    return FALLBACK.machines;
  }, [apiMachines, refMachines]);

  // id / code → machine lookup (covers both numeric IDs and string codes)
  const machineMap = useMemo(() => {
    const map = {};
    machineRows.forEach(m => {
      const id   = String(m.id   || m._id          || '').toLowerCase();
      const code = String(m.code || m.machineCode   || '').toLowerCase();
      if (id)   map[id]   = m;
      if (code) map[code] = m;
    });
    return map;
  }, [machineRows]);

  const [machineF, setMachineF] = useState("");
  const [statusF, setStatusF] = useState("");

  const [scheduleModal, setScheduleModal] = useState(null);
  const [scheduleForm, setScheduleForm] = useState(EMPTY_SCHEDULE_FORM);
  const [savingSchedule, setSavingSchedule] = useState(false);

  const [machineModal, setMachineModal] = useState(null);
  const [newMachine, setNewMachine] = useState("");
  const [machineReason, setMachineReason] = useState("");
  const [savingMachine, setSavingMachine] = useState(false);

  const machineOptions = useMemo(() => {
    const map = new Map();

    // Primary: machines from setup API
    machineRows.forEach((machine) => {
      const value = getMachineValue(machine);
      if (value) {
        map.set(value, {
          value,
          code: getMachineCode(machine),
          label: getMachineName(machine),
        });
      }
    });

    // Secondary: any machine IDs seen in WOs that aren't in the setup list yet
    apiRows.forEach((wo) => {
      const value = getWorkOrderMachineValue(wo);
      if (value && !map.has(value)) {
        const resolved = resolveWOMachineCode(wo, machineMap);
        map.set(value, { value, code: resolved, label: resolved });
      }
    });

    return Array.from(map.values());
  }, [apiRows, machineRows, machineMap]);

  const selectedMachineLabel = useMemo(() => {
    if (!machineF) return machinesLoading ? "Loading machines…" : "All Machines";
    return (
      machineOptions.find((machine) => machine.value === machineF)?.code ||
      machineF
    );
  }, [machineF, machineOptions, machinesLoading]);

  const visibleRows = useMemo(() => {
    return [...apiRows]
      .filter((wo) => rowMatchesMachine(wo, machineF))
      .filter((wo) => rowMatchesStatus(wo, statusF))
      .sort(sortByPriorityThenSchedule);
  }, [apiRows, machineF, statusF]);

  const stats = useMemo(() => {
    const totalRows = apiRows.length;
    const running = apiRows.filter(
      (row) =>
        getStatusMeta(row?.status || row?.woStatus).canonical === "running",
    ).length;
    const notStarted = apiRows.filter(
      (row) =>
        getStatusMeta(row?.status || row?.woStatus).canonical === "pending",
    ).length;
    const onHold = apiRows.filter(
      (row) =>
        getStatusMeta(row?.status || row?.woStatus).canonical === "paused",
    ).length;
    const completed = apiRows.filter((row) => {
      const status = getStatusMeta(row?.status || row?.woStatus).canonical;
      const plannedQty = getPlannedQty(row);
      const producedQty = getProducedQty(row);
      return (
        status === "completed" || (plannedQty > 0 && producedQty >= plannedQty)
      );
    }).length;

    return { totalRows, running, notStarted, onHold, completed };
  }, [apiRows]);

  const dateLabel = new Date().toLocaleDateString("en-GB", {
    weekday: "long",
    day: "2-digit",
    month: "short",
    year: "numeric",
  });

  const applyFilter = (nextMachine = machineF, nextStatus = statusF) => {
    setFilter({
      machineId: nextMachine || undefined,
      status: nextStatus || undefined,
    });
  };

  const handleMachineFilter = (value) => {
    setMachineF(value);
    applyFilter(value, statusF);
  };

  const handleStatusFilter = (value) => {
    setStatusF(value);
    applyFilter(machineF, value);
  };

  const openScheduleModal = (wo) => {
    setScheduleModal(wo);
    setScheduleForm({
      scheduledDate: toDateTimeLocal(getScheduleStart(wo)),
      scheduledEndDate: toDateTimeLocal(getScheduleEnd(wo)),
      priority: normalizePriorityForForm(wo?.priority),
    });
  };

  const openMachineModal = (wo) => {
    setMachineModal(wo);
    setNewMachine(getWorkOrderMachineValue(wo));
    setMachineReason("");
  };

  const resetScheduleModal = () => {
    setScheduleModal(null);
    setScheduleForm(EMPTY_SCHEDULE_FORM);
  };

  const resetMachineModal = () => {
    setMachineModal(null);
    setNewMachine("");
    setMachineReason("");
  };

  const closeScheduleModal = () => {
    if (!savingSchedule) resetScheduleModal();
  };

  const closeMachineModal = () => {
    if (!savingMachine) resetMachineModal();
  };

  const confirmScheduleUpdate = async () => {
    const id = getWorkOrderUpdateId(scheduleModal);

    if (!id) {
      showToast(
        "Unable to update schedule. Work order database ID is missing.",
        "error",
      );
      return;
    }

    setSavingSchedule(true);

    try {
      await productionService.updateWorkOrder(id, {
        scheduledDate: scheduleForm.scheduledDate || null,
        scheduledEndDate: scheduleForm.scheduledEndDate || null,
        priority: scheduleForm.priority || "normal",
      });

      showToast(
        `Schedule updated for ${getWorkOrderNumber(scheduleModal)}`,
        "success",
      );
      resetScheduleModal();
      await refetch();
    } catch (error) {
      showToast(
        error?.message || "Failed to update schedule from API",
        "error",
      );
    } finally {
      setSavingSchedule(false);
    }
  };

  const confirmMachineChange = async () => {
    const id = getWorkOrderUpdateId(machineModal);

    if (!id) {
      showToast(
        "Unable to change machine. Work order database ID is missing.",
        "error",
      );
      return;
    }

    if (!newMachine) {
      showToast("Please select a new machine", "warning");
      return;
    }

    setSavingMachine(true);

    try {
      await productionService.updateWorkOrder(id, {
        machineId: newMachine,
        machineChangeReason: machineReason || undefined,
      });

      const nextMachineLabel =
        machineOptions.find((machine) => machine.value === newMachine)?.code ||
        newMachine;
      showToast(
        `WO ${getWorkOrderNumber(machineModal)} moved to ${nextMachineLabel}`,
        "success",
      );
      resetMachineModal();
      await refetch();
    } catch (error) {
      showToast(error?.message || "Failed to change machine from API", "error");
    } finally {
      setSavingMachine(false);
    }
  };

  const exportSchedule = () => {
    const exportRows = visibleRows.length ? visibleRows : apiRows;

    if (!exportRows.length) {
      showToast("No work orders available to export", "warning");
      return;
    }

    const header =
      "#\tMachine\tWork Order\tStatus\tProduct\tQty\tCompleted\tScheduled Start\tScheduled Completion\tPriority\n";
    const body = exportRows
      .map((wo, index) => {
        return [
          index + 1,
          getWorkOrderMachine(wo),
          getWorkOrderNumber(wo),
          getStatusMeta(wo?.status || wo?.woStatus).label,
          getProductName(wo),
          getPlannedQty(wo),
          getProducedQty(wo),
          formatDateTime(getScheduleStart(wo)),
          formatDateTime(getScheduleEnd(wo)),
          getPriorityMeta(wo?.priority).label.replace(" – ", "-"),
        ]
          .map(escapeTsv)
          .join("\t");
      })
      .join("\n");

    const blob = new Blob([header + body], {
      type: "text/tab-separated-values;charset=utf-8;",
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");

    link.href = url;
    link.download = "Production_Schedule.xls";
    link.click();

    URL.revokeObjectURL(url);
    showToast("Downloading Production_Schedule.xls", "success");
  };

  const totalCount = Number.isFinite(Number(total))
    ? Number(total)
    : stats.totalRows;
  const pageLimit = Number(params?.limit || 20);
  const currentPage = Number(params?.page || 1);

  return (
    <div style={{ background: "var(--bg)", minHeight: "calc(100vh - 96px)" }}>
      <div
        style={{
          background: "var(--pur2)",
          borderBottom: "1px solid var(--bor)",
          padding: "14px 24px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          flexWrap: "wrap",
          gap: "10px",
        }}
      >
        <div>
          <div
            style={{
              fontSize: "15px",
              fontWeight: 700,
              color: "var(--tx)",
              display: "flex",
              alignItems: "center",
              gap: "8px",
            }}
          >
            <span
              style={{
                width: "7px",
                height: "7px",
                borderRadius: "50%",
                background: "var(--pur)",
                display: "inline-block",
              }}
            />
            Production Scheduling
          </div>
          <div
            style={{ fontSize: "12px", color: "var(--tx3)", marginTop: "3px" }}
          >
            FPP BU · {selectedMachineLabel} · {dateLabel}
          </div>
        </div>

        <div
          style={{
            display: "flex",
            gap: "8px",
            alignItems: "center",
            flexWrap: "wrap",
          }}
        >
          <select
            value={machineF}
            onChange={(event) => handleMachineFilter(event.target.value)}
            style={filterSelectStyle}
          >
            <option value="">All Machines</option>
            {machineOptions.map((machine) => (
              <option key={machine.value} value={machine.value}>
                {machine.code}
              </option>
            ))}
          </select>

          <select
            value={statusF}
            onChange={(event) => handleStatusFilter(event.target.value)}
            style={filterSelectStyle}
          >
            {STATUS_OPTIONS.map((option) => (
              <option key={option.value || "all"} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>

          <button
            className="btn bgh bsm"
            type="button"
            onClick={refetch}
            disabled={loading}
          >
            {loading ? "Refreshing..." : "🔄 Refresh"}
          </button>
          <button
            className="btn bpri bsm"
            type="button"
            onClick={exportSchedule}
          >
            📥 Export
          </button>
        </div>
      </div>

      <div
        style={{ padding: "14px 24px", borderBottom: "1px solid var(--bor)" }}
      >
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(5, 1fr)",
            gap: "10px",
          }}
        >
          <StatCard
            label="Total WOs"
            value={totalCount || stats.totalRows}
            color="var(--tx)"
          />
          <StatCard label="Running" value={stats.running} color="var(--grn)" />
          <StatCard
            label="Not Started"
            value={stats.notStarted}
            color="var(--amb)"
          />
          <StatCard label="On Hold" value={stats.onHold} color="var(--pur)" />
          <StatCard
            label="Completed"
            value={stats.completed}
            color="var(--blu)"
          />
        </div>
      </div>

      <div style={{ padding: "16px 24px" }}>
        <div
          style={{
            background: "var(--bg2)",
            border: "1px solid var(--bor)",
            borderRadius: "var(--rl)",
            overflow: "hidden",
          }}
        >
          <div style={{ overflowX: "auto" }}>
            <table
              style={{
                width: "100%",
                minWidth: "1120px",
                borderCollapse: "collapse",
                fontSize: "12px",
              }}
            >
              <thead>
                <tr style={{ background: "var(--pur2)" }}>
                  <TableHead>#</TableHead>
                  <TableHead>Machine</TableHead>
                  <TableHead>Work Order</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Product</TableHead>
                  <TableHead align="right">Quantity</TableHead>
                  <TableHead align="center">Progress</TableHead>
                  <TableHead>Scheduled Start</TableHead>
                  <TableHead>Scheduled Completion</TableHead>
                  <TableHead align="center">Priority</TableHead>
                  <TableHead align="center">Action</TableHead>
                </tr>
              </thead>

              <tbody>
                {loading && (
                  <tr>
                    <td colSpan={11} style={emptyCellStyle}>
                      Loading schedule from API...
                    </td>
                  </tr>
                )}

                {!loading && apiRows.length === 0 && (
                  <tr>
                    <td colSpan={11} style={emptyCellStyle}>
                      No work orders found from API.
                    </td>
                  </tr>
                )}

                {!loading && apiRows.length > 0 && visibleRows.length === 0 && (
                  <tr>
                    <td colSpan={11} style={emptyCellStyle}>
                      No work orders match this filter.
                    </td>
                  </tr>
                )}

                {!loading &&
                  visibleRows.map((wo, index) => {
                    const plannedQty = getPlannedQty(wo);
                    const producedQty = getProducedQty(wo);
                    const remainingQty = Math.max(0, plannedQty - producedQty);
                    const progress = plannedQty
                      ? Math.min(
                          100,
                          Math.round((producedQty * 100) / plannedQty),
                        )
                      : 0;
                    const statusMeta = getStatusMeta(
                      wo?.status || wo?.woStatus,
                    );
                    const priorityMeta = getPriorityMeta(wo?.priority);
                    const start = getScheduleStart(wo);
                    const end = getScheduleEnd(wo);
                    const isRunning = statusMeta.canonical === "running";
                    const isTerminated = statusMeta.canonical === "cancelled";
                    const isLate = isScheduleLate(end, statusMeta.canonical);

                    return (
                      <tr
                        key={
                          getWorkOrderUpdateId(wo) ||
                          getWorkOrderNumber(wo) ||
                          index
                        }
                        style={{ opacity: isTerminated ? 0.45 : 1 }}
                      >
                        <TableCell>
                          <span
                            style={{
                              fontFamily: "'Space Mono', monospace",
                              fontSize: "10px",
                              color: "var(--tx3)",
                            }}
                          >
                            {String(index + 1).padStart(2, "0")}
                          </span>
                        </TableCell>

                        <TableCell>
                          {(() => {
                            const code = resolveWOMachineCode(wo, machineMap);
                            const machineId = getWorkOrderMachineValue(wo);
                            const resolved = machineMap[machineId?.toLowerCase()];
                            return (
                              <>
                                <div
                                  style={{
                                    fontFamily: "'Space Mono', monospace",
                                    fontSize: "11px",
                                    fontWeight: 700,
                                    color: "var(--tel)",
                                  }}
                                >
                                  {code}
                                </div>
                                {resolved?.type && (
                                  <div
                                    style={{
                                      fontSize: "10px",
                                      color: "var(--tx3)",
                                      marginTop: "2px",
                                      textTransform: "uppercase",
                                      letterSpacing: ".5px",
                                    }}
                                  >
                                    {resolved.type}
                                  </div>
                                )}
                              </>
                            );
                          })()}
                        </TableCell>

                        <TableCell>
                          <div className="woid">{getWorkOrderNumber(wo)}</div>
                          {getOperationText(wo) && (
                            <div
                              style={{
                                fontSize: "10px",
                                color: "var(--tx3)",
                                marginTop: "1px",
                                textTransform: "uppercase",
                                letterSpacing: ".6px",
                              }}
                            >
                              {getOperationText(wo)}
                            </div>
                          )}
                        </TableCell>

                        <TableCell>
                          <span className={`bdg ${statusMeta.cls}`}>
                            {isRunning && <RunningDot />}
                            {statusMeta.label}
                          </span>
                        </TableCell>

                        <TableCell>
                          <div className="pnm">{getProductName(wo)}</div>
                          <div className="psb">{getProductSubText(wo)}</div>
                        </TableCell>

                        <TableCell align="right">
                          <div
                            style={{
                              fontFamily: "'Space Mono', monospace",
                              fontSize: "12px",
                              fontWeight: 700,
                              color: "var(--tx)",
                            }}
                          >
                            {plannedQty.toLocaleString()}{" "}
                            <span
                              style={{
                                fontSize: "10px",
                                color: "var(--tx3)",
                                fontFamily: "'DM Sans', sans-serif",
                                fontWeight: 400,
                              }}
                            >
                              total
                            </span>
                          </div>
                          <div
                            style={{
                              fontSize: "11px",
                              color: "var(--grn)",
                              fontWeight: 600,
                              marginTop: "2px",
                            }}
                          >
                            ✓ {producedQty.toLocaleString()} done ({progress}%)
                          </div>
                          <div
                            style={{
                              fontSize: "11px",
                              color: "var(--amb)",
                              fontWeight: 600,
                              marginTop: "1px",
                            }}
                          >
                            → {remainingQty.toLocaleString()} remaining
                          </div>
                          <MiniProgress value={progress} color="var(--grn)" />
                        </TableCell>

                        <TableCell align="center">
                          <div
                            style={{
                              display: "flex",
                              alignItems: "center",
                              gap: "6px",
                              minWidth: "120px",
                            }}
                          >
                            <div
                              style={{
                                flex: 1,
                                height: "6px",
                                background: "var(--bg3)",
                                borderRadius: "6px",
                                overflow: "hidden",
                              }}
                            >
                              <div
                                style={{
                                  height: "100%",
                                  width: `${progress}%`,
                                  background: isRunning
                                    ? "var(--blu)"
                                    : "var(--amb)",
                                  borderRadius: "6px",
                                  transition: "width .4s",
                                }}
                              />
                            </div>
                            <span
                              style={{
                                fontFamily: "'Space Mono', monospace",
                                fontSize: "10px",
                                color: "var(--tx3)",
                                flexShrink: 0,
                              }}
                            >
                              {progress}%
                            </span>
                          </div>
                        </TableCell>

                        <TableCell>
                          <div style={{ fontSize: "12px", color: "var(--tx)" }}>
                            {formatDateTime(start)}
                          </div>
                          {isRunning && (
                            <div
                              style={{
                                fontSize: "10px",
                                color: "var(--grn)",
                                fontWeight: 600,
                                marginTop: "2px",
                              }}
                            >
                              ▶ Started
                            </div>
                          )}
                        </TableCell>

                        <TableCell>
                          <div
                            style={{
                              fontSize: "12px",
                              color: isLate ? "var(--red)" : "var(--tx)",
                              fontWeight: isLate ? 700 : 400,
                            }}
                          >
                            {formatDateTime(end)}
                            {isLate ? " ⚠" : ""}
                          </div>
                          {!end && (
                            <div
                              style={{
                                fontSize: "10px",
                                color: "var(--tx3)",
                                marginTop: "2px",
                              }}
                            >
                              Not Scheduled
                            </div>
                          )}
                        </TableCell>

                        <TableCell align="center">
                          <span className={`bdg ${priorityMeta.cls}`}>
                            {priorityMeta.label}
                          </span>
                        </TableCell>

                        <TableCell align="center">
                          <div
                            style={{
                              display: "flex",
                              flexDirection: "column",
                              gap: "4px",
                              alignItems: "center",
                            }}
                          >
                            <button
                              className="btn bgh bsm"
                              type="button"
                              style={actionButtonStyle}
                              onClick={() => openMachineModal(wo)}
                            >
                              🔄 Change Machine
                            </button>
                            <button
                              className="btn bgh bsm"
                              type="button"
                              style={actionButtonStyle}
                              onClick={() => openScheduleModal(wo)}
                            >
                              ✏ Edit Schedule
                            </button>
                          </div>
                        </TableCell>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </div>

        {totalCount > pageLimit && (
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              padding: "10px 0",
              fontSize: "12px",
              color: "var(--tx3)",
            }}
          >
            <span>
              Showing {visibleRows.length} of {totalCount}
            </span>
            <Pagination
              current={currentPage}
              total={totalCount}
              limit={pageLimit}
              onChange={setPage}
            />
          </div>
        )}
      </div>

      {machineModal && (
        <ModalBackdrop onClose={closeMachineModal}>
          <div
            className="modal compact-modal"
            onClick={(event) => event.stopPropagation()}
          >
            <button
              className="mclose"
              type="button"
              onClick={closeMachineModal}
            >
              ×
            </button>

            <div className="mtit">Change Machine Assignment</div>

            <div className="mrow compact-row">
              <div className="mfg">
                <label>Work Order</label>
                <div className="woid">{getWorkOrderNumber(machineModal)}</div>
              </div>

              <div className="mfg">
                <label>Current Machine</label>
                <div
                  style={{
                    fontFamily: "'Space Mono', monospace",
                    fontSize: "13px",
                    color: "var(--tel)",
                    fontWeight: 700,
                  }}
                >
                  {resolveWOMachineCode(machineModal, machineMap)}
                </div>
              </div>
            </div>

            <div className="mfg">
              <label>Assign to New Machine</label>
              <select
                value={newMachine}
                onChange={(event) => setNewMachine(event.target.value)}
              >
                <option value="">Select Machine</option>
                {machineOptions.map((machine) => (
                  <option key={machine.value} value={machine.value}>
                    {machine.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="mfg">
              <label>Reason for Change</label>
              <textarea
                className="compact-textarea"
                value={machineReason}
                onChange={(event) => setMachineReason(event.target.value)}
                placeholder="e.g. Machine breakdown, capacity rebalancing..."
              />
            </div>

            <div className="mfooter compact-footer">
              <button
                className="btn bgh"
                type="button"
                onClick={closeMachineModal}
                disabled={savingMachine}
              >
                Cancel
              </button>
              <button
                className="btn bpri"
                type="button"
                onClick={confirmMachineChange}
                disabled={savingMachine}
              >
                {savingMachine ? "Saving..." : "Confirm Change"}
              </button>
            </div>
          </div>
        </ModalBackdrop>
      )}

      {scheduleModal && (
        <ModalBackdrop onClose={closeScheduleModal}>
          <div
            className="modal compact-modal"
            onClick={(event) => event.stopPropagation()}
          >
            <button
              className="mclose"
              type="button"
              onClick={closeScheduleModal}
            >
              ×
            </button>

            <div className="mtit">Edit Schedule</div>

            <div className="mfg">
              <label>Work Order</label>
              <div className="woid">{getWorkOrderNumber(scheduleModal)}</div>
            </div>

            <div className="mrow compact-row">
              <div className="mfg">
                <label>Scheduled Start</label>
                <input
                  type="datetime-local"
                  value={scheduleForm.scheduledDate}
                  onChange={(event) =>
                    setScheduleForm((prev) => ({
                      ...prev,
                      scheduledDate: event.target.value,
                    }))
                  }
                />
              </div>

              <div className="mfg">
                <label>Scheduled Completion</label>
                <input
                  type="datetime-local"
                  value={scheduleForm.scheduledEndDate}
                  onChange={(event) =>
                    setScheduleForm((prev) => ({
                      ...prev,
                      scheduledEndDate: event.target.value,
                    }))
                  }
                />
              </div>
            </div>

            <div className="mfg">
              <label>Priority</label>
              <select
                value={scheduleForm.priority}
                onChange={(event) =>
                  setScheduleForm((prev) => ({
                    ...prev,
                    priority: event.target.value,
                  }))
                }
              >
                {PRIORITY_OPTIONS.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="mfooter compact-footer">
              <button
                className="btn bgh"
                type="button"
                onClick={closeScheduleModal}
                disabled={savingSchedule}
              >
                Cancel
              </button>
              <button
                className="btn bpri"
                type="button"
                onClick={confirmScheduleUpdate}
                disabled={savingSchedule}
              >
                {savingSchedule ? "Saving..." : "Save Changes"}
              </button>
            </div>
          </div>
        </ModalBackdrop>
      )}
    </div>
  );
}

function StatCard({ label, value, color }) {
  return (
    <div
      style={{
        background: "var(--bg2)",
        border: "1px solid var(--bor)",
        borderRadius: "10px",
        padding: "12px 14px",
      }}
    >
      <div
        style={{
          fontSize: "10px",
          textTransform: "uppercase",
          letterSpacing: "1px",
          color: "var(--tx3)",
          fontWeight: 600,
          marginBottom: "5px",
        }}
      >
        {label}
      </div>
      <div
        style={{
          fontFamily: "'Space Mono', monospace",
          fontSize: "20px",
          fontWeight: 700,
          lineHeight: 1,
          color,
        }}
      >
        {value}
      </div>
    </div>
  );
}

function TableHead({ children, align = "left" }) {
  return (
    <th
      style={{
        padding: "10px 14px",
        textAlign: align,
        fontSize: "10px",
        textTransform: "uppercase",
        letterSpacing: "1px",
        color: "var(--tx3)",
        fontWeight: 500,
        borderBottom: "1px solid var(--bor)",
        whiteSpace: "nowrap",
      }}
    >
      {children}
    </th>
  );
}

function TableCell({ children, align = "left" }) {
  return (
    <td
      style={{
        padding: "10px 14px",
        borderBottom: "1px solid var(--bor)",
        color: "var(--tx2)",
        verticalAlign: "middle",
        textAlign: align,
      }}
    >
      {children}
    </td>
  );
}

function ModalBackdrop({ children, onClose }) {
  return (
    <div className="modal-bg on" onClick={onClose}>
      {children}
    </div>
  );
}

function RunningDot() {
  return (
    <span
      style={{
        width: "5px",
        height: "5px",
        borderRadius: "50%",
        background: "var(--grn)",
        display: "inline-block",
        animation: "pulse 1.5s infinite",
        marginRight: "3px",
      }}
    />
  );
}

function MiniProgress({ value, color }) {
  return (
    <div
      style={{
        height: "3px",
        background: "var(--bg3)",
        borderRadius: "3px",
        marginTop: "5px",
        overflow: "hidden",
      }}
    >
      <div
        style={{
          height: "100%",
          width: `${value}%`,
          background: color,
          borderRadius: "3px",
          transition: "width .4s",
        }}
      />
    </div>
  );
}

function Pagination({ current = 1, total, limit, onChange }) {
  const pages = Math.ceil(total / limit);
  if (pages <= 1) return null;

  const range = Array.from({ length: Math.min(5, pages) }, (_, index) => {
    const middle = Math.min(Math.max(current, 3), Math.max(3, pages - 2));
    return middle - 2 + index;
  }).filter((page) => page >= 1 && page <= pages);

  return (
    <div className="pag">
      <button
        className="pag-btn"
        type="button"
        disabled={current <= 1}
        onClick={() => onChange(current - 1)}
      >
        Prev
      </button>
      {range.map((page) => (
        <button
          key={page}
          className={`pag-btn ${page === current ? "on" : ""}`}
          type="button"
          onClick={() => onChange(page)}
        >
          {page}
        </button>
      ))}
      <button
        className="pag-btn"
        type="button"
        disabled={current >= pages}
        onClick={() => onChange(current + 1)}
      >
        Next
      </button>
    </div>
  );
}

const filterSelectStyle = {
  fontSize: "12px",
  padding: "6px 10px",
  border: "1px solid var(--bor2)",
  borderRadius: "8px",
  background: "var(--bg2)",
  color: "var(--tx)",
  fontFamily: "'DM Sans', sans-serif",
  width: "auto",
};

const emptyCellStyle = {
  textAlign: "center",
  padding: "32px",
  color: "var(--tx3)",
};

const actionButtonStyle = {
  fontSize: "10px",
  padding: "3px 8px",
  width: "132px",
  justifyContent: "center",
};

function getWorkOrderUpdateId(wo) {
  return wo?.id || wo?._id || wo?.workOrderId || wo?.woId || "";
}

function getWorkOrderNumber(wo) {
  return (
    wo?.woNumber ||
    wo?.workOrderNumber ||
    wo?.number ||
    wo?.id ||
    wo?._id ||
    "—"
  );
}

function getOperationText(wo) {
  return wo?.operation || wo?.op || wo?.operationName || "";
}

function getProductName(wo) {
  return (
    wo?.product || wo?.productName || wo?.itemName || wo?.itemDescription || "—"
  );
}

function getProductSubText(wo) {
  return (
    wo?.sub ||
    wo?.notes ||
    wo?.customer ||
    wo?.productCode ||
    wo?.itemCode ||
    "—"
  );
}

function getPlannedQty(wo) {
  return toNumber(
    wo?.plannedQty ?? wo?.qty ?? wo?.quantity ?? wo?.targetQty ?? wo?.totalQty,
  );
}

function getProducedQty(wo) {
  return toNumber(
    wo?.producedQty ??
      wo?.completedQty ??
      wo?.completedQuantity ??
      wo?.goodQty ??
      wo?.actualQty,
  );
}

function getScheduleStart(wo) {
  return (
    wo?.scheduledDate ||
    wo?.scheduledStart ||
    wo?.scheduleStart ||
    wo?.startDate ||
    wo?.startTime ||
    ""
  );
}

function getScheduleEnd(wo) {
  return (
    wo?.scheduledEndDate ||
    wo?.scheduledEnd ||
    wo?.scheduleEnd ||
    wo?.endDate ||
    wo?.endTime ||
    ""
  );
}

function getStatusMeta(status) {
  const key = String(status || "pending")
    .trim()
    .toLowerCase()
    .replace(/-/g, "_");
  return (
    STATUS_MAP[key] || {
      label: status || "Not Started",
      cls: "bp",
      canonical: "pending",
    }
  );
}

function getPriorityRank(priority) {
  const key = String(priority || "")
    .trim()
    .toLowerCase();
  if (key === "1" || key === "urgent" || key === "high") return 1;
  if (key === "2" || key === "medium") return 2;
  if (key === "3" || key === "normal") return 3;
  if (key === "4" || key === "low") return 4;
  return 3;
}

function getPriorityMeta(priority) {
  const rank = getPriorityRank(priority);

  if (rank === 1) return { label: "1 – High", cls: "brj" };
  if (rank === 2) return { label: "2 – Medium", cls: "bp" };
  if (rank === 4) return { label: "4 – Low", cls: "" };
  return { label: "3 – Normal", cls: "bd" };
}

function normalizePriorityForForm(priority) {
  const rank = getPriorityRank(priority);
  if (rank === 1) return "urgent";
  if (rank === 2) return "medium";
  return "normal";
}

function sortByPriorityThenSchedule(a, b) {
  const priorityDiff =
    getPriorityRank(a?.priority) - getPriorityRank(b?.priority);
  if (priorityDiff !== 0) return priorityDiff;

  const aDate = getScheduleSortValue(getScheduleStart(a));
  const bDate = getScheduleSortValue(getScheduleStart(b));
  return aDate - bDate;
}

function getScheduleSortValue(value) {
  if (!value) return Number.MAX_SAFE_INTEGER;
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? Number.MAX_SAFE_INTEGER
    : date.getTime();
}

function rowMatchesMachine(wo, machineF) {
  if (!machineF) return true;
  const requested = String(machineF).toLowerCase();
  return getMachineCandidates(wo).some(
    (value) => String(value).toLowerCase() === requested,
  );
}

function rowMatchesStatus(wo, statusF) {
  if (!statusF) return true;
  const selected = getStatusMeta(statusF).canonical;
  const actual = getStatusMeta(wo?.status || wo?.woStatus).canonical;
  return actual === selected;
}

function getMachineCandidates(wo) {
  return [
    wo?.machineId,
    wo?.machineCode,
    wo?.machineName,
    wo?.machine?.id,
    wo?.machine?._id,
    wo?.machine?.code,
    wo?.machine?.machineCode,
    wo?.machine?.name,
  ].filter(Boolean);
}

function getWorkOrderMachineValue(wo) {
  return String(
    wo?.machineId ||
      wo?.machine?.id ||
      wo?.machine?._id ||
      wo?.machineCode ||
      wo?.machine?.code ||
      wo?.machine?.machineCode ||
      "",
  );
}

function getWorkOrderMachine(wo) {
  return (
    wo?.machineCode ||
    wo?.machine?.code ||
    wo?.machine?.machineCode ||
    wo?.machine?.name ||
    wo?.machineName ||
    wo?.machineId ||
    "—"
  );
}

// Resolve human-readable machine code using machineMap lookup first,
// then fall back to whatever the WO carries directly.
function resolveWOMachineCode(wo, machineMap) {
  if (!wo) return "—";
  const id = getWorkOrderMachineValue(wo);
  if (id) {
    const found = machineMap[id.toLowerCase()];
    if (found) return getMachineCode(found);
  }
  return getWorkOrderMachine(wo);
}

function getMachineValue(machine) {
  return String(
    machine?.id || machine?._id || machine?.code || machine?.machineCode || "",
  );
}

function getMachineCode(machine) {
  return (
    machine?.code ||
    machine?.machineCode ||
    machine?.name ||
    machine?.id ||
    machine?._id ||
    ""
  );
}

function getMachineName(machine) {
  const code = getMachineCode(machine);
  const type =
    machine?.type ||
    machine?.machineType ||
    machine?.category ||
    machine?.dept ||
    "";
  return type ? `${code} - ${type}` : code;
}

function isScheduleLate(value, canonicalStatus) {
  if (
    !value ||
    canonicalStatus === "completed" ||
    canonicalStatus === "cancelled"
  )
    return false;
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return false;
  return date.getTime() < Date.now();
}

function formatDateTime(value) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";

  return date.toLocaleString([], {
    year: "numeric",
    month: "short",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function toDateTimeLocal(value) {
  if (!value) return "";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";

  const offsetMs = date.getTimezoneOffset() * 60 * 1000;
  return new Date(date.getTime() - offsetMs).toISOString().slice(0, 16);
}

function toNumber(value) {
  const number = Number(value);
  return Number.isFinite(number) ? number : 0;
}

function escapeTsv(value) {
  const safeValue = value === null || value === undefined ? "" : String(value);
  return safeValue.replace(/[\t\r\n]+/g, " ").trim();
}
