import { useState, useEffect } from 'react'
import { useList, useMutation } from '../../hooks/useApi'
import { setupService } from '../../services/api'
import { useApp } from '../../contexts/AppContext'
import MachineForm from './MachineForm'

export default function MachinesTab() {
  const { showToast } = useApp()
  const [innerTab, setInnerTab] = useState('list')
  const [editItem, setEditItem] = useState(null)
  const [filter, setFilter] = useState({ plant:'', dept:'', status:'', search:'' })

  const { items: apiMachines, refetch: refetchMachines } = useList(setupService.getMachines)
  const [machines, setMachines] = useState([])

  useEffect(() => {
    if (apiMachines?.length) setMachines(apiMachines)
  }, [apiMachines])

  const { mutate: createMachineApi } = useMutation(setupService.createMachine, {
    onSuccess: () => { refetchMachines(); showToast('Machine added','success'); setInnerTab('list') },
    onError: (e) => showToast(e?.message || 'Failed to save machine','error'),
  })
  const { mutate: updateMachineApi } = useMutation(
    (data) => setupService.updateMachine(data.id, data),
    { onSuccess: () => { refetchMachines(); showToast('Machine updated','success'); setInnerTab('list') },
      onError: (e) => showToast(e?.message || 'Failed to update machine','error') }
  )
  const { mutate: deleteMachineApi } = useMutation(setupService.deleteMachine, {
    onSuccess: () => { refetchMachines(); showToast('Machine removed','warning') },
    onError: (e) => showToast(e?.message || 'Failed to delete machine','error'),
  })

  const filtered = machines.filter(m => {
    if (filter.plant  && m.plant  !== filter.plant)  return false
    if (filter.dept   && m.dept   !== filter.dept)   return false
    if (filter.status && m.status !== filter.status) return false
    if (filter.search && !JSON.stringify(m).toLowerCase().includes(filter.search.toLowerCase())) return false
    return true
  })

  const totalMC = filtered.length
  const running = filtered.filter(m => m.status === 'Running').length
  const idle    = filtered.filter(m => m.status === 'Idle').length
  const fault   = filtered.filter(m => m.status === 'Fault').length
  const maint   = filtered.filter(m => m.status === 'Maintenance').length

  const openForm = (m) => { setEditItem(m || {}); setInnerTab('form') }

  const saveForm = (data) => {
    if (data.id) updateMachineApi(data)
    else createMachineApi(data)
  }

  return (
    <div>
      <div style={{display:'flex',gap:'6px',marginBottom:'18px'}}>
        <button className={`bq-itab ${innerTab === 'list' ? 'on' : ''}`} onClick={() => setInnerTab('list')}>🖥 Machine List</button>
        <button className={`bq-itab ${innerTab === 'form' ? 'on' : ''}`} onClick={() => openForm(null)}>➕ Add / Edit Machine</button>
      </div>

      {innerTab === 'list' && (
        <>
          <div style={{display:'grid',gridTemplateColumns:'repeat(5,1fr)',gap:'10px',marginBottom:'14px'}}>
            {[['Total Machines',totalMC,'var(--blu)'],['Running',running,'var(--grn)'],['Idle',idle,'var(--amb)'],['Fault / Alarm',fault,'var(--red)'],['Maintenance Due',maint,'var(--tel)']].map(([l,v,c]) => (
              <div key={l} style={{background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'var(--r)',padding:'12px 14px'}}>
                <div style={{fontSize:'10px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',fontWeight:600,marginBottom:'5px'}}>{l}</div>
                <div style={{fontFamily:"'Space Mono',monospace",fontSize:'20px',fontWeight:700,color:c}}>{v}</div>
              </div>
            ))}
          </div>

          <div style={{background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'14px',padding:'14px 18px',marginBottom:'14px',display:'flex',alignItems:'flex-start',gap:'12px',flexWrap:'wrap'}}>
            <div className="fgrp" style={{minWidth:'120px'}}>
              <label>Plant / Org</label>
              <select style={{fontSize:'12px',padding:'6px 9px'}} value={filter.plant} onChange={e => setFilter(f=>({...f,plant:e.target.value}))}>
                <option value="">All Plants</option>
                <option value="FPP">FPP BU</option>
                <option value="IPP">IPP BU</option>
              </select>
            </div>
            <div className="fgrp" style={{minWidth:'150px'}}>
              <label>Department</label>
              <select style={{fontSize:'12px',padding:'6px 9px'}} value={filter.dept} onChange={e => setFilter(f=>({...f,dept:e.target.value}))}>
                <option value="">All Departments</option>
                <option value="INJECTION">Injection</option>
                <option value="BLOWMOLDIN">Blow Moulding</option>
                <option value="PRINTING">Printing</option>
                <option value="EXTRUSION">Extrusion</option>
                <option value="ASSEMBLY">Assembly</option>
              </select>
            </div>
            <div className="fgrp" style={{minWidth:'130px'}}>
              <label>Status</label>
              <select style={{fontSize:'12px',padding:'6px 9px'}} value={filter.status} onChange={e => setFilter(f=>({...f,status:e.target.value}))}>
                <option value="">All</option>
                <option value="Running">Running</option>
                <option value="Idle">Idle</option>
                <option value="Fault">Fault</option>
                <option value="Maintenance">Maintenance</option>
              </select>
            </div>
            <div className="fgrp" style={{flex:1,minWidth:'180px'}}>
              <label>Search</label>
              <input type="text" placeholder="Machine ID, name, OEM, model..." style={{fontSize:'12px',padding:'6px 9px'}} value={filter.search} onChange={e => setFilter(f=>({...f,search:e.target.value}))} />
            </div>
            <div style={{display:'flex',gap:'6px',alignItems:'flex-start' ,marginTop:'23px'}}>
              <button className="btn bpri bsm" onClick={() => openForm(null)}>+ Add Machine</button>
              <button className="btn bgh bsm">📥 Export</button>
              <button className="btn bgh bsm" onClick={() => setFilter({plant:'',dept:'',status:'',search:''})}>Clear</button>
            </div>
          </div>

          <div style={{background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'14px',overflow:'hidden',overflowX:'auto'}}>
            <div style={{padding:'12px 16px',borderBottom:'1px solid var(--bor)',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
              <div style={{fontSize:'13px',fontWeight:600,color:'var(--tx)',display:'flex',alignItems:'center',gap:'7px'}}>
                <span style={{width:'7px',height:'7px',borderRadius:'50%',background:'var(--pur)',display:'inline-block'}}/>
                Machine Registry
              </div>
              <span style={{fontSize:'11px',color:'var(--tx3)'}}>{filtered.length} machines</span>
            </div>
            <table style={{width:'100%',borderCollapse:'collapse',fontSize:'12px',minWidth:'1100px'}}>
              <thead>
                <tr style={{background:'var(--bg3)'}}>
                  {['Machine ID','Machine Name','Dept / Plant','OEM / Model','Cycle Time (s)','Cavities','IP Address','Status','MES Code','PM Freq','Action'].map(h => (
                    <th key={h} style={{padding:'9px 12px',textAlign: h==='Cycle Time (s)'||h==='Cavities'?'right':'left',fontSize:'10px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',borderBottom:'1px solid var(--bor)'}}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.length === 0 ? (
                  <tr><td colSpan={11} style={{textAlign:'center',padding:'28px',color:'var(--tx3)'}}>No machines found.</td></tr>
                ) : filtered.map(m => (
                  <tr key={m.id} style={{borderBottom:'1px solid var(--bor)'}}>
                    <td style={{padding:'9px 12px',fontFamily:"'Space Mono',monospace",fontSize:'11px',color:'var(--pur)',fontWeight:600}}>{m.machineId}</td>
                    <td style={{padding:'9px 12px',fontSize:'11px'}}>{m.name}</td>
                    <td style={{padding:'9px 12px',fontSize:'11px',color:'var(--tx3)'}}>{m.dept} / {m.plant}</td>
                    <td style={{padding:'9px 12px',fontSize:'11px',color:'var(--tx3)'}}>{m.oem} {m.model}</td>
                    <td style={{padding:'9px 12px',textAlign:'right',fontFamily:"'Space Mono',monospace",fontSize:'10px'}}>{m.cycleTime}</td>
                    <td style={{padding:'9px 12px',textAlign:'right',fontFamily:"'Space Mono',monospace",fontSize:'10px'}}>{m.cavities}</td>
                    <td style={{padding:'9px 12px',fontFamily:"'Space Mono',monospace",fontSize:'10px',color:'var(--tel)'}}>{m.ip}</td>
                    <td style={{padding:'9px 12px'}}>
                      <span className={`bdg ${m.status==='Running'?'bd':m.status==='Idle'?'bp':m.status==='Maintenance'?'bpa':'brj'}`}>{m.status}</span>
                    </td>
                    <td style={{padding:'9px 12px',fontFamily:"'Space Mono',monospace",fontSize:'10px',color:'var(--tx3)'}}>{m.mesCode}</td>
                    <td style={{padding:'9px 12px',fontSize:'11px',color:'var(--tx3)'}}>{m.pmFreq}</td>
                    <td style={{padding:'9px 12px'}}>
                      <div style={{display:'flex',gap:'4px'}}>
                        <button className="btn bgh bsm" onClick={() => { setEditItem(m); setInnerTab('form') }}>Edit</button>
                        <button className="btn bdan bsm" onClick={() => { if (window.confirm('Delete machine?')) deleteMachineApi(m.id) }}>🗑</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'10px 14px',fontSize:'11px',color:'var(--tx3)',borderTop:'1px solid var(--bor)'}}>
              <span>{filtered.length} records</span>
            </div>
          </div>
        </>
      )}

      {innerTab === 'form' && (
        <MachineForm machine={editItem} onSave={saveForm} onCancel={() => setInnerTab('list')} />
      )}
    </div>
  )
}
