# Setup component refactor

Copy these files into the same folder where your original `Setup.jsx` currently lives.

## Files

- `Setup.jsx` — main shell with top tabs only.
- `BoxQtyTab.jsx` — Box Quantity form/report logic.
- `MachinesTab.jsx` — Machine list/filter/API logic.
- `MachineForm.jsx` — Machine create/edit form.
- `LocationsTab.jsx` — Locations list/card/zone/barcode logic.
- `ShiftsTab.jsx` — placeholder shift tab.
- `UsersTab.jsx` — User access management.

## Important

These files assume they sit in the same folder as the original `Setup.jsx`, so the existing imports like `../../hooks/useApi` and `../../services/api` stay valid.

If you place them inside a `components/` folder, add one more `../` to those shared imports.
