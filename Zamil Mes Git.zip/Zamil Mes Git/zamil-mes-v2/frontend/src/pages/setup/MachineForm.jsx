import { useState } from 'react'

export default function MachineForm({ machine, onSave, onCancel }) {
  const [form, setForm] = useState({
    machineId: machine?.machineId || '', name: machine?.name || '',
    type: machine?.type || '', mesCode: machine?.mesCode || '',
    oem: machine?.oem || '', model: machine?.model || '',
    serial: machine?.serial || '', tonnage: machine?.tonnage || '',
    plant: machine?.plant || '', dept: machine?.dept || '',
    area: machine?.area || '', locator: machine?.locator || '',
    cycleTime: machine?.cycleTime || '', cavities: machine?.cavities || '',
    pps: machine?.pps || '', clampForce: machine?.clampForce || '',
    shotWeight: machine?.shotWeight || '',
    plcType: machine?.plcType || '', commProtocol: machine?.commProtocol || '',
    ip: machine?.ip || '', port: machine?.port || '',
    tagRun: machine?.tagRun || '', tagProd: machine?.tagProd || '',
    tagReject: machine?.tagReject || '', tagAlarm: machine?.tagAlarm || '',
    tagMode: machine?.tagMode || '',
    pmFreq: machine?.pmFreq || '', lastPmDate: machine?.lastPmDate || '',
    nextPmDate: machine?.nextPmDate || '',
    status: machine?.status || 'Idle', notes: machine?.notes || '',
  })
  const set = (k,v) => setForm(f=>({...f,[k]:v}))

  return (
    <div style={{background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'14px',overflow:'hidden'}}>
      <div style={{padding:'16px 22px',borderBottom:'1px solid var(--bor)',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
        <div style={{fontSize:'13px',fontWeight:600,color:'var(--tx)',display:'flex',alignItems:'center',gap:'7px'}}>
          <span style={{width:'7px',height:'7px',borderRadius:'50%',background:'var(--pur)',display:'inline-block'}}/>
          {machine?.id ? 'Edit Machine' : 'Add Machine'}
        </div>
        <div style={{display:'flex',gap:'8px',alignItems:'center'}}>
          <span style={{fontSize:'11px',color:'var(--tx3)'}}>Fields marked <span style={{color:'var(--red)'}}>*</span> are required</span>
          <button className="btn bgh bsm" onClick={onCancel}>← Back to List</button>
        </div>
      </div>

      {/* Section 1: Basic Identification */}
      <div style={{padding:'16px 22px',borderBottom:'1px solid var(--bor)'}}>
        <div style={{fontSize:'11px',fontWeight:700,textTransform:'uppercase',letterSpacing:'.8px',color:'var(--pur)',marginBottom:'12px'}}>
          <span style={{background:'var(--pur2)',borderRadius:'6px',padding:'3px 8px',border:'1px solid var(--pur)'}}>🪪 Basic Identification</span>
        </div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 2fr 1fr 1fr',gap:'14px',marginBottom:'12px'}}>
          <div className="fgrp">
            <label>Machine ID <span style={{color:'var(--red)'}}>*</span></label>
            <input type="text" placeholder="e.g. ZFP-01" value={form.machineId} onChange={e=>set('machineId',e.target.value)} style={{fontFamily:"'Space Mono',monospace"}}/>
          </div>
          <div className="fgrp">
            <label>Machine Name <span style={{color:'var(--red)'}}>*</span></label>
            <input type="text" placeholder="Full machine name" value={form.name} onChange={e=>set('name',e.target.value)}/>
          </div>
          <div className="fgrp">
            <label>Machine Type <span style={{color:'var(--red)'}}>*</span></label>
            <select value={form.type} onChange={e=>set('type',e.target.value)}>
              <option value="">Select</option>
              <option value="INJECTION">Injection Moulding</option>
              <option value="BLOW">Blow Moulding</option>
              <option value="PRINTING">Printing</option>
              <option value="EXTRUSION">Extrusion</option>
              <option value="ASSEMBLY">Assembly</option>
              <option value="CNC">CNC</option>
              <option value="OTHER">Other</option>
            </select>
          </div>
          <div className="fgrp">
            <label>MES Machine Code</label>
            <input type="text" placeholder="e.g. MES-ZFP-01" value={form.mesCode} onChange={e=>set('mesCode',e.target.value)} style={{fontFamily:"'Space Mono',monospace"}}/>
          </div>
        </div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr 1fr',gap:'14px'}}>
          <div className="fgrp">
            <label>Manufacturer (OEM)</label>
            <input type="text" placeholder="e.g. BMB, JSW, TOYO" value={form.oem} onChange={e=>set('oem',e.target.value)}/>
          </div>
          <div className="fgrp">
            <label>Model Number</label>
            <input type="text" placeholder="e.g. eKW 28Pi/700" value={form.model} onChange={e=>set('model',e.target.value)}/>
          </div>
          <div className="fgrp">
            <label>Serial Number</label>
            <input type="text" placeholder="e.g. SN12345" value={form.serial} onChange={e=>set('serial',e.target.value)}/>
          </div>
          <div className="fgrp">
            <label>Tonnage / Capacity</label>
            <input type="text" placeholder="e.g. 280T" value={form.tonnage} onChange={e=>set('tonnage',e.target.value)}/>
          </div>
        </div>
      </div>

      {/* Section 2: Plant & Location */}
      <div style={{padding:'16px 22px',borderBottom:'1px solid var(--bor)'}}>
        <div style={{fontSize:'11px',fontWeight:700,textTransform:'uppercase',letterSpacing:'.8px',color:'var(--grn)',marginBottom:'12px'}}>
          <span style={{background:'var(--grn2)',borderRadius:'6px',padding:'3px 8px',border:'1px solid var(--grn)'}}>🏭 Plant &amp; Location</span>
        </div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr 1fr',gap:'14px'}}>
          <div className="fgrp">
            <label>Plant <span style={{color:'var(--red)'}}>*</span></label>
            <select value={form.plant} onChange={e=>set('plant',e.target.value)}>
              <option value="">Select</option>
              <option value="FPP">FPP BU</option>
              <option value="IPP">IPP BU</option>
              <option value="ZPC">ZPC BU</option>
            </select>
          </div>
          <div className="fgrp">
            <label>Department</label>
            <select value={form.dept} onChange={e=>set('dept',e.target.value)}>
              <option value="">Select</option>
              <option value="INJECTION">Injection</option>
              <option value="BLOWMOLDIN">Blow Moulding</option>
              <option value="PRINTING">Printing</option>
              <option value="EXTRUSION">Extrusion</option>
              <option value="ASSEMBLY">Assembly</option>
            </select>
          </div>
          <div className="fgrp">
            <label>Area / Bay</label>
            <input type="text" placeholder="e.g. Bay A" value={form.area} onChange={e=>set('area',e.target.value)}/>
          </div>
          <div className="fgrp">
            <label>Locator Code</label>
            <input type="text" placeholder="Auto-generated" value={form.locator} onChange={e=>set('locator',e.target.value)} style={{fontFamily:"'Space Mono',monospace"}}/>
          </div>
        </div>
      </div>

      {/* Section 3: Production Parameters */}
      <div style={{padding:'16px 22px',borderBottom:'1px solid var(--bor)'}}>
        <div style={{fontSize:'11px',fontWeight:700,textTransform:'uppercase',letterSpacing:'.8px',color:'var(--amb)',marginBottom:'12px'}}>
          <span style={{background:'var(--amb2)',borderRadius:'6px',padding:'3px 8px',border:'1px solid var(--amb)'}}>⚙ Production Parameters</span>
        </div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr 1fr 1fr',gap:'14px'}}>
          <div className="fgrp">
            <label>Cycle Time (sec) <span style={{color:'var(--red)'}}>*</span></label>
            <input type="number" placeholder="e.g. 28" value={form.cycleTime} onChange={e=>set('cycleTime',e.target.value)}/>
          </div>
          <div className="fgrp">
            <label>No. of Cavities <span style={{color:'var(--red)'}}>*</span></label>
            <input type="number" placeholder="e.g. 4" value={form.cavities} onChange={e=>set('cavities',e.target.value)}/>
          </div>
          <div className="fgrp">
            <label>Parts Per Shot</label>
            <input type="number" placeholder="e.g. 4" value={form.pps} onChange={e=>set('pps',e.target.value)}/>
          </div>
          <div className="fgrp">
            <label>Clamp Force (T)</label>
            <input type="text" placeholder="e.g. 280" value={form.clampForce} onChange={e=>set('clampForce',e.target.value)}/>
          </div>
          <div className="fgrp">
            <label>Shot Weight (g)</label>
            <input type="text" placeholder="e.g. 450" value={form.shotWeight} onChange={e=>set('shotWeight',e.target.value)}/>
          </div>
        </div>
      </div>

      {/* Section 4: PLC / Connectivity */}
      <div style={{padding:'16px 22px',borderBottom:'1px solid var(--bor)'}}>
        <div style={{fontSize:'11px',fontWeight:700,textTransform:'uppercase',letterSpacing:'.8px',color:'var(--tel)',marginBottom:'12px'}}>
          <span style={{background:'rgba(6,182,212,.12)',borderRadius:'6px',padding:'3px 8px',border:'1px solid var(--tel)'}}>🔌 PLC / Connectivity</span>
        </div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr 1fr',gap:'14px'}}>
          <div className="fgrp">
            <label>PLC Type</label>
            <input type="text" placeholder="e.g. Siemens S7-300" value={form.plcType} onChange={e=>set('plcType',e.target.value)}/>
          </div>
          <div className="fgrp">
            <label>Protocol</label>
            <select value={form.commProtocol} onChange={e=>set('commProtocol',e.target.value)}>
              <option value="">Select</option>
              <option value="OPC-UA">OPC-UA</option>
              <option value="OPC-DA">OPC-DA</option>
              <option value="MQTT">MQTT</option>
              <option value="Modbus TCP">Modbus TCP</option>
              <option value="Modbus RTU">Modbus RTU</option>
              <option value="EtherNet/IP">EtherNet/IP</option>
              <option value="PROFINET">PROFINET</option>
              <option value="S7">S7 (Siemens)</option>
            </select>
          </div>
          <div className="fgrp">
            <label>IP Address</label>
            <input type="text" placeholder="e.g. 192.168.1.10" value={form.ip} onChange={e=>set('ip',e.target.value)} style={{fontFamily:"'Space Mono',monospace"}}/>
          </div>
          <div className="fgrp">
            <label>Port</label>
            <input type="number" placeholder="e.g. 4840" value={form.port} onChange={e=>set('port',e.target.value)} style={{fontFamily:"'Space Mono',monospace"}}/>
          </div>
        </div>
      </div>

      {/* Section 5: OPC / MES Tag Mapping */}
      <div style={{padding:'16px 22px',borderBottom:'1px solid var(--bor)'}}>
        <div style={{fontSize:'11px',fontWeight:700,textTransform:'uppercase',letterSpacing:'.8px',color:'var(--blu)',marginBottom:'12px'}}>
          <span style={{background:'rgba(59,130,246,.1)',borderRadius:'6px',padding:'3px 8px',border:'1px solid var(--blu)'}}>🏷 OPC / MES Tag Mapping</span>
        </div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr 1fr 1fr',gap:'14px'}}>
          <div className="fgrp">
            <label>Tag: Run Status</label>
            <input type="text" placeholder="e.g. ns=2;s=Run" value={form.tagRun} onChange={e=>set('tagRun',e.target.value)} style={{fontFamily:"'Space Mono',monospace",fontSize:'11px'}}/>
          </div>
          <div className="fgrp">
            <label>Tag: Production Count</label>
            <input type="text" placeholder="e.g. ns=2;s=ProdCnt" value={form.tagProd} onChange={e=>set('tagProd',e.target.value)} style={{fontFamily:"'Space Mono',monospace",fontSize:'11px'}}/>
          </div>
          <div className="fgrp">
            <label>Tag: Reject Count</label>
            <input type="text" placeholder="e.g. ns=2;s=Reject" value={form.tagReject} onChange={e=>set('tagReject',e.target.value)} style={{fontFamily:"'Space Mono',monospace",fontSize:'11px'}}/>
          </div>
          <div className="fgrp">
            <label>Tag: Alarm</label>
            <input type="text" placeholder="e.g. ns=2;s=Alarm" value={form.tagAlarm} onChange={e=>set('tagAlarm',e.target.value)} style={{fontFamily:"'Space Mono',monospace",fontSize:'11px'}}/>
          </div>
          <div className="fgrp">
            <label>Tag: Mode</label>
            <input type="text" placeholder="e.g. ns=2;s=Mode" value={form.tagMode} onChange={e=>set('tagMode',e.target.value)} style={{fontFamily:"'Space Mono',monospace",fontSize:'11px'}}/>
          </div>
        </div>
      </div>

      {/* Section 6: PM & Status */}
      <div style={{padding:'16px 22px',borderBottom:'1px solid var(--bor)'}}>
        <div style={{fontSize:'11px',fontWeight:700,textTransform:'uppercase',letterSpacing:'.8px',color:'var(--pur)',marginBottom:'12px'}}>
          <span style={{background:'var(--pur2)',borderRadius:'6px',padding:'3px 8px',border:'1px solid var(--pur)'}}>🔧 Preventive Maintenance</span>
        </div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr 1fr',gap:'14px',marginBottom:'12px'}}>
          <div className="fgrp">
            <label>PM Frequency <span style={{color:'var(--red)'}}>*</span></label>
            <select value={form.pmFreq} onChange={e=>set('pmFreq',e.target.value)}>
              <option value="">Select</option>
              <option value="Daily">Daily</option>
              <option value="Weekly">Weekly</option>
              <option value="Monthly">Monthly</option>
              <option value="Quarterly">Quarterly</option>
              <option value="Annually">Annually</option>
            </select>
          </div>
          <div className="fgrp">
            <label>Last PM Date</label>
            <input type="date" value={form.lastPmDate} onChange={e=>set('lastPmDate',e.target.value)}/>
          </div>
          <div className="fgrp">
            <label>Next PM Date</label>
            <input type="date" value={form.nextPmDate} onChange={e=>set('nextPmDate',e.target.value)}/>
          </div>
          <div className="fgrp">
            <label>Status</label>
            <select value={form.status} onChange={e=>set('status',e.target.value)}>
              <option value="Running">Running</option>
              <option value="Idle">Idle</option>
              <option value="Fault">Fault</option>
              <option value="Maintenance">Maintenance</option>
            </select>
          </div>
        </div>
        <div className="fgrp">
          <label>Notes / Remarks</label>
          <textarea rows={2} placeholder="Any additional notes about this machine..." value={form.notes} onChange={e=>set('notes',e.target.value)} style={{width:'100%',resize:'vertical'}}/>
        </div>
      </div>

      <div style={{padding:'16px 22px',display:'flex',justifyContent:'flex-end',gap:'8px'}}>
        <button className="btn bgh" onClick={onCancel}>Cancel</button>
        <button className="btn bpri" onClick={() => onSave({ ...form, id: machine?.id })}>💾 Save Machine</button>
      </div>
    </div>
  )
}

/* ── Locations Tab ────────────────────────────────────────────────── */
/* ── Locations Tab ────────────────────────────────────────────────── */
/*
  Backend table supports only:
  id, code, name, type, plant, createdBy, updatedBy, isActive, isDeleted, createdAt, updatedAt

  UI mapping:
  code     = Locator Code / Barcode base
  name     = Area / Location Name
  type     = Zone / Location Type
  plant    = Division / BU
  isActive = Active / Inactive
*/
