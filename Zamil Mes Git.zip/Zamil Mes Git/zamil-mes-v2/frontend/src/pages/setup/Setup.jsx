import { useState } from 'react'
import { useApp } from '../../contexts/AppContext'

import BoxQtyTab from './BoxQtyTab'
import MachinesTab from './MachinesTab'
import LocationsTab from './LocationsTab'
import ShiftsTab from './ShiftsTab'
import UsersTab from './UsersTab'

const TABS = [
  { id:'boxqty',    label:'📦 Box Quantity' },
  { id:'machines',  label:'⚙ Machines'     },
  { id:'locations', label:'📍 Locations'   },
  { id:'shifts',    label:'🕐 Shifts'      },
  { id:'users',     label:'👤 Users'       },
]

const TAB_STORAGE_KEY = 'setup-active-tab'

export default function Setup() {
  const { goScreen } = useApp()

  const [tab, setTab] = useState(() => {
    const savedTab = localStorage.getItem(TAB_STORAGE_KEY)

    if (TABS.some(t => t.id === savedTab)) {
      return savedTab
    }

    return 'boxqty'
  })

  const changeTab = (tabId) => {
    setTab(tabId)
    localStorage.setItem(TAB_STORAGE_KEY, tabId)
  }

  return (
    <div style={{background:'var(--bg)',minHeight:'calc(100vh - 96px)'}}>
      <div style={{background:'var(--pur2)',borderBottom:'1px solid var(--bor)',padding:'16px 28px',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
        <div>
          <div style={{fontSize:'16px',fontWeight:700,color:'var(--tx)'}}>⚙ Setup &amp; Configuration</div>
          <div style={{fontSize:'12px',color:'var(--tx3)',marginTop:'2px'}}>Manage box quantities, machines, shifts and reference data</div>
        </div>

        <div style={{display:'flex',gap:'8px'}}>
          <button className="btn bgh bsm" onClick={() => goScreen('operator')}>
            ← Back to Dashboard
          </button>
        </div>
      </div>

      <div style={{padding:'20px 28px'}}>
        <div style={{display:'flex',borderBottom:'2px solid var(--bor)',marginBottom:'20px',gap:0}}>
          {TABS.map(t => (
            <button
              key={t.id}
              className={`setup-stab ${tab === t.id ? 'on' : ''}`}
              onClick={() => changeTab(t.id)}
            >
              {t.label}
            </button>
          ))}
        </div>

        {tab === 'boxqty'    && <BoxQtyTab />}
        {tab === 'machines'  && <MachinesTab />}
        {tab === 'locations' && <LocationsTab />}
        {tab === 'shifts'    && <ShiftsTab />}
        {tab === 'users'     && <UsersTab />}
      </div>
    </div>
  )
}