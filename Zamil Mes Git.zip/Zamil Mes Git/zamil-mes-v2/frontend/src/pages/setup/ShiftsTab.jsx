export default function ShiftsTab() {
  return (
    <div style={{background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'14px',padding:'60px',textAlign:'center'}}>
      <div style={{fontSize:'36px',marginBottom:'10px'}}>🕐</div>
      <div style={{fontSize:'14px',fontWeight:600,color:'var(--tx)',marginBottom:'6px'}}>Shift configuration — coming soon</div>
      <div style={{fontSize:'12px',color:'var(--tx3)'}}>Shift schedules and rotation patterns will be managed here.</div>
    </div>
  )
}

/* ── UA constants ─────────────────────────────────────────────────── */
