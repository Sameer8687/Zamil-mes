import { useState, useEffect } from "react";
import { useList, useMutation } from "../../hooks/useApi";
import { setupService } from "../../services/api";
import { useApp } from "../../contexts/AppContext";

const LOC_TYPE_OPTIONS = [
  { value: "PRD", label: "PRD – Production", icon: "🏭", color: "var(--pur)" },
  { value: "SIL", label: "SIL – Silo", icon: "🛢", color: "var(--amb)" },
  { value: "STG", label: "STG – Staging", icon: "📦", color: "var(--tel)" },
  { value: "ASM", label: "ASM – Assembly", icon: "🔩", color: "var(--blu)" },
  { value: "QA", label: "QA – Quality", icon: "🔍", color: "var(--grn)" },
  { value: "RJT", label: "RJT – Rejected", icon: "✕", color: "var(--red)" },
  { value: "HLD", label: "HLD – Hold", icon: "⏸", color: "var(--tx3)" },
];

const LOC_TYPE_STYLE = {
  PRD: {
    background: "var(--pur2)",
    border: "1px solid var(--pur)",
    color: "var(--pur)",
  },
  SIL: {
    background: "var(--amb2)",
    border: "1px solid var(--amb)",
    color: "var(--amb)",
  },
  STG: {
    background: "var(--tel2)",
    border: "1px solid var(--tel)",
    color: "var(--tel)",
  },
  ASM: {
    background: "var(--blu2)",
    border: "1px solid var(--blu)",
    color: "var(--blu)",
  },
  QA: {
    background: "var(--grn2)",
    border: "1px solid var(--grn)",
    color: "var(--grn)",
  },
  RJT: {
    background: "var(--red2)",
    border: "1px solid var(--red)",
    color: "var(--red)",
  },
  HLD: {
    background: "var(--bg3)",
    border: "1px solid var(--bor2)",
    color: "var(--tx3)",
  },
};

const normalizeLocType = (value) => {
  const v = String(value || "")
    .trim()
    .toUpperCase();

  if (["PRODUCTION", "PROD"].includes(v)) return "PRD";
  if (["WAREHOUSE", "WH", "STAGING"].includes(v)) return "STG";
  if (["SILO"].includes(v)) return "SIL";
  if (["ASSEMBLY"].includes(v)) return "ASM";
  if (["QUALITY", "QC"].includes(v)) return "QA";
  if (["SCRAP", "REJECTED"].includes(v)) return "RJT";
  if (["HOLD"].includes(v)) return "HLD";

  return ["PRD", "SIL", "STG", "ASM", "QA", "RJT", "HLD"].includes(v)
    ? v
    : "PRD";
};

const getLocTypeLabel = (type) => {
  const normalized = normalizeLocType(type);
  return (
    LOC_TYPE_OPTIONS.find((x) => x.value === normalized)?.label || normalized
  );
};

const getLocTypeIcon = (type) => {
  const normalized = normalizeLocType(type);
  return LOC_TYPE_OPTIONS.find((x) => x.value === normalized)?.icon || "📍";
};

const getLocStatus = (loc) => {
  if (loc?.status) return loc.status;
  return loc?.isActive === false ? "Inactive" : "Active";
};

const getLocationBarcodeValue = (loc) => {
  const code = String(loc?.code || "").trim();
  return code ? `LOC-${code}` : "LOC-BARCODE";
};

const getLocationDerivedLevel = (loc) => {
  const code = String(loc?.code || "");
  const match = code.match(/L\d+/i);
  return match ? match[0].toUpperCase() : "L1";
};

const getLocationDerivedCapacity = (loc) => {
  const code = String(loc?.code || loc?.id || "");
  let n = 0;
  for (let i = 0; i < code.length; i++) n += code.charCodeAt(i);
  const maxLPN = 8 + (n % 18);
  const usedLPN = loc?.isActive === false ? 0 : Math.min(maxLPN, n % maxLPN);
  return { maxLPN, usedLPN };
};

const normalizeLocation = (loc = {}) => {
  const code = String(loc.code || "").trim();
  const name = String(loc.name || "").trim();
  const type = normalizeLocType(loc.type);
  const plant = String(loc.plant || "FPP")
    .trim()
    .toUpperCase();
  const { maxLPN, usedLPN } = getLocationDerivedCapacity({ ...loc, code });

  return {
    ...loc,
    id: loc.id,
    code,
    name,
    type,
    plant,
    barcode: getLocationBarcodeValue({ code }),
    level: getLocationDerivedLevel({ code }),
    maxLPN,
    usedLPN,
    status: getLocStatus(loc),
    isActive: loc.isActive !== false,
    createdAt: loc.createdAt,
    updatedAt: loc.updatedAt,
  };
};

const buildLocationPayload = (form) => ({
  id: form.id,

  code: String(form.code || form.locator || "").trim().toUpperCase(),
  locator: String(form.locator || form.code || "").trim().toUpperCase(),

  name: String(form.name || form.area || "").trim(),
  area: String(form.area || form.name || "").trim(),

  type: normalizeLocType(form.type || form.zone),
  zone: normalizeLocType(form.zone || form.type),

  plant: String(form.plant || form.division || "FPP").trim().toUpperCase(),
  division: String(form.division || form.plant || "FPP").trim().toUpperCase(),

  section: form.section || "",
  level: form.level || "L1",

  locType: form.locType || form.locationType || "FLOOR",
  status: form.status || "Active",
  isActive: form.status !== "Inactive",

  minUnits: Number(form.minUnits) || 0,
  maxUnits: Number(form.maxUnits) || 0,
  maxLPN: Number(form.maxLPN || form.maxLpn) || 9,
  usedLPN: Number(form.usedLPN) || 0,

  uom: form.uom || "BOX",
  multiSKU: form.multiSKU || form.allowMultiSku || "Yes",
  partialPick: form.partialPick || form.partialPickAllowed || "Yes",
  specificSKU: form.specificSKU || form.specificSkuRestriction || null,
  maxWeight: Number(form.maxWeight || form.maxWeightKg) || 2000,

  owner: form.owner || form.primaryOwner || "",
  authUsers: form.authUsers || form.authorizedUsers || [],
  accessRestriction: form.accessRestriction || "AuthList",
  notes: form.notes || null,
});

function drawSetupBarcodeBars(text, width = 340, height = 50) {
  const barW = 2.2;
  const gap = 1.1;
  let bars = [];
  const value = String(text || "LOC-BARCODE");

  for (let i = 0; i < value.length; i++) {
    const c = value.charCodeAt(i);
    bars.push((c % 3 === 0 ? 3 : c % 3 === 1 ? 2 : 1.5) * barW);
    bars.push(gap + (i % 4 === 0 ? gap : 0));
  }

  bars = [
    barW * 2,
    gap,
    barW * 2,
    gap * 2,
    ...bars,
    gap * 2,
    barW * 2,
    gap,
    barW * 2,
  ];

  const rects = [];
  let x = 10;

  bars.forEach((w, i) => {
    if (i % 2 === 0) {
      rects.push(
        <rect
          key={i}
          x={Number(x.toFixed(1))}
          y={4}
          width={Number(w.toFixed(1))}
          height={height - 8}
          fill="#000"
        />,
      );
    }
    x += w;
  });

  return {
    viewBox: `0 0 ${width} ${height}`,
    rects,
  };
}

export default function LocationsTab() {
  const { showToast } = useApp();
  const [innerTab, setInnerTab] = useState("list");
  const [editLoc, setEditLoc] = useState(null);
  const [barcodeLoc, setBarcodeLoc] = useState(null);
  const [barcodeBatch, setBarcodeBatch] = useState([]);
  const [filter, setFilter] = useState({
    plant: "",
    type: "",
    status: "",
    search: "",
  });
  const [showCount, setShowCount] = useState(50);
  const [page, setPage] = useState(1);

  const { items: apiLocs, refetch: refetchLocs } = useList(
    setupService.getLocations,
  );
  const [locations, setLocations] = useState([]);

  useEffect(() => {
    setLocations(Array.isArray(apiLocs) ? apiLocs.map(normalizeLocation) : []);
  }, [apiLocs]);

  const { mutate: createLocApi } = useMutation(setupService.createLocation, {
    onSuccess: () => {
      refetchLocs();
      showToast("Location added", "success");
      setInnerTab("list");
    },
    onError: (e) => showToast(e?.message || "Failed to add location", "error"),
  });

  const { mutate: updateLocApi } = useMutation(
    (data) => setupService.updateLocation(data.id, data),
    {
      onSuccess: () => {
        refetchLocs();
        showToast("Location updated", "success");
        setInnerTab("list");
      },
      onError: (e) =>
        showToast(e?.message || "Failed to update location", "error"),
    },
  );

  const { mutate: deleteLocApi } = useMutation(setupService.deleteLocation, {
    onSuccess: () => {
      refetchLocs();
      showToast("Location removed", "warning");
    },
    onError: (e) =>
      showToast(e?.message || "Failed to delete location", "error"),
  });

  const filtered = locations.filter((l) => {
    if (filter.plant && l.plant !== filter.plant) return false;
    if (filter.type && l.type !== filter.type) return false;
    if (filter.status && l.status !== filter.status) return false;

    const search = filter.search.toLowerCase().trim();
    if (search) {
      const hay = [l.code, l.name, l.type, l.plant, l.barcode, l.status]
        .join(" ")
        .toLowerCase();

      if (!hay.includes(search)) return false;
    }

    return true;
  });

  const totalLoc = locations.length;
  const activeLoc = locations.filter((l) => l.status === "Active").length;
  const inactiveLoc = locations.filter((l) => l.status === "Inactive").length;
  const production = locations.filter((l) => l.type === "PRD").length;
  const staging = locations.filter((l) =>
    ["SIL", "STG"].includes(l.type),
  ).length;
  const assembly = locations.filter((l) => l.type === "ASM").length;
  const totalLPN = locations.reduce((s, l) => s + Number(l.maxLPN || 0), 0);
  const usedLPN = locations.reduce((s, l) => s + Number(l.usedLPN || 0), 0);
  const utilPct = totalLPN > 0 ? Math.round((usedLPN / totalLPN) * 100) : 0;

  const totalPages = Math.max(1, Math.ceil(filtered.length / showCount));
  const safePage = Math.min(page, totalPages);
  const start = (safePage - 1) * showCount;
  const rows = filtered.slice(start, start + showCount);

  const openForm = (loc) => {
    setEditLoc(loc ? normalizeLocation(loc) : {});
    setInnerTab("addedit");
  };

  const saveLoc = (data) => {
  const payload = buildLocationPayload(data);

  if (!payload.code || !payload.name || !payload.type || !payload.plant) {
    showToast("Code, Name, Type and Plant are required", "error");
    return;
  }

  if (!payload.owner) {
    showToast("Primary Owner is required", "error");
    return;
  }

  if (data.id) {
    updateLocApi({ id: data.id, ...payload });
  } else {
    createLocApi(payload);
  }
};

  const clearFilter = () => {
    setFilter({ plant: "", type: "", status: "", search: "" });
    setPage(1);
  };

  const openBarcodeModal = (loc) => {
    setBarcodeBatch([]);
    setBarcodeLoc(normalizeLocation(loc));
  };

  const openBatchBarcodeModal = () => {
    if (!filtered.length) {
      showToast("No locations available for barcode printing", "warning");
      return;
    }

    setBarcodeLoc(null);
    setBarcodeBatch(filtered.map(normalizeLocation));
  };

  const closeBarcodeModal = () => {
    setBarcodeLoc(null);
    setBarcodeBatch([]);
  };

  const exportLocations = () => {
    const headers = [
      "ID",
      "Code",
      "Name",
      "Type",
      "Plant",
      "Status",
      "Barcode",
      "Created At",
      "Updated At",
    ];
    const body = filtered
      .map((l) =>
        [
          l.id,
          l.code,
          l.name,
          l.type,
          l.plant,
          l.status,
          l.barcode,
          l.createdAt || "",
          l.updatedAt || "",
        ].join("\t"),
      )
      .join("\n");

    const blob = new Blob([headers.join("\t") + "\n" + body], {
      type: "text/tab-separated-values",
    });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "Inventory_Locations.xls";
    a.click();

    showToast("Inventory_Locations.xls downloaded", "success");
  };

  return (
    <div>
      <div style={{ display: "flex", gap: "6px", marginBottom: "18px" }}>
        <button
          className={`bq-itab ${innerTab === "list" ? "on" : ""}`}
          onClick={() => setInnerTab("list")}
        >
          📍 Location List
        </button>
        <button
          className={`bq-itab ${innerTab === "card" ? "on" : ""}`}
          onClick={() => setInnerTab("card")}
        >
          🗃 Card View
        </button>
        <button
          className={`bq-itab ${innerTab === "zone" ? "on" : ""}`}
          onClick={() => setInnerTab("zone")}
        >
          🗺 Zone Map
        </button>
        <button
          className={`bq-itab ${innerTab === "addedit" ? "on" : ""}`}
          onClick={() => openForm(null)}
        >
          ➕ Add Location
        </button>
      </div>

      {innerTab !== "addedit" && (
        <>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(6,1fr)",
              gap: "10px",
              marginBottom: "14px",
            }}
          >
            {[
              ["Total Locations", totalLoc, "var(--blu)", "All saved records"],
              ["Active", activeLoc, "var(--grn)", `${inactiveLoc} inactive`],
              ["Production", production, "var(--pur)", "PRD zone"],
              ["Silo / Staging", staging, "var(--amb)", "SIL + STG"],
              ["Assembly", assembly, "var(--tel)", "ASM zone"],
              [
                "Utilization",
                `${utilPct}%`,
                "var(--red)",
                `${usedLPN}/${totalLPN} virtual LPN`,
              ],
            ].map(([l, v, c, s]) => (
              <div
                key={l}
                style={{
                  background: "var(--bg2)",
                  border: "1px solid var(--bor)",
                  borderRadius: "var(--r)",
                  padding: "12px 14px",
                  position: "relative",
                  overflow: "hidden",
                }}
              >
                <div
                  style={{
                    fontSize: "10px",
                    textTransform: "uppercase",
                    letterSpacing: "1px",
                    color: "var(--tx3)",
                    fontWeight: 600,
                    marginBottom: "5px",
                  }}
                >
                  {l}
                </div>
                <div
                  style={{
                    fontFamily: "'Space Mono',monospace",
                    fontSize: "20px",
                    fontWeight: 700,
                    color: c,
                  }}
                >
                  {v}
                </div>
                <div
                  style={{
                    fontSize: "10px",
                    color: "var(--tx3)",
                    marginTop: "4px",
                  }}
                >
                  {s}
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {innerTab === "list" && (
        <>
          <div
            style={{
              background: "var(--bg2)",
              border: "1px solid var(--bor)",
              borderRadius: "14px",
              padding: "13px 18px",
              marginBottom: "14px",
              display: "flex",
              alignItems: "flex-end",
              gap: "10px",
              flexWrap: "wrap",
            }}
          >
            <div
              className="fgrp"
              style={{ minWidth: "120px", marginBottom: 0 }}
            >
              <label>Division / BU</label>
              <select
                style={{ fontSize: "12px", padding: "6px 9px" }}
                value={filter.plant}
                onChange={(e) => {
                  setFilter((f) => ({ ...f, plant: e.target.value }));
                  setPage(1);
                }}
              >
                <option value="">All</option>
                <option value="FPP">FPP</option>
                <option value="IPP">IPP</option>
                <option value="ZPC">ZPC</option>
              </select>
            </div>

            <div
              className="fgrp"
              style={{ minWidth: "150px", marginBottom: 0 }}
            >
              <label>Zone / Type</label>
              <select
                style={{ fontSize: "12px", padding: "6px 9px" }}
                value={filter.type}
                onChange={(e) => {
                  setFilter((f) => ({ ...f, type: e.target.value }));
                  setPage(1);
                }}
              >
                <option value="">All Zones</option>
                {LOC_TYPE_OPTIONS.map((t) => (
                  <option key={t.value} value={t.value}>
                    {t.label}
                  </option>
                ))}
              </select>
            </div>

            <div
              className="fgrp"
              style={{ minWidth: "120px", marginBottom: 0 }}
            >
              <label>Status</label>
              <select
                style={{ fontSize: "12px", padding: "6px 9px" }}
                value={filter.status}
                onChange={(e) => {
                  setFilter((f) => ({ ...f, status: e.target.value }));
                  setPage(1);
                }}
              >
                <option value="">All</option>
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </select>
            </div>

            <div
              className="fgrp"
              style={{ flex: 1, minWidth: "190px", marginBottom: 0 }}
            >
              <label>Search</label>
              <input
                type="text"
                placeholder="Code, name, barcode, plant..."
                style={{ fontSize: "12px", padding: "6px 9px" }}
                value={filter.search}
                onChange={(e) => {
                  setFilter((f) => ({ ...f, search: e.target.value }));
                  setPage(1);
                }}
              />
            </div>

            <div
              style={{
                display: "flex",
                gap: "6px",
                alignItems: "flex-end",
                flexWrap: "wrap",
              }}
            >
              <button className="btn bpri bsm" onClick={() => openForm(null)}>
                + Add Location
              </button>
              <button className="btn bgh bsm" onClick={exportLocations}>
                📥 Export
              </button>
              <button className="btn bgh bsm" onClick={openBatchBarcodeModal}>
                🖨 Print Barcodes
              </button>
              <button className="btn bgh bsm" onClick={clearFilter}>
                Clear
              </button>
            </div>
          </div>

          <div
            style={{
              background: "var(--bg2)",
              border: "1px solid var(--bor)",
              borderRadius: "14px",
              overflow: "hidden",
              overflowX: "auto",
            }}
          >
            <div
              style={{
                padding: "11px 16px",
                borderBottom: "1px solid var(--bor)",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              <div
                style={{
                  fontSize: "13px",
                  fontWeight: 600,
                  color: "var(--tx)",
                  display: "flex",
                  alignItems: "center",
                  gap: "7px",
                }}
              >
                <span
                  style={{
                    width: "7px",
                    height: "7px",
                    borderRadius: "50%",
                    background: "var(--grn)",
                    display: "inline-block",
                  }}
                />
                Location Registry
              </div>

              <div
                style={{ display: "flex", alignItems: "center", gap: "8px" }}
              >
                <span style={{ fontSize: "11px", color: "var(--tx3)" }}>
                  {filtered.length} location{filtered.length !== 1 ? "s" : ""}
                </span>
                <select
                  value={showCount}
                  onChange={(e) => {
                    setShowCount(Number(e.target.value));
                    setPage(1);
                  }}
                  style={{
                    fontSize: "11px",
                    padding: "3px 6px",
                    border: "1px solid var(--bor)",
                    borderRadius: "7px",
                    background: "var(--bg3)",
                    width: "70px",
                  }}
                >
                  <option value={25}>25</option>
                  <option value={50}>50</option>
                  <option value={100}>100</option>
                </select>
              </div>
            </div>

            <table
              style={{
                width: "100%",
                borderCollapse: "collapse",
                fontSize: "12px",
                minWidth: "1080px",
              }}
            >
              <thead>
                <tr style={{ background: "var(--bg3)" }}>
                  {[
                    "#",
                    "Locator Code",
                    "Barcode",
                    "Division",
                    "Zone / Type",
                    "Area / Name",
                    "Level",
                    "Capacity",
                    "Status",
                    "Created",
                    "Updated",
                    "Action",
                  ].map((h, i) => (
                    <th
                      key={h}
                      style={{
                        padding: "8px 12px",
                        textAlign: i === 11 ? "center" : "left",
                        fontSize: "10px",
                        textTransform: "uppercase",
                        letterSpacing: "1px",
                        color: "var(--tx3)",
                        borderBottom: "1px solid var(--bor)",
                        width: i === 0 ? "36px" : i === 11 ? "150px" : "auto",
                      }}
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>

              <tbody>
                {rows.length === 0 ? (
                  <tr>
                    <td
                      colSpan={12}
                      style={{
                        textAlign: "center",
                        padding: "28px",
                        color: "var(--tx3)",
                      }}
                    >
                      No locations match your filters.
                    </td>
                  </tr>
                ) : (
                  rows.map((l, i) => {
                    const pct =
                      l.maxLPN > 0
                        ? Math.round((l.usedLPN / l.maxLPN) * 100)
                        : 0;
                    const barColor =
                      pct >= 90
                        ? "var(--red)"
                        : pct >= 60
                          ? "var(--amb)"
                          : "var(--grn)";
                    const typeStyle =
                      LOC_TYPE_STYLE[l.type] || LOC_TYPE_STYLE.PRD;

                    return (
                      <tr key={l.id || l.code}>
                        <td
                          style={{
                            padding: "8px 12px",
                            fontFamily: "'Space Mono',monospace",
                            fontSize: "10px",
                            color: "var(--tx3)",
                          }}
                        >
                          {start + i + 1}
                        </td>

                        <td style={{ padding: "8px 12px" }}>
                          <div
                            style={{
                              fontFamily: "'Space Mono',monospace",
                              fontSize: "11px",
                              color: "var(--pur)",
                              fontWeight: 700,
                            }}
                          >
                            {l.code}
                          </div>
                          <div
                            style={{
                              fontSize: "9px",
                              color: "var(--tx3)",
                              marginTop: "1px",
                            }}
                          >
                            ID: {l.id}
                          </div>
                        </td>

                        <td
                          style={{
                            padding: "8px 12px",
                            fontFamily: "'Space Mono',monospace",
                            fontSize: "10px",
                            color: "var(--tel)",
                          }}
                        >
                          {l.barcode}
                        </td>

                        <td
                          style={{
                            padding: "8px 12px",
                            fontFamily: "'Space Mono',monospace",
                            fontSize: "10px",
                            fontWeight: 700,
                            color: "var(--tx2)",
                          }}
                        >
                          {l.plant}
                        </td>

                        <td style={{ padding: "8px 12px" }}>
                          <span
                            style={{
                              display: "inline-flex",
                              alignItems: "center",
                              gap: "4px",
                              padding: "2px 8px",
                              borderRadius: "20px",
                              fontSize: "9px",
                              fontWeight: 700,
                              ...typeStyle,
                            }}
                          >
                            {getLocTypeIcon(l.type)} {l.type}
                          </span>
                        </td>

                        <td style={{ padding: "8px 12px" }}>
                          <div
                            style={{
                              fontSize: "11px",
                              fontWeight: 600,
                              color: "var(--tx)",
                            }}
                          >
                            {l.name}
                          </div>
                          <div
                            style={{
                              fontSize: "9px",
                              color: "var(--tx3)",
                              marginTop: "1px",
                            }}
                          >
                            {getLocTypeLabel(l.type)}
                          </div>
                        </td>

                        <td
                          style={{
                            padding: "8px 12px",
                            fontFamily: "'Space Mono',monospace",
                            fontSize: "10px",
                          }}
                        >
                          {l.level}
                        </td>

                        <td style={{ padding: "8px 12px", minWidth: "120px" }}>
                          <div
                            style={{
                              fontSize: "10px",
                              color: "var(--tx3)",
                              marginBottom: "3px",
                            }}
                          >
                            {l.usedLPN}/{l.maxLPN} LPN
                          </div>
                          <div
                            style={{
                              height: "5px",
                              background: "var(--bg3)",
                              borderRadius: "5px",
                              overflow: "hidden",
                            }}
                          >
                            <div
                              style={{
                                height: "100%",
                                width: `${Math.min(100, pct)}%`,
                                background: barColor,
                                borderRadius: "5px",
                              }}
                            />
                          </div>
                        </td>

                        <td style={{ padding: "8px 12px" }}>
                          <span
                            className={`bdg ${l.status === "Active" ? "bd" : "bpa"}`}
                          >
                            {l.status}
                          </span>
                        </td>

                        <td
                          style={{
                            padding: "8px 12px",
                            fontSize: "10px",
                            color: "var(--tx3)",
                          }}
                        >
                          {l.createdAt
                            ? new Date(l.createdAt).toLocaleDateString()
                            : "—"}
                        </td>

                        <td
                          style={{
                            padding: "8px 12px",
                            fontSize: "10px",
                            color: "var(--tx3)",
                          }}
                        >
                          {l.updatedAt
                            ? new Date(l.updatedAt).toLocaleDateString()
                            : "—"}
                        </td>

                        <td
                          style={{ padding: "8px 12px", textAlign: "center" }}
                        >
                          <div
                            style={{
                              display: "flex",
                              gap: "4px",
                              justifyContent: "center",
                            }}
                          >
                            <button
                              className="btn bgh bsm"
                              onClick={() => openForm(l)}
                            >
                              Edit
                            </button>
                            <button
                              className="btn bgh bsm"
                              onClick={() => openBarcodeModal(l)}
                            >
                              🏷
                            </button>
                            <button
                              className="btn bdan bsm"
                              onClick={() => {
                                if (window.confirm(`Delete ${l.code}?`))
                                  deleteLocApi(l.id);
                              }}
                            >
                              🗑
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>

            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                padding: "10px 14px",
                fontSize: "11px",
                color: "var(--tx3)",
                borderTop: "1px solid var(--bor)",
              }}
            >
              <span>
                {filtered.length
                  ? `Showing ${start + 1}–${Math.min(start + showCount, filtered.length)} of ${filtered.length}`
                  : "No records"}
              </span>
              <div style={{ display: "flex", gap: "6px" }}>
                <button
                  className="btn bgh bsm"
                  disabled={safePage <= 1}
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                >
                  ← Prev
                </button>
                <button
                  className="btn bgh bsm"
                  disabled={safePage >= totalPages}
                  onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                >
                  Next →
                </button>
              </div>
            </div>
          </div>
        </>
      )}

      {innerTab === "card" && (
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill,minmax(255px,1fr))",
            gap: "12px",
          }}
        >
          {filtered.length === 0 ? (
            <div
              style={{
                gridColumn: "1/-1",
                background: "var(--bg2)",
                border: "1px solid var(--bor)",
                borderRadius: "14px",
                padding: "36px",
                textAlign: "center",
                color: "var(--tx3)",
              }}
            >
              No locations found.
            </div>
          ) : (
            filtered.map((l) => {
              const pct =
                l.maxLPN > 0 ? Math.round((l.usedLPN / l.maxLPN) * 100) : 0;
              const typeStyle = LOC_TYPE_STYLE[l.type] || LOC_TYPE_STYLE.PRD;

              return (
                <div
                  key={l.id || l.code}
                  style={{
                    background: "var(--bg2)",
                    border: "1px solid var(--bor)",
                    borderRadius: "12px",
                    padding: "14px",
                    position: "relative",
                    overflow: "hidden",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      marginBottom: "8px",
                    }}
                  >
                    <span
                      style={{
                        fontFamily: "'Space Mono',monospace",
                        fontSize: "11px",
                        fontWeight: 700,
                        color: "var(--pur)",
                      }}
                    >
                      {l.code}
                    </span>
                    <span
                      style={{
                        display: "inline-flex",
                        alignItems: "center",
                        gap: "4px",
                        padding: "2px 8px",
                        borderRadius: "20px",
                        fontSize: "9px",
                        fontWeight: 700,
                        ...typeStyle,
                      }}
                    >
                      {getLocTypeIcon(l.type)} {l.type}
                    </span>
                  </div>

                  <div
                    style={{
                      fontSize: "13px",
                      fontWeight: 600,
                      color: "var(--tx)",
                      marginBottom: "2px",
                    }}
                  >
                    {l.name}
                  </div>
                  <div
                    style={{
                      fontSize: "11px",
                      color: "var(--tx3)",
                      marginBottom: "10px",
                    }}
                  >
                    {l.plant} · {l.level} · {l.barcode}
                  </div>

                  <div
                    style={{
                      display: "grid",
                      gridTemplateColumns: "1fr 1fr",
                      gap: "8px",
                      marginBottom: "10px",
                    }}
                  >
                    <div
                      style={{
                        background: "var(--bg3)",
                        border: "1px solid var(--bor)",
                        borderRadius: "8px",
                        padding: "8px",
                      }}
                    >
                      <div
                        style={{
                          fontSize: "9px",
                          color: "var(--tx3)",
                          textTransform: "uppercase",
                          letterSpacing: ".7px",
                        }}
                      >
                        Virtual LPN
                      </div>
                      <div
                        style={{
                          fontFamily: "'Space Mono',monospace",
                          fontSize: "14px",
                          fontWeight: 700,
                          color: "var(--tx)",
                          marginTop: "2px",
                        }}
                      >
                        {l.usedLPN}/{l.maxLPN}
                      </div>
                    </div>
                    <div
                      style={{
                        background: "var(--bg3)",
                        border: "1px solid var(--bor)",
                        borderRadius: "8px",
                        padding: "8px",
                      }}
                    >
                      <div
                        style={{
                          fontSize: "9px",
                          color: "var(--tx3)",
                          textTransform: "uppercase",
                          letterSpacing: ".7px",
                        }}
                      >
                        Status
                      </div>
                      <div
                        style={{
                          fontSize: "11px",
                          fontWeight: 700,
                          color:
                            l.status === "Active" ? "var(--grn)" : "var(--amb)",
                          marginTop: "3px",
                        }}
                      >
                        {l.status}
                      </div>
                    </div>
                  </div>

                  <div
                    style={{
                      height: "6px",
                      background: "var(--bg3)",
                      borderRadius: "6px",
                      overflow: "hidden",
                      marginBottom: "12px",
                    }}
                  >
                    <div
                      style={{
                        height: "100%",
                        width: `${Math.min(100, pct)}%`,
                        background:
                          pct >= 90
                            ? "var(--red)"
                            : pct >= 60
                              ? "var(--amb)"
                              : "var(--grn)",
                      }}
                    />
                  </div>

                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      gap: "6px",
                    }}
                  >
                    <button
                      className="btn bgh bsm"
                      onClick={() => openBarcodeModal(l)}
                    >
                      🏷 Barcode
                    </button>
                    <button className="btn bgh bsm" onClick={() => openForm(l)}>
                      Edit
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {innerTab === "zone" && (
        <div
          style={{
            background: "var(--bg2)",
            border: "1px solid var(--bor)",
            borderRadius: "14px",
            padding: "18px",
          }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              marginBottom: "16px",
            }}
          >
            <div
              style={{
                fontSize: "13px",
                fontWeight: 600,
                color: "var(--tx)",
                display: "flex",
                alignItems: "center",
                gap: "7px",
              }}
            >
              <span
                style={{
                  width: "7px",
                  height: "7px",
                  borderRadius: "50%",
                  background: "var(--pur)",
                  display: "inline-block",
                }}
              />
              Zone Map
            </div>
            <button className="btn bgh bsm" onClick={openBatchBarcodeModal}>
              🖨 Print Zone Barcodes
            </button>
          </div>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(4,1fr)",
              gap: "12px",
            }}
          >
            {LOC_TYPE_OPTIONS.map((zone) => {
              const list = filtered.filter((l) => l.type === zone.value);
              const typeStyle =
                LOC_TYPE_STYLE[zone.value] || LOC_TYPE_STYLE.PRD;

              return (
                <div
                  key={zone.value}
                  style={{
                    background: "var(--bg3)",
                    border: "1px solid var(--bor)",
                    borderRadius: "12px",
                    padding: "12px",
                    minHeight: "150px",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      marginBottom: "10px",
                    }}
                  >
                    <span
                      style={{
                        display: "inline-flex",
                        alignItems: "center",
                        gap: "5px",
                        padding: "3px 9px",
                        borderRadius: "20px",
                        fontSize: "10px",
                        fontWeight: 700,
                        ...typeStyle,
                      }}
                    >
                      {zone.icon} {zone.value}
                    </span>
                    <span style={{ fontSize: "11px", color: "var(--tx3)" }}>
                      {list.length}
                    </span>
                  </div>

                  <div
                    style={{
                      fontSize: "11px",
                      fontWeight: 600,
                      color: "var(--tx)",
                      marginBottom: "8px",
                    }}
                  >
                    {zone.label}
                  </div>

                  <div
                    style={{ display: "flex", flexWrap: "wrap", gap: "5px" }}
                  >
                    {list.length === 0 ? (
                      <div
                        style={{
                          fontSize: "11px",
                          color: "var(--tx3)",
                          padding: "10px 0",
                        }}
                      >
                        No locations
                      </div>
                    ) : (
                      list.slice(0, 30).map((l) => (
                        <button
                          key={l.id || l.code}
                          onClick={() => openForm(l)}
                          title={`${l.code} · ${l.name}`}
                          style={{
                            fontFamily: "'Space Mono',monospace",
                            fontSize: "9px",
                            border: "1px solid var(--bor2)",
                            background:
                              l.status === "Active"
                                ? "var(--bg2)"
                                : "var(--amb2)",
                            color:
                              l.status === "Active"
                                ? "var(--tx2)"
                                : "var(--amb)",
                            borderRadius: "6px",
                            padding: "4px 7px",
                            cursor: "pointer",
                          }}
                        >
                          {l.code}
                        </button>
                      ))
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {innerTab === "addedit" && (
        <LocationForm
          location={editLoc}
          onSave={saveLoc}
          onCancel={() => setInnerTab("list")}
        />
      )}

      {(barcodeLoc || barcodeBatch.length > 0) && (
        <LocationBarcodeModal
          location={barcodeLoc}
          locations={barcodeBatch}
          onClose={closeBarcodeModal}
        />
      )}
    </div>
  );
}

function LocationForm({ location, onSave, onCancel }) {
  const loc = normalizeLocation(location || {});

  const [form, setForm] = useState({
    id: loc.id || "",
    division: loc.plant || "",
    zone: loc.type || "",
    area: loc.name || "",
    section: "",
    level: loc.level || "L1",
    locationType: "Machine Side",
    status: loc.id ? loc.status || "Active" : "Active",

    minUnits: "0",
    maxUnits: "5000",
    maxLpn: "9",
    uom: "Box",
    allowMultiSku: "Yes",
    partialPickAllowed: "Yes",
    specificSkuRestriction: "",
    maxWeightKg: "2000",

    primaryOwner: loc.owner || "",
    accessRestriction: "All – Any authenticated user",
    notes: "",
    authorizedUsers: "",
  });

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const areaCode = String(form.area || "")
    .replace(/[^a-z0-9]/gi, "")
    .toUpperCase();

  const sectionCode = String(form.section || "")
    .replace(/[^a-z0-9]/gi, "")
    .toUpperCase();

  const locatorCode =
    form.zone && areaCode && form.level
      ? `${form.zone}${areaCode}${sectionCode}${form.level}`
      : "";

  const barcodeValue = locatorCode ? `LOC-${locatorCode}` : "";
  const barcode = drawSetupBarcodeBars(barcodeValue || "LOC-BARCODE", 430, 56);

  const submit = () => {
    if (!form.division || !form.zone || !form.area || !form.level) {
      alert("Division, Zone / Plant, Area and Level are required.");
      return;
    }

    onSave({
  id: form.id,
  code: locatorCode,
  locator: locatorCode,

  name: form.area,
  area: form.area,
  type: form.zone,
  zone: form.zone,
  plant: form.division,
  division: form.division,

  section: form.section,
  level: form.level,
  locType: form.locationType,
  status: form.status === "Blocked" ? "Inactive" : form.status,

  minUnits: form.minUnits,
  maxUnits: form.maxUnits,
  maxLpn: form.maxLpn,
  uom: form.uom,
  allowMultiSku: form.allowMultiSku,
  partialPickAllowed: form.partialPickAllowed,
  specificSkuRestriction: form.specificSkuRestriction,
  maxWeightKg: form.maxWeightKg,

  primaryOwner: form.primaryOwner,
  accessRestriction: form.accessRestriction,
  notes: form.notes,
  authorizedUsers: form.authorizedUsers,
});
  };

  const clearForm = () => {
    setForm((f) => ({
      ...f,
      division: "",
      zone: "",
      area: "",
      section: "",
      level: "L1",
      locationType: "Machine Side",
      status: "Active",
      minUnits: "0",
      maxUnits: "5000",
      maxLpn: "9",
      uom: "Box",
      allowMultiSku: "Yes",
      partialPickAllowed: "Yes",
      specificSkuRestriction: "",
      maxWeightKg: "2000",
      primaryOwner: "",
      accessRestriction: "All – Any authenticated user",
      notes: "",
      authorizedUsers: "",
    }));
  };

  const labelStyle = {
    display: "block",
    fontSize: "9px",
    fontWeight: 800,
    letterSpacing: "1px",
    textTransform: "uppercase",
    color: "var(--tx3)",
    marginBottom: "5px",
  };

  const controlStyle = {
    width: "100%",
    height: "30px",
    border: "1px solid var(--bor2)",
    borderRadius: "8px",
    background: "var(--bg3)",
    color: "var(--tx)",
    fontSize: "11px",
    padding: "5px 10px",
    outline: "none",
    boxSizing: "border-box",
  };

  const textAreaStyle = {
    ...controlStyle,
    height: "36px",
    minHeight: "36px",
    resize: "none",
  };

  const sectionTitle = (icon, title, color = "var(--grn)") => (
    <div
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: "5px",
        height: "20px",
        padding: "0 10px",
        border: `1px solid ${color}`,
        borderRadius: "5px",
        background: "var(--bg3)",
        color,
        fontSize: "9px",
        fontWeight: 800,
        letterSpacing: ".8px",
        textTransform: "uppercase",
        marginBottom: "10px",
      }}
    >
      <span>{icon}</span>
      {title}
    </div>
  );

  const required = <span style={{ color: "var(--red)" }}>*</span>;

  // ADD LOCATION SCREEEN
  return (
    <div
      style={{
        background: "var(--bg2)",
        border: "1px solid var(--bor)",
        borderRadius: "10px",
        overflow: "hidden",
      }}
    >
      <div
        style={{
          height: "32px",
          padding: "0 14px",
          borderBottom: "1px solid var(--bor)",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <div
          style={{
            fontSize: "11px",
            fontWeight: 800,
            color: "var(--tx)",
            display: "flex",
            alignItems: "center",
            gap: "7px",
          }}
        >
          <span
            style={{
              width: "6px",
              height: "6px",
              borderRadius: "50%",
              background: "var(--grn)",
              display: "inline-block",
            }}
          />
          {form.id ? "Edit Location" : "Add Location"}
        </div>
      </div>

      <div style={{ padding: "10px 14px" }}>
        {/* LOCATION IDENTIFICATION */}
        <div
          style={{
            paddingBottom: "10px",
            borderBottom: "1px solid var(--bor)",
            marginBottom: "10px",
          }}
        >
          {sectionTitle("📍", "Location Identification", "var(--grn)")}

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(4, minmax(0, 1fr))",
              gap: "16px 10px",
            }}
          >
            <div>
              <label style={labelStyle}>Division {required}</label>
              <select
                value={form.division}
                onChange={(e) => set("division", e.target.value)}
                style={controlStyle}
              >
                <option value="">Select</option>
                <option value="FPP">FPP</option>
                <option value="IPP">IPP</option>
                <option value="ZPC">ZPC</option>
              </select>
            </div>

            <div>
              <label style={labelStyle}>Zone / Plant {required}</label>
              <select
                value={form.zone}
                onChange={(e) => set("zone", e.target.value)}
                style={controlStyle}
              >
                <option value="">Select</option>
                <option value="PRD">PRD – Production Floor</option>
                <option value="SIL">SIL – Silo Area</option>
                <option value="STG">STG – Staging Area</option>
                <option value="ASM">ASM – Assembly Area</option>
                <option value="QA">QA – Quality Area</option>
                <option value="RJT">RJT – Rejected Area</option>
                <option value="HLD">HLD – Hold Area</option>
              </select>
            </div>

            <div>
              <label style={labelStyle}>Area {required}</label>
              <input
                value={form.area}
                onChange={(e) => set("area", e.target.value.toUpperCase())}
                placeholder="e.g. ZFP001"
                style={controlStyle}
              />
            </div>

            <div>
              <label style={labelStyle}>Section</label>
              <input
                value={form.section}
                onChange={(e) => set("section", e.target.value.toUpperCase())}
                placeholder="e.g. A, ROW1"
                style={controlStyle}
              />
            </div>

            <div>
              <label style={labelStyle}>Level {required}</label>
              <select
                value={form.level}
                onChange={(e) => set("level", e.target.value)}
                style={controlStyle}
              >
                <option value="L1">L1 – Ground</option>
                <option value="L2">L2 – First Level</option>
                <option value="L3">L3 – Second Level</option>
                <option value="L4">L4 – Third Level</option>
              </select>
            </div>

            <div>
              <label style={labelStyle}>Locator Code</label>
              <input
                value={locatorCode}
                readOnly
                style={{
                  ...controlStyle,
                  color: "var(--grn)",
                  fontFamily: "'Space Mono', monospace",
                  fontWeight: 900,
                }}
              />
            </div>

            <div>
              <label style={labelStyle}>Location Type</label>
              <select
                value={form.locationType}
                onChange={(e) => set("locationType", e.target.value)}
                style={controlStyle}
              >
                <option value="Machine Side">Machine Side</option>
                <option value="Raw Material">Raw Material</option>
                <option value="Finished Goods">Finished Goods</option>
                <option value="Staging">Staging</option>
                <option value="Quality Hold">Quality Hold</option>
                <option value="Blocked Area">Blocked Area</option>
                <option value="General Storage">General Storage</option>
              </select>
            </div>

            <div>
              <label style={labelStyle}>Status</label>
              <select
                value={form.status}
                onChange={(e) => set("status", e.target.value)}
                style={controlStyle}
              >
                <option value="Active">Active</option>
                <option value="Blocked">Blocked</option>
                <option value="Inactive">Inactive</option>
              </select>
            </div>
          </div>

          <div
            style={{
              height: "76px",
              border: "1px dashed var(--bor2)",
              borderRadius: "8px",
              background: "var(--bg3)",
              marginTop: "20px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexDirection: "column",
              overflow: "hidden",
            }}
          >
            <div
              style={{
                fontSize: "8px",
                letterSpacing: ".8px",
                color: "var(--tx3)",
                textTransform: "uppercase",
                marginBottom: "3px",
              }}
            >
              Generated Barcode (Code 128)
            </div>

            {barcodeValue ? (
              <>
                <div
                  style={{
                    background: "#fff",
                    width: "370px",
                    height: "45px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    overflow: "hidden",
                  }}
                >
                  <svg
                    viewBox={barcode.viewBox}
                    style={{
                      width: "360px",
                      height: "42px",
                      display: "block",
                    }}
                  >
                    {barcode.rects}
                  </svg>
                </div>

                <div
                  style={{
                    fontSize: "8px",
                    fontFamily: "'Space Mono', monospace",
                    color: "#000",
                    marginTop: "-7px",
                  }}
                >
                  {barcodeValue}
                </div>

                <div
                  style={{
                    fontSize: "11px",
                    fontFamily: "'Space Mono', monospace",
                    fontWeight: 900,
                    color: "var(--tx)",
                    letterSpacing: "2px",
                    marginTop: "4px",
                  }}
                >
                  {barcodeValue}
                </div>
              </>
            ) : (
              <div
                style={{
                  fontSize: "14px",
                  fontFamily: "'Space Mono', monospace",
                  fontWeight: 900,
                  color: "var(--tx)",
                  marginTop: "18px",
                }}
              >
                -
              </div>
            )}
          </div>
        </div>

        {/* CAPACITY & STORAGE RULES */}
        <div
          style={{
            paddingBottom: "10px",
            borderBottom: "1px solid var(--bor)",
            marginBottom: "10px",
          }}
        >
          {sectionTitle("📦", "Capacity & Storage Rules", "var(--grn)")}

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(5, minmax(0, 1fr))",
              gap: "16px 10px",
            }}
          >
            <div>
              <label style={labelStyle}>Min Units</label>
              <input
                type="number"
                value={form.minUnits}
                onChange={(e) => set("minUnits", e.target.value)}
                style={controlStyle}
              />
            </div>

            <div>
              <label style={labelStyle}>Max Units</label>
              <input
                type="number"
                value={form.maxUnits}
                onChange={(e) => set("maxUnits", e.target.value)}
                style={controlStyle}
              />
            </div>

            <div>
              <label style={labelStyle}>Max LPN {required}</label>
              <input
                type="number"
                value={form.maxLpn}
                onChange={(e) => set("maxLpn", e.target.value)}
                style={controlStyle}
              />
            </div>

            <div>
              <label style={labelStyle}>UOM</label>
              <select
                value={form.uom}
                onChange={(e) => set("uom", e.target.value)}
                style={controlStyle}
              >
                <option value="Box">Box</option>
                <option value="Pallet">Pallet</option>
                <option value="LPN">LPN</option>
                <option value="KG">KG</option>
                <option value="EA">EA</option>
              </select>
            </div>

            <div>
              <label style={labelStyle}>Allow Multi-SKU</label>
              <select
                value={form.allowMultiSku}
                onChange={(e) => set("allowMultiSku", e.target.value)}
                style={controlStyle}
              >
                <option value="Yes">Yes</option>
                <option value="No">No</option>
              </select>
            </div>

            <div style={{ gridColumn: "span 2" }}>
              <label style={labelStyle}>Partial Pick Allowed</label>
              <select
                value={form.partialPickAllowed}
                onChange={(e) => set("partialPickAllowed", e.target.value)}
                style={controlStyle}
              >
                <option value="Yes">Yes</option>
                <option value="No">No</option>
              </select>
            </div>

            <div style={{ gridColumn: "span 2" }}>
              <label style={labelStyle}>Specific SKU Restriction</label>
              <input
                value={form.specificSkuRestriction}
                onChange={(e) => set("specificSkuRestriction", e.target.value)}
                placeholder="Leave blank = no restriction"
                style={controlStyle}
              />
            </div>

            <div>
              <label style={labelStyle}>Max Weight (KG)</label>
              <input
                type="number"
                value={form.maxWeightKg}
                onChange={(e) => set("maxWeightKg", e.target.value)}
                style={controlStyle}
              />
            </div>
          </div>
        </div>

        {/* OWNERSHIP & AUTHORIZATION */}
        <div style={{ marginBottom: "10px" }}>
          {sectionTitle("👤", "Ownership & Authorization", "var(--amb)")}

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1fr 1fr 1fr",
              gap: "16px 10px",
            }}
          >
            <div>
              <label style={labelStyle}>Primary Owner {required}</label>
              <select
                value={form.primaryOwner}
                onChange={(e) => set("primaryOwner", e.target.value)}
                style={controlStyle}
              >
                <option value="">Select Owner</option>
                <option value="warehouse_supervisor">Warehouse Supervisor</option>
                <option value="production_supervisor">Production Supervisor</option>
                <option value="qc_supervisor">QC Supervisor</option>
                <option value="admin">Admin</option>
              </select>
            </div>

            <div>
              <label style={labelStyle}>Access Restriction</label>
              <select
                value={form.accessRestriction}
                onChange={(e) => set("accessRestriction", e.target.value)}
                style={controlStyle}
              >
                <option value="All – Any authenticated user">
                  All – Any authenticated user
                </option>
                <option value="Owner only">Owner only</option>
                <option value="Owner + Authorized users">
                  Owner + Authorized users
                </option>
                <option value="Admin only">Admin only</option>
              </select>
            </div>

            <div>
              <label style={labelStyle}>Notes</label>
              <input
                value={form.notes}
                onChange={(e) => set("notes", e.target.value)}
                placeholder="e.g. Cold storage, fragile only..."
                style={controlStyle}
              />
            </div>

            <div style={{ gridColumn: "1 / -1" }}>
              <label style={labelStyle}>Authorized Users</label>
              <textarea
                value={form.authorizedUsers}
                onChange={(e) => set("authorizedUsers", e.target.value)}
                style={textAreaStyle}
              />
            </div>
          </div>
        </div>
      </div>

      <div
        style={{
          height: "43px",
          padding: "0 14px",
          background: "var(--bg3)",
          borderTop: "1px solid var(--bor)",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <span style={{ fontSize: "10px", color: "var(--tx3)" }}>
          Fields marked <span style={{ color: "var(--red)" }}>*</span> are
          required
        </span>

        <div style={{ display: "flex", gap: "8px" }}>
          <button className="btn bgh bsm" onClick={clearForm} type="button">
            Clear
          </button>
          <button className="btn bgh bsm" onClick={onCancel} type="button">
            ← Back to List
          </button>
          <button className="btn bpri bsm" onClick={submit} type="button">
            💾 Save Location
          </button>
        </div>
      </div>
    </div>
  );
}

function LocationBarcodeModal({ location, locations = [], onClose }) {
  const [copies, setCopies] = useState(1);
  const isBatch = locations.length > 0;
  const rows = isBatch ? locations : location ? [location] : [];

  return (
    <div
      className="modal-bg on"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
      style={{ zIndex: 900, backdropFilter: "blur(4px)" }}
    >
      <div
        className="modal"
        onMouseDown={(event) => event.stopPropagation()}
        style={{
          width: isBatch ? "760px" : "460px",
          maxWidth: "96vw",
          padding: "20px 22px",
          borderRadius: "var(--rxl)",
        }}
      >
        <button className="mclose" onClick={onClose} type="button">
          ✕
        </button>

        <div
          className="mtit"
          style={{
            marginBottom: "4px",
            display: "flex",
            alignItems: "center",
            gap: "8px",
          }}
        >
          <span
            style={{
              width: "28px",
              height: "28px",
              borderRadius: "8px",
              background: "var(--grn)",
              color: "#fff",
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: "14px",
            }}
          >
            🏷
          </span>
          {isBatch ? "Print Location Barcodes" : "Location Barcode"}
        </div>

        <div
          style={{
            fontSize: "11px",
            color: "var(--tx3)",
            marginBottom: "14px",
            paddingLeft: "36px",
          }}
        >
          {isBatch
            ? `${rows.length} filtered locations ready for printing`
            : `Barcode preview for ${location?.code || "Location"}`}
        </div>

        {!isBatch && location && <SingleLocationBarcodeCard loc={location} />}

        {isBatch && (
          <div
            style={{
              maxHeight: "430px",
              overflowY: "auto",
              border: "1px solid var(--bor)",
              borderRadius: "12px",
              background: "var(--bg3)",
              padding: "10px",
              display: "grid",
              gridTemplateColumns: "repeat(2, 1fr)",
              gap: "10px",
            }}
          >
            {rows.map((loc) => (
              <SingleLocationBarcodeCard
                key={loc.id || loc.code}
                loc={loc}
                compact
              />
            ))}
          </div>
        )}

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr auto",
            gap: "10px",
            alignItems: "end",
            marginTop: "14px",
            paddingTop: "14px",
            borderTop: "1px solid var(--bor)",
          }}
        >
          <div>
            <label
              style={{
                fontSize: "9px",
                textTransform: "uppercase",
                letterSpacing: ".8px",
                color: "var(--tx3)",
                fontWeight: 700,
                display: "block",
                marginBottom: "4px",
              }}
            >
              Printer
            </label>
            <select
              style={{
                width: "100%",
                background: "var(--bg3)",
                border: "1px solid var(--bor2)",
                borderRadius: "8px",
                padding: "8px 10px",
                fontSize: "12px",
                color: "var(--tx)",
                fontFamily: "'DM Sans',sans-serif",
                outline: "none",
              }}
            >
              <option>Zebra ZT410 — Location Labels</option>
              <option>Zebra ZT230 — Warehouse Bay</option>
              <option>Default Printer</option>
            </select>
          </div>

          <div>
            <label
              style={{
                fontSize: "9px",
                textTransform: "uppercase",
                letterSpacing: ".8px",
                color: "var(--tx3)",
                fontWeight: 700,
                display: "block",
                marginBottom: "4px",
              }}
            >
              Copies
            </label>
            <input
              type="number"
              min={1}
              max={20}
              value={copies}
              onChange={(e) =>
                setCopies(
                  Math.max(1, Math.min(20, Number(e.target.value) || 1)),
                )
              }
              style={{
                width: "68px",
                background: "var(--bg3)",
                border: "1px solid var(--bor2)",
                borderRadius: "8px",
                padding: "8px 10px",
                fontSize: "13px",
                color: "var(--tx)",
                fontFamily: "'Space Mono',monospace",
                outline: "none",
                textAlign: "center",
              }}
            />
          </div>
        </div>

        <div
          className="mfooter"
          style={{ marginTop: "14px", paddingTop: "14px" }}
        >
          <button className="btn bgh" onClick={onClose} type="button">
            Cancel
          </button>
          <button
            className="btn bpri"
            onClick={() => window.print()}
            type="button"
          >
            🖨 Print {isBatch ? `${rows.length} Barcodes` : "Barcode"}
          </button>
        </div>
      </div>
    </div>
  );
}

function SingleLocationBarcodeCard({ loc, compact = false }) {
  const barcodeValue = getLocationBarcodeValue(loc);
  const barcode = drawSetupBarcodeBars(
    barcodeValue,
    compact ? 280 : 340,
    compact ? 44 : 50,
  );
  const typeStyle = LOC_TYPE_STYLE[loc?.type] || LOC_TYPE_STYLE.PRD;
  const pct =
    Number(loc?.maxLPN || 0) > 0
      ? Math.round((Number(loc?.usedLPN || 0) / Number(loc?.maxLPN || 0)) * 100)
      : 0;

  return (
    <div
      style={{
        background: "#fff",
        border: "1px solid #c9d6ce",
        borderRadius: compact ? "8px" : "10px",
        padding: compact ? "10px 11px" : "13px 15px",
        color: "#111",
        fontFamily: "Arial, sans-serif",
        boxShadow: compact ? "none" : "0 3px 16px rgba(0,0,0,.12)",
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          borderBottom: "2px solid #111",
          paddingBottom: compact ? "6px" : "8px",
          marginBottom: compact ? "7px" : "10px",
        }}
      >
        <div>
          <div
            style={{
              fontSize: compact ? "17px" : "20px",
              fontWeight: 900,
              color: "#1a5e2a",
              letterSpacing: "-1px",
              fontFamily: "'Arial Black', Arial, sans-serif",
              lineHeight: 1,
            }}
          >
            Zamil{" "}
            <span
              style={{ color: "#2a7a3a", fontSize: compact ? "12px" : "15px" }}
            >
              ✔
            </span>
          </div>
          <div
            style={{
              fontSize: compact ? "8px" : "9px",
              color: "#1a5e2a",
              fontWeight: 700,
              lineHeight: 1.2,
            }}
          >
            Plastics
          </div>
        </div>

        <div
          style={{
            textAlign: "right",
            fontSize: compact ? "8px" : "9px",
            textTransform: "uppercase",
            color: "#555",
            fontWeight: 700,
            letterSpacing: ".5px",
          }}
        >
          Location Label
        </div>
      </div>

      <div
        style={{
          textAlign: "center",
          fontFamily: "'Courier New', monospace",
          fontSize: compact ? "17px" : "22px",
          fontWeight: 900,
          color: "#111",
          letterSpacing: ".8px",
          marginBottom: compact ? "4px" : "6px",
        }}
      >
        {loc?.code || "—"}
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          border: "1px solid #cfd8d2",
          marginBottom: compact ? "7px" : "9px",
        }}
      >
        <div
          style={{
            padding: compact ? "5px 7px" : "6px 8px",
            borderRight: "1px solid #cfd8d2",
          }}
        >
          <div
            style={{
              fontSize: "8px",
              textTransform: "uppercase",
              color: "#1a5e2a",
              fontWeight: 800,
            }}
          >
            Division
          </div>
          <div
            style={{
              fontSize: compact ? "10px" : "11px",
              fontWeight: 800,
              fontFamily: "'Courier New',monospace",
            }}
          >
            {loc?.plant || "FPP"}
          </div>
        </div>

        <div style={{ padding: compact ? "5px 7px" : "6px 8px" }}>
          <div
            style={{
              fontSize: "8px",
              textTransform: "uppercase",
              color: "#1a5e2a",
              fontWeight: 800,
            }}
          >
            Zone
          </div>
          <div
            style={{
              fontSize: compact ? "10px" : "11px",
              fontWeight: 800,
              fontFamily: "'Courier New',monospace",
            }}
          >
            {loc?.type || "PRD"}
          </div>
        </div>

        <div
          style={{
            padding: compact ? "5px 7px" : "6px 8px",
            borderTop: "1px solid #cfd8d2",
            borderRight: "1px solid #cfd8d2",
          }}
        >
          <div
            style={{
              fontSize: "8px",
              textTransform: "uppercase",
              color: "#1a5e2a",
              fontWeight: 800,
            }}
          >
            Area / Name
          </div>
          <div style={{ fontSize: compact ? "10px" : "11px", fontWeight: 700 }}>
            {loc?.name || "—"}
          </div>
        </div>

        <div
          style={{
            padding: compact ? "5px 7px" : "6px 8px",
            borderTop: "1px solid #cfd8d2",
          }}
        >
          <div
            style={{
              fontSize: "8px",
              textTransform: "uppercase",
              color: "#1a5e2a",
              fontWeight: 800,
            }}
          >
            Level / Cap.
          </div>
          <div style={{ fontSize: compact ? "10px" : "11px", fontWeight: 700 }}>
            {loc?.level || "L1"} · {loc?.usedLPN || 0}/{loc?.maxLPN || 0}
          </div>
        </div>
      </div>

      <div
        style={{
          textAlign: "center",
          padding: compact ? "4px 0 2px" : "7px 0 3px",
        }}
      >
        <svg
          viewBox={barcode.viewBox}
          style={{
            maxWidth: "100%",
            height: compact ? "45px" : "54px",
            display: "block",
            margin: "0 auto",
          }}
        >
          {barcode.rects}
        </svg>

        <div
          style={{
            fontSize: compact ? "8px" : "9px",
            fontFamily: "'Courier New', monospace",
            color: "#555",
            marginTop: "2px",
            letterSpacing: ".8px",
          }}
        >
          {barcodeValue}
        </div>
      </div>

      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          gap: "8px",
          borderTop: "1px solid #cfd8d2",
          marginTop: compact ? "6px" : "8px",
          paddingTop: compact ? "6px" : "8px",
        }}
      >
        <span
          style={{
            display: "inline-flex",
            padding: "2px 7px",
            borderRadius: "20px",
            fontSize: "8px",
            fontWeight: 800,
            ...typeStyle,
          }}
        >
          {loc?.type || "PRD"}
        </span>

        <span style={{ fontSize: "8px", color: "#555", fontWeight: 700 }}>
          Utilization: {pct}%
        </span>

        <span
          style={{
            fontSize: "8px",
            color: loc?.status === "Inactive" ? "#d97706" : "#00884a",
            fontWeight: 800,
          }}
        >
          {loc?.status || "Active"}
        </span>
      </div>
    </div>
  );
}

/* ── Shifts Tab ───────────────────────────────────────────────────── */
