import { useState, useEffect } from "react";
import { useList, useMutation } from "../../hooks/useApi";
import { userService, accessService, roleService } from "../../services/api";
import { useApp } from "../../contexts/AppContext";

const UA_PALETTE = [
  "#a78bfa",
  "#4f8ef7",
  "#2dd4a0",
  "#f5a623",
  "#22d3ee",
  "#f25f5c",
  "#ff8c42",
  "#84cc16",
  "#dc2626",
];
function uaColor(name) {
  let h = 0;
  const s = name || "?";
  for (let i = 0; i < s.length; i++) h = s.charCodeAt(i) + ((h << 5) - h);
  return UA_PALETTE[Math.abs(h) % UA_PALETTE.length];
}
function uaInits(name) {
  return (name || "?")
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0])
    .join("")
    .toUpperCase();
}

function uaDefaultScreens(roleId, roles, screens) {
  const r = roles.find(
    (x) =>
      x.id?.toLowerCase() === (roleId || "").toLowerCase() ||
      x.code?.toLowerCase() === (roleId || "").toLowerCase() ||
      x.name?.toLowerCase() === (roleId || "").toLowerCase(),
  );

  if (!r) {
    return screens.reduce(
      (a, s) => ({
        ...a,
        [s.id]: {
          view: false,
          create: false,
          edit: false,
          delete: false,
          export: false,
        },
      }),
      {},
    );
  }

  return screens.reduce(
    (a, s) => ({
      ...a,
      [s.id]: r.screens?.[s.id] || {
        view: false,
        create: false,
        edit: false,
        delete: false,
        export: false,
      },
    }),
    {},
  );
}

function uaDefaultFeatures(roleId, roles, features) {
  const r = roles.find(
    (x) =>
      x.id?.toLowerCase() === (roleId || "").toLowerCase() ||
      x.code?.toLowerCase() === (roleId || "").toLowerCase() ||
      x.name?.toLowerCase() === (roleId || "").toLowerCase(),
  );

  if (!r) {
    return features.reduce((a, f) => ({ ...a, [f.id]: false }), {});
  }

  return features.reduce(
    (a, f) => ({
      ...a,
      [f.id]: !!r.features?.[f.id],
    }),
    {},
  );
}

/* ── Scope Tree Node ─────────────────────────────────────────────── */
function ScopeNode({ node, level, checked, expanded, onCheck, onExpand }) {
  const kids = node.children || [];
  const hasKids = kids.length > 0;
  return (
    <>
      <div className={`ua-scope-row lvl-${level}`}>
        <button
          className={`ua-stog ${!hasKids ? "empty" : ""}`}
          onClick={() => hasKids && onExpand(node.id)}
        >
          {hasKids ? (expanded.has(node.id) ? "▼" : "▶") : ""}
        </button>
        <div
          className={`ua-schk ${checked.has(node.id) ? "checked" : ""}`}
          onClick={() => onCheck(node.id)}
        />
        {node.icon && <span className="ua-sicon">{node.icon}</span>}
        <span className="ua-slbl">{node.name}</span>
        {level >= 3 && kids.length > 0 && (
          <span className="ua-smeta">{kids.length} mach</span>
        )}
      </div>
      {expanded.has(node.id) &&
        kids.map((c) => (
          <ScopeNode
            key={c.id}
            node={c}
            level={level + 1}
            checked={checked}
            expanded={expanded}
            onCheck={onCheck}
            onExpand={onExpand}
          />
        ))}
    </>
  );
}
function ModalBackdrop({ children, onClose }) {
  return (
    <div className="modal-bg on" onClick={onClose}>
      {children}
    </div>
  );
}

/* ── Users Tab ────────────────────────────────────────────────────── */
export default function UsersTab() {
  const { showToast } = useApp();
  const [viewMode, setViewMode] = useState("users");
  const [search, setSearch] = useState("");
  const [stFilter, setStFilter] = useState("all");
  const [selectedUser, setSelUser] = useState(null);
  const [detailTab, setDetailTab] = useState("profile");
  const [selectedRole, setSelRole] = useState(null);
  const [showCreate, setShowCreate] = useState(false);

  const [roleOptions, setRoleOptions] = useState([]);

  const [profileEdit, setProfile] = useState({});
  const [userScreens, setUScreens] = useState({});
  const [userFeatures, setUFeats] = useState({});
  const [scopeChk, setScopeChk] = useState(new Set(["zg"]));
  const [scopeExp, setScopeExp] = useState(new Set(["zg", "fpp", "ipp"]));
  const [actLog, setActLog] = useState([]);
  const [loadAct, setLoadAct] = useState(false);
  const [secSet, setSecSet] = useState({
    pwReset: "none",
    pwStr: "medium",
    lockout: "5",
    timeout: "240",
    hours: "ANY",
    device: "ANY",
    audit: true,
    emailNotify: true,
    twoFA: false,
    ipRestrict: false,
  });
  const [newUser, setNewUser] = useState({
    empId: "",
    fullName: "",
    username: "",
    email: "",
    dept: "",
    role_id: "",
    plant: "FPP",
    password: "",
  });

  const [roleForm, setRoleForm] = useState({
    name: "",
    code: "",
    icon: "",
    color: "",
    description: "",
  });

  const [roleScreens, setRoleScreens] = useState({});
  const [roleFeatures, setRoleFeatures] = useState({});
  const { items: apiUsers, refetch: refetchUsers } = useList(
    userService.getAll,
  );
  const [rawUsers, setRawUsers] = useState([]);

  const [uaScreens, setUaScreens] = useState([]);
  const [uaFeatures, setUaFeatures] = useState([]);
  const [uaRoles, setUaRoles] = useState([]);
  const [uaOrgTree, setUaOrgTree] = useState([]);
  const [accessLoading, setAccessLoading] = useState(true);

  // const [showRoleCreate, setShowRoleCreate] = useState(false);

  const [newRole, setNewRole] = useState({
    name: "",
    code: "",
    icon: "🛡",
    color: "#006633",
    description: "",
  });
  const ROLE_ICONS = [
    "🎭",
    "🛡",
    "👤",
    "🔧",
    "🔍",
    "📦",
    "📊",
    "🖨",
    "⚙",
    "🔑",
    "🏭",
    "📋",
    "✅",
    "🚀",
    "💼",
    "🎯",
    "🔒",
    "🌐",
  ];

  const ROLE_COLORS = [
    "#a78bfa",
    "#4f8ef7",
    "#2dd4a0",
    "#f5a623",
    "#22d3ee",
    "#f25f5c",
    "#ff8c42",
    "#84cc16",
    "#d946ef",
    "#fb923c",
  ];

  const ROLE_CREATE_SCREEN_ORDER = [
    "production",
    "operator",
    "qcoverview",
    "packer",
    "dtform",
    "dtreport",
    "setup_mc",
    "setup_users",
    "lineclearance",
    "lcrpt",
  ];

  const [showRoleCreate, setShowRoleCreate] = useState(false);
  const [newRoleScreens, setNewRoleScreens] = useState({});

  const [assignedRoles, setAssignedRoles] = useState([]);

  const createRole = async () => {
    if (!newRole.name.trim()) {
      showToast("Role name is required", "error");
      return;
    }

    const roleCode = newRole.code || makeRoleCode(newRole.name);

    if (!roleCode) {
      showToast("Valid role code could not be generated", "error");
      return;
    }

    try {
      const res = await roleService.create({
        name: newRole.name.trim(),
        code: roleCode,
        icon: newRole.icon,
        color: newRole.color,
        description: newRole.description,
        permissions: {},
        isActive: true,
        isDeleted: false,
        isSystem: false,
      });

      const createdRole = res?.data || res;
      const roleId = createdRole?.role_id || createdRole?.id;

      if (roleId) {
        await accessService.updateRolePermissions(roleId, {
          screens: newRoleScreens,
          features: {},
        });
      }

      const boot = await accessService.bootstrap();
      const data = boot?.data || boot || {};

      setUaRoles(data.roles || []);

      const freshRole =
        (data.roles || []).find(
          (r) =>
            r.role_id === roleId ||
            r.id === createdRole?.id ||
            r.code === roleCode,
        ) || createdRole;

      setSelRole(freshRole);
      resetCreateRoleModal();

      showToast("Role created", "success");
    } catch (e) {
      showToast(e?.message || "Role create failed", "error");
    }
  };

  useEffect(() => {
    if (!selectedRole) return;

    setRoleForm({
      name: selectedRole.name || "",
      code: selectedRole.code || selectedRole.id || "",
      icon: selectedRole.icon || "",
      color: selectedRole.color || "",
      description: selectedRole.description || selectedRole.desc || "",
    });

    const roleId = selectedRole.role_id || selectedRole.id;

    accessService
      .getRolePermissions(roleId)
      .then((res) => {
        const data = res?.data || res || {};
        setRoleScreens(data.screens || selectedRole.screens || {});
        setRoleFeatures(data.features || selectedRole.features || {});
      })

      .catch(() => {
        setRoleScreens(selectedRole.screens || {});
        setRoleFeatures(selectedRole.features || {});
      });
  }, [selectedRole?.role_id, selectedRole?.id]);

  useEffect(() => {
    roleService
      .getAll({ isActive: true })
      .then((res) => {
        const data = res?.data?.items || res?.data || res?.items || res || [];
        setRoleOptions(Array.isArray(data) ? data : []);
      })
      .catch(() => {
        setRoleOptions([]);
      });
  }, []);

  useEffect(() => {
    if (apiUsers?.length) {
      setRawUsers(
        apiUsers.map((u) => ({ ...u, name: u.fullName || u.name || "" })),
      );
    }
  }, [apiUsers]);

  useEffect(() => {
    setAccessLoading(true);

    accessService
      .bootstrap()
      .then((res) => {
        const data = res?.data || res || {};

        setUaScreens(data.screens || []);
        setUaFeatures(data.features || []);
        setUaRoles(data.roles || []);
        setUaOrgTree(data.orgTree || []);
      })
      .catch((e) => {
        showToast(e?.message || "Failed to load access data", "error");
      })
      .finally(() => {
        setAccessLoading(false);
      });
  }, []);

  useEffect(() => {
    if (!selectedUser) return;
    setProfile({
      fullName: selectedUser.fullName || selectedUser.name || "",
      username: selectedUser.username || "",
      email: selectedUser.email || "",
      dept: selectedUser.dept || "",
      title: selectedUser.title || "",
      plant: selectedUser.plant || "FPP",
      shift: selectedUser.shift || "ANY",
      status: selectedUser.isActive !== false ? "ACTIVE" : "INACTIVE",
    });
    accessService

      .getUserAccess(selectedUser.id)
      .then((res) => {
        const data = res?.data || res || {};

        setAssignedRoles(data.roles || []);
        setUScreens(
          data.screens ||
            uaDefaultScreens(selectedUser.role, uaRoles, uaScreens),
        );

        setUFeats(
          data.features ||
            uaDefaultFeatures(selectedUser.role, uaRoles, uaFeatures),
        );

        setScopeChk(new Set(data.scope?.length ? data.scope : ["zg"]));

        if (data.security) {
          setSecSet(data.security);
        }
      })
      .catch(() => {
        setUScreens(uaDefaultScreens(selectedUser.role, uaRoles, uaScreens));
        setUFeats(uaDefaultFeatures(selectedUser.role, uaRoles, uaFeatures));
      });

    setDetailTab("profile");
    setActLog([]);
  }, [selectedUser?.id]);

  useEffect(() => {
    if (detailTab !== "activity" || !selectedUser?.id) return;
    setLoadAct(true);
    userService
      .getActivityLog(selectedUser.id, { limit: 30 })
      .then((r) => setActLog(Array.isArray(r) ? r : r?.data || []))
      .catch(() => setActLog([]))
      .finally(() => setLoadAct(false));
  }, [detailTab, selectedUser?.id]);

  const { mutate: updateApi } = useMutation(
    (d) => userService.update(d.id, d),
    {
      onSuccess: () => {
        refetchUsers();
        showToast("User saved", "success");
      },
      onError: (e) => showToast(e?.message || "Save failed", "error"),
    },
  );
  const { mutate: deleteApi } = useMutation(userService.delete, {
    onSuccess: () => {
      refetchUsers();
      setSelUser(null);
      showToast("User deleted", "warning");
    },
    onError: (e) => showToast(e?.message || "Delete failed", "error"),
  });
  const { mutate: createApi } = useMutation(userService.create, {
    onSuccess: () => {
      refetchUsers();
      setShowCreate(false);
      showToast("User created", "success");
      setNewUser({
        empId: "",
        fullName: "",
        username: "",
        email: "",
        dept: "",
        role_id: "",
        plant: "FPP",
        password: "",
      });
    },
    onError: (e) => showToast(e?.message || "Create failed", "error"),
  });

  const filtered = rawUsers.filter((u) => {
    const q = search.toLowerCase();
    if (q && !JSON.stringify(u).toLowerCase().includes(q)) return false;
    if (stFilter === "all") return true;
    if (stFilter === "ACTIVE") return u.isActive !== false;
    if (stFilter === "INACTIVE") return u.isActive === false;
    return u.role?.toLowerCase() === stFilter.toLowerCase();
  });

  const totalUsers = rawUsers.length;
  const active = rawUsers.filter((u) => u.isActive !== false).length;
  const suspended = rawUsers.filter((u) => u.isActive === false).length;
  const locked = rawUsers.filter((u) => u.isLocked).length;
  const admins = rawUsers.filter((u) => u.role === "admin").length;
  const roleCount = [...new Set(rawUsers.map((u) => u.role))].length;

  const saveSecurity = async () => {
    if (!selectedUser?.id) return;

    try {
      await accessService.saveUserSecurity(selectedUser.id, secSet);
      showToast("Security settings saved", "success");
    } catch (e) {
      showToast(e?.message || "Security save failed", "error");
    }
  };

  const forceLogout = async () => {
    if (!selectedUser?.id) return;

    try {
      await accessService.forceLogoutUser(selectedUser.id);
      showToast("Session invalidated", "warning");
    } catch (e) {
      showToast(e?.message || "Force logout failed", "error");
    }
  };
  const handleSaveOperations = () => {
    if (!selectedUser) return;

    saveProfile();
    saveAccess();
    saveSecurity();
  };

  const saveProfile = () => {
    if (!selectedUser) return;
    updateApi({
      id: selectedUser.id,
      fullName: profileEdit.fullName,
      username: profileEdit.username,
      email: profileEdit.email,
      dept: profileEdit.dept,
      title: profileEdit.title,
      plant: profileEdit.plant,
      shift: profileEdit.shift,
      isActive: profileEdit.status === "ACTIVE",
    });
  };

  const saveAccess = () => {
    if (!selectedUser) return;

    accessService
      .saveUserAccess(selectedUser.id, {
        screens: userScreens,
        features: userFeatures,
        scope: Array.from(scopeChk),
        security: secSet,
      })
      .then(() => showToast("Access saved", "success"))
      .catch((e) => showToast(e?.message || "Access save failed", "error"));
  };

  const scrByMod = uaScreens.reduce((a, s) => {
    if (!a[s.mod]) a[s.mod] = [];
    a[s.mod].push(s);
    return a;
  }, {});
  const featByCat = uaFeatures.reduce((a, f) => {
    if (!a[f.cat]) a[f.cat] = [];
    a[f.cat].push(f);
    return a;
  }, {});

  const toggleScr = (id, act) =>
    setUScreens((p) => ({ ...p, [id]: { ...p[id], [act]: !p[id]?.[act] } }));
  const allScr = (v) => {
    const x = {};
    uaScreens.forEach((s) => {
      x[s.id] = { view: v, create: v, edit: v, delete: v, export: v };
    });
    setUScreens(x);
  };
  const toggleFeat = (id) => setUFeats((p) => ({ ...p, [id]: !p[id] }));
  const allFeat = (v) => {
    const x = {};
    uaFeatures.forEach((f) => {
      x[f.id] = v;
    });
    setUFeats(x);
  };

  const scopeText = () => {
    if (scopeChk.has("zg")) return "All operations (Zamil Group)";
    const p = [
      scopeChk.has("fpp") && "FPP BU",
      scopeChk.has("ipp") && "IPP BU",
    ].filter(Boolean);
    return p.length ? p.join(" + ") : "No scope selected.";
  };
  const applyPreset = (k) => {
    if (k === "all") setScopeChk(new Set(["zg", "fpp", "ipp"]));
    else if (k === "fpp") setScopeChk(new Set(["fpp"]));
    else if (k === "ipp") setScopeChk(new Set(["ipp"]));
    else setScopeChk(new Set());
  };

  const handleCreate = () => {
    if (!newUser.empId || !newUser.fullName) {
      showToast("Employee ID and Full Name required", "error");
      return;
    }

    if (!newUser.role_id) {
      showToast("Role is required", "error");
      return;
    }

    if (!newUser.password) {
      showToast("Password is required", "error");
      return;
    }

    createApi({
      ...newUser,
      role_id: Number(newUser.role_id),
      isActive: true,
    });
  };

  const actIcon = (a) =>
    ({ login: "🔑", logout: "🚪", create: "➕", update: "✏", delete: "🗑" })[
      a
    ] || "📋";

  const toggleRoleScreen = (screenId, action) => {
    setRoleScreens((prev) => ({
      ...prev,
      [screenId]: {
        view: false,
        create: false,
        edit: false,
        delete: false,
        export: false,
        ...(prev[screenId] || {}),
        [action]: !prev[screenId]?.[action],
      },
    }));
  };

  const toggleRoleFeature = (featureId) => {
    setRoleFeatures((prev) => ({
      ...prev,
      [featureId]: !prev[featureId],
    }));
  };

  const grantAllRoleScreens = () => {
    const next = {};
    uaScreens.forEach((s) => {
      next[s.id] = {
        view: true,
        create: true,
        edit: true,
        delete: true,
        export: true,
      };
    });
    setRoleScreens(next);
  };

  const revokeAllRoleScreens = () => {
    const next = {};
    uaScreens.forEach((s) => {
      next[s.id] = {
        view: false,
        create: false,
        edit: false,
        delete: false,
        export: false,
      };
    });
    setRoleScreens(next);
  };

  const enableAllRoleFeatures = () => {
    const next = {};
    uaFeatures.forEach((f) => {
      next[f.id] = true;
    });
    setRoleFeatures(next);
  };

  const disableAllRoleFeatures = () => {
    const next = {};
    uaFeatures.forEach((f) => {
      next[f.id] = false;
    });
    setRoleFeatures(next);
  };

  const saveRolePermissions = () => {
    if (!selectedRole) return;

    const roleId = selectedRole.role_id || selectedRole.id;

    accessService
      .updateRolePermissions(roleId, {
        screens: roleScreens,
        features: roleFeatures,
      })
      .then(() => {
        showToast("Role permissions saved", "success");
        return accessService.bootstrap();
      })
      .then((res) => {
        const data = res?.data || res || {};
        setUaRoles(data.roles || []);
      })
      .catch((e) => {
        showToast(e?.message || "Role save failed", "error");
      });
  };

  const makeRoleCode = (name) =>
    String(name || "")
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "_")
      .replace(/^_+|_+$/g, "");

  const getCreateRoleScreens = () => {
    const byId = {};
    uaScreens.forEach((s) => {
      byId[s.id] = s;
    });

    return ROLE_CREATE_SCREEN_ORDER.map((id) => byId[id]).filter(Boolean);
  };

  const toggleNewRoleScreenPerm = (screenId, action) => {
    setNewRoleScreens((prev) => {
      const current = prev[screenId] || {
        view: false,
        create: false,
        edit: false,
        delete: false,
        export: false,
      };

      return {
        ...prev,
        [screenId]: {
          ...current,
          [action]: !current[action],
        },
      };
    });
  };

  const resetCreateRoleModal = () => {
    setShowRoleCreate(false);
    setNewRole({
      name: "",
      code: "",
      icon: "🎭",
      color: "#a78bfa",
      description: "",
    });
    setNewRoleScreens({});
  };

  const hasRole = (roleId) =>
    assignedRoles.some((r) => String(r.role_id) === String(roleId));

  const isPrimaryRole = (roleId) =>
    assignedRoles.some(
      (r) => String(r.role_id) === String(roleId) && Number(r.is_primary) === 1,
    );

  const refreshUserAccess = () => {
    if (!selectedUser?.id) return;

    accessService
      .getUserAccess(selectedUser.id)
      .then((res) => {
        const data = res?.data || res || {};

        setAssignedRoles(data.roles || []);
        setUScreens(data.screens || {});
        setUFeats(data.features || {});
        setScopeChk(new Set(data.scope?.length ? data.scope : ["zg"]));

        if (data.security) {
          setSecSet(data.security);
        }
      })
      .catch((e) => {
        showToast(e?.message || "Failed to refresh user access", "error");
      });
  };

  const toggleUserRole = async (role) => {
    if (!selectedUser?.id) return;

    try {
      if (hasRole(role.role_id)) {
        await accessService.removeUserRole(selectedUser.id, role.role_id);
        showToast("Role removed", "warning");
      } else {
        await accessService.addUserRole(selectedUser.id, {
          role_id: role.role_id,
          is_primary: assignedRoles.length === 0,
        });
        showToast("Role added", "success");
      }

      refreshUserAccess();
    } catch (e) {
      showToast(e?.message || "Role update failed", "error");
    }
  };

  const makePrimaryRole = async (role) => {
    if (!selectedUser?.id) return;

    if (!hasRole(role.role_id)) {
      showToast("Assign role first", "info");
      return;
    }

    try {
      await accessService.setPrimaryUserRole(selectedUser.id, role.role_id);
      showToast("Primary role updated", "success");
      refreshUserAccess();
    } catch (e) {
      showToast(e?.message || "Primary role update failed", "error");
    }
  };
  return (
    <div>
      {/* Header */}
      <div
        style={{
          display: "flex",
          alignItems: "flex-start",
          justifyContent: "space-between",
          gap: "14px",
          marginBottom: "16px",
          flexWrap: "wrap",
        }}
      >
        <div>
          <div
            style={{
              fontSize: "14px",
              fontWeight: 600,
              color: "var(--tx)",
              display: "flex",
              alignItems: "center",
              gap: "7px",
            }}
          >
            <span
              style={{
                width: "7px",
                height: "7px",
                borderRadius: "50%",
                background: "var(--pur)",
                display: "inline-block",
              }}
            />
            User Access Management
          </div>
          <div
            style={{ fontSize: "11px", color: "var(--tx3)", marginTop: "3px" }}
          >
            Define roles · assign multi-role to users · scope visibility to Org
            → Plant → Area → Machine
          </div>
        </div>
        <div
          style={{
            display: "flex",
            gap: "8px",
            flexWrap: "wrap",
            alignItems: "center",
          }}
        >
          <div className="ua-vmode">
            <button
              className={viewMode === "users" ? "on" : ""}
              onClick={() => setViewMode("users")}
            >
              👤 Users <span className="ua-vc">{rawUsers.length}</span>
            </button>
            <button
              className={viewMode === "roles" ? "on" : ""}
              onClick={() => setViewMode("roles")}
            >
              🎭 Roles <span className="ua-vc">{uaRoles.length}</span>
            </button>
          </div>
          <button className="btn bgh bsm" onClick={() => setShowCreate(true)}>
            ➕ Create User
          </button>
          <button
            className="btn bgh bsm"
            onClick={() => showToast("Export — coming soon", "info")}
          >
            📤 Export
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="ua-stats">
        {[
          ["Total Users", totalUsers, "var(--blu)"],
          ["Active", active, "var(--grn)"],
          ["Suspended", suspended, "var(--amb)"],
          ["Locked", locked, "var(--red)"],
          ["Admins", admins, "var(--pur)"],
          ["Defined Roles", roleCount, "var(--tel)"],
        ].map(([l, v, c]) => (
          <div key={l} className="ua-stc" style={{ borderLeftColor: c }}>
            <div className="ua-stlbl">{l}</div>
            <div className="ua-stval" style={{ color: c }}>
              {v}
            </div>
          </div>
        ))}
      </div>

      {/* ── USERS VIEW ──────────────────────────────────────────── */}
      {viewMode === "users" && (
        <div className="ua-layout">
          <div className="ua-side">
            <div className="ua-side-hdr">
              <div
                style={{
                  fontSize: "12px",
                  fontWeight: 600,
                  color: "var(--tx)",
                  display: "flex",
                  alignItems: "center",
                  gap: "7px",
                }}
              >
                <span
                  style={{
                    width: "7px",
                    height: "7px",
                    borderRadius: "50%",
                    background: "var(--blu)",
                    display: "inline-block",
                  }}
                />
                Users{" "}
                <span style={{ color: "var(--tx3)", fontWeight: 400 }}>
                  ({filtered.length})
                </span>
              </div>
              <button
                className="btn bpri bsm"
                onClick={() => setShowCreate(true)}
              >
                + New
              </button>
            </div>
            <div className="ua-side-search">
              <input
                type="text"
                placeholder="🔍 Search users..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            <div className="ua-side-filter">
              {[
                ["all", "All"],
                ["ACTIVE", "Active"],
                ["INACTIVE", "Susp."],
                ["admin", "Admin"],
                ["tech", "Tech"],
                ["operator", "Op"],
                ["qc", "QC"],
                ["packer", "Packer"],
              ].map(([v, l]) => (
                <button
                  key={v}
                  className={`ua-sf ${stFilter === v ? "on" : ""}`}
                  onClick={() => setStFilter(v)}
                >
                  {l}
                </button>
              ))}
            </div>
            <div className="ua-user-list">
              {filtered.length === 0 && (
                <div
                  style={{
                    padding: "24px",
                    textAlign: "center",
                    color: "var(--tx3)",
                    fontSize: "12px",
                  }}
                >
                  No users found.
                </div>
              )}
              {filtered.map((u) => (
                <div
                  key={u.id}
                  className={`ua-user-item ${selectedUser?.id === u.id ? "active" : ""}`}
                  onClick={() => setSelUser(u)}
                >
                  <div
                    className="ua-uav"
                    style={{ background: uaColor(u.name || u.empId || "?") }}
                  >
                    {uaInits(u.name || u.empId || "?")}
                  </div>
                  <div className="ua-uinfo">
                    <div className="ua-uname">{u.name}</div>
                    <div className="ua-utitle">
                      {u.empId} · {u.role}
                    </div>
                  </div>
                  <div
                    className="ua-ustatus"
                    style={{
                      background:
                        u.isActive !== false ? "var(--grn)" : "var(--amb)",
                    }}
                  />
                </div>
              ))}
            </div>
          </div>

          <div className="ua-main">
            {!selectedUser ? (
              <div
                className="ua-card"
                style={{
                  padding: "48px",
                  textAlign: "center",
                  color: "var(--tx3)",
                }}
              >
                <div style={{ fontSize: "42px", marginBottom: "10px" }}>👤</div>
                <div
                  style={{
                    fontSize: "14px",
                    fontWeight: 600,
                    color: "var(--tx)",
                    marginBottom: "6px",
                  }}
                >
                  Select a user to manage access
                </div>
                <div
                  style={{
                    fontSize: "11px",
                    maxWidth: "300px",
                    margin: "0 auto",
                  }}
                >
                  Click a user from the list to view and edit their profile,
                  roles, screen access, scope and features.
                </div>
                <button
                  className="btn bpri bsm"
                  style={{ marginTop: "16px" }}
                  onClick={() => setShowCreate(true)}
                >
                  ➕ Create First User
                </button>
              </div>
            ) : (
              <>
                {/* User header card */}
                <div className="ua-card">
                  <div
                    style={{
                      padding: "16px 18px",
                      display: "flex",
                      alignItems: "flex-start",
                      gap: "14px",
                      flexWrap: "wrap",
                    }}
                  >
                    <div
                      className="ua-uav"
                      style={{
                        width: "56px",
                        height: "56px",
                        borderRadius: "50%",
                        fontSize: "16px",
                        background: uaColor(selectedUser.name || "?"),
                      }}
                    >
                      {uaInits(selectedUser.name || "?")}
                    </div>
                    <div style={{ flex: 1, minWidth: "200px" }}>
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: "8px",
                          flexWrap: "wrap",
                          marginBottom: "4px",
                        }}
                      >
                        <div
                          style={{
                            fontSize: "16px",
                            fontWeight: 700,
                            color: "var(--tx)",
                          }}
                        >
                          {selectedUser.name}
                        </div>
                        <span
                          className={`bdg ${selectedUser.isActive !== false ? "bd" : "bgh"}`}
                        >
                          {selectedUser.isActive !== false
                            ? "Active"
                            : "Suspended"}
                        </span>
                        <span className="bdg bpa">{selectedUser.role}</span>
                      </div>
                      <div
                        style={{
                          fontSize: "11px",
                          color: "var(--tx3)",
                          marginBottom: "3px",
                        }}
                      >
                        {selectedUser.title || selectedUser.dept || "—"}
                      </div>
                      <div style={{ fontSize: "11px", color: "var(--tx3)" }}>
                        Emp{" "}
                        <span
                          style={{
                            fontFamily: "'Space Mono',monospace",
                            color: "var(--tx)",
                          }}
                        >
                          {selectedUser.empId}
                        </span>
                        &nbsp;·&nbsp;
                        <span style={{ color: "var(--tx)" }}>
                          {selectedUser.dept || "—"}
                        </span>
                        {selectedUser.email && (
                          <>
                            &nbsp;·&nbsp;
                            <span style={{ color: "var(--blu)" }}>
                              {selectedUser.email}
                            </span>
                          </>
                        )}
                      </div>
                    </div>
                    <div
                      style={{ display: "flex", gap: "6px", flexWrap: "wrap" }}
                    >
                      <button
                        className="btn bgh bsm"
                        onClick={() =>
                          showToast("Password reset link sent", "info")
                        }
                      >
                        🔑 Reset Pwd
                      </button>
                      <button
                        className={`btn ${selectedUser.isActive !== false ? "bamb" : "bsuc"} bsm`}
                        onClick={() =>
                          updateApi({
                            id: selectedUser.id,
                            isActive: selectedUser.isActive === false,
                          })
                        }
                      >
                        {selectedUser.isActive !== false
                          ? "⏸ Suspend"
                          : "▶ Activate"}
                      </button>
                      <button
                        className="btn bdan bsm"
                        onClick={() => {
                          if (window.confirm("Delete this user?"))
                            deleteApi(selectedUser.id);
                        }}
                      >
                        🗑 Delete
                      </button>
                      {/* Billo Ko Update  */}
                      <button
                        className="btn bpri bsm"
                        onClick={handleSaveOperations}
                      >
                        💾 Save
                      </button>
                    </div>
                  </div>
                </div>

                {/* Tab pills */}
                <div style={{ display: "flex", gap: "4px", flexWrap: "wrap" }}>
                  {[
                    ["profile", "👤 Profile"],
                    ["role", "🎭 Roles"],
                    ["scope", "🏭 Scope"],
                    ["screens", "🖥 Screens"],
                    ["features", "⚙ Features"],
                    ["security", "🔐 Security"],
                    ["activity", "📋 Activity"],
                  ].map(([t, l]) => (
                    <button
                      key={t}
                      className={`ua-tab ${detailTab === t ? "on" : ""}`}
                      onClick={() => setDetailTab(t)}
                    >
                      {l}
                    </button>
                  ))}
                </div>

                {/* ── PROFILE ── */}
                {detailTab === "profile" && (
                  <div className="ua-card">
                    <div className="ua-card-hdr">
                      <div
                        style={{
                          fontSize: "12px",
                          fontWeight: 600,
                          color: "var(--tx)",
                          display: "flex",
                          alignItems: "center",
                          gap: "7px",
                        }}
                      >
                        <span
                          style={{
                            width: "7px",
                            height: "7px",
                            borderRadius: "50%",
                            background: "var(--grn)",
                            display: "inline-block",
                          }}
                        />
                        User Profile
                      </div>
                    </div>
                    <div style={{ padding: "14px 16px" }}>
                      <div className="ua-g3">
                        <div className="ua-fg">
                          <label>Employee Number</label>
                          <input
                            type="text"
                            value={selectedUser.empId || ""}
                            readOnly
                            style={{ opacity: 0.6 }}
                          />
                        </div>
                        <div className="ua-fg">
                          <label>Full Name *</label>
                          <input
                            type="text"
                            value={profileEdit.fullName || ""}
                            onChange={(e) =>
                              setProfile((p) => ({
                                ...p,
                                fullName: e.target.value,
                              }))
                            }
                          />
                        </div>
                        <div className="ua-fg">
                          <label>Username / Login</label>
                          <input
                            type="text"
                            style={{ fontFamily: "'Space Mono',monospace" }}
                            value={profileEdit.username || ""}
                            onChange={(e) =>
                              setProfile((p) => ({
                                ...p,
                                username: e.target.value,
                              }))
                            }
                          />
                        </div>
                      </div>
                      <div className="ua-g3" style={{ marginTop: "10px" }}>
                        <div className="ua-fg">
                          <label>Email</label>
                          <input
                            type="email"
                            value={profileEdit.email || ""}
                            onChange={(e) =>
                              setProfile((p) => ({
                                ...p,
                                email: e.target.value,
                              }))
                            }
                          />
                        </div>
                        <div className="ua-fg">
                          <label>Department</label>
                          <input
                            type="text"
                            value={profileEdit.dept || ""}
                            onChange={(e) =>
                              setProfile((p) => ({
                                ...p,
                                dept: e.target.value,
                              }))
                            }
                          />
                        </div>
                        <div className="ua-fg">
                          <label>Job Title</label>
                          <input
                            type="text"
                            value={profileEdit.title || ""}
                            onChange={(e) =>
                              setProfile((p) => ({
                                ...p,
                                title: e.target.value,
                              }))
                            }
                          />
                        </div>
                      </div>
                      <div className="ua-g3" style={{ marginTop: "10px" }}>
                        <div className="ua-fg">
                          <label>Plant</label>
                          <select
                            value={profileEdit.plant || "FPP"}
                            onChange={(e) =>
                              setProfile((p) => ({
                                ...p,
                                plant: e.target.value,
                              }))
                            }
                          >
                            <option value="FPP">FPP BU</option>
                            <option value="IPP">IPP BU</option>
                            <option value="BOTH">FPP + IPP</option>
                            <option value="ZPC">ZPC BU</option>
                          </select>
                        </div>
                        <div className="ua-fg">
                          <label>Shift</label>
                          <select
                            value={profileEdit.shift || "ANY"}
                            onChange={(e) =>
                              setProfile((p) => ({
                                ...p,
                                shift: e.target.value,
                              }))
                            }
                          >
                            <option value="ANY">Any Shift</option>
                            <option value="DAY">Day Shift</option>
                            <option value="NIGHT">Night Shift</option>
                            <option value="ADMIN">Admin / Office</option>
                          </select>
                        </div>
                        <div className="ua-fg">
                          <label>Account Status</label>
                          <select
                            value={profileEdit.status || "ACTIVE"}
                            onChange={(e) =>
                              setProfile((p) => ({
                                ...p,
                                status: e.target.value,
                              }))
                            }
                          >
                            <option value="ACTIVE">Active</option>
                            <option value="INACTIVE">Suspended</option>
                            <option value="LOCKED">Locked</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* ── ROLES ── */}
                {detailTab === "role" && (
                  <div className="ua-card">
                    <div className="ua-card-hdr">
                      <div
                        style={{
                          fontSize: "12px",
                          fontWeight: 600,
                          color: "var(--tx)",
                          display: "flex",
                          alignItems: "center",
                          gap: "7px",
                        }}
                      >
                        <span
                          style={{
                            width: "7px",
                            height: "7px",
                            borderRadius: "50%",
                            background: "var(--pur)",
                            display: "inline-block",
                          }}
                        />
                        Assigned Roles
                      </div>
                      <div style={{ fontSize: "11px", color: "var(--tx3)" }}>
                        Pick one or more · ⭐ marks primary
                      </div>
                    </div>
                    <div style={{ padding: "14px 16px" }}>
                      <div className="ua-role-grid">
                        {uaRoles.map((r) => {
                          const selected = hasRole(r.role_id);
                          const primary = isPrimaryRole(r.role_id);

                          return (
                            <div
                              key={r.role_id}
                              className={`ua-role-tile ${selected ? "sel" : ""} ${
                                primary ? "primary" : ""
                              }`}
                              onClick={() => toggleUserRole(r)}
                            >
                              <div className="ua-rmark" />

                              <button
                                className="ua-rprim"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  makePrimaryRole(r);
                                }}
                                title="Make primary role"
                              >
                                {primary ? "⭐" : "☆"}
                              </button>

                              <div className="ua-rhdr">
                                <span className="ri">{r.icon}</span>
                                <span className="rn">{r.name}</span>
                              </div>

                              <div className="ua-rd">
                                {r.description || r.desc || "No description"}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                      <div className="ua-role-summary">
                        <span className="ua-rs-lbl">Active Roles:</span>

                        {assignedRoles.length === 0 ? (
                          <span className="ua-rs-chip">No role assigned</span>
                        ) : (
                          assignedRoles.map((r) => (
                            <span
                              key={r.role_id}
                              className={`ua-rs-chip ${Number(r.is_primary) === 1 ? "prim" : ""}`}
                            >
                              <span className="mrk">
                                {Number(r.is_primary) === 1 ? "★" : "•"}
                              </span>
                              {r.name}
                            </span>
                          ))
                        )}
                      </div>

                      <div
                        style={{
                          marginTop: "12px",
                          padding: "11px 14px",
                          background: "rgba(59,130,246,.08)",
                          border: "1px solid var(--blu)",
                          borderRadius: "9px",
                          fontSize: "12px",
                          color: "var(--blu)",
                          display: "flex",
                          alignItems: "flex-start",
                          gap: "9px",
                        }}
                      >
                        <span style={{ fontSize: "14px" }}>ℹ</span>
                        <div>
                          <b>How multi-role works:</b> the user's effective
                          access is the <b>union</b> of all selected roles.
                          Customise individual screens or features on the next
                          two tabs.
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* ── SCOPE ── */}
                {detailTab === "scope" && (
                  <div className="ua-card">
                    <div className="ua-card-hdr">
                      <div
                        style={{
                          fontSize: "12px",
                          fontWeight: 600,
                          color: "var(--tx)",
                          display: "flex",
                          alignItems: "center",
                          gap: "7px",
                        }}
                      >
                        <span
                          style={{
                            width: "7px",
                            height: "7px",
                            borderRadius: "50%",
                            background: "var(--tel)",
                            display: "inline-block",
                          }}
                        />
                        Operational Scope
                      </div>
                      <div style={{ fontSize: "11px", color: "var(--tx3)" }}>
                        Limits which WOs, downtime & reports the user sees
                      </div>
                    </div>
                    <div style={{ padding: "14px 16px" }}>
                      <div className="ua-scope-summary">
                        <div className="ua-ss-ic">🎯</div>
                        <div style={{ flex: 1 }}>
                          <div
                            style={{
                              fontSize: "10px",
                              fontWeight: 700,
                              color: "var(--grn)",
                              textTransform: "uppercase",
                              letterSpacing: ".5px",
                              marginBottom: "4px",
                            }}
                          >
                            Effective Visibility
                          </div>
                          <div style={{ fontSize: "12px", color: "var(--tx)" }}>
                            {scopeText()}
                          </div>
                        </div>
                      </div>
                      <div style={{ marginTop: "14px" }}>
                        <div
                          style={{
                            fontSize: "10px",
                            fontWeight: 700,
                            color: "var(--tx3)",
                            textTransform: "uppercase",
                            letterSpacing: ".8px",
                            marginBottom: "8px",
                          }}
                        >
                          Quick Presets
                        </div>
                        <div className="ua-scope-presets">
                          {[
                            ["all", "🌐 All Operations"],
                            ["fpp", "📦 FPP BU only"],
                            ["ipp", "🧪 IPP BU only"],
                            ["clear", "✕ Clear All"],
                          ].map(([k, l]) => (
                            <button
                              key={k}
                              className="ua-spreset"
                              onClick={() => applyPreset(k)}
                            >
                              {l}
                            </button>
                          ))}
                        </div>
                      </div>
                      <div
                        style={{
                          marginTop: "14px",
                          border: "1px solid var(--bor)",
                          borderRadius: "10px",
                          overflow: "hidden",
                        }}
                      >
                        <div
                          style={{
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "space-between",
                            padding: "8px 12px",
                            background: "var(--bg3)",
                            borderBottom: "1px solid var(--bor)",
                          }}
                        >
                          <div
                            style={{
                              fontSize: "10px",
                              fontWeight: 700,
                              color: "var(--tx3)",
                              textTransform: "uppercase",
                              letterSpacing: ".8px",
                            }}
                          >
                            Scope Tree · Org → Plant → Area → Machine
                          </div>
                          <div style={{ display: "flex", gap: "5px" }}>
                            <button
                              className="btn bgh bsm"
                              style={{ fontSize: "10px", padding: "3px 9px" }}
                              onClick={() =>
                                setScopeExp(
                                  new Set([
                                    "zg",
                                    "fpp",
                                    "ipp",
                                    "fpp-ext",
                                    "fpp-print",
                                    "fpp-slit",
                                    "ipp-inj",
                                    "ipp-asm",
                                    "ipp-blow",
                                  ]),
                                )
                              }
                            >
                              ⊕ Expand
                            </button>
                            <button
                              className="btn bgh bsm"
                              style={{ fontSize: "10px", padding: "3px 9px" }}
                              onClick={() => setScopeExp(new Set(["zg"]))}
                            >
                              ⊖ Collapse
                            </button>
                          </div>
                        </div>
                        <div className="ua-scope-tree">
                          {uaOrgTree.map((n) => (
                            <ScopeNode
                              key={n.id}
                              node={n}
                              level={1}
                              checked={scopeChk}
                              expanded={scopeExp}
                              onCheck={(id) =>
                                setScopeChk((p) => {
                                  const s = new Set(p);
                                  s.has(id) ? s.delete(id) : s.add(id);
                                  return s;
                                })
                              }
                              onExpand={(id) =>
                                setScopeExp((p) => {
                                  const s = new Set(p);
                                  s.has(id) ? s.delete(id) : s.add(id);
                                  return s;
                                })
                              }
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* ── SCREENS ── */}
                {detailTab === "screens" && (
                  <div className="ua-card">
                    <div className="ua-card-hdr">
                      <div
                        style={{
                          fontSize: "12px",
                          fontWeight: 600,
                          color: "var(--tx)",
                          display: "flex",
                          alignItems: "center",
                          gap: "7px",
                        }}
                      >
                        <span
                          style={{
                            width: "7px",
                            height: "7px",
                            borderRadius: "50%",
                            background: "var(--blu)",
                            display: "inline-block",
                          }}
                        />
                        Screen &amp; Module Access
                      </div>
                      <div style={{ display: "flex", gap: "5px" }}>
                        <button
                          className="btn bgh bsm"
                          style={{ fontSize: "10px", padding: "3px 9px" }}
                          onClick={() => allScr(true)}
                        >
                          ✓ Grant All
                        </button>
                        <button
                          className="btn bgh bsm"
                          style={{ fontSize: "10px", padding: "3px 9px" }}
                          onClick={() => allScr(false)}
                        >
                          ✕ Revoke All
                        </button>
                      </div>
                    </div>
                    <div style={{ overflowX: "auto" }}>
                      <div className="ua-perm-matrix">
                        <div
                          className="ua-pm-row"
                          style={{
                            gridTemplateColumns: "220px repeat(5,80px)",
                            background: "var(--bg3)",
                          }}
                        >
                          <div
                            className="ua-pm-col-hdr"
                            style={{ textAlign: "left" }}
                          >
                            Screen
                          </div>
                          {["View", "Create", "Edit", "Delete", "Export"].map(
                            (a) => (
                              <div key={a} className="ua-pm-col-hdr">
                                {a}
                              </div>
                            ),
                          )}
                        </div>
                        {Object.entries(scrByMod).map(([mod, scrns]) => (
                          <div key={mod}>
                            <div className="ua-mod-hdr">{mod}</div>
                            {scrns.map((s) => (
                              <div
                                key={s.id}
                                className="ua-pm-row"
                                style={{
                                  gridTemplateColumns: "220px repeat(5,80px)",
                                }}
                              >
                                <div className="ua-pm-cell">
                                  <div className="ua-pm-screen">
                                    {s.icon} {s.label}
                                  </div>
                                  <div className="ua-pm-sub">{s.id}</div>
                                </div>
                                {[
                                  "view",
                                  "create",
                                  "edit",
                                  "delete",
                                  "export",
                                ].map((a) => (
                                  <div key={a} className="ua-pm-cell">
                                    <div className="ua-pm-check">
                                      <input
                                        type="checkbox"
                                        checked={!!userScreens[s.id]?.[a]}
                                        onChange={() => toggleScr(s.id, a)}
                                      />
                                    </div>
                                  </div>
                                ))}
                              </div>
                            ))}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* ── FEATURES ── */}
                {detailTab === "features" && (
                  <div className="ua-card">
                    <div className="ua-card-hdr">
                      <div
                        style={{
                          fontSize: "12px",
                          fontWeight: 600,
                          color: "var(--tx)",
                          display: "flex",
                          alignItems: "center",
                          gap: "7px",
                        }}
                      >
                        <span
                          style={{
                            width: "7px",
                            height: "7px",
                            borderRadius: "50%",
                            background: "var(--amb)",
                            display: "inline-block",
                          }}
                        />
                        Feature Flags
                      </div>
                      <div style={{ display: "flex", gap: "5px" }}>
                        <button
                          className="btn bgh bsm"
                          style={{ fontSize: "10px", padding: "3px 9px" }}
                          onClick={() => allFeat(true)}
                        >
                          ✓ Enable All
                        </button>
                        <button
                          className="btn bgh bsm"
                          style={{ fontSize: "10px", padding: "3px 9px" }}
                          onClick={() => allFeat(false)}
                        >
                          ✕ Disable All
                        </button>
                      </div>
                    </div>
                    <div style={{ padding: "6px 16px 14px" }}>
                      {Object.entries(featByCat).map(([cat, feats]) => (
                        <div key={cat}>
                          <div className="ua-feature-cat">{cat}</div>
                          <div className="ua-feature-grid">
                            {feats.map((f) => (
                              <div
                                key={f.id}
                                className="ua-feature-row"
                                onClick={() => toggleFeat(f.id)}
                              >
                                <label
                                  className="ua-toggle-sw"
                                  onClick={(e) => e.stopPropagation()}
                                >
                                  <input
                                    type="checkbox"
                                    checked={!!userFeatures[f.id]}
                                    onChange={() => toggleFeat(f.id)}
                                  />
                                  <span className="ua-toggle-slider" />
                                </label>
                                <div>
                                  <div className="flbl">{f.label}</div>
                                  <div className="fdsc">{f.desc}</div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* ── SECURITY ── */}
                {detailTab === "security" && (
                  <div className="ua-card">
                    <div className="ua-card-hdr">
                      <div
                        style={{
                          fontSize: "12px",
                          fontWeight: 600,
                          color: "var(--tx)",
                          display: "flex",
                          alignItems: "center",
                          gap: "7px",
                        }}
                      >
                        <span
                          style={{
                            width: "7px",
                            height: "7px",
                            borderRadius: "50%",
                            background: "var(--red)",
                            display: "inline-block",
                          }}
                        />
                        Security Settings
                      </div>
                    </div>
                    <div style={{ padding: "14px 16px" }}>
                      <div className="ua-sec-ttl">🔑 Password Policy</div>
                      <div className="ua-g3">
                        <div className="ua-fg">
                          <label>Force Password Reset</label>
                          <select
                            value={secSet.pwReset}
                            onChange={(e) =>
                              setSecSet((s) => ({
                                ...s,
                                pwReset: e.target.value,
                              }))
                            }
                          >
                            <option value="none">Never</option>
                            <option value="first_login">On First Login</option>
                            <option value="30d">Every 30 Days</option>
                            <option value="90d">Every 90 Days</option>
                          </select>
                        </div>
                        <div className="ua-fg">
                          <label>Strength</label>
                          <select
                            value={secSet.pwStr}
                            onChange={(e) =>
                              setSecSet((s) => ({
                                ...s,
                                pwStr: e.target.value,
                              }))
                            }
                          >
                            <option value="basic">Basic</option>
                            <option value="medium">Medium</option>
                            <option value="strong">Strong</option>
                          </select>
                        </div>
                        <div className="ua-fg">
                          <label>Lockout After</label>
                          <select
                            value={secSet.lockout}
                            onChange={(e) =>
                              setSecSet((s) => ({
                                ...s,
                                lockout: e.target.value,
                              }))
                            }
                          >
                            <option value="3">3 attempts</option>
                            <option value="5">5 attempts</option>
                            <option value="10">10 attempts</option>
                          </select>
                        </div>
                      </div>
                      <div className="ua-sec-ttl" style={{ marginTop: "18px" }}>
                        🕐 Session &amp; Access
                      </div>
                      <div className="ua-g3">
                        <div className="ua-fg">
                          <label>Session Timeout</label>
                          <select
                            value={secSet.timeout}
                            onChange={(e) =>
                              setSecSet((s) => ({
                                ...s,
                                timeout: e.target.value,
                              }))
                            }
                          >
                            <option value="30">30 min</option>
                            <option value="60">1 hour</option>
                            <option value="240">4 hours</option>
                            <option value="480">8 hours (shift)</option>
                          </select>
                        </div>
                        <div className="ua-fg">
                          <label>Allowed Login Hours</label>
                          <select
                            value={secSet.hours}
                            onChange={(e) =>
                              setSecSet((s) => ({
                                ...s,
                                hours: e.target.value,
                              }))
                            }
                          >
                            <option value="ANY">Anytime</option>
                            <option value="DAY">Day (6:30–18:30)</option>
                            <option value="NIGHT">Night (18:30–06:30)</option>
                            <option value="OFFICE">Office (8–17)</option>
                          </select>
                        </div>
                        <div className="ua-fg">
                          <label>Login From</label>
                          <select
                            value={secSet.device}
                            onChange={(e) =>
                              setSecSet((s) => ({
                                ...s,
                                device: e.target.value,
                              }))
                            }
                          >
                            <option value="ANY">Any Device</option>
                            <option value="PLANT">Plant Network Only</option>
                            <option value="TABLET">Tablet / Kiosk Only</option>
                          </select>
                        </div>
                      </div>
                      <div className="ua-sec-ttl" style={{ marginTop: "18px" }}>
                        📋 Audit &amp; Notifications
                      </div>
                      <div
                        style={{
                          display: "grid",
                          gridTemplateColumns: "1fr 1fr",
                          gap: "8px",
                        }}
                      >
                        {[
                          ["audit", "Log all user actions (audit trail)"],
                          ["emailNotify", "Email on login"],
                          ["twoFA", "Require 2FA"],
                          ["ipRestrict", "IP Whitelist restriction"],
                        ].map(([k, l]) => (
                          <label key={k} className="ua-cbx">
                            <input
                              type="checkbox"
                              checked={secSet[k]}
                              onChange={(e) =>
                                setSecSet((s) => ({
                                  ...s,
                                  [k]: e.target.checked,
                                }))
                              }
                            />
                            {l}
                          </label>
                        ))}
                      </div>
                      <div
                        style={{
                          marginTop: "16px",
                          display: "flex",
                          gap: "8px",
                        }}
                      >
                        {/* <button
                          className="btn bpri bsm"
                          onClick={() =>
                            showToast("Security settings saved", "success")
                          }
                        >
                          💾 Save Settings
                        </button> */}
                        <button className="btn bdan bsm" onClick={forceLogout}>
                          ⏻ Force Logout
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* ── ACTIVITY ── */}
                {detailTab === "activity" && (
                  <div className="ua-card">
                    <div className="ua-card-hdr">
                      <div
                        style={{
                          fontSize: "12px",
                          fontWeight: 600,
                          color: "var(--tx)",
                          display: "flex",
                          alignItems: "center",
                          gap: "7px",
                        }}
                      >
                        <span
                          style={{
                            width: "7px",
                            height: "7px",
                            borderRadius: "50%",
                            background: "var(--tel)",
                            display: "inline-block",
                          }}
                        />
                        Activity Log
                      </div>
                      <div style={{ fontSize: "11px", color: "var(--tx3)" }}>
                        Last 30 days
                      </div>
                    </div>
                    {loadAct ? (
                      <div
                        style={{
                          padding: "40px",
                          textAlign: "center",
                          color: "var(--tx3)",
                        }}
                      >
                        <div
                          className="spinner"
                          style={{
                            width: "24px",
                            height: "24px",
                            margin: "0 auto 10px",
                          }}
                        />
                        Loading...
                      </div>
                    ) : actLog.length === 0 ? (
                      <div
                        style={{
                          padding: "40px",
                          textAlign: "center",
                          color: "var(--tx3)",
                          fontSize: "12px",
                        }}
                      >
                        <div style={{ fontSize: "28px", marginBottom: "8px" }}>
                          📋
                        </div>
                        No activity recorded in the last 30 days.
                      </div>
                    ) : (
                      actLog.map((a, i) => (
                        <div key={a.id || i} className="ua-act-row">
                          <div
                            className="ua-act-ic"
                            style={{
                              background: "var(--pur2)",
                              color: "var(--pur)",
                            }}
                          >
                            {actIcon(a.action)}
                          </div>
                          <div style={{ flex: 1 }}>
                            <div
                              style={{ fontSize: "12px", color: "var(--tx)" }}
                            >
                              {a.description || a.action}
                            </div>
                            <div className="ua-act-time">
                              {a.createdAt
                                ? new Date(a.createdAt).toLocaleString()
                                : "—"}
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      )}

      {/* ── ROLES VIEW ──────────────────────────────────────────── */}
      {viewMode === "roles" && (
        <div className="ua-layout ">
          <div className="ua-side sticky top-0 h-screen flex flex-col overflow-hidden ">
            <div className="ua-side-hdr">
              <div
                style={{
                  fontSize: "12px",
                  fontWeight: 600,
                  color: "var(--tx)",
                  display: "flex",
                  alignItems: "center",
                  gap: "7px",
                }}
              >
                <span
                  style={{
                    width: "7px",
                    height: "7px",
                    borderRadius: "50%",
                    background: "var(--pur)",
                    display: "inline-block",
                  }}
                />
                Roles Library{" "}
                <span style={{ color: "var(--tx3)", fontWeight: 400 }}>
                  ({uaRoles.length})
                </span>
              </div>

              <button
                className="btn bpri bsm"
                onClick={() => setShowRoleCreate(true)}
              >
                + New
              </button>
            </div>
            <div
              style={{
                padding: "10px 14px",
                borderBottom: "1px solid var(--bor)",
                fontSize: "11px",
                color: "var(--tx3)",
                lineHeight: 1.5,
              }}
            >
              Roles bundle <b style={{ color: "var(--tx)" }}>screen access</b> +{" "}
              <b style={{ color: "var(--tx)" }}>feature flags</b>.
            </div>
            <div className="flex-1 min-h-0 overflow-y-auto">
              <div
                className=""
                style={{
                  padding: "10px",
                  display: "flex",
                  flexDirection: "column",
                  gap: "8px",
                  // maxHeight: "680px",
                  // overflowY: "auto",
                }}
              >
                {uaRoles.map((r) => (
                  <div
                    key={r.id}
                    className={`ua-role-card ${selectedRole?.id === r.id ? "active" : ""}`}
                    onClick={() => setSelRole(r)}
                  >
                    <div className="ua-rc-ic" style={{ background: r.color }}>
                      {r.icon}
                    </div>
                    <div className="ua-rc-body">
                      <div className="ua-rc-name">
                        {r.name}{" "}
                        {/* {r.isSystem && (
                        <span className="bdg brj" style={{ fontSize: "9px" }}>
                          🔒
                        </span>
                      )} */}
                      </div>
                      <div className="ua-rc-desc">{r.desc}</div>
                      <div className="ua-rc-meta">
                        <span>
                          👥{" "}
                          <b>
                            {
                              rawUsers.filter(
                                (u) =>
                                  u.role?.toLowerCase() ===
                                    r.id.toLowerCase() || u.role === r.name,
                              ).length
                            }
                          </b>
                        </span>
                        <span>
                          🖥{" "}
                          <b>
                            {r.screens.ALL
                              ? uaScreens.length
                              : Object.keys(r.screens).length}
                          </b>{" "}
                          scr
                        </span>
                        <span>
                          ⚙{" "}
                          <b>
                            {r.features.ALL
                              ? uaFeatures.length
                              : Object.keys(r.features).filter(
                                  (k) => r.features[k],
                                ).length}
                          </b>{" "}
                          feat
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="ua-main">
            {!selectedRole ? (
              <div
                className="ua-card"
                style={{
                  padding: "48px",
                  textAlign: "center",
                  color: "var(--tx3)",
                }}
              >
                <div style={{ fontSize: "42px", marginBottom: "10px" }}>🎭</div>
                <div
                  style={{
                    fontSize: "14px",
                    fontWeight: 600,
                    color: "var(--tx)",
                    marginBottom: "6px",
                  }}
                >
                  Select a role to view
                </div>
                <div
                  style={{
                    fontSize: "11px",
                    maxWidth: "340px",
                    margin: "0 auto",
                  }}
                >
                  Define screen access, feature flags, icon and description.
                </div>
              </div>
            ) : (
              <>
                <div className="ua-card">
                  <div
                    style={{
                      padding: "16px 18px",
                      display: "flex",
                      alignItems: "flex-start",
                      gap: "12px",
                      flexWrap: "wrap",
                    }}
                  >
                    <div
                      style={{
                        width: "50px",
                        height: "50px",
                        borderRadius: "12px",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        fontSize: "22px",
                        background: selectedRole.color,
                        flexShrink: 0,
                      }}
                    >
                      {selectedRole.icon}
                    </div>
                    <div style={{ flex: 1, minWidth: "200px" }}>
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: "8px",
                          flexWrap: "wrap",
                          marginBottom: "4px",
                        }}
                      >
                        <div
                          style={{
                            fontSize: "16px",
                            fontWeight: 700,
                            color: "var(--tx)",
                          }}
                        >
                          {selectedRole.name}
                        </div>
                        {selectedRole.system && (
                          <span className="bdg brj">🔒 System</span>
                        )}
                      </div>
                      <div
                        style={{
                          fontSize: "12px",
                          color: "var(--tx3)",
                          marginBottom: "8px",
                        }}
                      >
                        {selectedRole.desc}
                      </div>
                      <div
                        style={{
                          display: "flex",
                          gap: "14px",
                          fontSize: "11px",
                          color: "var(--tx3)",
                          fontFamily: "'Space Mono',monospace",
                        }}
                      >
                        <span>
                          👥{" "}
                          <b style={{ color: "var(--grn)" }}>
                            {
                              rawUsers.filter(
                                (u) =>
                                  u.role?.toLowerCase() ===
                                    selectedRole.id.toLowerCase() ||
                                  u.role === selectedRole.name,
                              ).length
                            }
                          </b>{" "}
                          members
                        </span>
                        <span>
                          🖥{" "}
                          <b style={{ color: "var(--blu)" }}>
                            {selectedRole.screens.ALL
                              ? uaScreens.length
                              : Object.keys(selectedRole.screens).length}
                          </b>{" "}
                          screens
                        </span>
                        <span>
                          ⚙{" "}
                          <b style={{ color: "var(--amb)" }}>
                            {selectedRole.features.ALL
                              ? uaFeatures.length
                              : Object.keys(selectedRole.features).filter(
                                  (k) => selectedRole.features[k],
                                ).length}
                          </b>{" "}
                          features
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div
                  style={{
                    background: "rgba(59,130,246,.08)",
                    border: "1px solid var(--blu)",
                    borderRadius: "9px",
                    padding: "10px 14px",
                    display: "flex",
                    alignItems: "center",
                    gap: "10px",
                    color: "var(--blu)",
                    fontSize: "12px",
                  }}
                >
                  <div
                    style={{
                      width: "28px",
                      height: "28px",
                      borderRadius: "7px",
                      background: "var(--blu)",
                      color: "#fff",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      fontSize: "13px",
                    }}
                  >
                    ⚡
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700, marginBottom: "1px" }}>
                      Changes propagate live
                    </div>
                    <div style={{ fontSize: "11px", opacity: 0.85 }}>
                      Modifying this role auto-applies to{" "}
                      <b>
                        {
                          rawUsers.filter(
                            (u) =>
                              u.role?.toLowerCase() ===
                                selectedRole.id.toLowerCase() ||
                              u.role === selectedRole.name,
                          ).length
                        }{" "}
                        users
                      </b>
                      .
                    </div>
                  </div>
                </div>

                {/* Role screens matrix */}
                <div className="ua-card">
                  <div className="ua-card-hdr">
                    <div
                      style={{
                        fontSize: "12px",
                        fontWeight: 600,
                        color: "var(--tx)",
                        display: "flex",
                        alignItems: "center",
                        gap: "7px",
                      }}
                    >
                      <span
                        style={{
                          width: "7px",
                          height: "7px",
                          borderRadius: "50%",
                          background: "var(--blu)",
                          display: "inline-block",
                        }}
                      />
                      Default Screen Access
                    </div>
                    <div style={{ fontSize: "11px", color: "var(--tx3)" }}>
                      <button
                        className="btn bpri bsm"
                        onClick={saveRolePermissions}
                      >
                        Save & Propagate
                      </button>
                    </div>
                  </div>
                  <div style={{ overflowX: "auto" }}>
                    <div className="ua-perm-matrix">
                      <div
                        className="ua-pm-row"
                        style={{
                          gridTemplateColumns: "220px repeat(5,80px)",
                          background: "var(--bg3)",
                        }}
                      >
                        <div
                          className="ua-pm-col-hdr"
                          style={{ textAlign: "left" }}
                        >
                          Screen
                        </div>
                        {["View", "Create", "Edit", "Delete", "Export"].map(
                          (a) => (
                            <div key={a} className="ua-pm-col-hdr">
                              {a}
                            </div>
                          ),
                        )}
                      </div>
                      {Object.entries(scrByMod).map(([mod, scrns]) => (
                        <div key={mod}>
                          <div className="ua-mod-hdr">{mod}</div>
                          {scrns.map((s) => {
                            const p = selectedRole.screens.ALL
                              ? selectedRole.screens.ALL
                              : selectedRole.screens[s.id] || {
                                  view: false,
                                  create: false,
                                  edit: false,
                                  delete: false,
                                  export: false,
                                };
                            return (
                              <div
                                key={s.id}
                                className="ua-pm-row"
                                style={{
                                  gridTemplateColumns: "220px repeat(5,80px)",
                                }}
                              >
                                <div className="ua-pm-cell">
                                  <div className="ua-pm-screen">
                                    {s.icon} {s.label}
                                  </div>
                                  <div className="ua-pm-sub">{s.id}</div>
                                </div>
                                {[
                                  "view",
                                  "create",
                                  "edit",
                                  "delete",
                                  "export",
                                ].map((a) => (
                                  <div key={a} className="ua-pm-cell">
                                    <div className="ua-pm-check">
                                      <input
                                        type="checkbox"
                                        checked={!!roleScreens?.[s.id]?.[a]}
                                        onChange={() =>
                                          toggleRoleScreen(s.id, a)
                                        }
                                        style={{ cursor: "default" }}
                                      />
                                    </div>
                                  </div>
                                ))}
                              </div>
                            );
                          })}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Role features */}
                <div className="ua-card">
                  <div className="ua-card-hdr">
                    <div
                      style={{
                        fontSize: "12px",
                        fontWeight: 600,
                        color: "var(--tx)",
                        display: "flex",
                        alignItems: "center",
                        gap: "7px",
                      }}
                    >
                      <span
                        style={{
                          width: "7px",
                          height: "7px",
                          borderRadius: "50%",
                          background: "var(--amb)",
                          display: "inline-block",
                        }}
                      />
                      Default Feature Flags
                    </div>
                  </div>
                  <div style={{ padding: "6px 16px 14px" }}>
                    {Object.entries(featByCat).map(([cat, feats]) => (
                      <div key={cat}>
                        <div className="ua-feature-cat">{cat}</div>
                        <div className="ua-feature-grid">
                          {feats.map((f) => {
                            const en =
                              selectedRole.features.ALL ||
                              !!selectedRole.features[f.id];
                            return (
                              <div
                                key={f.id}
                                className={`ua-feature-row ${roleFeatures?.[f.id] ? "has-override" : ""}`}
                                onClick={() => toggleRoleFeature(f.id)}
                              >
                                <label
                                  className="ua-toggle-sw"
                                  onClick={(e) => e.stopPropagation()}
                                >
                                  <input
                                    type="checkbox"
                                    checked={!!roleFeatures?.[f.id]}
                                    onChange={() => toggleRoleFeature(f.id)}
                                  />
                                  <span className="ua-toggle-slider" />
                                </label>

                                <div>
                                  <div className="flbl">{f.label}</div>
                                  <div className="fdsc">{f.desc}</div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Members */}
                <div className="ua-card">
                  <div className="ua-card-hdr">
                    <div
                      style={{
                        fontSize: "12px",
                        fontWeight: 600,
                        color: "var(--tx)",
                        display: "flex",
                        alignItems: "center",
                        gap: "7px",
                      }}
                    >
                      <span
                        style={{
                          width: "7px",
                          height: "7px",
                          borderRadius: "50%",
                          background: "var(--grn)",
                          display: "inline-block",
                        }}
                      />
                      Members
                    </div>
                  </div>
                  <div
                    style={{
                      padding: "12px 16px",
                      display: "flex",
                      gap: "8px",
                      flexWrap: "wrap",
                    }}
                  >
                    {rawUsers.filter(
                      (u) =>
                        u.role?.toLowerCase() ===
                          selectedRole.id.toLowerCase() ||
                        u.role === selectedRole.name,
                    ).length === 0 ? (
                      <div style={{ fontSize: "12px", color: "var(--tx3)" }}>
                        No users assigned to this role.
                      </div>
                    ) : (
                      rawUsers
                        .filter(
                          (u) =>
                            u.role?.toLowerCase() ===
                              selectedRole.id.toLowerCase() ||
                            u.role === selectedRole.name,
                        )
                        .map((u) => (
                          <div
                            key={u.id}
                            className="ua-member-pill"
                            onClick={() => {
                              setViewMode("users");
                              setSelUser(u);
                            }}
                          >
                            <div
                              className="ua-uav"
                              style={{
                                width: "18px",
                                height: "18px",
                                fontSize: "8px",
                                background: uaColor(u.name || "?"),
                              }}
                            >
                              {uaInits(u.name || "?")}
                            </div>
                            {u.name}
                          </div>
                        ))
                    )}
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* ── Create User Modal ────────────────────────────────────── */}
      {showCreate && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0,0,0,.6)",
            zIndex: 1000,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: "20px",
          }}
        >
          <div
            style={{
              background: "var(--bg2)",
              border: "1px solid var(--bor)",
              borderRadius: "16px",
              width: "100%",
              maxWidth: "560px",
              overflow: "hidden",
            }}
          >
            <div
              style={{
                padding: "16px 20px",
                borderBottom: "1px solid var(--bor)",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              <div
                style={{
                  fontSize: "14px",
                  fontWeight: 700,
                  color: "var(--tx)",
                }}
              >
                ➕ Create New User
              </div>
              <button
                className="btn bgh bsm"
                onClick={() => setShowCreate(false)}
              >
                ✕
              </button>
            </div>
            <div
              style={{
                padding: "20px",
                display: "flex",
                flexDirection: "column",
                gap: "14px",
              }}
            >
              <div className="ua-g3">
                <div className="ua-fg">
                  <label>Employee ID *</label>
                  <input
                    type="text"
                    placeholder="EMP-XXXX"
                    style={{ fontFamily: "'Space Mono',monospace" }}
                    value={newUser.empId}
                    onChange={(e) =>
                      setNewUser((n) => ({ ...n, empId: e.target.value }))
                    }
                  />
                </div>
                <div className="ua-fg" style={{ gridColumn: "span 2" }}>
                  <label>Full Name *</label>
                  <input
                    type="text"
                    placeholder="First and last name"
                    value={newUser.fullName}
                    onChange={(e) =>
                      setNewUser((n) => ({ ...n, fullName: e.target.value }))
                    }
                  />
                </div>
              </div>
              <div className="ua-g3">
                <div className="ua-fg">
                  <label>Username</label>
                  <input
                    type="text"
                    style={{ fontFamily: "'Space Mono',monospace" }}
                    value={newUser.username}
                    onChange={(e) =>
                      setNewUser((n) => ({ ...n, username: e.target.value }))
                    }
                  />
                </div>
                <div className="ua-fg">
                  <label>Email</label>
                  <input
                    type="email"
                    value={newUser.email}
                    onChange={(e) =>
                      setNewUser((n) => ({ ...n, email: e.target.value }))
                    }
                  />
                </div>
                <div className="ua-fg">
                  <label>Department</label>
                  <input
                    type="text"
                    value={newUser.dept}
                    onChange={(e) =>
                      setNewUser((n) => ({ ...n, dept: e.target.value }))
                    }
                  />
                </div>
              </div>
              <div className="ua-g3">
                <div className="ua-fg">
                  <label>Role *</label>
                  <select
                    value={newUser.role_id}
                    onChange={(e) =>
                      setNewUser((n) => ({ ...n, role_id: e.target.value }))
                    }
                  >
                    <option value="">Select Role</option>
                    {roleOptions.map((r) => (
                      <option key={r.role_id} value={r.role_id}>
                        {r.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="ua-fg">
                  <label>Plant</label>
                  <select
                    value={newUser.plant}
                    onChange={(e) =>
                      setNewUser((n) => ({ ...n, plant: e.target.value }))
                    }
                  >
                    <option value="FPP">FPP BU</option>
                    <option value="IPP">IPP BU</option>
                    <option value="BOTH">FPP + IPP</option>
                    <option value="ZPC">ZPC BU</option>
                  </select>
                </div>
                <div className="ua-fg">
                  <label>Password *</label>
                  <input
                    type="password"
                    placeholder="Set initial password"
                    value={newUser.password}
                    onChange={(e) =>
                      setNewUser((n) => ({ ...n, password: e.target.value }))
                    }
                  />
                </div>
              </div>
            </div>
            <div
              style={{
                padding: "14px 20px",
                borderTop: "1px solid var(--bor)",
                display: "flex",
                justifyContent: "flex-end",
                gap: "8px",
              }}
            >
              <button className="btn bgh" onClick={() => setShowCreate(false)}>
                Cancel
              </button>
              <button className="btn bpri" onClick={handleCreate}>
                Create User
              </button>
            </div>
          </div>
        </div>
      )}
      {showRoleCreate && (
        <ModalBackdrop onClose={resetCreateRoleModal}>
          <div className="">
            <div
              className="ua-role-create-modal"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                className="ua-role-create-close"
                onClick={resetCreateRoleModal}
              >
                ×
              </button>

              <div className="ua-role-create-head">
                <div
                  className="ua-role-create-head-icon"
                  style={{ background: newRole.color }}
                >
                  {newRole.icon}
                </div>

                <div>
                  <div className="ua-role-create-title">Create New Role</div>
                  <div className="text-xs" style={{ color: "var(--tx3)" }}>
                    Define a role's name, icon, color and screen permissions. It
                    will appear instantly in the Roles Library and user
                    assignment tiles.
                  </div>
                </div>
              </div>

              <div className="ua-role-create-section-title">Live Preview</div>

              <div className="ua-role-live-preview">
                <div
                  className="ua-role-live-icon"
                  style={{ background: newRole.color }}
                >
                  {newRole.icon}
                </div>

                <div>
                  <div className="ua-role-live-name">
                    {newRole.name || "New Role"}
                  </div>
                  <div className="ua-role-live-desc">
                    {newRole.description ||
                      "Role description will appear here..."}
                  </div>
                </div>
              </div>

              <div className="ua-role-create-grid">
                <div className="ua-role-create-field">
                  <label>
                    Role Name <span>*</span>
                  </label>
                  <input
                    autoFocus
                    value={newRole.name}
                    onChange={(e) =>
                      setNewRole((p) => ({
                        ...p,
                        name: e.target.value,
                        code: makeRoleCode(e.target.value),
                      }))
                    }
                    placeholder="e.g. Shift Supervisor"
                  />
                </div>

                <div className="ua-role-create-field">
                  <label>Description</label>
                  <input
                    value={newRole.description}
                    onChange={(e) =>
                      setNewRole((p) => ({ ...p, description: e.target.value }))
                    }
                    placeholder="Short summary of this role's purpose"
                  />
                </div>
              </div>

              <div className="ua-role-create-section-title">Icon</div>

              <div className="ua-role-icon-grid">
                {ROLE_ICONS.map((icon) => (
                  <button
                    key={icon}
                    type="button"
                    className={`ua-role-icon-choice ${
                      newRole.icon === icon ? "active" : ""
                    }`}
                    onClick={() => setNewRole((p) => ({ ...p, icon }))}
                  >
                    {icon}
                  </button>
                ))}
              </div>

              <div className="ua-role-create-section-title">Color</div>

              <div className="ua-role-color-row">
                {ROLE_COLORS.map((color) => (
                  <button
                    key={color}
                    type="button"
                    className={`ua-role-color-choice ${
                      newRole.color === color ? "active" : ""
                    }`}
                    style={{ background: color }}
                    onClick={() => setNewRole((p) => ({ ...p, color }))}
                  />
                ))}

                <input
                  className="ua-role-color-input"
                  value={newRole.color}
                  onChange={(e) =>
                    setNewRole((p) => ({ ...p, color: e.target.value }))
                  }
                />
              </div>

              <div className="ua-role-create-section-title">
                Screen Permissions
              </div>

              <div className="ua-role-create-help">
                Toggle View / Edit / Export per screen. Leave all off for no
                access.
              </div>

              <div className="ua-role-screen-create-grid">
                {getCreateRoleScreens().map((screen) => {
                  const perms = newRoleScreens[screen.id] || {};

                  return (
                    <div key={screen.id} className="ua-role-screen-create-row">
                      <div className="ua-role-screen-create-name">
                        {screen.label}
                      </div>

                      <div className="ua-role-screen-create-actions">
                        {[
                          ["view", "View"],
                          ["edit", "Edit"],
                          ["export", "Export"],
                        ].map(([key, label]) => (
                          <button
                            key={key}
                            type="button"
                            className={`ua-role-perm-pill ${
                              perms[key] ? "active" : ""
                            }`}
                            onClick={() =>
                              toggleNewRoleScreenPerm(screen.id, key)
                            }
                          >
                            {label}
                          </button>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="ua-role-create-footer">
                <button className="btn bgh" onClick={resetCreateRoleModal}>
                  Cancel
                </button>

                <button className="btn bpri" onClick={createRole}>
                  ✅ Create Role
                </button>
              </div>
            </div>
          </div>
        </ModalBackdrop>
      )}
    </div>
  );
}
