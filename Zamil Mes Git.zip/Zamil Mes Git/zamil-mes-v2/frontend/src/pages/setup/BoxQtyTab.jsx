import { useState, useEffect } from 'react'
import { useList, useMutation } from '../../hooks/useApi'
import { setupService } from '../../services/api'
import { useApp } from '../../contexts/AppContext'

export default function BoxQtyTab() {
  const { showToast } = useApp()
  const [innerTab, setInnerTab] = useState('form')

  const [form, setForm] = useState({ org:'', date: new Date().toISOString().slice(0,10), user:'' })
  const [items, setItems] = useState([])
  const [showAddItem, setShowAddItem] = useState(false)
  const [newItem, setNewItem] = useState({ code:'', desc:'', qty:'' })

  const { items: apiBq, refetch: refetchBq } = useList(setupService.getBoxQtyReport)
  const [bqList, setBqList] = useState([])
  const [bqFilter, setBqFilter] = useState({ org:'', code:'', search:'' })

  useEffect(() => {
    if (apiBq?.length) setBqList(apiBq)
  }, [apiBq])

  const { mutate: saveBqApi } = useMutation(setupService.saveBoxQtyRecords, {
    onSuccess: () => { refetchBq(); showToast('Box quantities saved successfully','success') },
    onError: () => showToast('Save failed — check required fields','error'),
  })

  const addItem = () => {
    if (!newItem.code || !newItem.qty) { showToast('Item code and qty required','error'); return }
    setItems(prev => [{ ...newItem, id: Date.now() }, ...prev])
    setNewItem({ code:'', desc:'', qty:'' })
    setShowAddItem(false)
  }

  const removeItem = id => setItems(prev => prev.filter(x => x.id !== id))

  const saveForm = () => {
    if (!form.org) { showToast('Select an Organization','error'); return }
    if (!items.length) { showToast('Add at least one item','error'); return }
    saveBqApi({ org: form.org, date: form.date, user: form.user, items })
    setItems([])
  }

  const filteredBq = bqList.filter(r => {
    if (bqFilter.org    && r.org  !== bqFilter.org) return false
    if (bqFilter.code   && !r.code?.toLowerCase().includes(bqFilter.code.toLowerCase())) return false
    if (bqFilter.search && !JSON.stringify(r).toLowerCase().includes(bqFilter.search.toLowerCase())) return false
    return true
  })

  return (
    <div>
      <div style={{display:'flex',gap:'6px',marginBottom:'18px'}}>
        <button className={`bq-itab ${innerTab === 'form' ? 'on' : ''}`} onClick={() => setInnerTab('form')}>Form</button>
        <button className={`bq-itab ${innerTab === 'report' ? 'on' : ''}`} onClick={() => setInnerTab('report')}>Report / List</button>
      </div>

      {innerTab === 'form' && (
        <div style={{background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'14px',padding:'22px'}}>
          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:'18px',paddingBottom:'14px',borderBottom:'1px solid var(--bor)'}}>
            <div>
              <div style={{fontSize:'13px',fontWeight:600,color:'var(--tx)',display:'flex',alignItems:'center',gap:'7px'}}>
                <span style={{width:'7px',height:'7px',borderRadius:'50%',background:'var(--pur)',display:'inline-block'}}/>
                Box Quantity Form
              </div>
              <div style={{fontSize:'11px',color:'var(--tx3)',marginTop:'3px'}}>Define how many units are packed per box for each item code</div>
            </div>
            <div style={{fontSize:'11px',padding:'4px 12px',borderRadius:'20px',background:'var(--pur2)',border:'1px solid var(--pur)',color:'var(--pur)'}}>ZPI.MFG.BQ.01</div>
          </div>

          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:'16px',marginBottom:'16px'}}>
            <div>
              <label style={{fontSize:'11px',fontWeight:600,textTransform:'uppercase',letterSpacing:'.8px',color:'var(--tx3)',display:'block',marginBottom:'5px'}}>Organization <span style={{color:'var(--red)'}}>*</span></label>
              <select style={{width:'100%'}} value={form.org} onChange={e => setForm(f=>({...f,org:e.target.value}))}>
                <option value="">Select Organization</option>
                <option value="FPP BU">FPP BU</option>
                <option value="IPP BU">IPP BU</option>
                <option value="ZPC BU">ZPC BU</option>
              </select>
              <div style={{fontSize:'11px',color:'var(--tx3)',marginTop:'3px'}}>Scopes item search to the selected org.</div>
            </div>
            <div>
              <label style={{fontSize:'11px',fontWeight:600,textTransform:'uppercase',letterSpacing:'.8px',color:'var(--tx3)',display:'block',marginBottom:'5px'}}>Effective Date</label>
              <input type="date" value={form.date} onChange={e => setForm(f=>({...f,date:e.target.value}))} />
            </div>
            <div>
              <label style={{fontSize:'11px',fontWeight:600,textTransform:'uppercase',letterSpacing:'.8px',color:'var(--tx3)',display:'block',marginBottom:'5px'}}>Created By</label>
              <input type="text" placeholder="Name or Employee ID" value={form.user} onChange={e => setForm(f=>({...f,user:e.target.value}))} />
            </div>
          </div>

          <div style={{display:'flex',gap:'8px',marginBottom:'16px'}}>
            <button className="btn bpri" onClick={() => setShowAddItem(true)}>+ Add Item</button>
            <button className="btn bgh" onClick={() => { setItems([]); setForm({ org:'', date: new Date().toISOString().slice(0,10), user:'' }) }}>Clear All</button>
          </div>

          {showAddItem && (
            <div style={{background:'var(--bg3)',border:'1px solid var(--bor)',borderRadius:'10px',padding:'14px',marginBottom:'14px',display:'grid',gridTemplateColumns:'1fr 2fr 1fr auto',gap:'10px',alignItems:'end'}}>
              <div>
                <label style={{fontSize:'11px',color:'var(--tx3)',display:'block',marginBottom:'4px'}}>Item Code</label>
                <input type="text" placeholder="e.g. FG9406" value={newItem.code} onChange={e => setNewItem(n=>({...n,code:e.target.value}))} style={{fontFamily:"'Space Mono',monospace"}} />
              </div>
              <div>
                <label style={{fontSize:'11px',color:'var(--tx3)',display:'block',marginBottom:'4px'}}>Item Description</label>
                <input type="text" placeholder="Product description" value={newItem.desc} onChange={e => setNewItem(n=>({...n,desc:e.target.value}))} />
              </div>
              <div>
                <label style={{fontSize:'11px',color:'var(--tx3)',display:'block',marginBottom:'4px'}}>Qty Per Box</label>
                <input type="number" placeholder="e.g. 2400" value={newItem.qty} onChange={e => setNewItem(n=>({...n,qty:e.target.value}))} />
              </div>
              <div style={{display:'flex',gap:'6px'}}>
                <button className="btn bsuc bsm" onClick={addItem}>Add</button>
                <button className="btn bgh bsm" onClick={() => setShowAddItem(false)}>✕</button>
              </div>
            </div>
          )}

          <div style={{border:'1px solid var(--bor)',borderRadius:'10px',overflow:'hidden',marginBottom:'10px'}}>
            <table style={{width:'100%',borderCollapse:'collapse',fontSize:'12px'}}>
              <thead>
                <tr style={{background:'var(--bg3)'}}>
                  <th style={{padding:'9px 14px',textAlign:'left',fontSize:'10px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',borderBottom:'1px solid var(--bor)',width:'36px'}}>#</th>
                  <th style={{padding:'9px 14px',textAlign:'left',fontSize:'10px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',borderBottom:'1px solid var(--bor)'}}>Item Code</th>
                  <th style={{padding:'9px 14px',textAlign:'left',fontSize:'10px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',borderBottom:'1px solid var(--bor)'}}>Item Description</th>
                  <th style={{padding:'9px 14px',textAlign:'right',fontSize:'10px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',borderBottom:'1px solid var(--bor)',width:'130px'}}>Qty Per Box</th>
                  <th style={{padding:'9px 14px',textAlign:'center',fontSize:'10px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',borderBottom:'1px solid var(--bor)',width:'100px'}}>Action</th>
                </tr>
              </thead>
              <tbody>
                {items.length === 0 ? (
                  <tr><td colSpan={5} style={{textAlign:'center',padding:'28px',color:'var(--tx3)'}}>
                    <div style={{fontSize:'22px',marginBottom:'6px'}}>📦</div>No items added yet.
                  </td></tr>
                ) : items.map((it, i) => (
                  <tr key={it.id} style={{borderBottom:'1px solid var(--bor)'}}>
                    <td style={{padding:'9px 14px',fontFamily:"'Space Mono',monospace",fontSize:'10px',color:'var(--tx3)'}}>{i+1}</td>
                    <td style={{padding:'9px 14px',fontFamily:"'Space Mono',monospace",fontSize:'11px',color:'var(--pur)',fontWeight:600}}>{it.code}</td>
                    <td style={{padding:'9px 14px',fontSize:'11px'}}>{it.desc}</td>
                    <td style={{padding:'9px 14px',textAlign:'right',fontFamily:"'Space Mono',monospace",fontSize:'12px',fontWeight:700,color:'var(--tx)'}}>{Number(it.qty).toLocaleString()}</td>
                    <td style={{padding:'9px 14px',textAlign:'center'}}>
                      <button className="btn bdan bsm" onClick={() => removeItem(it.id)}>✕ Remove</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',paddingTop:'14px',borderTop:'1px solid var(--bor)'}}>
            <div style={{fontSize:'11px',color:'var(--tx3)'}}>You can add multiple items — each new one appears at the top.</div>
            <div style={{display:'flex',gap:'8px'}}>
              <button className="btn bgh" onClick={() => setItems([])}>Reset</button>
              <button className="btn bpri" onClick={saveForm}>💾 Save</button>
            </div>
          </div>
        </div>
      )}

      {innerTab === 'report' && (
        <div style={{background:'var(--bg2)',border:'1px solid var(--bor)',borderRadius:'14px',padding:'22px'}}>
          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:'16px',paddingBottom:'14px',borderBottom:'1px solid var(--bor)'}}>
            <div style={{fontSize:'13px',fontWeight:600,color:'var(--tx)',display:'flex',alignItems:'center',gap:'7px'}}>
              <span style={{width:'7px',height:'7px',borderRadius:'50%',background:'var(--pur)',display:'inline-block'}}/>
              Box Quantity List
            </div>
            <div style={{fontSize:'11px',color:'var(--tx3)'}}>View, filter and manage all saved records</div>
          </div>

          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr auto',gap:'10px',alignItems:'end',marginBottom:'16px'}}>
            <div>
              <label style={{fontSize:'11px',fontWeight:600,textTransform:'uppercase',letterSpacing:'.8px',color:'var(--tx3)',display:'block',marginBottom:'5px'}}>Organization</label>
              <select value={bqFilter.org} onChange={e => setBqFilter(f=>({...f,org:e.target.value}))}>
                <option value="">Select Organization ID</option>
                <option value="FPP BU">FPP BU</option>
                <option value="IPP BU">IPP BU</option>
                <option value="ZPC BU">ZPC BU</option>
              </select>
            </div>
            <div>
              <label style={{fontSize:'11px',fontWeight:600,textTransform:'uppercase',letterSpacing:'.8px',color:'var(--tx3)',display:'block',marginBottom:'5px'}}>Item Code</label>
              <input type="text" placeholder="Enter Item Code" value={bqFilter.code} onChange={e => setBqFilter(f=>({...f,code:e.target.value}))} />
            </div>
            <button className="btn bpri">🔍 Search</button>
          </div>

          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:'12px',gap:'10px',flexWrap:'wrap'}}>
            <div style={{display:'flex',gap:'8px',alignItems:'center'}}>
              <button className="btn bgh bsm">📥 Export Excel</button>
              <span style={{fontSize:'11px',color:'var(--tx3)'}}>{filteredBq.length} records</span>
            </div>
            <div style={{display:'flex',alignItems:'center',gap:'8px'}}>
              <span style={{fontSize:'12px',color:'var(--tx3)'}}>Search:</span>
              <input type="text" placeholder="Search any field..." style={{width:'200px'}} value={bqFilter.search} onChange={e => setBqFilter(f=>({...f,search:e.target.value}))} />
            </div>
          </div>

          <div style={{border:'1px solid var(--bor)',borderRadius:'10px',overflow:'hidden',marginBottom:'8px',overflowX:'auto'}}>
            <table style={{width:'100%',borderCollapse:'collapse',fontSize:'12px',minWidth:'800px'}}>
              <thead>
                <tr style={{background:'var(--bg3)'}}>
                  {/* <th style={{padding:'9px 14px',textAlign:'left',fontSize:'10px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',borderBottom:'1px solid var(--bor)',width:'48px'}}>ID</th> */}
                  <th style={{padding:'9px 14px',textAlign:'left',fontSize:'10px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',borderBottom:'1px solid var(--bor)'}}>Org ID</th>
                  <th style={{padding:'9px 14px',textAlign:'left',fontSize:'10px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',borderBottom:'1px solid var(--bor)'}}>Item Code</th>
                  <th style={{padding:'9px 14px',textAlign:'left',fontSize:'10px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',borderBottom:'1px solid var(--bor)'}}>Item Description</th>
                  <th style={{padding:'9px 14px',textAlign:'right',fontSize:'10px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',borderBottom:'1px solid var(--bor)',width:'120px'}}>Qty Per Box</th>
                  <th style={{padding:'9px 14px',textAlign:'center',fontSize:'10px',textTransform:'uppercase',letterSpacing:'1px',color:'var(--tx3)',borderBottom:'1px solid var(--bor)',width:'80px'}}>Action</th>
                </tr>
              </thead>
              <tbody>
                {filteredBq.length === 0 ? (
                  <tr><td colSpan={6} style={{textAlign:'center',padding:'28px',color:'var(--tx3)'}}>No records found.</td></tr>
                ) : filteredBq.map(r => (
                  <tr key={r.id} style={{borderBottom:'1px solid var(--bor)'}}>
                    {/* <td style={{padding:'9px 14px',fontFamily:"'Space Mono',monospace",fontSize:'10px',color:'var(--tx3)'}}>{r.id}</td> */}
                    <td style={{padding:'9px 14px',fontSize:'11px'}}>{r.org}</td>
                    <td style={{padding:'9px 14px',fontFamily:"'Space Mono',monospace",fontSize:'11px',color:'var(--pur)',fontWeight:600}}>{r.code}</td>
                    <td style={{padding:'9px 14px',fontSize:'11px'}}>{r.desc}</td>
                    <td style={{padding:'9px 14px',textAlign:'right',fontFamily:"'Space Mono',monospace",fontSize:'12px',fontWeight:700}}>{Number(r.qty).toLocaleString()}</td>
                    <td style={{padding:'9px 14px',textAlign:'center'}}>
                      <button className="btn bdan bsm" onClick={() => { if(window.confirm('Delete?')) { setupService.deleteBoxQtyRecord(r.id).then(refetchBq).catch(()=>{}) } }}>🗑</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div style={{fontSize:'11px',color:'var(--tx3)',paddingTop:'10px'}}>{filteredBq.length} records</div>
        </div>
      )}
    </div>
  )
}

/* ── Machines Tab ─────────────────────────────────────────────────── */
