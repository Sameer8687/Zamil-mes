import { useState, useEffect } from 'react'
import { useAuth } from '../../contexts/AuthContext'
import { useApp } from '../../contexts/AppContext'
import { wasteService, setupService, productionService, referenceService } from '../../services/api'

const REASON_CODES = [
  { group: 'Material', options: [
    { value: 'MAT-DEFECT', label: 'MAT-DEFECT — Material defect at infeed' },
    { value: 'CONTAM',     label: 'CONTAM — Contamination' },
    { value: 'COLOR-VAR',  label: 'COLOR-VAR — Color variation' },
  ]},
  { group: 'Process', options: [
    { value: 'SHORT-SHOT', label: 'SHORT-SHOT — Injection short shot' },
    { value: 'DIM-OUT',    label: 'DIM-OUT — Dimensions out of tolerance' },
    { value: 'FLASH',      label: 'FLASH — Excessive flash / burr' },
  ]},
  { group: 'Other', options: [
    { value: 'TRIAL',     label: 'TRIAL — Setup / Trial run' },
    { value: 'OPER-ERR',  label: 'OPER-ERR — Operator error' },
    { value: 'MC-FAULT',  label: 'MC-FAULT — Machine fault' },
  ]},
]

const QUICK_REASONS = ['SHORT-SHOT', 'DIM-OUT', 'MAT-DEFECT', 'TRIAL']

const SUBINVS = [
  { value: 'SCRAP-FPP',  label: 'SCRAP-FPP — Scrap Holding Area' },
  { value: 'HOLD-QC',    label: 'HOLD-QC — QC Hold' },
  { value: 'REWORK-FPP', label: 'REWORK-FPP — Rework Cell' },
]

const LOCATORS = [
  { value: 'SCRAP.A1', label: 'SCRAP.A1 · Aisle A Bin 1' },
  { value: 'SCRAP.A2', label: 'SCRAP.A2 · Aisle A Bin 2' },
  { value: 'SCRAP.B1', label: 'SCRAP.B1 · Aisle B Bin 1' },
]

export default function WasteRecording() {
  const { user } = useAuth()
  const { showToast } = useApp()

  const [machines,    setMachines]    = useState([])
  const [wos,         setWos]         = useState([])
  const [wasteTypes,  setWasteTypes]  = useState([])
  const [history,     setHistory]     = useState([])
  const [summary,     setSummary]     = useState(null)

  const [selMachine, setSelMachine] = useState(null)
  const [selWO,      setSelWO]      = useState(null)
  const [selComp,    setSelComp]    = useState(null)
  const [mode,       setMode]       = useState('scrap')

  const [qty,     setQty]     = useState('')
  const [reason,  setReason]  = useState('')
  const [subinv,  setSubinv]  = useState(SUBINVS[0].value)
  const [locator, setLocator] = useState(LOCATORS[0].value)
  const [txnDate, setTxnDate] = useState('')
  const [notes,   setNotes]   = useState('')

  useEffect(() => {
    setupService.getMachines().then(r => setMachines(r?.data ?? r ?? [])).catch(() => setMachines([]))
    productionService.getWorkOrders({ status: 'active', limit: 50 }).then(r => setWos(r?.data ?? r ?? [])).catch(() => setWos([]))
    referenceService.getWasteTypes().then(r => setWasteTypes(r?.data ?? r ?? [])).catch(() => setWasteTypes([]))
    wasteService.getRecords({ limit: 20 }).then(r => {
      const rows = r?.data ?? r ?? []
      setHistory(Array.isArray(rows) ? rows : rows.rows ?? [])
    }).catch(() => setHistory([]))
    wasteService.getSummary().then(r => setSummary(r?.data ?? r)).catch(() => setSummary(null))
  }, [])

  const refreshHistory = async () => {
    try {
      const r = await wasteService.getRecords({ limit: 20 })
      const rows = r?.data ?? r ?? []
      setHistory(Array.isArray(rows) ? rows : rows.rows ?? [])
    } catch (_) {}
    try {
      const s = await wasteService.getSummary()
      setSummary(s?.data ?? s)
    } catch (_) {}
  }

  const woList   = selMachine ? wos : []
  const compList = selWO ? wasteTypes : []
  const compData = selComp ? wasteTypes.find(t => t.id === selComp) : null
  const formReady = !!(selComp && qty && reason)

  const adjQty = (delta) => {
    setQty(prev => {
      const next = Math.max(0, (+prev || 0) + delta * 0.5)
      return next.toFixed(1)
    })
  }

  const submitTxn = async () => {
    if (!formReady) return
    const entry = {
      id:     '—',
      time:   new Date().toLocaleTimeString('en-GB', { hour:'2-digit', minute:'2-digit' }),
      wo:     selWO?.woNumber || '—',
      cmp:    compData?.label || selComp,
      qty:    +qty,
      uom:    'KG',
      reason,
      by:     user?.fullName || user?.name || 'Operator',
      type:   mode,
    }
    try {
      const res = await wasteService.create({
        woId:      selWO?.id,
        component: selComp,
        qty:       +qty,
        reason,
        subinv,
        locator,
        notes,
        mode,
        unit:      'KG',
      })
      const created = res?.data ?? res
      if (created?.id) entry.id = created.id
    } catch (_) {}
    setHistory(prev => [entry, ...prev])
    showToast(`Submitted · ${qty} KG · ${reason}`, 'success')
    setQty(''); setReason(''); setNotes('')
    refreshHistory()
  }

  const modeBtnCls = (m) => `msbtn${mode === m ? ` on ${m}` : ''}`

  const initials = (user?.fullName || user?.name || 'WR').split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase()
  const stripTitle = mode === 'scrap' ? 'Waste Recording — Material Scrap'
    : mode === 'fg' ? 'Waste Recording — FG Rejected'
    : 'Waste Recording — Scrap Return'

  return (
    <div>
      {/* Red header bar */}
      <div style={{background:'var(--red2)',padding:'10px 24px',display:'flex',alignItems:'center',gap:'10px',borderBottom:'1px solid var(--red)'}}>
        <span style={{fontSize:'13px',fontWeight:700,color:'var(--red)',letterSpacing:'.5px',fontFamily:"'Space Mono',monospace"}}>⨯ WASTE RECORDING</span>
        <span style={{fontSize:'10px',color:'var(--tx3)',fontWeight:400}}>Material Scrap · FG Reject · Scrap Return</span>
        <div style={{marginLeft:'auto',display:'flex',gap:'8px',alignItems:'center'}}>
          <span style={{fontSize:'10px',color:'var(--tx3)',fontFamily:"'Space Mono',monospace"}}>Day Shift · FPP BU</span>
        </div>
      </div>

      {/* Red breadcrumb */}
      <div className="bc" style={{background:'var(--red2)',borderBottom:'1px solid var(--red)'}}>
        <div className="bci"><div className="bcn pend">1</div>Select Machine</div><div className="bcs">›</div>
        <div className="bci"><div className="bcn pend">2</div>Select Work Order</div><div className="bcs">›</div>
        <div className="bci"><div className="bcn pend">3</div>Pick Component</div><div className="bcs">›</div>
        <div className="bci"><div className="bcn pend">4</div>Enter Qty &amp; Reason</div><div className="bcs">›</div>
        <div className="bci"><div className="bcn pend">5</div>Submit Txn</div>
      </div>

      <div className="lay3">

        {/* ── Left Panel ── */}
        <div className="lpanel">

          {/* Select Machine */}
          <div className="psec">
            <div className="pshdr">
              <div className="pst"><div className="pphdd" style={{background:'var(--tel)'}}/>Select Machine</div>
              <span style={{fontSize:'10px',color:'var(--tx3)'}}>{machines.length} stations</span>
            </div>
            <div className="mlist">
              {machines.length === 0 && (
                <div style={{fontSize:'11px',color:'var(--tx3)',textAlign:'center',padding:'10px'}}>Loading…</div>
              )}
              {machines.map(m => (
                <div key={m.id}
                  className={`mcard${selMachine?.id === m.id ? ' sel' : ''}`}
                  onClick={() => { setSelMachine(m); setSelWO(null); setSelComp(null) }}>
                  <div style={{fontSize:'11px',fontWeight:700,fontFamily:"'Space Mono',monospace",
                    color: selMachine?.id === m.id ? 'var(--tel)' : 'var(--tx)'}}>
                    {m.machineId || m.name}
                  </div>
                  <div style={{fontSize:'10px',color:'var(--tx3)',marginTop:'2px'}}>
                    {[m.type, m.plant].filter(Boolean).join(' · ') || '—'}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Active Work Orders */}
          <div className="psec">
            <div className="pshdr">
              <div className="pst"><div className="pphdd" style={{background:'var(--blu)'}}/>Active Work Orders</div>
              <span style={{fontSize:'10px',color:'var(--tx3)'}}>{selMachine ? `${woList.length} active` : '—'}</span>
            </div>
            <div className="wlist">
              {!selMachine && (
                <div className="empty"><div className="emi">⊟</div>Select a machine to see its work orders</div>
              )}
              {woList.map(wo => (
                <div key={wo.id} onClick={() => { setSelWO(wo); setSelComp(null) }}
                  style={{
                    padding:'10px 14px', borderBottom:'1px solid var(--bor)', cursor:'pointer', transition:'.12s',
                    background: selWO?.id === wo.id ? 'var(--blu2)' : 'transparent',
                  }}>
                  <div className="wrt">
                    <span className="wnum">{wo.woNumber}</span>
                    {selWO?.id === wo.id && <span className="bdg bd" style={{fontSize:'9px'}}>Active</span>}
                  </div>
                  <div className="wprod">{wo.product}</div>
                  <div className="wmeta"><span>{wo.plannedQty ?? 0} units</span></div>
                </div>
              ))}
            </div>
          </div>

          {/* Shift Scrap Totals */}
          <div className="psec">
            <div className="pshdr">
              <div className="pst"><div className="pphdd" style={{background:'var(--amb)'}}/>Shift Scrap Totals</div>
              <span style={{fontSize:'10px',color:'var(--tx3)'}}>Day · so far</span>
            </div>
            <div style={{padding:'11px 13px',display:'grid',gridTemplateColumns:'1fr 1fr',gap:'10px'}}>
              <div>
                <div style={{fontSize:'9px',textTransform:'uppercase',letterSpacing:'.8px',color:'var(--tx3)',fontWeight:600,marginBottom:'3px'}}>Transactions</div>
                <div style={{fontFamily:"'Space Mono',monospace",fontSize:'18px',fontWeight:700,color:'var(--tx)'}}>{summary?.count ?? history.length}</div>
              </div>
              <div>
                <div style={{fontSize:'9px',textTransform:'uppercase',letterSpacing:'.8px',color:'var(--tx3)',fontWeight:600,marginBottom:'3px'}}>Est. Cost</div>
                <div style={{fontFamily:"'Space Mono',monospace",fontSize:'18px',fontWeight:700,color:'var(--red)'}}>
                  {summary?.totalCost ? `SAR ${Number(summary.totalCost).toLocaleString()}` : '—'}
                </div>
              </div>
              <div>
                <div style={{fontSize:'9px',textTransform:'uppercase',letterSpacing:'.8px',color:'var(--tx3)',fontWeight:600,marginBottom:'3px'}}>Returns</div>
                <div style={{fontFamily:"'Space Mono',monospace",fontSize:'18px',fontWeight:700,color:'var(--grn)'}}>{summary?.returns ?? 0}</div>
              </div>
              <div>
                <div style={{fontSize:'9px',textTransform:'uppercase',letterSpacing:'.8px',color:'var(--tx3)',fontWeight:600,marginBottom:'3px'}}>Approval</div>
                <div style={{fontSize:'11px',fontWeight:600,color:'var(--amb)',marginTop:'3px'}}>
                  {summary?.count ? `${summary.count} recorded` : '0 recorded'}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ── Center Panel ── */}
        <div className="rpanel content">

          {/* Identity Strip */}
          <div className="strip">
            <div className="av" style={{background:'var(--red2)',borderColor:'var(--red)',color:'var(--red)'}}>
              {initials}
            </div>
            <div style={{flex:1}}>
              <div className="oname">{stripTitle.toUpperCase()}</div>
              <div className="ometa">
                <span>{selMachine ? (selMachine.machineId || selMachine.name) : 'No selection'}</span>
                <span style={{color:'var(--bor2)'}}>·</span>
                <span>{selWO ? selWO.woNumber : 'Pick a machine on the left to begin'}</span>
              </div>
            </div>
            <div className="modeswitch">
              <button className={modeBtnCls('scrap')} onClick={() => setMode('scrap')}>⨯ Material Scrap</button>
              <button className={`msbtn${mode === 'fg' ? ' on fg' : ''}`} onClick={() => setMode('fg')}>✕ FG Rejected</button>
              <button className={`msbtn${mode === 'return' ? ' on return' : ''}`} onClick={() => setMode('return')}>↺ Scrap Return</button>
            </div>
          </div>

          {/* 4 KPI Stats */}
          <div className="g4">
            <div className="sc" style={{'--sa':'var(--red)'}}>
              <div className="slbl">Scrapped Today</div>
              <div>
                <span className="sval" style={{color:'var(--red)'}}>{summary?.totalQty ?? 0}</span>
                <span className="svu">kg</span>
              </div>
              <div className="ssub">Across {machines.length} machines</div>
            </div>
            <div className="sc" style={{'--sa':'var(--blu)'}}>
              <div className="slbl">Active Work Orders</div>
              <div><span className="sval" style={{color:'var(--blu)'}}>{wos.length}</span><span className="svu">on shift</span></div>
              <div className="ssub">{summary?.count ?? 0} with scrap recorded</div>
            </div>
            <div className="sc" style={{'--sa':'var(--amb)'}}>
              <div className="slbl">Top Reason</div>
              <div><span className="sval" style={{color:'var(--amb)',fontSize:'18px',letterSpacing:'.5px'}}>{summary?.topReason || '—'}</span></div>
              <div className="ssub">Most frequent today</div>
            </div>
            <div className="sc" style={{'--sa':'var(--grn)'}}>
              <div className="slbl">Scrap Rate</div>
              <div>
                <span className="sval" style={{color:'var(--grn)'}}>
                  {wos.length && summary?.totalQty
                    ? (summary.totalQty / wos.reduce((s, w) => s + (w.plannedQty || 0), 0) * 100).toFixed(2)
                    : '0.00'}
                </span>
                <span className="svu">%</span>
              </div>
              <div className="pbar"><div className="pfil" style={{width:'5%',background:'var(--grn)'}}/></div>
            </div>
          </div>

          {/* Components Picker */}
          <div className="sh">
            <div className="st">
              <div className="sd" style={{background:'var(--blu)'}}/>
              Issued Components
              <span style={{fontSize:'11px',color:'var(--tx3)',fontWeight:400,marginLeft:'6px'}}>
                {selWO ? `${compList.length} types` : 'Select a work order first'}
              </span>
            </div>
          </div>
          <div className="cgrid">
            {!selWO && (
              <div className="empty" style={{gridColumn:'1/-1',background:'var(--bg2)',border:'1px dashed var(--bor)',borderRadius:'var(--rl)'}}>
                <div className="emi">⊞</div>
                Components appear after a work order is selected
              </div>
            )}
            {compList.map(wt => (
              <div key={wt.id}
                onClick={() => setSelComp(wt.id)}
                style={{
                  background: selComp === wt.id ? 'var(--blu2)' : 'var(--bg2)',
                  border: `1px solid ${selComp === wt.id ? 'var(--blu)' : 'var(--bor)'}`,
                  borderRadius:'var(--rl)', padding:'12px 14px', cursor:'pointer', transition:'.12s',
                }}>
                <div style={{fontSize:'11px',fontWeight:700,color:'var(--tx)',marginBottom:'4px'}}>{wt.label}</div>
                <div style={{fontSize:'10px',color:'var(--tx3)',fontFamily:"'Space Mono',monospace"}}>{wt.id}</div>
                <div style={{display:'flex',gap:'12px',marginTop:'8px',fontSize:'10px',color:'var(--tx3)'}}>
                  <span>Category: <b style={{color:'var(--tx)'}}>{wt.category || '—'}</b></span>
                </div>
              </div>
            ))}
          </div>

          {/* Recording Form */}
          <div className={`fcard${!selComp ? ' dis' : ''}`}>
            <div className="sh" style={{marginBottom:'14px'}}>
              <div className="st">
                <div className="sd" style={{background:'var(--red)'}}/>
                <span>Record {mode === 'scrap' ? 'Material Scrap' : mode === 'fg' ? 'FG Rejected' : 'Scrap Return'}</span>
              </div>
              <span style={{fontSize:'11px',color:'var(--tx3)',fontFamily:"'Space Mono',monospace"}}>TXN ID will generate on submit</span>
            </div>

            {/* Row 1: Quantity + Reason */}
            <div className="frow">
              <div className="fgrp" style={{gridColumn:'1/3'}}>
                <label>Quantity to {mode === 'scrap' ? 'Scrap' : mode === 'fg' ? 'Reject' : 'Return'}</label>
                <div className="qty-input">
                  <button className="qb" onClick={() => adjQty(-1)}>−</button>
                  <input type="number" value={qty} onChange={e => setQty(e.target.value)}
                    placeholder="0" step="0.5" min="0"/>
                  <button className="qb" onClick={() => adjQty(1)}>+</button>
                  <div className="uom">KG</div>
                </div>
              </div>
              <div className="fgrp">
                <label>Reason Code</label>
                <select value={reason} onChange={e => setReason(e.target.value)}>
                  <option value="">— Select reason —</option>
                  {REASON_CODES.map(grp => (
                    <optgroup key={grp.group} label={grp.group}>
                      {grp.options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                    </optgroup>
                  ))}
                </select>
                <div className="rchips">
                  {QUICK_REASONS.map(r => (
                    <span key={r} className={`rchip${reason === r ? ' sel' : ''}`} onClick={() => setReason(r)}>{r}</span>
                  ))}
                </div>
              </div>
            </div>

            {/* Row 2: Destination */}
            <div className="frow">
              <div className="fgrp">
                <label>Destination Subinventory</label>
                <select value={subinv} onChange={e => setSubinv(e.target.value)}>
                  {SUBINVS.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
                </select>
              </div>
              <div className="fgrp">
                <label>Locator</label>
                <select value={locator} onChange={e => setLocator(e.target.value)}>
                  {LOCATORS.map(l => <option key={l.value} value={l.value}>{l.label}</option>)}
                </select>
              </div>
              <div className="fgrp">
                <label>Transaction Date / Time</label>
                <input type="datetime-local" value={txnDate} onChange={e => setTxnDate(e.target.value)}/>
              </div>
            </div>

            {/* Row 3: Notes */}
            <div className="frow one">
              <div className="fgrp">
                <label>
                  Transaction Notes
                  <span style={{color:'var(--tx3)',fontWeight:400,textTransform:'none',letterSpacing:0,marginLeft:'6px'}}>— optional</span>
                </label>
                <textarea value={notes} onChange={e => setNotes(e.target.value)}
                  placeholder="e.g. Defective lot — discovered on inspection of first 40 parts after color change."/>
              </div>
            </div>

            {/* Footer */}
            <div className="formfoot">
              <div className="fhint">
                Posting will record <b>{compData?.label || 'component'}</b> waste at{' '}
                <b>{subinv} / {locator}</b> and write a{' '}
                <b>{mode === 'scrap' ? 'Material Scrap' : mode === 'fg' ? 'FG Reject' : 'Scrap Return'}</b> txn against{' '}
                <b>{selWO?.woNumber || 'WO'}</b>.
              </div>
              <div style={{display:'flex',gap:'8px'}}>
                <button className="btn bgh" onClick={() => { setQty(''); setReason(''); setNotes('') }}>Clear</button>
                <button className="btn bpri blg" disabled={!formReady} onClick={submitTxn}>
                  Submit Scrap Txn
                </button>
              </div>
            </div>
          </div>

          {/* History */}
          <div className="sh">
            <div className="st"><div className="sd" style={{background:'var(--pur)'}}/>Recent Scrap Transactions</div>
          </div>
          <div className="twrap">
            <table>
              <thead>
                <tr>
                  <th style={{width:'36px'}}></th>
                  <th>TXN ID</th>
                  <th>Time</th>
                  <th>WO</th>
                  <th>Component</th>
                  <th style={{textAlign:'right'}}>Qty</th>
                  <th>Reason</th>
                  <th>By</th>
                </tr>
              </thead>
              <tbody>
                {history.length === 0 && (
                  <tr><td colSpan={8} style={{textAlign:'center',padding:'20px',color:'var(--tx3)',fontSize:'12px'}}>No transactions recorded yet.</td></tr>
                )}
                {history.map((t, i) => (
                  <tr key={t.id || i}>
                    <td style={{textAlign:'center'}}>
                      <span style={{fontSize:'14px'}}>{t.type === 'scrap' ? '⨯' : t.type === 'return' ? '↺' : '✕'}</span>
                    </td>
                    <td><span className="woid" style={{fontSize:'10px'}}>{t.id}</span></td>
                    <td style={{fontFamily:"'Space Mono',monospace",fontSize:'11px',color:'var(--tx3)'}}>{t.time}</td>
                    <td><span className="woid" style={{fontSize:'10px'}}>{t.wo}</span></td>
                    <td style={{fontSize:'11px',color:'var(--tx)'}}>{t.cmp}</td>
                    <td style={{textAlign:'right'}}>
                      <span className={`txn-qty ${t.type}`}>{t.type === 'return' ? '+' : '-'}{t.qty}</span>
                      <span style={{fontSize:'10px',color:'var(--tx3)',fontFamily:"'Space Mono',monospace",marginLeft:'4px'}}>{t.uom}</span>
                    </td>
                    <td><span className="bdg" style={{background:'var(--bg3)',borderColor:'var(--bor)',color:'var(--tx2)',fontSize:'10px'}}>{t.reason}</span></td>
                    <td style={{fontSize:'11px',color:'var(--tx3)'}}>{t.by}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* ── Right Panel ── */}
        <div className="rrpanel">

          <div className="rrcard">
            <div className="rrtit"><div className="rrsq" style={{background:'var(--red)'}}/>Component Snapshot</div>
            {!compData ? (
              <div style={{fontSize:'11px',color:'var(--tx3)',lineHeight:1.6}}>
                Pick a component from the centre grid to see details and recent posting trend.
              </div>
            ) : (
              <div>
                <div style={{fontSize:'13px',fontWeight:600,color:'var(--tx)',marginBottom:'10px'}}>{compData.label}</div>
                {[
                  { label: 'Type ID',     val: compData.id,       color: 'var(--tx)'  },
                  { label: 'Category',    val: compData.category, color: 'var(--tel)' },
                  { label: 'Issued to WO',val: '—',               color: 'var(--tx)'  },
                  { label: 'On-hand',     val: '—',               color: 'var(--grn)' },
                  { label: 'Scrapped',    val: '—',               color: 'var(--red)' },
                ].map(row => (
                  <div key={row.label} style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:'7px'}}>
                    <span style={{fontSize:'11px',color:'var(--tx3)'}}>{row.label}</span>
                    <span style={{fontFamily:"'Space Mono',monospace",fontSize:'11px',fontWeight:700,color:row.color}}>{row.val}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="rrcard">
            <div className="rrtit"><div className="rrsq" style={{background:'var(--amb)'}}/>Reason Distribution · Today</div>
            {(() => {
              if (!history.length) return <div style={{fontSize:'11px',color:'var(--tx3)'}}>No data yet.</div>
              const counts = {}
              history.forEach(h => { if (h.reason) counts[h.reason] = (counts[h.reason] || 0) + 1 })
              const total = Object.values(counts).reduce((s, n) => s + n, 0) || 1
              return Object.entries(counts).slice(0, 5).map(([r, n]) => {
                const pct = Math.round(n * 100 / total)
                return (
                  <div key={r} style={{marginBottom:'8px'}}>
                    <div style={{display:'flex',justifyContent:'space-between',fontSize:'10px',color:'var(--tx2)',marginBottom:'3px'}}>
                      <span>{r}</span><span style={{color:'var(--tx3)'}}>{pct}%</span>
                    </div>
                    <div style={{height:'4px',background:'var(--bg4)',borderRadius:'2px',overflow:'hidden'}}>
                      <div style={{height:'100%',width:`${pct}%`,background:'var(--amb)',borderRadius:'2px'}}/>
                    </div>
                  </div>
                )
              })
            })()}
          </div>

          <div className="rrcard">
            <div className="rrtit"><div className="rrsq" style={{background:'var(--blu)'}}/>Work Order Progress</div>
            {!selWO ? (
              <div style={{fontSize:'11px',color:'var(--tx3)'}}>— select a WO —</div>
            ) : (
              <div>
                <div style={{fontSize:'12px',fontWeight:600,color:'var(--tx)',marginBottom:'8px'}}>{selWO.woNumber}</div>
                <div style={{fontSize:'11px',color:'var(--tx3)',marginBottom:'6px'}}>{selWO.product}</div>
                <div style={{height:'6px',background:'var(--bg4)',borderRadius:'3px',overflow:'hidden',marginBottom:'6px'}}>
                  <div style={{height:'100%',
                    width: selWO.plannedQty
                      ? `${Math.min(100, Math.round((selWO.producedQty || 0) * 100 / selWO.plannedQty))}%`
                      : '0%',
                    background:'var(--grn)',borderRadius:'3px'}}/>
                </div>
                <div style={{fontSize:'10px',color:'var(--tx3)'}}>
                  {selWO.producedQty || 0} / {selWO.plannedQty || 0} · target
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
