import { useEffect, useMemo, useState } from 'react'
import { useAuth } from '../../contexts/AuthContext'
import { useApp } from '../../contexts/AppContext'
import { setupService } from '../../services/api'

const QUICK_USERS_KEY = 'mes_quick_login_users'
const LAST_EMP_KEY = 'mes_last_emp_id'
const LAST_ROLE_KEY = 'mes_last_role'
const LAST_MACHINE_KEY = 'mes_last_machine_id'


const ROLE_OPTIONS = [
  { id: 'tech', icon: '👨‍🔧', label: 'Process Tech' },
  { id: 'operator', icon: '🖨', label: 'Operator' },
  { id: 'qc', icon: '🔍', label: 'QC Inspector' },
  { id: 'packer', icon: '📦', label: 'Packer' },
  { id: 'System Admin', icon: '🛡', label: 'System Admin' },
]

const ROLE_META = {
  tech: {
    icon: '👨‍🔧',
    label: 'Process Technician',
    color: 'var(--blu)',
    border: 'var(--bor2)',
    shadow: '',
  },
  operator: {
    icon: '🖨',
    label: 'Operator',
    color: 'var(--tel)',
    border: 'var(--bor2)',
    shadow: '',
  },
  qc: {
    icon: '🔍',
    label: 'QC Inspector',
    color: 'var(--grn)',
    border: 'var(--bor2)',
    shadow: '',
  },
  packer: {
    icon: '📦',
    label: 'Packer',
    color: 'var(--amb)',
    border: 'var(--bor2)',
    shadow: '',
  },
  "System Admin": {
    icon: '🛡',
    label: 'Service System Admin · Full Access',
    color: 'var(--pur)',
    border: 'var(--pur)',
    shadow: '0 0 0 2px var(--pur2)',
  },
}

const FALLBACK_MACHINES = [
  { id: 'ZFP001', machineId: 'ZFP001', code: 'ZFP001', name: 'ZFP001', type: 'INJECTION', label: 'ZFP001 - ZFP001 - INJECTION' },
  { id: 'ZFP002', machineId: 'ZFP002', code: 'ZFP002', name: 'ZFP002', type: 'INJECTION', label: 'ZFP002 - ZFP002 - INJECTION' },
  { id: 'ZBL010', machineId: 'ZBL010', code: 'ZBL010', name: 'ZBL010', type: 'BLOW MOULDING', label: 'ZBL010 - ZBL010 - BLOW MOULDING' },
  { id: 'ZPK005', machineId: 'ZPK005', code: 'ZPK005', name: 'ZPK005', type: 'PACKAGING LINE', label: 'ZPK005 - ZPK005 - PACKAGING LINE' },
  { id: 'INJ-077', machineId: 'INJ-077', code: 'INJ-077', name: 'INJ-077', type: 'INJECTION', label: 'INJ-077 - INJ-077 - INJECTION' },
  { id: 'INJ-083', machineId: 'INJ-083', code: 'INJ-083', name: 'INJ-083', type: 'INJECTION', label: 'INJ-083 - INJ-083 - INJECTION' },
]

const safeSessionGet = (key, fallback = '') => {
  try {
    return sessionStorage.getItem(key) || fallback
  } catch (_) {
    return fallback
  }
}

const safeSessionSet = (key, value) => {
  try {
    sessionStorage.setItem(key, value)
  } catch (_) {}
}

const readQuickUsers = () => {
  try {
    const raw = sessionStorage.getItem(QUICK_USERS_KEY)
    const parsed = raw ? JSON.parse(raw) : []
    return Array.isArray(parsed) ? parsed : []
  } catch (_) {
    return []
  }
}

const saveQuickUsers = (users) => {
  try {
    sessionStorage.setItem(QUICK_USERS_KEY, JSON.stringify(users))
  } catch (_) {}
}

const normalizeApiList = (res) => {
  const payload = res?.data ?? res

  if (Array.isArray(payload)) return payload
  if (Array.isArray(payload?.rows)) return payload.rows
  if (Array.isArray(payload?.data)) return payload.data
  if (Array.isArray(payload?.data?.rows)) return payload.data.rows
  if (Array.isArray(payload?.items)) return payload.items

  return []
}

const normalizeMachine = (m) => {
  const id = m?.id || m?.machineId || m?.code || ''
  const code = m?.code || m?.machineId || id
  const name = m?.name || code
  const type = m?.type || m?.dept || m?.area || ''

  return {
    ...m,
    id,
    machineId: m?.machineId || code,
    code,
    name,
    type,
    label: type ? `${code} - ${name} - ${type}` : `${code} - ${name}`,
  }
}

const getUserEmpId = (user, fallbackEmpId = '') => {
  return (
    user?.empId ||
    user?.employeeId ||
    user?.employeeCode ||
    user?.username ||
    fallbackEmpId ||
    ''
  )
}

const getUserName = (user, fallbackEmpId = '') => {
  return (
    user?.name ||
    user?.fullName ||
    user?.displayName ||
    user?.username ||
    fallbackEmpId ||
    'User'
  )
}

const getUserRole = (user, fallbackRole = '') => {
  return user?.role || user?.roleName || fallbackRole || ''
}

const normalizeQuickUser = ({ user, empId, role, machine }) => {
  const finalEmpId = getUserEmpId(user, empId)
  const finalRole = getUserRole(user, role)
  const meta = ROLE_META[finalRole] || {
    icon: '👤',
    label: finalRole || 'User',
    color: 'var(--tx2)',
    border: 'var(--bor2)',
    shadow: '',
  }

  return {
    id: user?.id || finalEmpId,
    empId: finalEmpId,
    name: getUserName(user, finalEmpId),
    role: finalRole,
    roleLabel: meta.label,
    roleColor: meta.color,
    icon: meta.icon,
    border: meta.border,
    shadow: meta.shadow,
    machineId: machine?.id || machine?.machineId || machine?.code || '',
    machineCode: machine?.code || machine?.machineId || '',
    lastLoginAt: new Date().toISOString(),
  }
}

const upsertQuickUser = (quickUser) => {
  if (!quickUser?.empId) return readQuickUsers()

  const existing = readQuickUsers()
  const withoutCurrent = existing.filter(
    u => String(u.empId).toUpperCase() !== String(quickUser.empId).toUpperCase()
  )

  const updated = [quickUser, ...withoutCurrent].slice(0, 6)
  saveQuickUsers(updated)
  return updated
}

export default function Login() {
  const { login, setMachine } = useAuth()
  const { theme, setTheme } = useApp()

  const [quickUsers, setQuickUsers] = useState(() => readQuickUsers())
  const [empId, setEmpId] = useState(() => safeSessionGet(LAST_EMP_KEY))
  const [password, setPassword] = useState('')
  const [role, setRole] = useState(() => safeSessionGet(LAST_ROLE_KEY))
  const [machineId, setMachineId] = useState(() => safeSessionGet(LAST_MACHINE_KEY))
  const [machines, setMachines] = useState([])
  const [loadingMachines, setLoadingMachines] = useState(false)
  const [error, setError] = useState('')
  const [submitting, setSub] = useState(false)

  useEffect(() => {
    let alive = true

    const loadMachines = async () => {
      setLoadingMachines(true)

      try {
        const res = await setupService.getMachines({ limit: 100 })
        const list = normalizeApiList(res).map(normalizeMachine).filter(m => m.id)

        if (!alive) return

        const finalList = list.length ? list : FALLBACK_MACHINES
        setMachines(finalList)

        const savedMachine = safeSessionGet(LAST_MACHINE_KEY)
        const exists = finalList.some(m => String(m.id) === String(savedMachine))

        if (savedMachine && exists) {
          setMachineId(savedMachine)
        } else if (finalList[0]?.id) {
          setMachineId(finalList[0].id)
        }
      } catch (_) {
        if (!alive) return

        setMachines(FALLBACK_MACHINES)

        if (!machineId && FALLBACK_MACHINES[0]?.id) {
          setMachineId(FALLBACK_MACHINES[0].id)
        }
      } finally {
        if (alive) setLoadingMachines(false)
      }
    }

    loadMachines()

    return () => {
      alive = false
    }
  }, [])

  const selectedMachine = useMemo(() => {
    return machines.find(m => String(m.id) === String(machineId)) || machines[0] || null
  }, [machines, machineId])

  const roleOptionsToShow = useMemo(() => {
    if (!role) return ROLE_OPTIONS

    const selected = ROLE_OPTIONS.find(r => r.id === role)
    const others = ROLE_OPTIONS.filter(r => r.id !== role)

    return selected ? [selected, ...others] : ROLE_OPTIONS
  }, [role])

  const handleQuickUserClick = (u) => {
    setEmpId(u.empId || '')
    setRole(u.role || '')
    setPassword('')
    setError('')

    if (u.machineId) {
      const exists = machines.some(m => String(m.id) === String(u.machineId))
      if (exists) {
        setMachineId(u.machineId)
      }
    }
  }

  const handleSubmit = async () => {
    if (!empId || !password || !role || !machineId) {
      setError('Please fill in Employee ID, Password, Role and Machine / Station.')
      return
    }

    setSub(true)
    setError('')

    try {
      const apiUser = await login({
        empId,
        password,
        machineId,
      })

      if (selectedMachine) {
        setMachine(selectedMachine)
        sessionStorage.setItem('mes_machine', JSON.stringify(selectedMachine))
      }

      const finalRole = apiUser?.role || role

      safeSessionSet(LAST_EMP_KEY, getUserEmpId(apiUser, empId))
      safeSessionSet(LAST_ROLE_KEY, finalRole)
      safeSessionSet(LAST_MACHINE_KEY, selectedMachine?.id || machineId)

      const savedQuickUser = normalizeQuickUser({
        user: apiUser,
        empId,
        role: finalRole,
        machine: selectedMachine,
      })

      const updatedQuickUsers = upsertQuickUser(savedQuickUser)
      setQuickUsers(updatedQuickUsers)
    } catch (err) {
      setError(err.message || 'Login failed')
    } finally {
      setSub(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-2 " style={{ background: 'var(--bg)' }}>
      <div className="login-card fade-in" style={{ width: '430px', maxWidth: '100%', padding: '22px 24px' }}>

        {/* Logo */}
        <div className="login-logo" style={{ marginBottom: '12px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '9px', marginBottom: '6px' }}>
            <div style={{ width: '34px', height: '34px', background: 'var(--grn)', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '18px', fontWeight: 900, color: '#fff', fontFamily: "'Space Mono',monospace" }}>Z</div>
            <div style={{ fontFamily: "'Space Mono',monospace", fontSize: '18px', fontWeight: 700, color: 'var(--grn)', letterSpacing: '1px' }}>Zamil Operations</div>
          </div>
          <div className="login-logo-sub   flex items-center justify-center" style={{ fontSize: '11px' }} >Smart Manufacturing Dashboard · FPP / IPP BU</div>
        </div>

        <div style={{ fontSize: '13px', color: 'var(--tx2)', marginBottom: '13px', textAlign: 'center' }}>
          Sign in with your employee account
        </div>

        {/* Error */}
        {error && <div className="login-err" style={{ display: 'block', marginBottom: '10px' }}>{error}</div>}

        {/* Quick Login - only users already logged in during this browser session */}
        {quickUsers.length > 0 && (
          <div style={{ marginBottom: '12px' }}>
            <label style={{ marginBottom: '6px', fontSize: '12px' }}>Quick Login — Select Account</label>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6px' }}>
              {quickUsers.map(u => (
                <QuickUserCard
                  key={u.empId}
                  user={u}
                  active={String(empId).toUpperCase() === String(u.empId).toUpperCase()}
                  onClick={() => handleQuickUserClick(u)}
                />
              ))}
            </div>

            <div style={{ fontSize: '9.5px', color: 'var(--tx3)', textAlign: 'center', marginTop: '6px' }}>
              Select a previously signed-in account, then enter password
            </div>
          </div>
        )}

        {quickUsers.length > 0 && <div style={{ height: '1px', background: 'var(--bor)', marginBottom: '12px' }} />}

        {/* EmpID */}
        <div className="fgrp" style={{ marginBottom: '10px' }}>
          <label style={{ fontSize: '12px' }}>Employee ID</label>
          <input
            value={empId}
            onChange={e => {
              setEmpId(e.target.value)
              setError('')
            }}
            placeholder="e.g. EMP-2479"
            onKeyDown={e => e.key === 'Enter' && handleSubmit()}
          />
        </div>

        {/* Password */}
        <div className="fgrp" style={{ marginBottom: '10px' }}>
          <label style={{ fontSize: '12px' }}>Password</label>
          <input
            type="password"
            value={password}
            onChange={e => setPassword(e.target.value)}
            placeholder="Enter password"
            onKeyDown={e => e.key === 'Enter' && handleSubmit()}
          />
        </div>

        {/* Role */}
        <div className="fgrp" style={{ marginBottom: '10px' }}>
          <label style={{ fontSize: '12px' }}>
            Role
            {role && (
              <span style={{ marginLeft: '6px', fontSize: '10px', color: 'var(--grn)' }}>
                selected from user profile
              </span>
            )}
          </label>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gap: '6px', marginTop: '6px' }}>
            {roleOptionsToShow.map(r => (
              <div
                key={r.id}
                className={`role-card ${role === r.id ? 'sel' : ''}`}
                onClick={() => setRole(r.id)}
                style={{ padding: '8px 5px' }}
              >
                <div className="rico" style={{ fontSize: '18px', marginBottom: '3px' }}>{r.icon}</div>
                <div className={`rnm ${role === r.id ? 'text-blu' : ''}`} style={{ fontSize: '9.5px', lineHeight: 1.15 }}>
                  {r.label}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Machine */}
        <div className="fgrp" style={{ marginBottom: '10px' }}>
          <label style={{ fontSize: '12px' }}>Machine / Station</label>
          <select
            value={machineId}
            onChange={e => {
              setMachineId(e.target.value)
              safeSessionSet(LAST_MACHINE_KEY, e.target.value)
            }}
            disabled={loadingMachines}
          >
            {machines.map(m => (
              <option key={m.id} value={m.id}>
                {m.label}
              </option>
            ))}
          </select>

          <div style={{ fontSize: '9.5px', color: 'var(--tx3)', marginTop: '4px' }}>
            {loadingMachines ? 'Loading machines from backend...' : selectedMachine ? `Selected: ${selectedMachine.code || selectedMachine.machineId}` : 'No machine selected'}
          </div>
        </div>

        {/* Theme */}
        <div className="fgrp" style={{ marginBottom: '12px' }}>
          <label style={{ fontSize: '12px' }}>Theme</label>
          <div style={{ display: 'flex', gap: '6px', marginTop: '6px' }}>
            <button className={`tbtn tbk ${theme === 'black' ? 'on' : ''}`} onClick={() => setTheme('black')} style={{ flex: 1, padding: '5px 8px' }}>Black</button>
            <button className={`tbtn tbw ${theme === 'white' ? 'on' : ''}`} onClick={() => setTheme('white')} style={{ flex: 1, padding: '5px 8px' }}>White</button>
            <button className={`tbtn tbz ${theme === 'zamil' ? 'on' : ''}`} onClick={() => setTheme('zamil')} style={{ flex: 1, padding: '5px 8px' }}>Zamil Green</button>
          </div>
        </div>

        {/* Submit */}
        <button className="login-btn" onClick={handleSubmit} disabled={submitting || loadingMachines} style={{ marginTop: '12px', padding: '10px' }}>
          {submitting ? 'Signing in...' : 'Sign In'}
        </button>

        <div style={{ textAlign: 'center', fontSize: '10px', color: 'var(--tx3)', marginTop: '9px' }}>
          Zamil Plastics · FPP BU · v3.0
        </div>
      </div>
    </div>
  )
}

function QuickUserCard({ user, active, onClick }) {
  return (
    <div
      className="demo-acc"
      onClick={onClick}
      style={{
        background: active ? 'var(--blu2)' : 'var(--bg3)',
        border: `1.5px solid ${active ? 'var(--blu)' : user.border}`,
        borderRadius: 'var(--r)',
        padding: '7px 7px',
        textAlign: 'center',
        cursor: 'pointer',
        transition: '.15s',
        boxShadow: active ? '0 0 0 2px var(--blu2)' : user.shadow || 'none',
      }}
    >
      <div style={{ fontSize: '16px', marginBottom: '2px' }}>{user.icon}</div>
      <div style={{ fontSize: '10.5px', fontWeight: 600, color: 'var(--tx)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
        {user.name}
      </div>
      <div style={{ fontSize: '9.5px', color: user.roleColor, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
        {user.roleLabel}
      </div>
      <div style={{ fontSize: '8.8px', color: 'var(--tx3)', fontFamily: "'Space Mono',monospace", marginTop: '2px' }}>
        {user.empId}
      </div>
    </div>
  )
}