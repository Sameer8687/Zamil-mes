import { useEffect, useMemo, useRef, useState } from "react";
import { useAuth } from "../../contexts/AuthContext";
import { useApp } from "../../contexts/AppContext";
import { productionService, setupService } from "../../services/api";
import useClock from "../../hooks/useClock";

const PRIORITY_OPTS = [
  {
    value: "1",
    rank: 1,
    label: "1 – High",
    badgeStyle: "background:#fee2e2;color:#991b1b;border-color:#fca5a5",
  },
  {
    value: "2",
    rank: 2,
    label: "2 – Medium",
    badgeStyle:
      "background:var(--amb2);color:var(--amb);border-color:var(--amb)",
  },
  {
    value: "3",
    rank: 3,
    label: "3 – low",
    badgeStyle:
      "background:var(--grn2);color:var(--grn);border-color:var(--grn)",
  },
];

const LEGACY_PRIORITY_TO_RANK = {
  urgent: 1,
  high: 1,
  medium: 2,
  normal: 3,
  low: 3,
};

const RANK_TO_LEGACY_PRIORITY = {
  1: "high",
  2: "normal",
  3: "low",
};

const STATUS_LABELS = {
  notStarted: "Not Started",
  running: "Running",
  onHold: "On Hold",
  terminated: "Terminated",
  completed: "Completed",
};

const STATUS_TO_API = {
  start: "active",
  resume: "active",
  hold: "paused",
  terminate: "cancelled",
};

const ACTION_META = {
  start: {
    label: "▶ Start",
    title: "Start Work Order",
    confirm: "Start",
    message: (wo) =>
      `Start WO ${getWONumber(wo)}? Machine will begin production.`,
    color: "var(--grn)",
    nextStatus: STATUS_LABELS.running,
  },
  hold: {
    label: "⏸ Hold",
    title: "Hold Work Order",
    confirm: "Hold",
    message: (wo) =>
      `Put WO ${getWONumber(wo)} on hold? Production will pause.`,
    color: "var(--amb)",
    nextStatus: STATUS_LABELS.onHold,
  },
  resume: {
    label: "▶ Resume",
    title: "Resume Work Order",
    confirm: "Resume",
    message: (wo) => `Resume WO ${getWONumber(wo)}? Production will restart.`,
    color: "var(--grn)",
    nextStatus: STATUS_LABELS.running,
  },
  terminate: {
    label: "✕ Terminate",
    title: "Terminate Work Order",
    confirm: "Terminate",
    message: (wo) =>
      `Terminate WO ${getWONumber(wo)}? This action cannot be undone.`,
    color: "var(--red)",
    nextStatus: STATUS_LABELS.terminated,
  },
};

const EMPTY_BOX_QTY_LEFT = [
  { code: "No Data", qty: "-", boxes: "-", packer: "-" },
];

const EMPTY_BOX_QTY_RIGHT = [
  { code: "No Data", qty: "-", boxes: "-", packer: "-" },
];

const getTotalBoxes = (wo) => {
  const plannedQty = Number(wo?.plannedQty || 0);
  const boxQty = Number(wo?.boxQty || 0);

  if (!plannedQty || !boxQty) return 0;

  return Math.ceil(plannedQty / boxQty);
};
function useElapsed() {
  const [elapsed, setElapsed] = useState("00:00");
  const startRef = useRef(Date.now());

  useEffect(() => {
    const id = setInterval(() => {
      const sec = Math.floor((Date.now() - startRef.current) / 1000);
      const h = Math.floor(sec / 3600);
      const m = Math.floor((sec % 3600) / 60);
      const s = sec % 60;

      if (h > 0) {
        setElapsed(
          `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`,
        );
      } else {
        setElapsed(
          `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`,
        );
      }
    }, 1000);

    return () => clearInterval(id);
  }, []);

  return elapsed;
}

function normalizeApiList(res) {
  if (Array.isArray(res?.data?.rows)) return res.data.rows;
  if (Array.isArray(res?.data?.items)) return res.data.items;
  if (Array.isArray(res?.data?.records)) return res.data.records;
  if (Array.isArray(res?.data?.workOrders)) return res.data.workOrders;
  if (Array.isArray(res?.data)) return res.data;

  if (Array.isArray(res?.rows)) return res.rows;
  if (Array.isArray(res?.items)) return res.items;
  if (Array.isArray(res?.records)) return res.records;
  if (Array.isArray(res?.workOrders)) return res.workOrders;
  if (Array.isArray(res)) return res;

  return [];
}

function normalizeApiObject(res) {
  if (res?.data?.workOrder) return res.data.workOrder;
  if (res?.data?.record) return res.data.record;
  if (res?.data?.item) return res.data.item;
  if (res?.data && !Array.isArray(res.data)) return res.data;
  if (res?.workOrder) return res.workOrder;
  if (res?.record) return res.record;
  if (res?.item) return res.item;
  if (res && typeof res === "object" && !Array.isArray(res)) return res;
  return null;
}

function normalizeNumber(value) {
  const num = Number(value);
  return Number.isFinite(num) ? num : 0;
}

function formatNumber(value) {
  return normalizeNumber(value).toLocaleString();
}

function coalesce(...values) {
  return values.find(
    (value) => value !== undefined && value !== null && value !== "",
  );
}

function getWOKey(wo) {
  return coalesce(
    wo?.id,
    wo?._id,
    wo?.workOrderId,
    wo?.woId,
    wo?.woNumber,
    wo?.idNumber,
  );
}

function getWONumber(wo) {
  return coalesce(
    wo?.woNumber,
    wo?.workOrderNumber,
    wo?.number,
    wo?.id,
    wo?._id,
    "-",
  );
}

function getPriorityRank(wo) {
  const raw = coalesce(
    wo?.priority,
    wo?.priorityRank,
    wo?.executionPriority,
    wo?.sequencePriority,
  );
  const parsed = Number(raw);

  if (Number.isFinite(parsed) && parsed > 0) {
    return Math.min(3, Math.max(1, Math.round(parsed)));
  }

  const legacy = LEGACY_PRIORITY_TO_RANK[String(raw || "").toLowerCase()];
  return legacy || 3;
}

function getSequenceRank(wo, index = 0) {
  const raw = coalesce(
    wo?.executionSequence,
    wo?.sequence,
    wo?.sortOrder,
    wo?.lineSequence,
    wo?.displayOrder,
  );
  const parsed = Number(raw);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : index + 1;
}

function getWOStatus(wo) {
  const raw = String(
    coalesce(wo?.woStatus, wo?.workOrderStatus, wo?.status, "Not Started"),
  ).trim();
  const value = raw.toLowerCase().replace(/[_-]+/g, " ");

  if (["running", "run", "active", "in progress", "started"].includes(value))
    return STATUS_LABELS.running;
  if (["on hold", "hold", "paused", "pause"].includes(value))
    return STATUS_LABELS.onHold;
  if (["terminated", "cancelled", "canceled", "cancel", "void"].includes(value))
    return STATUS_LABELS.terminated;
  if (["completed", "complete", "done", "closed"].includes(value))
    return STATUS_LABELS.completed;
  if (
    ["pending", "not started", "new", "open", "created", "scheduled"].includes(
      value,
    )
  )
    return STATUS_LABELS.notStarted;

  return raw || STATUS_LABELS.notStarted;
}

function getWOOperation(wo) {
  return coalesce(
    wo?.op,
    wo?.operation,
    wo?.operationName,
    wo?.department,
    "INJECTION",
  );
}

function getWOProduct(wo) {
  return coalesce(
    wo?.product,
    wo?.productName,
    wo?.itemName,
    wo?.description,
    "-",
  );
}

function getWOSubtitle(wo) {
  return coalesce(
    wo?.sub,
    wo?.variant,
    wo?.notes,
    wo?.customer,
    wo?.itemDescription,
    "",
  );
}

function getWOCode(wo) {
  return coalesce(
    wo?.code,
    wo?.itemCode,
    wo?.productCode,
    wo?.fgCode,
    wo?.sku,
    "-",
  );
}

function getWOQty(wo) {
  return normalizeNumber(
    coalesce(wo?.qty, wo?.plannedQty, wo?.quantity, wo?.totalQty, wo?.orderQty),
  );
}

function getWOCompletedQty(wo) {
  return normalizeNumber(
    coalesce(
      wo?.completedQty,
      wo?.producedQty,
      wo?.completedQuantity,
      wo?.doneQty,
      wo?.goodQty,
    ),
  );
}

function getWOBoxes(wo) {
  const existingBoxes = normalizeNumber(
    coalesce(
      wo?.boxes,
      wo?.boxesTotal,
      wo?.totalBoxes,
      wo?.boxCount,
      wo?.plannedBoxes,
    ),
  );

  if (existingBoxes > 0) return existingBoxes;

  const plannedQty = normalizeNumber(
    coalesce(wo?.plannedQty, wo?.qty, wo?.quantity, wo?.totalQty, wo?.orderQty),
  );
  const boxQty = normalizeNumber(
    coalesce(wo?.boxQty, wo?.qtyPerBox, wo?.quantityPerBox),
  );

  if (!plannedQty || !boxQty) return 0;

  return Math.ceil(plannedQty / boxQty);
}

function getWOBoxesPrinted(wo) {
  return normalizeNumber(
    coalesce(
      wo?.boxesPrinted,
      wo?.printedBoxes,
      wo?.boxesDone,
      wo?.labelsPrinted,
    ),
  );
}

function getStatusBadge(status) {
  if (status === STATUS_LABELS.running) {
    return {
      cls: "bd",
      content: (
        <>
          <span
            style={{
              width: "5px",
              height: "5px",
              borderRadius: "50%",
              background: "var(--grn)",
              display: "inline-block",
              animation: "pulse 1.5s infinite",
              marginRight: "3px",
            }}
          />
          Running
        </>
      ),
    };
  }

  if (status === STATUS_LABELS.onHold)
    return { cls: "bamb", content: "⏸ On Hold" };
  if (status === STATUS_LABELS.terminated)
    return { cls: "brj", content: "✕ Terminated" };
  if (status === STATUS_LABELS.completed)
    return { cls: "bd", content: "Completed" };
  return { cls: "bp", content: status || STATUS_LABELS.notStarted };
}

function getAvailableActions(status, machineBusy) {
  if (status === STATUS_LABELS.terminated || status === STATUS_LABELS.completed)
    return [];

  if (status === STATUS_LABELS.running) {
    return [
      { value: "hold", label: ACTION_META.hold.label },
      { value: "terminate", label: ACTION_META.terminate.label },
    ];
  }

  if (status === STATUS_LABELS.onHold) {
    return [
      {
        value: "resume",
        label: machineBusy
          ? "▶ Resume (Machine busy)"
          : ACTION_META.resume.label,
        disabled: machineBusy,
      },
      { value: "terminate", label: ACTION_META.terminate.label },
    ];
  }

  return [
    {
      value: "start",
      label: machineBusy ? "▶ Start (Machine busy)" : ACTION_META.start.label,
      disabled: machineBusy,
    },
    { value: "terminate", label: ACTION_META.terminate.label },
  ];
}

function mapRowsForBQ(rows) {
  return rows.map((row) => ({
    code: coalesce(
      row?.code,
      row?.itemCode,
      row?.productCode,
      row?.fgCode,
      row?.sku,
      "-",
    ),
    qty: coalesce(row?.qty, row?.qtyPerBox, row?.boxQty, row?.quantity, "-"),
    boxes: coalesce(
      row?.boxes,
      row?.totalBoxes,
      row?.boxCount,
      row?.plannedBoxes,
      "-",
    ),
    packer: coalesce(
      row?.packer,
      row?.packerCode,
      row?.packerId,
      row?.operator,
      "-",
    ),
  }));
}
function ModalBackdrop({ children, onClose }) {
  return (
    <div className="modal-bg on" onClick={onClose}>
      {children}
    </div>
  );
}

export default function TechnicianScreen() {
  const { user, machine } = useAuth();
  const { showToast } = useApp();
  const { time } = useClock();
  const elapsed = useElapsed();

  const [wos, setWos] = useState([]);
  const [bqRef, setBqRef] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadingBQ, setLoadingBQ] = useState(false);
  const [confirm, setConfirm] = useState(null);
  const [savingActionId, setSavingActionId] = useState(null);
  const [savingPriorityId, setSavingPriorityId] = useState(null);
  const [sequenceMode, setSequenceMode] = useState(false);
  const [sequenceRows, setSequenceRows] = useState([]);
  const [savingSequence, setSavingSequence] = useState(false);
  const [locators, setLocators] = useState([]);
  const [locatorModal, setLocatorModal] = useState(null);
  const [selectedLocator, setSelectedLocator] = useState("");
  const [locatorSearch, setLocatorSearch] = useState("");
  const [savingLocatorId, setSavingLocatorId] = useState(null);

  const loadLocators = async () => {
    try {
      const res = await setupService.getLocations({ limit: 100 });

      const rows = normalizeApiList(res);

      setLocators(rows);
    } catch (error) {
      console.error("Failed to load locators:", error);
      setLocators([]);
      showToast("Failed to load locators from backend", "error");
    }
  };

  const startTime = useRef(
    new Date().toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
    }),
  );

  const loadWOs = async () => {
    setLoading(true);

    try {
      const res = await productionService.getWorkOrders({ limit: 100 });
      setWos(normalizeApiList(res));
    } catch (error) {
      console.error("Failed to load work orders:", error);
      setWos([]);
      showToast(
        error?.message || "Failed to load work orders from API",
        "error",
      );
    } finally {
      setLoading(false);
    }
  };

  const loadBQRef = async () => {
    setLoadingBQ(true);

    try {
      const res = await setupService.getBoxQtyReport?.({ limit: 100 });
      setBqRef(normalizeApiList(res));
    } catch (error) {
      console.error("Failed to load box quantity reference:", error);
      setBqRef([]);
    } finally {
      setLoadingBQ(false);
    }
  };

  useEffect(() => {
    loadWOs();
    loadBQRef();
    loadLocators();
  }, []);

  const sortedWOs = useMemo(() => {
    return [...wos].sort((a, b) => {
      const seqA = getSequenceRank(a, 0);
      const seqB = getSequenceRank(b, 0);
      const prioA = getPriorityRank(a);
      const prioB = getPriorityRank(b);

      if (seqA !== seqB) return seqA - seqB;
      if (prioA !== prioB) return prioA - prioB;
      return String(getWONumber(a)).localeCompare(String(getWONumber(b)));
    });
  }, [wos]);

  const visibleRows = sequenceMode ? sequenceRows : sortedWOs;

  const runningWO = useMemo(() => {
    return wos.find((wo) => getWOStatus(wo) === STATUS_LABELS.running);
  }, [wos]);

  const machineDisplayStatus = useMemo(() => {
    if (runningWO) return STATUS_LABELS.running;
    if (wos.some((wo) => getWOStatus(wo) === STATUS_LABELS.onHold))
      return STATUS_LABELS.onHold;
    return machine?.status || STATUS_LABELS.running;
  }, [machine?.status, runningWO, wos]);

  const mcStatusOk = ["running", "active"].includes(
    String(machineDisplayStatus).toLowerCase(),
  );
  const mcStatusHold = String(machineDisplayStatus).toLowerCase() === "on hold";
  const mcStatusColor = mcStatusOk
    ? "var(--grn)"
    : mcStatusHold
      ? "var(--amb)"
      : "var(--red)";
  const mcStatusBg = mcStatusOk
    ? "var(--grn2)"
    : mcStatusHold
      ? "var(--amb2)"
      : "var(--red2)";

  const completedWOs = wos.filter((w) => {
    const status = getWOStatus(w);
    return (
      status === STATUS_LABELS.terminated ||
      status === STATUS_LABELS.completed ||
      getWOCompletedQty(w) >= getWOQty(w)
    );
  }).length;

  const boxesTotal = wos.reduce((s, w) => s + getWOBoxes(w), 0);
  const boxesPrinted = wos.reduce((s, w) => s + getWOBoxesPrinted(w), 0);
  const totalProduced = wos.reduce((s, w) => s + getWOCompletedQty(w), 0);
  const totalPlanned = wos.reduce((s, w) => s + getWOQty(w), 0);
  const remaining = Math.max(0, totalPlanned - totalProduced);
  const prodPct =
    totalPlanned > 0
      ? Math.min(100, Math.round((totalProduced * 100) / totalPlanned))
      : 0;

  const bqRows = mapRowsForBQ(bqRef);
  const bqLeft =
    bqRows.length > 0
      ? bqRows.slice(0, Math.ceil(bqRows.length / 2))
      : EMPTY_BOX_QTY_LEFT;
  const bqRight =
    bqRows.length > 0
      ? bqRows.slice(Math.ceil(bqRows.length / 2))
      : EMPTY_BOX_QTY_RIGHT;

  const initials = (user?.fullName || user?.name || "SH")
    .split(" ")
    .map((w) => w[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  const openActionConfirm = (wo, action) => {
    const meta = ACTION_META[action];
    if (!meta) return;

    const currentKey = getWOKey(wo);
    const machineBusy = Boolean(
      runningWO && getWOKey(runningWO) !== currentKey,
    );

    if ((action === "start" || action === "resume") && machineBusy) {
      showToast(
        "Cannot start — machine already has a running WO. Hold or terminate it first.",
        "warning",
      );
      return;
    }

    setConfirm({ wo, action });
  };

  const applyWOUpdateLocally = (wo, patch) => {
    const key = getWOKey(wo);
    setWos((prev) =>
      prev.map((item) => {
        if (getWOKey(item) !== key) return item;
        return { ...item, ...patch };
      }),
    );
  };

  const callUpdateWorkOrder = async (wo, payload) => {
    const key = getWOKey(wo);
    if (!key) throw new Error("Database ID is missing for this work order");
    if (!productionService.updateWorkOrder)
      throw new Error("productionService.updateWorkOrder is not available");
    return productionService.updateWorkOrder(key, payload);
  };

  const handleAction = async (wo, action) => {
    const meta = ACTION_META[action];
    if (!meta) {
      showToast("Invalid work order action", "error");
      setConfirm(null);
      return;
    }

    const key = getWOKey(wo);
    if (!key) {
      showToast(
        "Cannot update work order because database ID is missing",
        "error",
      );
      setConfirm(null);
      return;
    }

    setSavingActionId(key);

    try {
      const apiStatus = STATUS_TO_API[action];
      const res = await callUpdateWorkOrder(wo, { status: apiStatus });
      const updatedWO = normalizeApiObject(res);
      const localPatch = {
        ...(updatedWO || {}),
        status: updatedWO?.status || apiStatus,
        woStatus: updatedWO?.woStatus || meta.nextStatus,
      };

      applyWOUpdateLocally(wo, localPatch);
      showToast(
        `WO ${getWONumber(wo)} ${action === "start" ? "started" : action === "hold" ? "held" : action === "resume" ? "resumed" : "terminated"}`,
        "success",
      );
      await loadWOs();
    } catch (error) {
      console.error("Failed to update work order:", error);
      showToast(
        error?.message || "Failed to update work order in database",
        "error",
      );
    } finally {
      setSavingActionId(null);
      setConfirm(null);
    }
  };

  const handlePriorityChange = async (wo, nextRankRaw) => {
    const key = getWOKey(wo);
    if (!key) {
      showToast(
        "Cannot update priority because database ID is missing",
        "error",
      );
      return;
    }

    const nextRank = Number(nextRankRaw) || 3;
    const legacyPriority = RANK_TO_LEGACY_PRIORITY[nextRank] || "normal";
    setSavingPriorityId(key);

    try {
      let res;

      try {
        res = await callUpdateWorkOrder(wo, { priority: nextRank });
      } catch (error) {
        // Compatibility fallback for older APIs that used string priorities.
        res = await callUpdateWorkOrder(wo, { priority: legacyPriority });
      }

      const updatedWO = normalizeApiObject(res);
      applyWOUpdateLocally(wo, {
        ...(updatedWO || {}),
        priority: updatedWO?.priority ?? nextRank,
      });

      showToast(`Priority updated for ${getWONumber(wo)}`, "success");
      await loadWOs();
    } catch (error) {
      console.error("Failed to update priority:", error);
      showToast(
        error?.message || "Failed to update priority in database",
        "error",
      );
      await loadWOs();
    } finally {
      setSavingPriorityId(null);
    }
  };

  const toggleSequenceMode = () => {
    if (sequenceMode) {
      setSequenceMode(false);
      setSequenceRows([]);
      return;
    }

    setSequenceRows(sortedWOs);
    setSequenceMode(true);
  };

  const moveSequenceRow = (index, delta) => {
    setSequenceRows((prev) => {
      const nextIndex = index + delta;
      if (nextIndex < 0 || nextIndex >= prev.length) return prev;
      const next = [...prev];
      const [row] = next.splice(index, 1);
      next.splice(nextIndex, 0, row);
      return next;
    });
  };

  const saveSequence = async () => {
    setSavingSequence(true);

    try {
      const payload = sequenceRows.map((wo, index) => ({
        id: getWOKey(wo),
        woNumber: getWONumber(wo),
        executionSequence: index + 1,
      }));

      if (productionService.updateWorkOrderSequence) {
        await productionService.updateWorkOrderSequence(payload);
      } else if (productionService.reorderWorkOrders) {
        await productionService.reorderWorkOrders(payload);
      } else {
        await Promise.all(
          payload.map((item) =>
            productionService.updateWorkOrder(item.id, {
              executionSequence: item.executionSequence,
            }),
          ),
        );
      }

      showToast("Execution sequence saved", "success");
      setSequenceMode(false);
      setSequenceRows([]);
      await loadWOs();
    } catch (error) {
      console.error("Failed to save execution sequence:", error);
      showToast(error?.message || "Failed to save execution sequence", "error");
    } finally {
      setSavingSequence(false);
    }
  };

  const openLocatorModal = (wo) => {
    setLocatorModal(wo);
    setSelectedLocator(getWOLocator(wo));
  };

  const closeLocatorModal = () => {
    if (savingLocatorId) return;
    setLocatorModal(null);
    setSelectedLocator("");
  };

  const confirmSetLocator = async () => {
    const key = getWOKey(locatorModal);

    if (!key) {
      showToast("Cannot set locator because work order ID is missing", "error");
      return;
    }

    if (!selectedLocator) {
      showToast("Please select or enter locator", "warning");
      return;
    }

    setSavingLocatorId(key);

    try {
      const payload = {
        locatorCode: selectedLocator,
        locator: selectedLocator,
        stockLocator: selectedLocator,
      };

      const res = await callUpdateWorkOrder(locatorModal, payload);
      const updatedWO = normalizeApiObject(res);

      applyWOUpdateLocally(locatorModal, {
        ...(updatedWO || {}),
        ...payload,
      });

      showToast(`Locator set for ${getWONumber(locatorModal)}`, "success");

      setLocatorModal(null);
      setSelectedLocator("");
      await loadWOs();
    } catch (error) {
      console.error("Failed to set locator:", error);
      showToast(error?.message || "Failed to set locator in database", "error");
    } finally {
      setSavingLocatorId(null);
    }
  };

  const locatorOptions = useMemo(() => {
    const search = locatorSearch.trim().toLowerCase();

    if (!search) return locators;

    return locators.filter((locator) => {
      const code = getLocatorValue(locator).toLowerCase();
      const label = getLocatorLabel(locator).toLowerCase();
      const area = String(
        locator?.area ||
          locator?.plant ||
          locator?.type ||
          locator?.description ||
          "",
      ).toLowerCase();

      return (
        code.includes(search) || label.includes(search) || area.includes(search)
      );
    });
  }, [locators, locatorSearch]);

  return (
    <div className="content">
      <div className="strip" style={{ flexWrap: "wrap", gap: "10px" }}>
        <div
          className="av"
          style={{
            background: "var(--grn2)",
            borderColor: "var(--grn)",
            color: "var(--grn)",
          }}
        >
          {initials}
        </div>

        <div style={{ flex: 1, minWidth: "200px" }}>
          <div className="oname">
            {(
              user?.fullName ||
              user?.name ||
              "Process Technician"
            ).toUpperCase()}
          </div>

          <div
            className="ometa"
            style={{
              display: "flex",
              alignItems: "center",
              gap: "10px",
              flexWrap: "wrap",
              marginTop: "4px",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: "5px" }}>
              Machine:
              <div className="mtag" style={{ marginLeft: "4px" }}>
                <div className="mdot" />
                <span>
                  {machine?.name || machine?.code || "ZFP001 – INJECTION"}
                </span>
              </div>
            </div>

            <span style={{ color: "var(--bor2)" }}>·</span>

            <div style={{ display: "flex", alignItems: "center", gap: "5px" }}>
              Status:
              <div
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: "5px",
                  background: mcStatusBg,
                  border: `1px solid ${mcStatusColor}`,
                  borderRadius: "20px",
                  padding: "3px 10px",
                  fontSize: "11px",
                  fontWeight: 600,
                  color: mcStatusColor,
                  marginLeft: "4px",
                }}
              >
                <div className="cdot" style={{ background: mcStatusColor }} />
                {machineDisplayStatus}
              </div>
            </div>

            <span style={{ color: "var(--bor2)" }}>·</span>

            <div
              style={{
                fontSize: "11px",
                color: "var(--tx3)",
                display: "flex",
                alignItems: "center",
                gap: "4px",
              }}
            >
              Start:
              <b style={{ color: "var(--tx)", marginLeft: "2px" }}>
                {startTime.current}
              </b>
            </div>

            <span style={{ color: "var(--bor2)" }}>·</span>

            <div
              style={{
                fontSize: "11px",
                color: "var(--tx3)",
                display: "flex",
                alignItems: "center",
                gap: "4px",
              }}
            >
              Elapsed:
              <b
                style={{
                  color: "var(--tx)",
                  marginLeft: "2px",
                  fontFamily: "'Space Mono', monospace",
                }}
              >
                {elapsed}
              </b>
            </div>

            <span style={{ color: "var(--bor2)" }}>·</span>

            <div style={{ fontSize: "11px", color: "var(--tx3)" }}>
              FPP BU ·{" "}
              <span style={{ fontFamily: "'Space Mono', monospace" }}>
                {time}
              </span>
            </div>
          </div>
        </div>

        <div
          className="cstatus"
          style={{
            background: "var(--grn2)",
            borderColor: "var(--grn)",
            color: "var(--grn)",
          }}
        >
          <div className="cdot" style={{ background: "var(--grn)" }} />
          Checked In
        </div>
      </div>

      <div className="g4">
        <div className="sc" style={{ "--sa": "var(--blu)" }}>
          <div className="slbl">Work Orders</div>
          <div className="sval" style={{ color: "var(--blu)" }}>
            {wos.length}
          </div>
          <div className="ssub">Current Shift</div>
          <div
            className="sbdg"
            style={{
              background: "var(--blu2)",
              color: "var(--blu)",
              borderColor: "var(--blu)",
            }}
          >
            {completedWOs} Completed
          </div>
        </div>

        <div className="sc" style={{ "--sa": "var(--amb)" }}>
          <div className="slbl">Boxes Printed</div>
          <div className="sval" style={{ color: "var(--amb)" }}>
            {boxesPrinted}
          </div>
          <div className="ssub">Across all WOs</div>
          <div
            className="sbdg"
            style={{
              background: "var(--amb2)",
              color: "var(--amb)",
              borderColor: "var(--amb)",
            }}
          >
            of {boxesTotal} total
          </div>
        </div>

        <div className="sc" style={{ "--sa": "var(--grn)" }}>
          <div className="slbl">Total Produced Qty</div>
          <div className="sval" style={{ color: "var(--grn)" }}>
            {totalProduced.toLocaleString()}
          </div>
          <div className="ssub">Units completed this shift</div>
          <div className="pbar">
            <div
              className="pfil"
              style={{ width: `${prodPct}%`, background: "var(--grn)" }}
            />
          </div>
        </div>

        <div className="sc" style={{ "--sa": "var(--red)" }}>
          <div className="slbl">Remaining Qty</div>
          <div className="sval" style={{ color: "var(--red)" }}>
            {remaining.toLocaleString()}
          </div>
          <div className="ssub">Units still to produce</div>
          <div
            className="sbdg"
            style={{
              background: "var(--red2)",
              color: "var(--red)",
              borderColor: "var(--red)",
            }}
          >
            {prodPct}% done
          </div>
        </div>
      </div>

      <div className="sh">
        <div className="st">
          <div className="sd" style={{ background: "var(--grn)" }} />
          Assigned Work Order Operations
        </div>

        <div
          style={{
            display: "flex",
            gap: "8px",
            flexWrap: "wrap",
            justifyContent: "flex-end",
          }}
        >
          <button
            className="btn bgh bsm"
            onClick={loadWOs}
            disabled={loading || savingSequence}
            type="button"
          >
            {loading ? "Refreshing..." : "Refresh"}
          </button>

          {sequenceMode && (
            <>
              <button
                className="btn bpri bsm"
                onClick={saveSequence}
                disabled={savingSequence}
                type="button"
              >
                {savingSequence ? "Saving..." : "Save Sequence"}
              </button>
              <button
                className="btn bgh bsm"
                onClick={toggleSequenceMode}
                disabled={savingSequence}
                type="button"
              >
                Cancel
              </button>
            </>
          )}

          {!sequenceMode && (
            <button
              className="btn bgh bsm"
              type="button"
              onClick={toggleSequenceMode}
              disabled={loading || wos.length < 2}
            >
              Set Execution Sequence
            </button>
          )}
        </div>
      </div>

      <div className="twrap" id="wo-table-wrap">
        <div className="tscroll">
          <table>
            <thead>
              <tr>
                <th>Work Order</th>
                <th>Product</th>
                <th>Item Code</th>
                <th>Qty / Completed / Remaining</th>
                <th>Boxes Printed</th>
                <th>Priority</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>

            <tbody>
              {loading && (
                <tr>
                  <td
                    colSpan={8}
                    style={{
                      textAlign: "center",
                      padding: "32px 14px",
                      color: "var(--tx3)",
                    }}
                  >
                    Loading work orders from API...
                  </td>
                </tr>
              )}

              {!loading && visibleRows.length === 0 && (
                <tr>
                  <td
                    colSpan={8}
                    style={{
                      textAlign: "center",
                      padding: "32px 14px",
                      color: "var(--tx3)",
                    }}
                  >
                    No work orders found from API.
                  </td>
                </tr>
              )}

              {!loading &&
                visibleRows.map((wo, index) => {
                  const key = getWOKey(wo) || `${getWONumber(wo)}-${index}`;
                  const status = getWOStatus(wo);
                  const totalQty = getWOQty(wo);
                  const compQty = getWOCompletedQty(wo);
                  const remQty = Math.max(0, totalQty - compQty);
                  const compPct =
                    totalQty > 0 ? Math.round((compQty / totalQty) * 100) : 0;
                  const boxTotal = getWOBoxes(wo);
                  const boxPrinted = getWOBoxesPrinted(wo);
                  const boxPct =
                    boxTotal > 0
                      ? Math.round((boxPrinted / boxTotal) * 100)
                      : 0;
                  const priorityRank = getPriorityRank(wo);
                  const priority =
                    PRIORITY_OPTS.find((p) => p.rank === priorityRank) ||
                    PRIORITY_OPTS[2];
                  const statusBadge = getStatusBadge(status);
                  const machineBusy = Boolean(
                    runningWO && getWOKey(runningWO) !== getWOKey(wo),
                  );
                  const actions = getAvailableActions(status, machineBusy);
                  const rowDisabled = status === STATUS_LABELS.terminated;

                  return (
                    <tr key={key} style={{ opacity: rowDisabled ? 0.45 : 1 }}>
                      <td>
                        <div className="woid">{getWONumber(wo)}</div>
                        <div
                          style={{
                            fontSize: "10px",
                            color: "var(--tx3)",
                            marginTop: "1px",
                            textTransform: "uppercase",
                            letterSpacing: ".6px",
                          }}
                        >
                          {getWOOperation(wo)}
                        </div>

                        {sequenceMode && (
                          <div
                            style={{
                              display: "flex",
                              gap: "4px",
                              marginTop: "8px",
                              alignItems: "center",
                            }}
                          >
                            <span className="bdg bpa">SEQ {index + 1}</span>
                            <button
                              className="btn bgh bsm"
                              type="button"
                              onClick={() => moveSequenceRow(index, -1)}
                              disabled={index === 0 || savingSequence}
                            >
                              ↑
                            </button>
                            <button
                              className="btn bgh bsm"
                              type="button"
                              onClick={() => moveSequenceRow(index, 1)}
                              disabled={
                                index === visibleRows.length - 1 ||
                                savingSequence
                              }
                            >
                              ↓
                            </button>
                          </div>
                        )}
                      </td>

                      <td>
                        <div className="pnm">{getWOProduct(wo)}</div>
                        <div className="psb">
                          {String(getWOSubtitle(wo)).slice(0, 55)}
                        </div>
                      </td>

                      <td>
                        <span
                          style={{
                            fontFamily: "'Space Mono', monospace",
                            fontSize: "11px",
                            color: "var(--grn)",
                            fontWeight: 700,
                          }}
                        >
                          {getWOCode(wo)}
                        </span>
                      </td>

                      <td>
                        <div
                          style={{
                            fontFamily: "'Space Mono', monospace",
                            fontSize: "12px",
                            fontWeight: 700,
                            color: "var(--tx)",
                          }}
                        >
                          {totalQty.toLocaleString()}{" "}
                          <span
                            style={{
                              fontSize: "10px",
                              color: "var(--tx3)",
                              fontFamily: "'DM Sans', sans-serif",
                              fontWeight: 400,
                            }}
                          >
                            total
                          </span>
                        </div>
                        <div
                          style={{
                            fontSize: "11px",
                            color: "var(--grn)",
                            fontWeight: 600,
                            marginTop: "2px",
                          }}
                        >
                          ✓ {compQty.toLocaleString()} done ({compPct}%)
                        </div>
                        <div
                          style={{
                            fontSize: "11px",
                            color: "var(--amb)",
                            fontWeight: 600,
                            marginTop: "1px",
                          }}
                        >
                          → {remQty.toLocaleString()} remaining
                        </div>
                        <div
                          style={{
                            height: "3px",
                            background: "var(--bg3)",
                            borderRadius: "3px",
                            marginTop: "5px",
                            overflow: "hidden",
                          }}
                        >
                          <div
                            style={{
                              height: "100%",
                              width: `${compPct}%`,
                              background: "var(--grn)",
                              borderRadius: "3px",
                              transition: "width .4s",
                            }}
                          />
                        </div>
                      </td>

                      <td>
                        <div
                          style={{
                            fontSize: "12px",
                            fontWeight: 600,
                            color: "var(--tel)",
                          }}
                        >
                          {boxPrinted} / {boxTotal} boxes
                        </div>
                        <div
                          style={{
                            height: "3px",
                            background: "var(--bg3)",
                            borderRadius: "3px",
                            marginTop: "5px",
                            overflow: "hidden",
                          }}
                        >
                          <div
                            style={{
                              height: "100%",
                              width: `${boxPct}%`,
                              background: "var(--tel)",
                              borderRadius: "3px",
                              transition: "width .4s",
                            }}
                          />
                        </div>
                        <div
                          style={{
                            fontSize: "10px",
                            color: "var(--tx3)",
                            marginTop: "3px",
                          }}
                        >
                          {boxPct}% printed
                        </div>
                      </td>

                      <td style={{ minWidth: "130px" }}>
                        <div>
                          <span
                            style={{
                              display: "inline-flex",
                              padding: "2px 10px",
                              borderRadius: "20px",
                              fontSize: "11px",
                              fontWeight: 700,
                              border: "1px solid",
                              ...styleStringToObject(priority.badgeStyle),
                            }}
                          >
                            {priority.label}
                          </span>
                          <select
                            value={String(priorityRank)}
                            disabled={savingPriorityId === key || sequenceMode}
                            onChange={(e) =>
                              handlePriorityChange(wo, e.target.value)
                            }
                            style={{
                              fontSize: "11px",
                              marginTop: "5px",
                              border: "1px solid var(--bor2)",
                              borderRadius: "7px",
                              padding: "4px 8px",
                              background: "var(--bg3)",
                              color: "var(--tx)",
                              fontFamily: "'DM Sans', sans-serif",
                              width: "100%",
                              display: "block",
                            }}
                          >
                            {PRIORITY_OPTS.map((p) => (
                              <option key={p.value} value={p.value}>
                                {p.label}
                              </option>
                            ))}
                          </select>
                        </div>
                      </td>

                      <td>
                        <span className={`bdg ${statusBadge.cls}`}>
                          {statusBadge.content}
                        </span>
                      </td>

                      <td style={{ minWidth: "150px" }}>
                        {actions.length > 0 ? (
                          <select
                            value=""
                            disabled={savingActionId === key || sequenceMode}
                            onChange={(e) => {
                              const action = e.target.value;
                              if (!action) return;
                              openActionConfirm(wo, action);
                            }}
                            style={{
                              fontSize: "12px",
                              border: "1px solid var(--bor2)",
                              borderRadius: "8px",
                              padding: "6px 10px",
                              background: "var(--bg3)",
                              color: "var(--tx)",
                              fontFamily: "'DM Sans', sans-serif",
                              width: "100%",
                              cursor: "pointer",
                            }}
                          >
                            <option value="">— Action —</option>
                            {actions.map((action) => (
                              <option
                                key={action.value}
                                value={action.value}
                                disabled={action.disabled}
                              >
                                {action.label}
                              </option>
                            ))}
                          </select>
                        ) : (
                          <span
                            style={{ fontSize: "11px", color: "var(--tx3)" }}
                          >
                            {status}
                          </span>
                        )}
                        <div
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: "5px",
                            marginTop: "6px",
                          }}
                        >
                          <span
                            style={{
                              fontFamily: "'Space Mono', monospace",
                              fontSize: "9px",
                              color: "#0b8d47",
                              border: "1px solid #8ed1a7",
                              background: "#e8f7ee",
                              borderRadius: "6px",
                              padding: "3px 8px",
                              maxWidth: "100px",
                              overflow: "hidden",
                              textOverflow: "ellipsis",
                              whiteSpace: "nowrap",
                              lineHeight: 1.2,
                              display: "inline-block",
                            }}
                            title={getWOLocator(wo) || "No Locator"}
                          >
                            {getWOLocator(wo) || "SET LOCATOR"}
                          </span>

                          <button
                            type="button"
                            disabled={
                              sequenceMode ||
                              savingLocatorId === key ||
                              rowDisabled
                            }
                            onClick={() => openLocatorModal(wo)}
                            style={{
                              fontSize: "9px",
                              padding: "3px 8px",
                              borderRadius: "6px",
                              border: "1px solid #8ed1a7",
                              background: "#f6fbf8",
                              color: "#0b8d47",
                              cursor: "pointer",
                              fontWeight: 600,
                              lineHeight: 1.2,
                            }}
                          >
                            📍 {savingLocatorId === key ? "..." : "Set"}
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </table>
        </div>
      </div>

      <div className="sh" style={{ marginBottom: "10px" }}>
        <div className="st">
          <div className="sd" style={{ background: "var(--amb)" }} />
          Box Quantity Reference
        </div>

        {loadingBQ && (
          <div style={{ fontSize: "11px", color: "var(--tx3)" }}>
            Loading reference...
          </div>
        )}
      </div>

      <div className="g2">
        <BQRefTable rows={bqLeft} />
        <BQRefTable rows={bqRight} />
      </div>

      {confirm && (
        <ModalBackdrop onClose={() => setConfirm(null)}>
          <div
            // className="modal-bg on"
            onClick={(e) => {
              if (e.target === e.currentTarget) setConfirm(null);
            }}
          >
            <div className="modal confirm-modal">
              <button
                className="mclose"
                onClick={() => setConfirm(null)}
                type="button"
              >
                X
              </button>

              <div className="mtit">
                {ACTION_META[confirm.action]?.title || "Confirm Action"}
              </div>

              <div className="mdesc">
                {ACTION_META[confirm.action]?.message(confirm.wo) ||
                  "Are you sure?"}
              </div>

              <div className="mfooter">
                <button
                  className="btn bgh"
                  onClick={() => setConfirm(null)}
                  type="button"
                >
                  Cancel
                </button>

                <button
                  className="btn"
                  onClick={() => handleAction(confirm.wo, confirm.action)}
                  disabled={savingActionId === getWOKey(confirm.wo)}
                  type="button"
                  style={{
                    background:
                      ACTION_META[confirm.action]?.color || "var(--blu)",
                    borderColor:
                      ACTION_META[confirm.action]?.color || "var(--blu)",
                    color: "#fff",
                  }}
                >
                  {savingActionId === getWOKey(confirm.wo)
                    ? "Applying..."
                    : ACTION_META[confirm.action]?.confirm || "Confirm"}
                </button>
              </div>
            </div>
          </div>
        </ModalBackdrop>
      )}
      {locatorModal && (
        <ModalBackdrop onClose={closeLocatorModal}>
          <div
            onClick={(event) => event.stopPropagation()}
            style={{
              width: "468px",
              maxWidth: "95vw",
              background: "#ffffff",
              border: "1px solid #d7e7dd",
              borderRadius: "18px",
              boxShadow: "0 26px 70px rgba(0,0,0,.24)",
              padding: "20px 22px 18px",
              position: "relative",
              fontFamily: "'DM Sans', sans-serif",
            }}
          >
            {/* Close Button */}
            <button
              type="button"
              onClick={closeLocatorModal}
              disabled={Boolean(savingLocatorId)}
              style={{
                position: "absolute",
                right: "16px",
                top: "14px",
                border: "none",
                background: "transparent",
                color: "#72877b",
                fontSize: "22px",
                cursor: "pointer",
                lineHeight: 1,
              }}
            >
              ×
            </button>

            {/* Header */}
            <div
              style={{
                display: "flex",
                alignItems: "flex-start",
                gap: "10px",
                marginBottom: "11px",
              }}
            >
              <div
                style={{
                  width: "28px",
                  height: "28px",
                  borderRadius: "8px",
                  background: "#008f4c",
                  color: "#ffffff",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: "13px",
                  flexShrink: 0,
                  marginTop: "1px",
                }}
              >
                📍
              </div>

              <div style={{ flex: 1, paddingRight: "24px" }}>
                <div
                  style={{
                    fontSize: "15px",
                    fontWeight: 800,
                    color: "#102418",
                    lineHeight: 1.25,
                    marginBottom: "6px",
                  }}
                >
                  Set Locator for {getWONumber(locatorModal)}
                </div>

                <div
                  style={{
                    fontSize: "11px",
                    color: "#63786d",
                    lineHeight: 1.45,
                  }}
                >
                  Select where produced boxes for this work order will be
                  stored. This locator appears on box labels and in the Stock
                  Register.
                </div>
              </div>
            </div>

            {/* Search */}
            <div style={{ marginBottom: "11px" }}>
              <label
                style={{
                  display: "block",
                  fontSize: "9px",
                  textTransform: "uppercase",
                  letterSpacing: ".8px",
                  color: "#557064",
                  fontWeight: 800,
                  marginBottom: "6px",
                }}
              >
                Filter by Area
              </label>

              <input
                type="text"
                value={locatorSearch}
                onChange={(event) => setLocatorSearch(event.target.value)}
                placeholder="Search area or locator code..."
                style={{
                  width: "100%",
                  height: "39px",
                  border: "1px solid #8ab89f",
                  background: "#f8fcf9",
                  color: "#183428",
                  borderRadius: "8px",
                  padding: "0 12px",
                  fontSize: "12px",
                  outline: "none",
                  boxSizing: "border-box",
                }}
              />
            </div>

            {/* Locator Cards */}
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                gap: "8px",
                maxHeight: "300px",
                overflowY: "auto",
                paddingRight: "4px",
                marginBottom: "12px",
                scrollbarWidth: "thin",
              }}
            >
              {locatorOptions.length === 0 && (
                <div
                  style={{
                    gridColumn: "1 / -1",
                    padding: "22px 12px",
                    textAlign: "center",
                    border: "1px dashed #b8d1c2",
                    borderRadius: "10px",
                    color: "#667b70",
                    fontSize: "12px",
                    background: "#f7fbf8",
                  }}
                >
                  No locators found from backend.
                </div>
              )}

              {locatorOptions.map((locator, index) => {
                const value = getLocatorValue(locator);
                const selected = selectedLocator === value;

                const locatorName =
                  locator?.name ||
                  locator?.machine ||
                  locator?.machineCode ||
                  value;

                const area =
                  locator?.area ||
                  locator?.plant ||
                  locator?.type ||
                  "FPP · PRD";

                const used = locator?.used ?? locator?.usedCount ?? 2;
                const capacity = locator?.capacity ?? locator?.maxCapacity ?? 9;

                return (
                  <button
                    key={value || index}
                    type="button"
                    onClick={() => setSelectedLocator(value)}
                    style={{
                      textAlign: "left",
                      minHeight: "74px",
                      borderRadius: "8px",
                      border: selected
                        ? "1.5px solid #0a9a50"
                        : "1px solid #91b9a2",
                      background: selected ? "#bfebcf" : "#edf6f1",
                      padding: "10px 11px",
                      cursor: "pointer",
                      transition: ".14s ease",
                      color: "#102418",
                    }}
                  >
                    <div
                      style={{
                        fontFamily: "'Space Mono', monospace",
                        fontSize: "11px",
                        fontWeight: 900,
                        color: "#008c48",
                        marginBottom: "5px",
                        lineHeight: 1.1,
                      }}
                    >
                      {value}
                    </div>

                    <div
                      style={{
                        fontSize: "10px",
                        color: "#5e766a",
                        marginBottom: "2px",
                        lineHeight: 1.2,
                      }}
                    >
                      {locatorName}
                    </div>

                    <div
                      style={{
                        fontSize: "10px",
                        color: "#5e766a",
                        lineHeight: 1.2,
                      }}
                    >
                      {area} · Used: {used}/{capacity}
                    </div>

                    {selected && (
                      <div
                        style={{
                          marginTop: "6px",
                          fontSize: "10px",
                          fontWeight: 800,
                          color: "#008c48",
                          lineHeight: 1,
                        }}
                      >
                        ✓ Selected
                      </div>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Divider */}
            <div
              style={{
                borderTop: "1px solid #dbe9e1",
                marginBottom: "14px",
              }}
            />

            {/* Footer */}
            <div
              style={{
                display: "flex",
                justifyContent: "flex-end",
                alignItems: "center",
                gap: "10px",
              }}
            >
              <button
                type="button"
                onClick={closeLocatorModal}
                disabled={Boolean(savingLocatorId)}
                style={{
                  height: "34px",
                  minWidth: "72px",
                  borderRadius: "8px",
                  border: "1px solid #8fb69f",
                  background: "#ffffff",
                  color: "#224333",
                  fontSize: "12px",
                  fontWeight: 600,
                  cursor: "pointer",
                }}
              >
                Cancel
              </button>

              <button
                type="button"
                onClick={confirmSetLocator}
                disabled={Boolean(savingLocatorId) || !selectedLocator}
                style={{
                  height: "34px",
                  minWidth: "112px",
                  borderRadius: "8px",
                  border: "1px solid #008c48",
                  background:
                    Boolean(savingLocatorId) || !selectedLocator
                      ? "#8bbda2"
                      : "#008c48",
                  color: "#ffffff",
                  fontSize: "12px",
                  fontWeight: 800,
                  cursor:
                    Boolean(savingLocatorId) || !selectedLocator
                      ? "not-allowed"
                      : "pointer",
                }}
              >
                📍 {savingLocatorId ? "Saving..." : "Set Locator"}
              </button>
            </div>
          </div>
        </ModalBackdrop>
      )}
    </div>
  );
}

function styleStringToObject(styleString) {
  return String(styleString || "")
    .split(";")
    .filter(Boolean)
    .reduce((acc, declaration) => {
      const [prop, value] = declaration.split(":");
      if (!prop || !value) return acc;
      const camelProp = prop
        .trim()
        .replace(/-([a-z])/g, (_, char) => char.toUpperCase());
      acc[camelProp] = value.trim();
      return acc;
    }, {});
}

function BQRefTable({ rows }) {
  return (
    <div className="twrap" style={{ marginBottom: 0 }}>
      <table>
        <thead>
          <tr>
            <th>Item Code</th>
            <th>Qty / Box</th>
            <th>Total Boxes</th>
            <th>Packer</th>
          </tr>
        </thead>

        <tbody>
          {rows.map((r, i) => (
            <tr key={`${r.code || "row"}-${i}`}>
              <td
                style={{
                  fontFamily: "'Space Mono', monospace",
                  fontSize: "11px",
                  color: "var(--grn)",
                  fontWeight: 700,
                }}
              >
                {r.code || "-"}
              </td>

              <td style={{ fontFamily: "'Space Mono', monospace" }}>
                {Number.isFinite(Number(r.qty))
                  ? formatNumber(r.qty)
                  : r.qty || "-"}
              </td>

              <td>
                <span className="bdg bp">{r.boxes || "-"}</span>
              </td>

              <td style={{ color: "var(--tx2)" }}>{r.packer || "-"}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
function getWOLocator(wo) {
  return coalesce(
    wo?.locatorCode,
    wo?.locator,
    wo?.stockLocator,
    wo?.locatorName,
    wo?.locationCode,
    wo?.location?.code,
    wo?.location?.name,
    "",
  );
}

function getLocatorValue(locator) {
  return String(
    coalesce(
      locator?.code,
      locator?.locatorCode,
      locator?.name,
      locator?.locationCode,
      locator?.id,
      locator?._id,
      "",
    ),
  );
}

function getLocatorLabel(locator) {
  const code = getLocatorValue(locator);
  const name = coalesce(locator?.name, locator?.description, locator?.type, "");

  return name && name !== code ? `${code} - ${name}` : code;
}
