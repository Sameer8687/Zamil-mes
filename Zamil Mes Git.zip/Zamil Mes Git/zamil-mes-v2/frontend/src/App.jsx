import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "./contexts/AuthContext";
import { AppProvider } from "./contexts/AppContext";

import DashboardLayout from "./layouts/DashboardLayout";
import Login from "./pages/auth/Login";
import InstallWizard from "./pages/install/InstallWizard";

// Screens
import ProductionScheduling from "./pages/production/ProductionScheduling";
import TechnicianScreen from "./pages/technician/TechnicianScreen";
import OperatorScreen from "./pages/operator/OperatorScreen";
import QCOverview from "./pages/qc/QCOverview";
import QCDetail from "./pages/qc/QCDetail";
import WasteRecording from "./pages/waste/WasteRecording";
import DowntimeForm from "./pages/downtime/DowntimeForm";
import DowntimeReport from "./pages/downtime/DowntimeReport";
import PackerOverview from "./pages/packer/PackerOverview";
import PalletLabel from "./pages/packer/PalletLabel";
import LineClearance from "./pages/lineclearance/LineClearance";
import LineClearanceReport from "./pages/lineclearance/LineClearanceReport";
import StockRegister from "./pages/stock/StockRegister";
import Setup from "./pages/setup/Setup";
import UserAdmin from "./pages/admin/UserAdmin";

function ProtectedRoute({ children }) {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <div
        className="min-h-screen flex items-center justify-center"
        style={{ background: "var(--bg)" }}
      >
        <div className="flex flex-col items-center gap-3">
          <div className="spinner w-8 h-8" />
          <div className="text-tx3 text-sm">Loading Zamil MES…</div>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return children;
}

function PublicRoute({ children }) {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <div
        className="min-h-screen flex items-center justify-center"
        style={{ background: "var(--bg)" }}
      >
        <div className="flex flex-col items-center gap-3">
          <div className="spinner w-8 h-8" />
          <div className="text-tx3 text-sm">Loading Zamil MES…</div>
        </div>
      </div>
    );
  }

  if (isAuthenticated) {
    return <Navigate to="/app/production" replace />;
  }

  return children;
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/install" element={<InstallWizard />} />

      <Route
        path="/login"
        element={
          <PublicRoute>
            <Login />
          </PublicRoute>
        }
      />

      <Route
        path="/app"
        element={
          <ProtectedRoute>
            <DashboardLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<Navigate to="/app/production" replace />} />

        <Route path="production" element={<ProductionScheduling />} />
        <Route path="technician" element={<TechnicianScreen />} />
        <Route path="operator" element={<OperatorScreen />} />
        <Route path="qc-overview" element={<QCOverview />} />
        <Route path="qc-detail" element={<QCDetail />} />
        <Route path="waste" element={<WasteRecording />} />
        <Route path="downtime" element={<DowntimeForm />} />
        <Route path="downtime-report" element={<DowntimeReport />} />
        <Route path="packer" element={<PackerOverview />} />
        <Route path="pallet" element={<PalletLabel />} />
        <Route path="line-clearance" element={<LineClearance />} />
        <Route path="lc-report" element={<LineClearanceReport />} />
        <Route path="stock" element={<StockRegister />} />
        <Route path="setup" element={<Setup />} />
        <Route path="user-admin" element={<UserAdmin />} />

        <Route path="*" element={<Navigate to="/app/production" replace />} />
      </Route>

      <Route path="/" element={<Navigate to="/app/production" replace />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppProvider>
          <AppRoutes />
        </AppProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}