// ══════════ MODAL ══════════
export function Modal({ open, onClose, title, children, footer, width = 480 }) {
  if (!open) return null
  return (
    <div className="modal-bg" onClick={e => { if (e.target === e.currentTarget) onClose() }}>
      <div className="modal" style={{ width }}>
        <button className="mclose" onClick={onClose}>✕</button>
        {title && <div className="mtit">{title}</div>}
        {children}
        {footer && <div className="mfooter">{footer}</div>}
      </div>
    </div>
  )
}

// ══════════ STAT CARD ══════════
export function StatCard({ label, value, sub, color = 'blu', badge, barPct, children }) {
  return (
    <div className="sc" style={{ '--sa': `var(--${color})` }}>
      <div className="slbl">{label}</div>
      <div className="sval" style={{ color: `var(--${color})` }}>{value}</div>
      {sub && <div className="ssub">{sub}</div>}
      {badge && (
        <div className="sbdg" style={{ background: `var(--${color}2)`, color: `var(--${color})`, borderColor: `var(--${color})` }}>
          {badge}
        </div>
      )}
      {barPct !== undefined && (
        <div className="pbar">
          <div className="pfil" style={{ width: `${barPct}%`, background: `var(--${color})` }} />
        </div>
      )}
      {children}
    </div>
  )
}

// ══════════ BADGE ══════════
export function Badge({ status }) {
  const map = {
    'In Progress': 'bpa', Pending: 'bp', Completed: 'bd',
    Approved: 'bd', Rejected: 'brj', Draft: 'brv',
    running: 'bd', idle: 'bp', breakdown: 'brj', 'High': 'brj', 'Medium': 'bp', 'Low': 'bpa',
  }
  return <span className={`bdg ${map[status] || 'bpa'}`}>{status}</span>
}

// ══════════ SECTION HEADER ══════════
export function SectionHeader({ title, color = 'grn', actions }) {
  return (
    <div className="sh">
      <div className="st"><div className="sd" style={{ background: `var(--${color})` }} />{title}</div>
      {actions && <div style={{ display: 'flex', gap: 8 }}>{actions}</div>}
    </div>
  )
}

// ══════════ EMPTY STATE ══════════
export function EmptyState({ icon = '📭', title = 'No data', sub }) {
  return (
    <div style={{ textAlign: 'center', padding: '40px 20px', color: 'var(--tx3)' }}>
      <div style={{ fontSize: 40, marginBottom: 10 }}>{icon}</div>
      <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--tx)', marginBottom: 6 }}>{title}</div>
      {sub && <div style={{ fontSize: 12 }}>{sub}</div>}
    </div>
  )
}

// ══════════ PROGRESS BAR ══════════
export function ProgressRow({ label, pct, color = 'grn', count, total }) {
  return (
    <div className="pr">
      <div className="prl">{label}</div>
      <div className="prt"><div className="prf" style={{ width: `${pct}%`, background: `var(--${color})` }} /></div>
      <div className="prc" style={{ color: `var(--${color})` }}>{count}/{total}</div>
    </div>
  )
}

// ══════════ CONFIRM BUTTON GROUP ══════════
export function FormFooter({ onSave, onReset, onCancel, saveLabel = '💾 Save', loading }) {
  return (
    <div className="mfooter">
      {onCancel && <button className="btn bgh" onClick={onCancel}>Cancel</button>}
      {onReset  && <button className="btn bgh" onClick={onReset}>Reset</button>}
      <button className="btn bpri" onClick={onSave} disabled={loading}>
        {loading ? 'Saving…' : saveLabel}
      </button>
    </div>
  )
}

// ══════════ LOADING SPINNER ══════════
export function Spinner() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 40 }}>
      <div style={{
        width: 28, height: 28, borderRadius: '50%',
        border: '3px solid var(--bor)',
        borderTopColor: 'var(--blu)',
        animation: 'spin .7s linear infinite',
      }} />
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  )
}
