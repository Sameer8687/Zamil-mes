import { useApp } from '../../contexts/AppContext'
import { useAuth } from '../../contexts/AuthContext'
import useClock from '../../hooks/useClock'

export default function Topbar() {
  const { theme, setTheme } = useApp()
  const { user, machine, logout } = useAuth()
  const { time, date } = useClock()

  const initials = user?.fullName
    ? user.fullName.split(' ').map(w=>w[0]).slice(0,2).join('').toUpperCase()
    : (user?.name?.split(' ').map(w=>w[0]).slice(0,2).join('').toUpperCase() || '??')

  return (
    <div className="topbar">
      <span className="tbl hidden sm:inline">THEME</span>
      <span className="vsep hidden sm:block" />
      <button className={`tbtn tbk ${theme==='black'?'on':''}`} onClick={()=>setTheme('black')}>Black</button>
      <button className={`tbtn tbw ${theme==='white'?'on':''}`} onClick={()=>setTheme('white')}>White</button>
      <button className={`tbtn tbz ${theme==='zamil'?'on':''}`} onClick={()=>setTheme('zamil')}>Zamil</button>

      <div className="user-info">
        <span className="hidden md:inline text-[10px] text-tx3 mono">{date}</span>
        <span className="hidden sm:inline nclock">{time}</span>
        {machine && (
          <span className="hidden lg:inline nshift">{machine.code || machine.name}</span>
        )}
        <div className="uav">{initials}</div>
        <span className="hidden sm:inline text-tx2 text-[12px] font-medium truncate max-w-[120px]">
          {user?.fullName || user?.name}
        </span>
        <button className="ulogout" onClick={logout}>Logout</button>
      </div>
    </div>
  )
}
