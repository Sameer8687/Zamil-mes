import { useState } from "react";
import { NavLink } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import useClock from "../../hooks/useClock";

const NAV_ITEMS = [
  { id: "production", label: " Production", cls: "", roles: ["System Admin"] },
  {
    id: "technician",
    label: "Process Tech",
    cls: "",
    roles: ["System Admin", "tech"],
  },
  {
    id: "operator",
    label: "Operator",
    cls: "op",
    roles: ["System Admin", "tech", "operator"],
  },
  // {
  //   id: "waste",
  //   label: "Waste",
  //   cls: "",
  //   roles: ["System Admin", "tech", "operator", "qc"],
  // },
  // {
  //   id: "qc-overview",
  //   label: "QC Overview",
  //   cls: "qi",
  //   roles: ["System Admin", "tech", "qc"],
  // },
  // {
  //   id: "qc-detail",
  //   label: "QC Detail",
  //   cls: "qi",
  //   roles: ["System Admin", "tech", "qc"],
  // },
  // { id: "packer", label: "Packer", cls: "pk", roles: ["System Admin", "packer"] },
  {
    id: "pallet",
    label: "Pallet + Label",
    cls: "pk",
    roles: ["System Admin", "packer"],
  },
  // {
  //   id: "downtime",
  //   label: "Downtime",
  //   cls: "dt",
  //   roles: ["System Admin", "tech", "operator"],
  // },
  // {
  //   id: "downtime-report",
  //   label: " DT Report",
  //   cls: "dt",
  //   roles: ["System Admin", "tech"],
  // },
  // {
  //   id: "line-clearance",
  //   label: "Line Clearance",
  //   cls: "lc",
  //   roles: ["System Admin", "tech", "qc"],
  // },
  // {
  //   id: "lc-report",
  //   label: "LC Report",
  //   cls: "lc",
  //   roles: ["System Admin", "tech", "qc"],
  // },
  // { id: "stock", label: "Stock", cls: "su", roles: ["System Admin", "tech"] },
  { id: "setup", label: "Setup", cls: "su", roles: ["System Admin", "tech"] },
  // { id: "user-System Admin", label: "User System Admin", cls: "pr", roles: ["System Admin"] },
];

export default function Navbar() {
  const { hasRole } = useAuth();
  const { time, shift } = useClock();
  const [mobileOpen, setMobileOpen] = useState(false);

  const visibleTabs = NAV_ITEMS.filter((n) => hasRole(...n.roles));

  return (
    <>
      <div className="nav flex items-center gap-6 px-4 py-3 border-b" style={{ background: "var(--bg)", borderColor: "var(--bor)" }}>
        {/* Brand */}
        <div className="brand flex-shrink-0">
          <div className="ndot" />
          <span>Zamil Operations</span>
        </div>

        {/* Desktop tabs — scrollable */}
        <div className="ntabs flex-1 hidden md:flex">
          {visibleTabs.map((n) => (
            <NavLink
              key={n.id}
              to={`/app/${n.id}`}
              className={({ isActive }) =>
                `ntab ${n.cls} ${isActive ? "on" : ""}`.trim()
              }
            >
              {n.label}
            </NavLink>
          ))}
        </div>

        {/* Right side */}
        <div className="flex items-center gap-2.5 flex-shrink-0">
          <span className="nclock hidden lg:inline">{time}</span>
          {shift && <span className="nshift hidden xl:inline">{shift}</span>}

          {/* Hamburger for mobile */}
          <button
            type="button"
            className="md:hidden p-1.5 rounded border border-bor2 text-tx2"
            onClick={() => setMobileOpen((o) => !o)}
          >
            <svg
              className="w-4 h-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M4 6h16M4 12h16M4 18h16"
              />
            </svg>
          </button>
        </div>
      </div>

      {/* Mobile menu drawer */}
      {mobileOpen && (
        <div
          className="md:hidden border-b"
          style={{ background: "var(--bg2)", borderColor: "var(--bor)" }}
        >
          <div className="grid grid-cols-2 gap-1 p-2">
            {visibleTabs.map((n) => (
              <NavLink
                key={n.id}
                to={`/app/${n.id}`}
                className={({ isActive }) =>
                  `text-left px-3 py-2.5 rounded-lg text-[11px] font-medium uppercase tracking-[.5px] transition-all ${
                    isActive
                      ? "bg-blu2 border-blu text-blu border"
                      : "text-tx3 hover:bg-bg3 hover:text-tx border border-transparent"
                  }`
                }
                onClick={() => setMobileOpen(false)}
              >
                {n.label}
              </NavLink>
            ))}
          </div>
        </div>
      )}
    </>
  );
}