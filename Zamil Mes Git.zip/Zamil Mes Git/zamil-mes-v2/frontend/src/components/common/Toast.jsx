import { useApp } from '../../contexts/AppContext'

export default function ToastContainer() {
  const { toasts } = useApp()

  if (!toasts.length) return null

  return (
    <div className="toast-container">
      {toasts.map(t => (
        <div
          key={t.id}
          style={{
            background: t.type === 'error' ? 'var(--red)' : t.type === 'warn' ? 'var(--amb)' : 'var(--grn)',
            color: '#fff',
            padding: '10px 18px',
            borderRadius: 10,
            fontSize: 13,
            fontWeight: 600,
            display: 'flex',
            alignItems: 'center',
            gap: 8,
            boxShadow: '0 8px 24px rgba(0,0,0,.18)',
            animation: 'tshow .25s ease',
          }}
        >
          <span style={{ fontSize: 16 }}>
            {t.type === 'error' ? '✕' : t.type === 'warn' ? '⚠' : '✓'}
          </span>
          {t.msg}
        </div>
      ))}
      <style>{`
        @keyframes tshow { from { opacity:0;transform:translateY(10px); } to { opacity:1;transform:translateY(0); } }
      `}</style>
    </div>
  )
}
