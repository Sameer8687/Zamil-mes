// Number formatters
export const fmtNum = (n, decimals = 0) =>
  Number(n).toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });

export const fmtSAR = (n) =>
  `SAR ${fmtNum(n, 2)}`;

export const fmtPct = (n) =>
  `${Number(n).toFixed(1)}%`;

// Date/time formatters
export const fmtDate = (d) => {
  if (!d) return '—';
  const date = new Date(d);
  return date.toLocaleDateString('en-GB', { day:'2-digit', month:'short', year:'numeric' });
};

export const fmtDateTime = (d) => {
  if (!d) return '—';
  return new Date(d).toLocaleString('en-GB');
};

export const fmtTime = (d) => {
  if (!d) return '—';
  return new Date(d).toLocaleTimeString('en-GB', { hour:'2-digit', minute:'2-digit' });
};

// Duration
export const fmtDuration = (seconds) => {
  if (!seconds) return '0s';
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
};

// Box/pallet label helpers
export const boxId = (wo, num) => `${wo}-${String(num).padStart(2,'0')}`;
export const palletId = (year, num) => `PAL-${year}-${String(num).padStart(4,'0')}`;
export const requestNo = (prefix) => `${prefix}-${Date.now().toString().slice(-6)}`;

// Status badge color resolver
export const statusColor = (status) => {
  const map = {
    approved: { bg:'var(--grn2)',border:'var(--grn)',color:'var(--grn)' },
    appr:     { bg:'var(--grn2)',border:'var(--grn)',color:'var(--grn)' },
    rejected: { bg:'var(--red2)',border:'var(--red)',color:'var(--red)' },
    rejt:     { bg:'var(--red2)',border:'var(--red)',color:'var(--red)' },
    pending:  { bg:'var(--amb2)',border:'var(--amb)',color:'var(--amb)' },
    pend:     { bg:'var(--amb2)',border:'var(--amb)',color:'var(--amb)' },
    running:  { bg:'var(--grn2)',border:'var(--grn)',color:'var(--grn)' },
    draft:    { bg:'var(--amb2)',border:'var(--amb)',color:'var(--amb)' },
    submitted:{ bg:'var(--blu2,rgba(59,130,246,.1))',border:'var(--blu)',color:'var(--blu)' },
    active:   { bg:'var(--grn2)',border:'var(--grn)',color:'var(--grn)' },
    inactive: { bg:'var(--red2)',border:'var(--red)',color:'var(--red)' },
  };
  return map[status?.toLowerCase()] || { bg:'var(--bg3)',border:'var(--bor2)',color:'var(--tx3)' };
};

// Role display
export const roleLabel = (role) => ({
  admin:      'Administrator',
  technician: 'Process Tech',
  operator:   'Operator',
  qc:         'QC Inspector',
  packer:     'Packer',
}[role] || role);

// String utilities
export const capitalize = (s) => s ? s.charAt(0).toUpperCase() + s.slice(1) : '';
export const truncate = (s, max = 40) => s?.length > max ? s.slice(0, max) + '…' : s || '';
export const initials = (name) => name?.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase() || '??';

// CSV export helper
export function exportCSV(rows, filename = 'export.csv') {
  if (!rows?.length) return;
  const keys = Object.keys(rows[0]);
  const csv  = [keys.join(','), ...rows.map(r => keys.map(k => JSON.stringify(r[k] ?? '')).join(','))].join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const url  = URL.createObjectURL(blob);
  const a    = Object.assign(document.createElement('a'), { href: url, download: filename });
  a.click();
  URL.revokeObjectURL(url);
}
